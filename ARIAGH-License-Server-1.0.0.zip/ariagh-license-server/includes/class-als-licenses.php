<?php
/**
 * License & activation model.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ALS_Licenses {

	const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

	/* ============================ Helpers ============================ */

	public static function now() {
		return current_time( 'mysql', true );
	}

	public static function generate_key() {
		global $wpdb;
		do {
			$groups = array();
			for ( $g = 0; $g < 4; $g++ ) {
				$s = '';
				for ( $i = 0; $i < 4; $i++ ) {
					$s .= self::ALPHABET[ random_int( 0, strlen( self::ALPHABET ) - 1 ) ];
				}
				$groups[] = $s;
			}
			$key = 'AIW-' . implode( '-', $groups );
			$ex  = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . ALS_DB::t( 'licenses' ) . ' WHERE license_key = %s', $key ) ); // phpcs:ignore
		} while ( $ex );
		return $key;
	}

	public static function sanitize_key( $key ) {
		return strtoupper( preg_replace( '/[^A-Za-z0-9\-]/', '', (string) $key ) );
	}

	public static function normalize_domain( $url ) {
		$url  = trim( (string) $url );
		$host = wp_parse_url( false === strpos( $url, '://' ) ? 'http://' . $url : $url, PHP_URL_HOST );
		$host = strtolower( (string) $host );
		$host = preg_replace( '/^www\./', '', $host );
		return rtrim( $host, '.' );
	}

	/** Local / staging domains do not consume a site slot. */
	public static function is_dev_domain( $domain ) {
		if ( ! $domain ) {
			return false;
		}
		if ( 'localhost' === $domain || false === strpos( $domain, '.' ) ) {
			return true;
		}
		if ( preg_match( '/\.(local|localhost|test|example|invalid|lan|internal)$/', $domain ) ) {
			return true;
		}
		if ( preg_match( '/^(staging|stage|dev|test|demo|sandbox)[\.\-]/', $domain ) ) {
			return true;
		}
		if ( preg_match( '/\.(instawp\.xyz|tastewp\.com|wpengine\.com|kinsta\.cloud|flywheelstaging\.com|cloudwaysapps\.com|wpcomstaging\.com|pantheonsite\.io|ngrok\.io|ngrok-free\.app|trycloudflare\.com)$/', $domain ) ) {
			return true;
		}
		if ( filter_var( $domain, FILTER_VALIDATE_IP ) ) {
			return ! filter_var( $domain, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
		}
		return false;
	}

	public static function ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return substr( $ip, 0, 64 );
	}

	public static function log( $license_id, $type, $message ) {
		global $wpdb;
		$wpdb->insert( // phpcs:ignore
			ALS_DB::t( 'events' ),
			array(
				'license_id' => (int) $license_id,
				'type'       => substr( $type, 0, 40 ),
				'message'    => $message,
				'ip'         => self::ip(),
				'created_at' => self::now(),
			)
		);
	}

	/* ============================ CRUD ============================ */

	public static function create( array $a ) {
		global $wpdb;
		$months = isset( $a['months'] ) ? (int) $a['months'] : 0;
		$row    = array(
			'license_key'    => ! empty( $a['license_key'] ) ? self::sanitize_key( $a['license_key'] ) : self::generate_key(),
			'product'        => ALS_PRODUCT,
			'plan'           => sanitize_text_field( $a['plan'] ?? 'استاندارد' ),
			'sites'          => max( 0, (int) ( $a['sites'] ?? 1 ) ),
			'status'         => 'active',
			'expires_at'     => isset( $a['expires_at'] ) ? (int) $a['expires_at'] : ( $months > 0 ? strtotime( '+' . $months . ' months' ) : 0 ),
			'customer_email' => sanitize_email( $a['customer_email'] ?? '' ),
			'customer_name'  => sanitize_text_field( $a['customer_name'] ?? '' ),
			'user_id'        => (int) ( $a['user_id'] ?? 0 ),
			'order_id'       => (int) ( $a['order_id'] ?? 0 ),
			'product_id'     => (int) ( $a['product_id'] ?? 0 ),
			'notes'          => sanitize_textarea_field( $a['notes'] ?? '' ),
			'created_at'     => self::now(),
			'updated_at'     => self::now(),
		);
		if ( ! $row['user_id'] && $row['customer_email'] ) {
			$u = get_user_by( 'email', $row['customer_email'] );
			if ( $u ) {
				$row['user_id'] = $u->ID;
			}
		}
		$ok = $wpdb->insert( ALS_DB::t( 'licenses' ), $row ); // phpcs:ignore
		if ( ! $ok ) {
			return new WP_Error( 'als', 'ثبت لایسنس ناموفق بود: ' . $wpdb->last_error );
		}
		$id = (int) $wpdb->insert_id;
		self::log( $id, 'created', 'لایسنس صادر شد' . ( $row['order_id'] ? ' (سفارش #' . $row['order_id'] . ')' : '' ) );
		do_action( 'als_license_created', $id, $row );
		return $id;
	}

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ALS_DB::t( 'licenses' ) . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
	}

	public static function find( $key ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ALS_DB::t( 'licenses' ) . ' WHERE license_key = %s', self::sanitize_key( $key ) ), ARRAY_A ); // phpcs:ignore
	}

	public static function update( $id, array $data ) {
		global $wpdb;
		$allowed = array( 'plan', 'sites', 'status', 'expires_at', 'customer_email', 'customer_name', 'user_id', 'notes' );
		$data    = array_intersect_key( $data, array_flip( $allowed ) );
		if ( ! $data ) {
			return false;
		}
		$data['updated_at'] = self::now();
		return false !== $wpdb->update( ALS_DB::t( 'licenses' ), $data, array( 'id' => (int) $id ) ); // phpcs:ignore
	}

	public static function delete( $id ) {
		global $wpdb;
		$wpdb->delete( ALS_DB::t( 'activations' ), array( 'license_id' => (int) $id ) ); // phpcs:ignore
		$wpdb->delete( ALS_DB::t( 'licenses' ), array( 'id' => (int) $id ) ); // phpcs:ignore
	}

	public static function extend( $id, $months ) {
		$l = self::get( $id );
		if ( ! $l || $months <= 0 ) {
			return false;
		}
		$base = max( time(), (int) $l['expires_at'] );
		$new  = strtotime( '+' . (int) $months . ' months', $base );
		self::update( $id, array( 'expires_at' => $new, 'status' => 'active' ) );
		self::log( $id, 'renewed', 'تمدید تا ' . wp_date( 'Y/m/d', $new ) );
		return $new;
	}

	public static function query( array $args = array() ) {
		global $wpdb;
		$t      = ALS_DB::t( 'licenses' );
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where[]  = '(license_key LIKE %s OR customer_email LIKE %s OR customer_name LIKE %s OR order_id = %d)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = (int) $args['search'];
		}
		if ( ! empty( $args['status'] ) ) {
			if ( 'expired' === $args['status'] ) {
				$where[]  = '(expires_at > 0 AND expires_at < %d)';
				$params[] = time();
			} else {
				$where[]  = 'status = %s';
				$params[] = $args['status'];
			}
		}
		if ( ! empty( $args['user_id'] ) || ! empty( $args['email'] ) ) {
			$where[]  = '(user_id = %d OR customer_email = %s)';
			$params[] = (int) ( $args['user_id'] ?? 0 );
			$params[] = (string) ( $args['email'] ?? '-' );
		}
		$per    = isset( $args['per_page'] ) ? max( 1, (int) $args['per_page'] ) : 20;
		$page   = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;
		$sql_w  = implode( ' AND ', $where );
		$total  = (int) $wpdb->get_var( $params ? $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE $sql_w", $params ) : "SELECT COUNT(*) FROM $t WHERE $sql_w" ); // phpcs:ignore
		$qp     = array_merge( $params, array( $per, ( $page - 1 ) * $per ) );
		$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT l.*, (SELECT COUNT(*) FROM " . ALS_DB::t( 'activations' ) . " a WHERE a.license_id = l.id AND a.is_dev = 0) AS used FROM $t l WHERE $sql_w ORDER BY l.id DESC LIMIT %d OFFSET %d", $qp ), ARRAY_A ); // phpcs:ignore
		return array( 'rows' => $rows ? $rows : array(), 'total' => $total, 'pages' => (int) ceil( $total / $per ) );
	}

	public static function stats() {
		global $wpdb;
		$l = ALS_DB::t( 'licenses' );
		$a = ALS_DB::t( 'activations' );
		return array(
			'total'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $l" ), // phpcs:ignore
			'active'   => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $l WHERE status = 'active' AND (expires_at = 0 OR expires_at > %d)", time() ) ), // phpcs:ignore
			'sites'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $a WHERE is_dev = 0" ), // phpcs:ignore
			'expiring' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $l WHERE status = 'active' AND expires_at > %d AND expires_at < %d", time(), time() + 30 * DAY_IN_SECONDS ) ), // phpcs:ignore
			'month'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $l WHERE created_at >= %s", gmdate( 'Y-m-01 00:00:00' ) ) ), // phpcs:ignore
		);
	}

	/* ============================ Activations ============================ */

	public static function activations( $license_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ALS_DB::t( 'activations' ) . ' WHERE license_id = %d ORDER BY is_dev ASC, id ASC', $license_id ), ARRAY_A ); // phpcs:ignore
	}

	public static function activation( $license_id, $domain ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ALS_DB::t( 'activations' ) . ' WHERE license_id = %d AND domain = %s', $license_id, $domain ), ARRAY_A ); // phpcs:ignore
	}

	public static function used_sites( $license_id ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ALS_DB::t( 'activations' ) . ' WHERE license_id = %d AND is_dev = 0', $license_id ) ); // phpcs:ignore
	}

	public static function remove_activation( $license_id, $domain ) {
		global $wpdb;
		$n = $wpdb->delete( ALS_DB::t( 'activations' ), array( 'license_id' => (int) $license_id, 'domain' => $domain ) ); // phpcs:ignore
		if ( $n ) {
			self::log( $license_id, 'deactivated', 'آزادسازی دامنه ' . $domain );
		}
		return (bool) $n;
	}

	/** Why a license cannot be used right now ('' when usable). */
	public static function problem( $l ) {
		if ( ! $l ) {
			return array( 'invalid', 'کلید لایسنس معتبر نیست.' );
		}
		if ( ALS_PRODUCT !== $l['product'] ) {
			return array( 'product', 'این کلید برای محصول دیگری است.' );
		}
		if ( 'active' !== $l['status'] ) {
			return array( 'revoked', 'این لایسنس غیرفعال یا باطل شده است. با پشتیبانی تماس بگیرید.' );
		}
		if ( (int) $l['expires_at'] > 0 && time() > (int) $l['expires_at'] ) {
			return array( 'expired', 'اعتبار این لایسنس در ' . wp_date( 'Y/m/d', (int) $l['expires_at'] ) . ' تمام شده است. از حساب کاربری فروشگاه تمدید کنید.' );
		}
		return array( '', '' );
	}

	/**
	 * Activate (or refresh) a domain.
	 *
	 * @return array|WP_Error Activation row.
	 */
	public static function activate( array $l, $domain, array $meta = array() ) {
		global $wpdb;
		list( $code, $msg ) = self::problem( $l );
		if ( $code ) {
			return new WP_Error( $code, $msg );
		}
		if ( ! $domain ) {
			return new WP_Error( 'domain', 'دامنه سایت مشخص نیست.' );
		}
		$is_dev = ALS_Settings::get( 'dev_free' ) && self::is_dev_domain( $domain ) ? 1 : 0;
		$row    = self::activation( $l['id'], $domain );
		$data   = array(
			'site_url'   => esc_url_raw( $meta['site_url'] ?? '' ),
			'version'    => substr( sanitize_text_field( $meta['version'] ?? '' ), 0, 20 ),
			'wp'         => substr( sanitize_text_field( $meta['wp'] ?? '' ), 0, 20 ),
			'php'        => substr( sanitize_text_field( $meta['php'] ?? '' ), 0, 20 ),
			'ip'         => self::ip(),
			'last_check' => self::now(),
		);
		if ( $row ) {
			$wpdb->update( ALS_DB::t( 'activations' ), $data, array( 'id' => $row['id'] ) ); // phpcs:ignore
			return array_merge( $row, $data );
		}
		if ( ! $is_dev && (int) $l['sites'] > 0 && self::used_sites( $l['id'] ) >= (int) $l['sites'] ) {
			return new WP_Error( 'limit', 'ظرفیت این لایسنس (' . (int) $l['sites'] . ' سایت) پر شده است. از حساب کاربری فروشگاه یک دامنه را آزاد کنید یا پلن بزرگ‌تر بخرید.' );
		}
		$data += array(
			'license_id' => (int) $l['id'],
			'domain'     => $domain,
			'is_dev'     => $is_dev,
			'created_at' => self::now(),
		);
		$wpdb->insert( ALS_DB::t( 'activations' ), $data ); // phpcs:ignore
		self::log( $l['id'], 'activated', 'فعال‌سازی روی ' . $domain . ( $is_dev ? ' (سایت تست)' : '' ) );
		return $data;
	}

	/** Signed token for the client plugin. */
	public static function token( array $l, $domain ) {
		$grace = max( 1, (int) ALS_Settings::get( 'grace_days' ) );
		return ALS_Keys::sign(
			array(
				'v'           => 1,
				'product'     => $l['product'],
				'lid'         => (int) $l['id'],
				'hint'        => substr( $l['license_key'], -4 ),
				'domain'      => $domain,
				'plan'        => $l['plan'],
				'sites'       => (int) $l['sites'],
				'activations' => self::used_sites( $l['id'] ),
				'status'      => $l['status'],
				'expires'     => (int) $l['expires_at'],
				'issued'      => time(),
				'valid_until' => time() + $grace * DAY_IN_SECONDS,
			)
		);
	}

	public static function customer_licenses( $user_id, $email ) {
		$r = self::query( array( 'user_id' => $user_id, 'email' => $email ? $email : '-', 'per_page' => 100 ) );
		return $r['rows'];
	}

	public static function daily() {
		global $wpdb;
		// Prune event log older than 180 days.
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ALS_DB::t( 'events' ) . ' WHERE created_at < %s', gmdate( 'Y-m-d H:i:s', time() - 180 * DAY_IN_SECONDS ) ) ); // phpcs:ignore
		// Renewal reminders 7 days before expiry.
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ALS_DB::t( 'licenses' ) . " WHERE status = 'active' AND expires_at BETWEEN %d AND %d", time() + 6 * DAY_IN_SECONDS, time() + 7 * DAY_IN_SECONDS ), ARRAY_A ); // phpcs:ignore
		foreach ( (array) $rows as $l ) {
			if ( $l['customer_email'] ) {
				ALS_Woo::mail_renewal( $l );
			}
		}
	}
}
