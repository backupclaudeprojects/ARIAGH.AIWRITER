<?php
/**
 * Public REST API used by the ARIAGH.AIWRITER client plugin.
 *
 * POST license/activate | license/check | license/deactivate | update/check
 * GET  download (signed) | store/plans | info
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ALS_API {

	const NS = 'ariagh/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		$post = array(
			'license/activate'   => 'activate',
			'license/check'      => 'check',
			'license/deactivate' => 'deactivate',
			'update/check'       => 'update_check',
		);
		foreach ( $post as $route => $cb ) {
			register_rest_route(
				self::NS,
				'/' . $route,
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, $cb ),
					'permission_callback' => '__return_true',
				)
			);
		}
		register_rest_route( self::NS, '/download', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'download' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NS, '/store/plans', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'plans' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NS, '/info', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'info' ), 'permission_callback' => '__return_true' ) );
	}

	/* ============================ Helpers ============================ */

	private static function fail( $code, $message, $status = 400 ) {
		return new WP_REST_Response( array( 'success' => false, 'code' => $code, 'message' => $message ), $status );
	}

	private static function ok( array $data ) {
		return new WP_REST_Response( array( 'success' => true ) + $data, 200 );
	}

	private static function params( $request ) {
		$p = $request->get_json_params();
		if ( ! is_array( $p ) || ! $p ) {
			$p = $request->get_params();
		}
		return is_array( $p ) ? $p : array();
	}

	/** Simple per-IP rate limit. */
	private static function limited( $bucket, $max = 30, $window = 600 ) {
		$k = 'als_rl_' . $bucket . '_' . md5( ALS_Licenses::ip() );
		$n = (int) get_transient( $k );
		if ( $n >= $max ) {
			return true;
		}
		set_transient( $k, $n + 1, $window );
		return false;
	}

	private static function summary( array $l ) {
		return array(
			'plan'        => $l['plan'],
			'sites'       => (int) $l['sites'],
			'activations' => ALS_Licenses::used_sites( $l['id'] ),
			'expires'     => (int) $l['expires_at'],
			'status'      => $l['status'],
		);
	}

	/* ============================ License ============================ */

	public static function activate( $request ) {
		if ( self::limited( 'act', 20 ) ) {
			return self::fail( 'rate', 'تعداد درخواست‌ها زیاد است؛ چند دقیقه بعد دوباره تلاش کنید.', 429 );
		}
		$p      = self::params( $request );
		$l      = ALS_Licenses::find( $p['license_key'] ?? '' );
		$domain = ALS_Licenses::normalize_domain( $p['domain'] ?? ( $p['site_url'] ?? '' ) );
		if ( $l && ! empty( $p['product'] ) && $p['product'] !== $l['product'] ) {
			return self::fail( 'product', 'این کلید برای محصول دیگری است.' );
		}
		$a = $l ? ALS_Licenses::activate( $l, $domain, $p ) : new WP_Error( 'invalid', 'کلید لایسنس معتبر نیست.' );
		if ( is_wp_error( $a ) ) {
			if ( $l ) {
				ALS_Licenses::log( $l['id'], 'denied', $domain . ': ' . $a->get_error_message() );
			}
			return self::fail( $a->get_error_code(), $a->get_error_message(), 'invalid' === $a->get_error_code() ? 404 : 403 );
		}
		$token = ALS_Licenses::token( $l, $domain );
		if ( is_wp_error( $token ) ) {
			return self::fail( 'server', $token->get_error_message(), 500 );
		}
		return self::ok( array( 'token' => $token, 'license' => self::summary( $l ) ) );
	}

	public static function check( $request ) {
		if ( self::limited( 'chk', 60 ) ) {
			return self::fail( 'rate', 'تعداد درخواست‌ها زیاد است.', 429 );
		}
		$p      = self::params( $request );
		$l      = ALS_Licenses::find( $p['license_key'] ?? '' );
		$domain = ALS_Licenses::normalize_domain( $p['domain'] ?? '' );
		list( $code, $msg ) = ALS_Licenses::problem( $l );
		if ( $code ) {
			return self::fail( $code, $msg, 'invalid' === $code ? 404 : 403 );
		}
		if ( ! ALS_Licenses::activation( $l['id'], $domain ) ) {
			return self::fail( 'not_activated', 'این دامنه از لایسنس آزاد شده است؛ دوباره فعال‌سازی کنید.', 403 );
		}
		ALS_Licenses::activate( $l, $domain, $p ); // Refresh last_check / version.
		$token = ALS_Licenses::token( $l, $domain );
		if ( is_wp_error( $token ) ) {
			return self::fail( 'server', $token->get_error_message(), 500 );
		}
		return self::ok( array( 'token' => $token, 'license' => self::summary( $l ) ) );
	}

	public static function deactivate( $request ) {
		$p      = self::params( $request );
		$l      = ALS_Licenses::find( $p['license_key'] ?? '' );
		$domain = ALS_Licenses::normalize_domain( $p['domain'] ?? '' );
		if ( ! $l ) {
			return self::fail( 'invalid', 'کلید لایسنس معتبر نیست.', 404 );
		}
		ALS_Licenses::remove_activation( $l['id'], $domain );
		return self::ok( array( 'message' => 'دامنه آزاد شد.' ) );
	}

	/* ============================ Updates ============================ */

	public static function update_check( $request ) {
		if ( self::limited( 'upd', 60 ) ) {
			return self::fail( 'rate', 'تعداد درخواست‌ها زیاد است.', 429 );
		}
		$p   = self::params( $request );
		$rel = ALS_Releases::latest();
		if ( ! $rel ) {
			return self::ok( array( 'update' => array() ) );
		}
		$info = array(
			'version'      => $rel['version'],
			'requires'     => $rel['requires'],
			'requires_php' => $rel['requires_php'],
			'tested'       => $rel['tested'],
			'changelog'    => $rel['changelog'],
			'last_updated' => gmdate( 'Y-m-d', (int) $rel['date'] ),
			'package'      => '',
		);
		$l      = ALS_Licenses::find( $p['license_key'] ?? '' );
		$domain = ALS_Licenses::normalize_domain( $p['domain'] ?? '' );
		list( $code ) = ALS_Licenses::problem( $l );
		if ( ! $code && ALS_Licenses::activation( $l['id'], $domain ) ) {
			$info['package'] = ALS_Releases::signed_url( $l, $domain );
		}
		return self::ok( array( 'update' => $info ) );
	}

	public static function download( $request ) {
		$id     = (int) $request->get_param( 'l' );
		$domain = rawurldecode( (string) $request->get_param( 'd' ) );
		$exp    = (int) $request->get_param( 'e' );
		$sig    = (string) $request->get_param( 's' );
		if ( $exp < time() || ! hash_equals( ALS_Keys::hmac( $id . '|' . $domain . '|' . $exp ), $sig ) ) {
			return self::fail( 'link', 'لینک دانلود منقضی یا نامعتبر است.', 403 );
		}
		$l = ALS_Licenses::get( $id );
		list( $code, $msg ) = ALS_Licenses::problem( $l );
		if ( $code ) {
			return self::fail( $code, $msg, 403 );
		}
		$path = ALS_Releases::build();
		if ( is_wp_error( $path ) ) {
			return self::fail( 'build', $path->get_error_message(), 500 );
		}
		ALS_Licenses::log( $id, 'download', 'دانلود نسخه ' . ( ALS_Releases::latest()['version'] ?? '' ) . ( '*' === $domain ? ' از حساب کاربری' : ' برای ' . $domain ) );
		ALS_Releases::stream( $path, ALS_CLIENT_SLUG . '.zip' );
	}

	/* ============================ Store ============================ */

	public static function plans() {
		return self::ok( array( 'plans' => ALS_Woo::plans() ) );
	}

	public static function info() {
		$rel = ALS_Releases::latest();
		return self::ok(
			array(
				'product'    => ALS_PRODUCT,
				'name'       => ALS_Settings::get( 'product_name' ),
				'version'    => $rel ? $rel['version'] : '',
				'public_key' => ALS_Keys::public_key(),
				'store_url'  => ALS_Settings::store_url(),
			)
		);
	}
}
