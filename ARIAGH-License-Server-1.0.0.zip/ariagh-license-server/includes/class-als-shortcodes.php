<?php
/**
 * Sales page shortcodes: [ariagh_landing] and [ariagh_pricing].
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ALS_Shortcodes {

	public static function init() {
		add_shortcode( 'ariagh_landing', array( __CLASS__, 'landing' ) );
		add_shortcode( 'ariagh_pricing', array( __CLASS__, 'pricing' ) );
		add_filter( 'template_include', array( __CLASS__, 'canvas' ), 99 );
	}

	public static function icon( $name ) {
		$p = array(
			'spark'  => '<path d="M12 3l1.8 4.9L18.7 9.7l-4.9 1.8L12 16.4l-1.8-4.9L5.3 9.7l4.9-1.8z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
			'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
			'clock'  => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
			'cloud'  => '<path d="M17.5 19a4.5 4.5 0 1 0-1.4-8.8A6 6 0 0 0 4.5 12 3.5 3.5 0 0 0 6 19z"/>',
			'shield' => '<path d="M12 3l8 3v6c0 5-3.4 8.4-8 9-4.6-.6-8-4-8-9V6z"/><path d="m9 12 2 2 4-4"/>',
			'seo'    => '<path d="M3 3v18h18"/><path d="m7 15 4-4 3 3 5-6"/>',
			'image'  => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 17-5-5-9 8"/>',
			'check'  => '<path d="m5 12 5 5L20 7"/>',
			'layers' => '<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>',
			'user'   => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
			'review' => '<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
			'globe'  => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
		);
		return '<svg class="alp-ic" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( $p[ $name ] ?? $p['spark'] ) . '</svg>';
	}

	public static function canvas( $template ) {
		$page = (int) ALS_Settings::get( 'landing_page' );
		if ( $page && ALS_Settings::get( 'landing_canvas' ) && is_page( $page ) ) {
			return ALS_DIR . 'templates/canvas.php';
		}
		return $template;
	}

	private static function styles() {
		static $done = false;
		if ( $done ) {
			return '';
		}
		$done = true;
		$c    = ALS_Settings::get( 'brand_color' );
		return '<style>' . str_replace( '#1D4ED8', esc_attr( $c ), (string) file_get_contents( ALS_DIR . 'assets/landing.css' ) ) . '</style>'; // phpcs:ignore
	}

	public static function pricing( $atts = array() ) {
		$plans = ALS_Woo::plans();
		ob_start();
		echo self::styles(); // phpcs:ignore
		echo '<div class="alp alp-pricing-wrap" dir="rtl">';
		if ( ! $plans ) {
			echo '<p class="alp-muted" style="text-align:center">' . ( class_exists( 'WooCommerce' ) ? 'هنوز پلنی تعریف نشده است. در ووکامرس یک محصول مجازی بسازید و گزینه «لایسنس AIWRITER» را فعال کنید.' : 'برای نمایش قیمت‌ها و فروش آنلاین، ووکامرس را نصب و فعال کنید.' ) . '</p>';
		} else {
			echo '<div class="alp-plans alp-cols-' . min( 4, count( $plans ) ) . '">';
			foreach ( $plans as $pl ) {
				echo '<div class="alp-plan' . ( $pl['featured'] ? ' is-featured' : '' ) . '">';
				if ( $pl['featured'] ) {
					echo '<span class="alp-plan-tag">محبوب‌ترین</span>';
				}
				echo '<h3>' . esc_html( $pl['name'] ) . '</h3>';
				echo '<div class="alp-price">' . ( $pl['regular'] ? '<del>' . esc_html( $pl['regular'] ) . '</del>' : '' ) . esc_html( $pl['price'] ) . '</div>';
				echo '<div class="alp-plan-sub">' . esc_html( ( $pl['sites'] ? $pl['sites'] . ' سایت' : 'سایت نامحدود' ) . ' · ' . $pl['period'] ) . '</div>';
				if ( $pl['features'] ) {
					echo '<ul>';
					foreach ( $pl['features'] as $f ) {
						echo '<li>' . self::icon( 'check' ) . esc_html( $f ) . '</li>'; // phpcs:ignore
					}
					echo '</ul>';
				}
				echo '<a class="alp-btn ' . ( $pl['featured'] ? 'alp-btn-primary' : 'alp-btn-ghost' ) . '" href="' . esc_url( $pl['url'] ) . '">خرید و دریافت فوری</a>';
				echo '</div>';
			}
			echo '</div>';
			echo '<p class="alp-muted alp-center">پرداخت امن · تحویل فوری کلید لایسنس و فایل افزونه پس از پرداخت · سایت‌های تست و staging رایگان</p>';
		}
		echo '</div>';
		return ob_get_clean();
	}

	public static function landing( $atts = array() ) {
		$s = ALS_Settings::all();
		ob_start();
		echo self::styles(); // phpcs:ignore
		include ALS_DIR . 'templates/landing.php';
		return ob_get_clean();
	}
}
