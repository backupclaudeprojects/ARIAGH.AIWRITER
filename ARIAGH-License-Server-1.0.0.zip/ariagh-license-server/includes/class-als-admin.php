<?php
/**
 * Store owner admin: dashboard, licenses, releases, settings.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ALS_Admin {

	private static $hook = '';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		foreach ( array( 'save_settings', 'create_license', 'update_license', 'delete_license', 'remove_activation', 'upload_release', 'delete_release', 'download_build', 'regen_keys', 'create_landing', 'export' ) as $a ) {
			add_action( 'admin_post_als_' . $a, array( __CLASS__, 'h_' . $a ) );
		}
		add_filter( 'plugin_action_links_' . plugin_basename( ALS_FILE ), array( __CLASS__, 'links' ) );
	}

	public static function links( $l ) {
		array_unshift( $l, '<a href="' . esc_url( self::url() ) . '">پیشخوان فروش</a>' );
		return $l;
	}

	public static function url( $tab = '', $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => 'als' ), $tab ? array( 'tab' => $tab ) : array(), $args ), admin_url( 'admin.php' ) );
	}

	public static function menu() {
		$icon       = 'data:image/svg+xml;base64,' . base64_encode( (string) file_get_contents( ALS_DIR . 'assets/img/menu-icon.svg' ) ); // phpcs:ignore
		self::$hook = add_menu_page( 'ARIAGH فروش و لایسنس', 'فروش AIWRITER', 'manage_options', 'als', array( __CLASS__, 'render' ), $icon, 56 );
	}

	public static function assets( $hook ) {
		if ( $hook === self::$hook ) {
			wp_enqueue_style( 'als-admin', ALS_URL . 'assets/admin.css', array(), ALS_VERSION );
		}
	}

	private static function guard( $nonce ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی غیرمجاز' );
		}
		check_admin_referer( $nonce );
	}

	private static function back( $tab, $msg = '', $type = 'success', $args = array() ) {
		if ( $msg ) {
			set_transient( 'als_notice_' . get_current_user_id(), array( $msg, $type ), 60 );
		}
		wp_safe_redirect( self::url( $tab, $args ) );
		exit;
	}

	/* ============================ Handlers ============================ */

	public static function h_save_settings() {
		self::guard( 'als_settings' );
		$in = wp_unslash( $_POST['s'] ?? array() ); // phpcs:ignore
		foreach ( array( 'dev_free', 'landing_canvas', 'email_manual' ) as $b ) {
			$in[ $b ] = empty( $in[ $b ] ) ? 0 : 1;
		}
		ALS_Settings::save( (array) $in );
		ALS_Releases::clear_builds();
		self::back( 'settings', 'تنظیمات ذخیره شد. نسخه‌های برندشده با تنظیمات جدید ساخته می‌شوند.' );
	}

	public static function h_create_license() {
		self::guard( 'als_create' );
		$p  = wp_unslash( $_POST ); // phpcs:ignore
		$id = ALS_Licenses::create(
			array(
				'customer_email' => $p['email'] ?? '',
				'customer_name'  => $p['name'] ?? '',
				'plan'           => $p['plan'] ?? '',
				'sites'          => $p['sites'] ?? 1,
				'months'         => $p['months'] ?? 0,
				'notes'          => $p['notes'] ?? '',
			)
		);
		if ( is_wp_error( $id ) ) {
			self::back( 'licenses', $id->get_error_message(), 'error' );
		}
		if ( ! empty( $p['send'] ) ) {
			ALS_Woo::mail_license( ALS_Licenses::get( $id ) );
		}
		self::back( 'licenses', 'لایسنس صادر شد.', 'success', array( 'id' => $id ) );
	}

	public static function h_update_license() {
		self::guard( 'als_update' );
		$p  = wp_unslash( $_POST ); // phpcs:ignore
		$id = (int) ( $p['id'] ?? 0 );
		$ex = trim( (string) ( $p['expires'] ?? '' ) );
		ALS_Licenses::update(
			$id,
			array(
				'plan'           => sanitize_text_field( $p['plan'] ?? '' ),
				'sites'          => max( 0, (int) ( $p['sites'] ?? 1 ) ),
				'status'         => in_array( $p['status'] ?? '', array( 'active', 'revoked' ), true ) ? $p['status'] : 'active',
				'expires_at'     => $ex ? (int) strtotime( $ex . ' 23:59:59' ) : 0,
				'customer_email' => sanitize_email( $p['email'] ?? '' ),
				'customer_name'  => sanitize_text_field( $p['name'] ?? '' ),
				'notes'          => sanitize_textarea_field( $p['notes'] ?? '' ),
			)
		);
		if ( ! empty( $p['extend'] ) ) {
			ALS_Licenses::extend( $id, (int) $p['extend'] );
		}
		ALS_Licenses::log( $id, 'edited', 'ویرایش توسط مدیر' );
		if ( ! empty( $p['resend'] ) ) {
			ALS_Woo::mail_license( ALS_Licenses::get( $id ) );
		}
		self::back( 'licenses', 'لایسنس به‌روزرسانی شد.', 'success', array( 'id' => $id ) );
	}

	public static function h_delete_license() {
		self::guard( 'als_delete' );
		ALS_Licenses::delete( (int) ( $_POST['id'] ?? 0 ) ); // phpcs:ignore
		self::back( 'licenses', 'لایسنس حذف شد.' );
	}

	public static function h_remove_activation() {
		self::guard( 'als_act' );
		$id = (int) ( $_POST['id'] ?? 0 ); // phpcs:ignore
		ALS_Licenses::remove_activation( $id, sanitize_text_field( wp_unslash( $_POST['domain'] ?? '' ) ) ); // phpcs:ignore
		self::back( 'licenses', 'دامنه آزاد شد.', 'success', array( 'id' => $id ) );
	}

	public static function h_upload_release() {
		self::guard( 'als_release' );
		if ( empty( $_FILES['zip']['tmp_name'] ) || ! is_uploaded_file( $_FILES['zip']['tmp_name'] ) ) { // phpcs:ignore
			self::back( 'releases', 'فایل ZIP انتخاب نشده است.', 'error' );
		}
		$v = ALS_Releases::add( $_FILES['zip']['tmp_name'], wp_unslash( $_POST['changelog'] ?? '' ), wp_unslash( $_POST['tested'] ?? '' ) ); // phpcs:ignore
		if ( is_wp_error( $v ) ) {
			self::back( 'releases', $v->get_error_message(), 'error' );
		}
		delete_transient( 'als_plans' );
		self::back( 'releases', 'نسخه ' . $v . ' منتشر شد؛ مشتریان ظرف ۱۲ ساعت اعلان به‌روزرسانی می‌گیرند.' );
	}

	public static function h_delete_release() {
		self::guard( 'als_release_del' );
		ALS_Releases::remove( sanitize_text_field( wp_unslash( $_POST['version'] ?? '' ) ) ); // phpcs:ignore
		self::back( 'releases', 'نسخه حذف شد.' );
	}

	public static function h_download_build() {
		self::guard( 'als_build' );
		$path = ALS_Releases::build();
		if ( is_wp_error( $path ) ) {
			self::back( 'releases', $path->get_error_message(), 'error' );
		}
		ALS_Releases::stream( $path, ALS_CLIENT_SLUG . '.zip' );
	}

	public static function h_regen_keys() {
		self::guard( 'als_keys' );
		ALS_Keys::generate();
		self::back( 'settings', 'کلید امضای جدید ساخته شد. نسخه‌های قبلی افزونه دیگر لایسنس را تایید نمی‌کنند؛ مشتریان باید نسخه جدید را نصب کنند.', 'warning' );
	}

	public static function h_create_landing() {
		self::guard( 'als_landing' );
		$id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => 'ARIAGH.AIWRITER – نویسنده هوشمند مقالات سئو',
				'post_name'    => 'aiwriter',
				'post_content' => '[ariagh_landing]',
			)
		);
		if ( is_wp_error( $id ) ) {
			self::back( '', $id->get_error_message(), 'error' );
		}
		ALS_Settings::save( array( 'landing_page' => $id ) );
		ALS_Releases::clear_builds();
		self::back( '', 'صفحه فروش ساخته شد.', 'success' );
	}

	public static function h_export() {
		self::guard( 'als_export' );
		$r = ALS_Licenses::query( array( 'per_page' => 100000 ) );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="aiwriter-licenses-' . gmdate( 'Ymd' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore
		fputcsv( $out, array( 'id', 'license_key', 'plan', 'sites', 'used', 'status', 'expires', 'email', 'name', 'order_id', 'created_at' ) );
		foreach ( $r['rows'] as $l ) {
			fputcsv( $out, array( $l['id'], $l['license_key'], $l['plan'], $l['sites'], $l['used'], $l['status'], $l['expires_at'] ? gmdate( 'Y-m-d', $l['expires_at'] ) : 'lifetime', $l['customer_email'], $l['customer_name'], $l['order_id'], $l['created_at'] ) );
		}
		fclose( $out ); // phpcs:ignore
		exit;
	}

	/* ============================ Render ============================ */

	public static function field( $name, $label, $value, $type = 'text', $help = '' ) {
		echo '<label class="als-f"><span>' . esc_html( $label ) . '</span>';
		if ( 'textarea' === $type ) {
			echo '<textarea name="' . esc_attr( $name ) . '" rows="3">' . esc_textarea( $value ) . '</textarea>';
		} elseif ( 'checkbox' === $type ) {
			echo '<input type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . checked( (bool) $value, true, false ) . '>';
		} else {
			echo '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"' . ( in_array( $type, array( 'url', 'email' ), true ) ? ' dir="ltr"' : '' ) . '>';
		}
		if ( $help ) {
			echo '<small>' . esc_html( $help ) . '</small>';
		}
		echo '</label>';
	}

	public static function render() {
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'dashboard'; // phpcs:ignore
		$tabs = array(
			'dashboard' => 'پیشخوان',
			'licenses'  => 'لایسنس‌ها',
			'releases'  => 'نسخه‌ها',
			'settings'  => 'تنظیمات',
		);
		$tab    = isset( $tabs[ $tab ] ) ? $tab : 'dashboard';
		$notice = get_transient( 'als_notice_' . get_current_user_id() );
		delete_transient( 'als_notice_' . get_current_user_id() );
		echo '<div class="als" dir="rtl">';
		echo '<header class="als-top"><img src="' . esc_url( ALS_URL . 'assets/img/logo.svg' ) . '" alt="ARIAGH.AIWRITER" height="30"><span>پیشخوان فروش و لایسنس</span><nav>';
		foreach ( $tabs as $k => $label ) {
			echo '<a class="' . ( $k === $tab ? 'is-on' : '' ) . '" href="' . esc_url( self::url( 'dashboard' === $k ? '' : $k ) ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</nav></header>';
		if ( $notice ) {
			echo '<div class="als-notice is-' . esc_attr( $notice[1] ) . '">' . esc_html( $notice[0] ) . '</div>';
		}
		include ALS_DIR . 'admin/' . $tab . '.php';
		echo '</div>';
	}
}
