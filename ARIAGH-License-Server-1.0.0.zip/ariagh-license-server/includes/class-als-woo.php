<?php
/**
 * WooCommerce integration: license products, automatic issuing on payment,
 * renewals, refunds, "My licenses" account page and emails.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ALS_Woo {

	const ENDPOINT = 'ariagh-licenses';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'add_endpoint' ) );
		add_action( 'template_redirect', array( __CLASS__, 'handle_account_actions' ) );
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		// Product admin.
		add_filter( 'product_type_options', array( __CLASS__, 'type_option' ) );
		add_action( 'woocommerce_product_options_general_product_data', array( __CLASS__, 'product_fields' ) );
		add_action( 'woocommerce_process_product_meta', array( __CLASS__, 'save_product' ) );
		// Orders.
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'issue' ) );
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'issue' ) );
		add_action( 'woocommerce_order_status_refunded', array( __CLASS__, 'revoke_order' ) );
		add_action( 'woocommerce_order_status_cancelled', array( __CLASS__, 'revoke_order' ) );
		add_filter( 'woocommerce_add_cart_item_data', array( __CLASS__, 'cart_item_data' ), 10, 2 );
		add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'show_cart_item_data' ), 10, 2 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'order_item_meta' ), 10, 3 );
		add_filter( 'woocommerce_payment_complete_order_status', array( __CLASS__, 'autocomplete' ), 10, 3 );
		add_action( 'woocommerce_email_after_order_table', array( __CLASS__, 'email_block' ), 10, 4 );
		add_action( 'woocommerce_thankyou', array( __CLASS__, 'thankyou' ), 5 );
		// Account.
		add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'menu_item' ) );
		add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( __CLASS__, 'account_page' ) );
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
	}

	public static function add_endpoint() {
		add_rewrite_endpoint( self::ENDPOINT, EP_ROOT | EP_PAGES );
	}

	public static function query_vars( $vars ) {
		$vars[] = self::ENDPOINT;
		return $vars;
	}

	/* ============================ Product ============================ */

	public static function type_option( $options ) {
		$options['als_license'] = array(
			'id'            => '_als_enabled',
			'wrapper_class' => 'show_if_simple show_if_variable',
			'label'         => 'لایسنس AIWRITER',
			'description'   => 'با پرداخت این محصول، لایسنس ARIAGH.AIWRITER صادر شود.',
			'default'       => 'no',
		);
		return $options;
	}

	public static function product_fields() {
		echo '<div class="options_group show_if_als_license">';
		echo '<p class="form-field"><strong style="padding-right:12px">تنظیمات لایسنس ARIAGH.AIWRITER</strong></p>';
		woocommerce_wp_text_input( array( 'id' => '_als_plan', 'label' => 'نام پلن', 'placeholder' => 'مثلاً حرفه‌ای', 'desc_tip' => true, 'description' => 'در لایسنس و پیشخوان مشتری نمایش داده می‌شود.' ) );
		woocommerce_wp_text_input( array( 'id' => '_als_sites', 'label' => 'تعداد سایت', 'type' => 'number', 'custom_attributes' => array( 'min' => 0 ), 'placeholder' => '1', 'desc_tip' => true, 'description' => '0 یعنی نامحدود. سایت‌های تست و staging شمرده نمی‌شوند.' ) );
		woocommerce_wp_text_input( array( 'id' => '_als_months', 'label' => 'مدت اعتبار (ماه)', 'type' => 'number', 'custom_attributes' => array( 'min' => 0 ), 'placeholder' => '12', 'desc_tip' => true, 'description' => '0 یعنی لایسنس دائمی.' ) );
		woocommerce_wp_textarea_input( array( 'id' => '_als_features', 'label' => 'ویژگی‌های پلن', 'placeholder' => "هر خط یک ویژگی\nتولید نامحدود مقاله\nپشتیبانی ۱۲ ماهه", 'desc_tip' => true, 'description' => 'در جدول قیمت صفحه فروش و داخل افزونه نمایش داده می‌شود.' ) );
		woocommerce_wp_checkbox( array( 'id' => '_als_featured', 'label' => 'پلن پیشنهادی', 'description' => 'در جدول قیمت برجسته شود' ) );
		woocommerce_wp_text_input( array( 'id' => '_als_order', 'label' => 'ترتیب نمایش', 'type' => 'number', 'placeholder' => '0' ) );
		echo '</div>';
		echo '<script>jQuery(function($){function t(){$(".show_if_als_license").toggle($("#_als_enabled").is(":checked"));}$("#_als_enabled").on("change",t);t();});</script>';
	}

	public static function save_product( $post_id ) {
		update_post_meta( $post_id, '_als_enabled', isset( $_POST['_als_enabled'] ) ? 'yes' : 'no' ); // phpcs:ignore
		update_post_meta( $post_id, '_als_featured', isset( $_POST['_als_featured'] ) ? 'yes' : 'no' ); // phpcs:ignore
		foreach ( array( '_als_plan' => 'text', '_als_sites' => 'int', '_als_months' => 'int', '_als_order' => 'int', '_als_features' => 'textarea' ) as $k => $t ) {
			if ( ! isset( $_POST[ $k ] ) ) { // phpcs:ignore
				continue;
			}
			$v = wp_unslash( $_POST[ $k ] ); // phpcs:ignore
			$v = 'int' === $t ? max( 0, (int) $v ) : ( 'textarea' === $t ? sanitize_textarea_field( $v ) : sanitize_text_field( $v ) );
			update_post_meta( $post_id, $k, $v );
		}
		delete_transient( 'als_plans' );
	}

	public static function is_license_product( $product_id ) {
		return 'yes' === get_post_meta( $product_id, '_als_enabled', true );
	}

	/** Plans for the pricing table and the client plugin. */
	public static function plans() {
		if ( ! function_exists( 'wc_get_products' ) ) {
			return array();
		}
		$c = get_transient( 'als_plans' );
		if ( is_array( $c ) ) {
			return $c;
		}
		$products = wc_get_products( array( 'status' => 'publish', 'limit' => 20, 'meta_key' => '_als_enabled', 'meta_value' => 'yes' ) ); // phpcs:ignore
		$plans    = array();
		foreach ( $products as $p ) {
			$id     = $p->get_id();
			$months = (int) get_post_meta( $id, '_als_months', true );
			$sites  = get_post_meta( $id, '_als_sites', true );
			$plans[] = array(
				'id'       => $id,
				'name'     => get_post_meta( $id, '_als_plan', true ) ? get_post_meta( $id, '_als_plan', true ) : $p->get_name(),
				'price'    => html_entity_decode( wp_strip_all_tags( $p->get_price_html() ), ENT_QUOTES, 'UTF-8' ),
				'regular'  => $p->is_on_sale() ? html_entity_decode( wp_strip_all_tags( wc_price( (float) $p->get_regular_price() ) ), ENT_QUOTES, 'UTF-8' ) : '',
				'sites'    => '' === $sites ? 1 : (int) $sites,
				'period'   => $months ? ( 12 === $months ? 'یک‌ساله' : $months . ' ماهه' ) : 'دائمی',
				'url'      => add_query_arg( 'add-to-cart', $id, wc_get_checkout_url() ),
				'featured' => 'yes' === get_post_meta( $id, '_als_featured', true ),
				'features' => array_values( array_filter( array_map( 'trim', preg_split( '/\r?\n/', (string) get_post_meta( $id, '_als_features', true ) ) ) ) ),
				'order'    => (int) get_post_meta( $id, '_als_order', true ),
			);
		}
		usort(
			$plans,
			function ( $a, $b ) {
				return $a['order'] <=> $b['order'];
			}
		);
		set_transient( 'als_plans', $plans, HOUR_IN_SECONDS );
		return $plans;
	}

	/* ============================ Cart / checkout ============================ */

	public static function cart_item_data( $data, $product_id ) {
		if ( ! empty( $_GET['als_renew'] ) && self::is_license_product( $product_id ) ) { // phpcs:ignore
			$l = ALS_Licenses::find( sanitize_text_field( wp_unslash( $_GET['als_renew'] ) ) ); // phpcs:ignore
			if ( $l && ( ! $l['user_id'] || get_current_user_id() === (int) $l['user_id'] ) ) {
				$data['als_renew'] = $l['license_key'];
			}
		}
		return $data;
	}

	public static function show_cart_item_data( $item_data, $cart_item ) {
		if ( ! empty( $cart_item['als_renew'] ) ) {
			$item_data[] = array( 'key' => 'تمدید لایسنس', 'value' => substr( $cart_item['als_renew'], 0, 8 ) . '…' . substr( $cart_item['als_renew'], -4 ) );
		}
		return $item_data;
	}

	public static function order_item_meta( $item, $key, $values ) {
		if ( ! empty( $values['als_renew'] ) ) {
			$item->add_meta_data( '_als_renew', $values['als_renew'], true );
		}
	}

	/** Virtual license orders go straight to "completed" after payment. */
	public static function autocomplete( $status, $order_id, $order ) {
		if ( ! $order ) {
			return $status;
		}
		foreach ( $order->get_items() as $item ) {
			$pid = $item->get_product_id();
			if ( ! self::is_license_product( $pid ) ) {
				return $status;
			}
			$product = $item->get_product();
			if ( $product && ! $product->is_virtual() ) {
				return $status;
			}
		}
		return 'completed';
	}

	/* ============================ Issuing ============================ */

	public static function issue( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || $order->get_meta( '_als_issued' ) ) {
			return;
		}
		$issued = array();
		foreach ( $order->get_items() as $item ) {
			$pid = $item->get_product_id();
			if ( ! self::is_license_product( $pid ) ) {
				continue;
			}
			$months = (int) get_post_meta( $pid, '_als_months', true );
			$renew  = $item->get_meta( '_als_renew' );
			if ( $renew ) {
				$l = ALS_Licenses::find( $renew );
				if ( $l ) {
					$new = ALS_Licenses::extend( $l['id'], max( 1, $months ) * max( 1, (int) $item->get_quantity() ) );
					$item->add_meta_data( 'لایسنس تمدیدشده', $l['license_key'] . ' — تا ' . wp_date( 'Y/m/d', $new ), true );
					$item->save();
					$issued[] = $l['license_key'];
					continue;
				}
			}
			$sites = get_post_meta( $pid, '_als_sites', true );
			$keys  = array();
			for ( $i = 0; $i < max( 1, (int) $item->get_quantity() ); $i++ ) {
				$id = ALS_Licenses::create(
					array(
						'plan'           => get_post_meta( $pid, '_als_plan', true ) ? get_post_meta( $pid, '_als_plan', true ) : $item->get_name(),
						'sites'          => '' === $sites ? 1 : (int) $sites,
						'months'         => $months,
						'customer_email' => $order->get_billing_email(),
						'customer_name'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
						'user_id'        => $order->get_customer_id(),
						'order_id'       => $order->get_id(),
						'product_id'     => $pid,
					)
				);
				if ( ! is_wp_error( $id ) ) {
					$l      = ALS_Licenses::get( $id );
					$keys[] = $l['license_key'];
				}
			}
			if ( $keys ) {
				$item->add_meta_data( 'کلید لایسنس', implode( ' , ', $keys ), true );
				$item->save();
				$issued = array_merge( $issued, $keys );
			}
		}
		if ( $issued ) {
			$order->update_meta_data( '_als_issued', implode( ',', $issued ) );
			$order->add_order_note( 'لایسنس ARIAGH.AIWRITER صادر شد: ' . implode( ', ', $issued ) );
			$order->save();
		}
	}

	public static function revoke_order( $order_id ) {
		global $wpdb;
		$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . ALS_DB::t( 'licenses' ) . ' WHERE order_id = %d', $order_id ) ); // phpcs:ignore
		foreach ( (array) $ids as $id ) {
			ALS_Licenses::update( $id, array( 'status' => 'revoked' ) );
			ALS_Licenses::log( $id, 'revoked', 'ابطال به‌دلیل استرداد/لغو سفارش #' . $order_id );
		}
	}

	public static function order_licenses( $order_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ALS_DB::t( 'licenses' ) . ' WHERE order_id = %d', $order_id ), ARRAY_A ); // phpcs:ignore
	}

	private static function license_box_html( array $rows, $plain = false ) {
		if ( ! $rows ) {
			return '';
		}
		if ( $plain ) {
			$t = "\n" . 'لایسنس‌های ARIAGH.AIWRITER:' . "\n";
			foreach ( $rows as $l ) {
				$t .= $l['license_key'] . ' (' . $l['plan'] . ")\n";
			}
			return $t . 'مدیریت و دانلود: ' . ALS_Settings::account_url() . "\n";
		}
		$h = '<div style="margin:20px 0;padding:18px;border:1px solid #DBEAFE;border-radius:12px;background:#EFF6FF;direction:rtl;text-align:right">';
		$h .= '<h3 style="margin:0 0 10px;color:#0B1B3F">لایسنس ARIAGH.AIWRITER شما</h3>';
		foreach ( $rows as $l ) {
			$h .= '<p style="margin:6px 0"><code style="font-size:15px;direction:ltr;display:inline-block;background:#fff;border:1px solid #DBEAFE;padding:6px 10px;border-radius:8px;letter-spacing:1px">' . esc_html( $l['license_key'] ) . '</code> <span style="color:#475569">' . esc_html( $l['plan'] ) . ' · ' . esc_html( (int) $l['sites'] ? (int) $l['sites'] . ' سایت' : 'سایت نامحدود' ) . ' · ' . esc_html( (int) $l['expires_at'] ? 'تا ' . wp_date( 'Y/m/d', (int) $l['expires_at'] ) : 'دائمی' ) . '</span></p>';
		}
		$h .= '<p style="margin:12px 0 0">۱) افزونه را از <a href="' . esc_url( ALS_Settings::account_url() ) . '">حساب کاربری ← لایسنس‌های من</a> دانلود و نصب کنید. ۲) در پیشخوان وردپرس ← AIWRITER ← «لایسنس و حساب» کلید را وارد کنید.</p></div>';
		return $h;
	}

	public static function email_block( $order, $sent_to_admin, $plain_text, $email = null ) {
		if ( $sent_to_admin || ! in_array( $order->get_status(), array( 'completed', 'processing' ), true ) ) {
			return;
		}
		echo self::license_box_html( self::order_licenses( $order->get_id() ), $plain_text ); // phpcs:ignore
	}

	public static function thankyou( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( $order && $order->is_paid() ) {
			self::issue( $order_id );
		}
		echo self::license_box_html( self::order_licenses( $order_id ) ); // phpcs:ignore
	}

	/** Manual licenses (issued by admin) get their own email. */
	public static function mail_license( array $l ) {
		if ( ! $l['customer_email'] ) {
			return false;
		}
		$body  = self::license_box_html( array( $l ) );
		$title = 'لایسنس ' . ALS_Settings::get( 'product_name' ) . ' شما';
		return wp_mail( $l['customer_email'], $title, '<html><body style="font-family:Tahoma,sans-serif">' . $body . '</body></html>', array( 'Content-Type: text/html; charset=UTF-8' ) );
	}

	public static function mail_renewal( array $l ) {
		$renew = self::renew_url( $l );
		$body  = '<div style="direction:rtl;text-align:right;font-family:Tahoma,sans-serif"><p>سلام،</p><p>اعتبار لایسنس ' . esc_html( ALS_Settings::get( 'product_name' ) ) . ' شما (' . esc_html( substr( $l['license_key'], 0, 8 ) ) . '…) در تاریخ ' . esc_html( wp_date( 'Y/m/d', (int) $l['expires_at'] ) ) . ' به پایان می‌رسد. برای ادامه تولید خودکار مقاله و دریافت به‌روزرسانی‌ها، تمدید کنید.</p>' . ( $renew ? '<p><a href="' . esc_url( $renew ) . '" style="background:#1D4ED8;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">تمدید لایسنس</a></p>' : '' ) . '</div>';
		return wp_mail( $l['customer_email'], 'یادآوری تمدید لایسنس ' . ALS_Settings::get( 'product_name' ), $body, array( 'Content-Type: text/html; charset=UTF-8' ) );
	}

	public static function renew_url( array $l ) {
		if ( ! function_exists( 'wc_get_checkout_url' ) || ! $l['product_id'] || ! get_post( $l['product_id'] ) ) {
			return '';
		}
		return add_query_arg( array( 'add-to-cart' => (int) $l['product_id'], 'als_renew' => $l['license_key'] ), wc_get_checkout_url() );
	}

	/* ============================ My account ============================ */

	public static function menu_item( $items ) {
		$new = array();
		foreach ( $items as $k => $v ) {
			$new[ $k ] = $v;
			if ( 'orders' === $k ) {
				$new[ self::ENDPOINT ] = 'لایسنس‌های من';
			}
		}
		if ( ! isset( $new[ self::ENDPOINT ] ) ) {
			$new[ self::ENDPOINT ] = 'لایسنس‌های من';
		}
		return $new;
	}

	public static function handle_account_actions() {
		if ( empty( $_POST['als_action'] ) || ! is_user_logged_in() ) { // phpcs:ignore
			return;
		}
		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'als_account' ) ) {
			return;
		}
		$user = wp_get_current_user();
		$l    = ALS_Licenses::get( isset( $_POST['license'] ) ? (int) $_POST['license'] : 0 );
		if ( ! $l || ( (int) $l['user_id'] !== $user->ID && strtolower( $l['customer_email'] ) !== strtolower( $user->user_email ) ) ) {
			return;
		}
		$action = sanitize_key( wp_unslash( $_POST['als_action'] ) );
		if ( 'release' === $action && ! empty( $_POST['domain'] ) ) {
			ALS_Licenses::remove_activation( $l['id'], sanitize_text_field( wp_unslash( $_POST['domain'] ) ) );
			if ( function_exists( 'wc_add_notice' ) ) {
				wc_add_notice( 'دامنه آزاد شد و می‌توانید لایسنس را روی سایت دیگری فعال کنید.' );
			}
		}
		if ( 'download' === $action ) {
			list( $code, $msg ) = ALS_Licenses::problem( $l );
			if ( $code ) {
				if ( function_exists( 'wc_add_notice' ) ) {
					wc_add_notice( $msg, 'error' );
				}
				return;
			}
			wp_safe_redirect( ALS_Releases::signed_url( $l, '*', 600 ) );
			exit;
		}
		wp_safe_redirect( wc_get_account_endpoint_url( self::ENDPOINT ) );
		exit;
	}

	public static function account_page() {
		$user = wp_get_current_user();
		$rows = ALS_Licenses::customer_licenses( $user->ID, $user->user_email );
		include ALS_DIR . 'templates/account-licenses.php';
	}
}
