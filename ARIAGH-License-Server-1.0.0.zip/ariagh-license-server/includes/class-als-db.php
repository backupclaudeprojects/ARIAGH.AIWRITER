<?php
/**
 * Database schema and lifecycle.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ALS_DB {

	const DB_VERSION = '1.0.0';

	public static function t( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'als_' . $name;
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();

		dbDelta(
			'CREATE TABLE ' . self::t( 'licenses' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			license_key varchar(64) NOT NULL,
			product varchar(64) NOT NULL DEFAULT '',
			plan varchar(120) NOT NULL DEFAULT '',
			sites int(11) NOT NULL DEFAULT 1,
			status varchar(20) NOT NULL DEFAULT 'active',
			expires_at bigint(20) NOT NULL DEFAULT 0,
			customer_email varchar(190) NOT NULL DEFAULT '',
			customer_name varchar(190) NOT NULL DEFAULT '',
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			product_id bigint(20) unsigned NOT NULL DEFAULT 0,
			notes text NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY license_key (license_key),
			KEY customer_email (customer_email),
			KEY user_id (user_id),
			KEY order_id (order_id)
		) $c;"
		);

		dbDelta(
			'CREATE TABLE ' . self::t( 'activations' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			license_id bigint(20) unsigned NOT NULL,
			domain varchar(190) NOT NULL,
			site_url varchar(255) NOT NULL DEFAULT '',
			is_dev tinyint(1) NOT NULL DEFAULT 0,
			version varchar(20) NOT NULL DEFAULT '',
			wp varchar(20) NOT NULL DEFAULT '',
			php varchar(20) NOT NULL DEFAULT '',
			ip varchar(64) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			last_check datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY license_domain (license_id,domain),
			KEY domain (domain)
		) $c;"
		);

		dbDelta(
			'CREATE TABLE ' . self::t( 'events' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			license_id bigint(20) unsigned NOT NULL DEFAULT 0,
			type varchar(40) NOT NULL DEFAULT '',
			message text NULL,
			ip varchar(64) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY license_id (license_id)
		) $c;"
		);
		update_option( 'als_db_version', self::DB_VERSION, false );
	}

	public static function activate() {
		self::create_tables();
		ALS_Keys::ensure();
		ALS_Releases::ensure_dir();
		ALS_Releases::import_bundle();
		ALS_Woo::add_endpoint();
		flush_rewrite_rules();
		if ( ! wp_next_scheduled( 'als_daily' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'als_daily' );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'als_daily' );
		flush_rewrite_rules();
	}

	public static function maybe_upgrade() {
		if ( get_option( 'als_db_version' ) !== self::DB_VERSION ) {
			self::create_tables();
			ALS_Keys::ensure();
		}
		add_action( 'als_daily', array( 'ALS_Licenses', 'daily' ) );
	}
}
