<?php
/**
 * Ed25519 signing keys (private key encrypted at rest).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ALS_Keys {

	const OPTION = 'als_keys';

	private static function wrap_key() {
		return sodium_crypto_generichash( wp_salt( 'auth' ) . '|als-keys', '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES );
	}

	public static function ensure() {
		$k = get_option( self::OPTION );
		if ( is_array( $k ) && ! empty( $k['public'] ) && ! empty( $k['secret'] ) ) {
			return;
		}
		self::generate();
	}

	public static function generate() {
		$pair   = sodium_crypto_sign_keypair();
		$secret = sodium_crypto_sign_secretkey( $pair );
		$public = sodium_crypto_sign_publickey( $pair );
		$nonce  = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		update_option(
			self::OPTION,
			array(
				'public'  => base64_encode( $public ), // phpcs:ignore
				'secret'  => base64_encode( $nonce . sodium_crypto_secretbox( $secret, $nonce, self::wrap_key() ) ), // phpcs:ignore
				'created' => time(),
			),
			false
		);
		// Every cached branded build embeds the public key.
		if ( class_exists( 'ALS_Releases' ) ) {
			ALS_Releases::clear_builds();
		}
	}

	public static function public_key() {
		$k = get_option( self::OPTION );
		return is_array( $k ) && ! empty( $k['public'] ) ? $k['public'] : '';
	}

	public static function created() {
		$k = get_option( self::OPTION );
		return is_array( $k ) && ! empty( $k['created'] ) ? (int) $k['created'] : 0;
	}

	private static function secret() {
		$k = get_option( self::OPTION );
		if ( ! is_array( $k ) || empty( $k['secret'] ) ) {
			return '';
		}
		$raw = base64_decode( $k['secret'], true ); // phpcs:ignore
		if ( ! $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
			return '';
		}
		$plain = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), self::wrap_key() );
		return false === $plain ? '' : $plain;
	}

	public static function b64url( $s ) {
		return rtrim( strtr( base64_encode( $s ), '+/', '-_' ), '=' ); // phpcs:ignore
	}

	/** Sign a payload → "base64url(json).base64url(sig)". */
	public static function sign( array $payload ) {
		$sk = self::secret();
		if ( ! $sk ) {
			return new WP_Error( 'als_keys', 'کلید امضای سرور در دسترس نیست (احتمالاً Salt‌های wp-config تغییر کرده است). از تنظیمات، کلید جدید بسازید.' );
		}
		$body = self::b64url( wp_json_encode( $payload ) );
		return $body . '.' . self::b64url( sodium_crypto_sign_detached( $body, $sk ) );
	}

	/** HMAC for signed download URLs. */
	public static function hmac( $data ) {
		return hash_hmac( 'sha256', $data, wp_salt( 'secure_auth' ) . '|als-dl' );
	}
}
