<?php
/**
 * Store settings.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ALS_Settings {

	const OPTION = 'als_settings';

	public static function defaults() {
		return array(
			'product_name'   => 'ARIAGH.AIWRITER',
			'landing_page'   => 0,
			'buy_url'        => '',
			'support_url'    => '',
			'docs_url'       => '',
			'trial_days'     => 7,
			'trial_articles' => 5,
			'grace_days'     => 14,
			'dev_free'       => 1,
			'landing_canvas' => 1,
			'email_manual'   => 1,
			'brand_color'    => '#1D4ED8',
			'hero_title'     => 'هر روز یک مقاله حرفه‌ای و سئوشده، بدون اینکه حتی یک کلمه بنویسید',
			'hero_text'      => 'ARIAGH.AIWRITER سایت شما را تحلیل می‌کند، موضوعات پرجستجو و کلمات کلیدی را پیدا می‌کند و طبق زمان‌بندی، مقاله کامل با تصویر، فهرست مطالب، FAQ و متای سئو را در پیش‌نویس وردپرس آماده تایید شما می‌گذارد.',
		);
	}

	public static function all() {
		$s = get_option( self::OPTION, array() );
		return array_merge( self::defaults(), is_array( $s ) ? $s : array() );
	}

	public static function get( $k ) {
		$a = self::all();
		return isset( $a[ $k ] ) ? $a[ $k ] : null;
	}

	public static function save( array $in ) {
		$d   = self::defaults();
		$cur = self::all();
		foreach ( $in as $k => $v ) {
			if ( ! array_key_exists( $k, $d ) ) {
				continue;
			}
			if ( is_int( $d[ $k ] ) ) {
				$cur[ $k ] = max( 0, (int) $v );
			} elseif ( in_array( $k, array( 'buy_url', 'support_url', 'docs_url' ), true ) ) {
				$cur[ $k ] = esc_url_raw( trim( (string) $v ) );
			} elseif ( 'brand_color' === $k ) {
				$cur[ $k ] = sanitize_hex_color( $v ) ? sanitize_hex_color( $v ) : $d[ $k ];
			} elseif ( 'hero_text' === $k ) {
				$cur[ $k ] = sanitize_textarea_field( $v );
			} else {
				$cur[ $k ] = sanitize_text_field( $v );
			}
		}
		update_option( self::OPTION, $cur, false );
		return $cur;
	}

	public static function store_url() {
		$p = (int) self::get( 'landing_page' );
		return $p && get_post( $p ) ? get_permalink( $p ) : home_url( '/' );
	}

	public static function buy_url() {
		$u = self::get( 'buy_url' );
		return $u ? $u : self::store_url() . '#pricing';
	}

	public static function account_url() {
		if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
			return wc_get_account_endpoint_url( ALS_Woo::ENDPOINT );
		}
		return self::store_url();
	}

	/** Values written into the client plugin's license-config.php. */
	public static function client_config() {
		return array(
			'product'        => ALS_PRODUCT,
			'product_name'   => self::get( 'product_name' ),
			'api'            => untrailingslashit( rest_url( ALS_API::NS ) ),
			'public_key'     => ALS_Keys::public_key(),
			'store_url'      => self::store_url(),
			'buy_url'        => self::buy_url(),
			'account_url'    => self::account_url(),
			'support_url'    => (string) self::get( 'support_url' ),
			'docs_url'       => (string) self::get( 'docs_url' ),
			'trial_days'     => (int) self::get( 'trial_days' ),
			'trial_articles' => (int) self::get( 'trial_articles' ),
		);
	}
}
