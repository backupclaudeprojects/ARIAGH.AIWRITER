<?php
/**
 * My account → My licenses.
 *
 * @var array $rows
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$rel = ALS_Releases::latest();
?>
<style>
.als-acc{direction:rtl;text-align:right}
.als-acc-card{border:1px solid #E2E8F0;border-radius:14px;padding:18px;margin:0 0 16px;background:#fff}
.als-acc-head{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;margin-bottom:10px}
.als-acc-key{font-family:ui-monospace,Menlo,Consolas,monospace;direction:ltr;display:inline-block;background:#EFF6FF;border:1px solid #DBEAFE;color:#0B1B3F;padding:6px 12px;border-radius:8px;letter-spacing:1px;font-size:15px}
.als-acc-tag{display:inline-block;padding:3px 10px;border-radius:99px;font-size:12px;font-weight:600}
.als-ok{background:#ECFDF5;color:#047857}.als-bad{background:#FEF2F2;color:#B91C1C}
.als-acc-meta{display:flex;flex-wrap:wrap;gap:16px;color:#475569;font-size:13px;margin:6px 0 12px}
.als-acc table{width:100%;border-collapse:collapse;font-size:13px}
.als-acc th,.als-acc td{padding:8px;border-top:1px solid #F1F5F9;text-align:right}
.als-acc .button{margin:2px}
.als-acc-logo{height:26px;width:auto;margin-bottom:12px}
</style>
<div class="als-acc">
	<img class="als-acc-logo" src="<?php echo esc_url( ALS_URL . 'assets/img/logo.svg' ); ?>" alt="ARIAGH.AIWRITER">
	<?php if ( ! $rows ) : ?>
		<p>هنوز لایسنسی برای حساب شما ثبت نشده است.</p>
		<p><a class="button" href="<?php echo esc_url( ALS_Settings::buy_url() ); ?>">مشاهده پلن‌ها و خرید</a></p>
	<?php endif; ?>
	<?php foreach ( $rows as $l ) : ?>
		<?php
		list( $code, $msg ) = ALS_Licenses::problem( $l );
		$acts               = ALS_Licenses::activations( $l['id'] );
		$renew              = ALS_Woo::renew_url( $l );
		?>
		<div class="als-acc-card">
			<div class="als-acc-head">
				<span class="als-acc-key"><?php echo esc_html( $l['license_key'] ); ?></span>
				<span class="als-acc-tag <?php echo $code ? 'als-bad' : 'als-ok'; ?>"><?php echo esc_html( $code ? ( 'expired' === $code ? 'منقضی شده' : 'غیرفعال' ) : 'فعال' ); ?></span>
			</div>
			<div class="als-acc-meta">
				<span>پلن: <b><?php echo esc_html( $l['plan'] ); ?></b></span>
				<span>سایت‌ها: <b><?php echo esc_html( ALS_Licenses::used_sites( $l['id'] ) . ' از ' . ( (int) $l['sites'] ? (int) $l['sites'] : 'نامحدود' ) ); ?></b></span>
				<span>اعتبار: <b><?php echo esc_html( (int) $l['expires_at'] ? wp_date( 'Y/m/d', (int) $l['expires_at'] ) : 'دائمی' ); ?></b></span>
				<?php if ( $l['order_id'] ) : ?><span>سفارش: <b>#<?php echo esc_html( $l['order_id'] ); ?></b></span><?php endif; ?>
			</div>
			<?php if ( $code ) : ?><p style="color:#B91C1C"><?php echo esc_html( $msg ); ?></p><?php endif; ?>
			<form method="post" style="display:inline">
				<?php wp_nonce_field( 'als_account' ); ?>
				<input type="hidden" name="license" value="<?php echo esc_attr( $l['id'] ); ?>">
				<button class="button button-primary" name="als_action" value="download" <?php disabled( (bool) $code || ! $rel ); ?>>دانلود افزونه<?php echo $rel ? ' (نسخه ' . esc_html( $rel['version'] ) . ')' : ''; ?></button>
			</form>
			<?php if ( $renew && ( (int) $l['expires_at'] > 0 ) ) : ?>
				<a class="button" href="<?php echo esc_url( $renew ); ?>">تمدید لایسنس</a>
			<?php endif; ?>
			<?php if ( $acts ) : ?>
				<table>
					<thead><tr><th>دامنه</th><th>نسخه</th><th>آخرین بررسی</th><th></th></tr></thead>
					<tbody>
					<?php foreach ( $acts as $a ) : ?>
						<tr>
							<td dir="ltr" style="text-align:right"><?php echo esc_html( $a['domain'] ); ?><?php echo $a['is_dev'] ? ' <small>(تست)</small>' : ''; ?></td>
							<td><?php echo esc_html( $a['version'] ? $a['version'] : '—' ); ?></td>
							<td><?php echo esc_html( wp_date( 'Y/m/d H:i', strtotime( $a['last_check'] . ' UTC' ) ) ); ?></td>
							<td>
								<form method="post">
									<?php wp_nonce_field( 'als_account' ); ?>
									<input type="hidden" name="license" value="<?php echo esc_attr( $l['id'] ); ?>">
									<input type="hidden" name="domain" value="<?php echo esc_attr( $a['domain'] ); ?>">
									<button class="button" name="als_action" value="release">آزادسازی</button>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p style="color:#64748B;font-size:13px;margin-top:10px">هنوز روی هیچ سایتی فعال نشده است. پس از نصب افزونه، کلید را در «AIWRITER ← لایسنس و حساب» وارد کنید.</p>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>
</div>
