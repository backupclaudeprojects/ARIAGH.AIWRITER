<?php
/**
 * Full-width canvas for the sales page (no theme header/footer).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
	<style>html,body{margin:0;padding:0;background:#fff}</style>
</head>
<body <?php body_class( 'als-canvas' ); ?>>
<?php
while ( have_posts() ) {
	the_post();
	the_content();
}
wp_footer();
?>
</body>
</html>
