<?php
/**
 * Sales landing page for ARIAGH.AIWRITER.
 *
 * @var array $s Settings.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$I       = array( 'ALS_Shortcodes', 'icon' );
$buy     = ALS_Settings::buy_url();
$account = ALS_Settings::account_url();
$rel     = ALS_Releases::latest();
$features = array(
	array( 'search', 'تحلیل هوشمند سایت و رقبا', 'مقالات، محصولات و دسته‌های شما را می‌خواند، سایت رقبا را بررسی می‌کند و شکاف‌های محتوایی و موضوعات پرجستجو را با کلمه کلیدی پیدا می‌کند.' ),
	array( 'clock', 'تولید خودکار طبق زمان‌بندی', 'هر ۱۲ ساعت (یا هر زمانی که بخواهید) یک مقاله کامل آماده می‌شود؛ روی سرور کلادفلر، مستقل از بازدید سایت و بدون فشار روی هاست.' ),
	array( 'review', 'پیش‌نویس برای تایید شما', 'هیچ چیز بدون اجازه شما منتشر نمی‌شود. مقاله در صف بازبینی می‌نشیند؛ با یک کلیک منتشر، زمان‌بندی یا بازنویسی کنید.' ),
	array( 'seo', 'سئوی کامل و استاندارد', 'عنوان و متای سئو، اسلاگ، فهرست مطالب، FAQ با اسکیما، لینک داخلی و سازگاری کامل با Yoast، Rank Math، AIOSEO و SEOPress.' ),
	array( 'image', 'تصویر شاخص اختصاصی', 'برای هر مقاله تصویر شاخص با هوش مصنوعی ساخته و با متن جایگزین مناسب در کتابخانه رسانه ذخیره می‌شود.' ),
	array( 'layers', 'بیش از ۲۰ موتور هوش مصنوعی', 'OpenAI، Claude، Gemini، DeepSeek، Grok، Mistral، OpenRouter، اول‌ای‌آی و… به‌همراه زنجیره پشتیبان خودکار و Workers AI رایگان.' ),
	array( 'user', 'اکانت اشتراکی Claude و ChatGPT', 'اگر API ندارید، با اکانت Claude Pro/Max یا ChatGPT Plus خودتان و ابزارهای رسمی آن‌ها از طریق GitHub Actions مقاله بنویسید.' ),
	array( 'shield', 'امن و حرفه‌ای', 'کلیدهای API فقط در Secrets کلادفلر شما ذخیره می‌شوند و همه ارتباط‌ها با امضای HMAC و محافظت در برابر تکرار انجام می‌شود.' ),
);
$providers = array( 'OpenAI', 'Anthropic Claude', 'Google Gemini', 'DeepSeek', 'xAI Grok', 'Mistral', 'OpenRouter', 'Groq', 'Perplexity', 'Qwen', 'Kimi', 'GLM', 'AvalAI', 'GapGPT', 'Workers AI' );
$faq = array(
	array( 'آیا مقاله‌ها بدون اجازه من منتشر می‌شوند؟', 'خیر. همه مقاله‌ها به‌صورت پیش‌نویس ذخیره می‌شوند و تا شما تایید نکنید منتشر نمی‌شوند. در صورت تمایل می‌توانید انتشار خودکار یا زمان‌بندی‌شده را فعال کنید.' ),
	array( 'به هاست قوی نیاز دارم؟', 'خیر. زمان‌بندی و ارتباط با هوش مصنوعی روی Cloudflare Worker (پلن رایگان کافی است) انجام می‌شود و هاست شما فقط پیش‌نویس نهایی را دریافت می‌کند.' ),
	array( 'هزینه هوش مصنوعی جداست؟', 'افزونه به کلید API خود شما وصل می‌شود؛ هزینه هر مقاله با مدل‌های اقتصادی معمولاً بسیار ناچیز است. گزینه رایگان Workers AI و استفاده از اکانت اشتراکی Claude/ChatGPT هم وجود دارد.' ),
	array( 'روی چند سایت می‌توانم استفاده کنم؟', 'به تعداد سایت‌های پلن خریداری‌شده. سایت‌های لوکال، تست و staging شمرده نمی‌شوند و هر زمان بخواهید می‌توانید لایسنس را از یک دامنه آزاد و روی دامنه دیگر فعال کنید.' ),
	array( 'بعد از پرداخت چطور افزونه را دریافت می‌کنم؟', 'بلافاصله پس از پرداخت، کلید لایسنس در صفحه سفارش و ایمیل شما نمایش داده می‌شود و فایل افزونه از «حساب کاربری ← لایسنس‌های من» قابل دانلود است.' ),
	array( 'به‌روزرسانی‌ها چطور انجام می‌شود؟', 'مثل افزونه‌های مخزن وردپرس؛ نسخه جدید در صفحه افزونه‌ها نمایش داده می‌شود و با یک کلیک نصب می‌شود.' ),
	array( 'امکان تست قبل از خرید هست؟', 'بله. افزونه پس از نصب یک دوره آزمایشی ' . (int) $s['trial_days'] . ' روزه با ' . (int) $s['trial_articles'] . ' مقاله رایگان دارد.' ),
);
?>
<div class="alp" dir="rtl">
	<header class="alp-nav">
		<div class="alp-wrap alp-nav-in">
			<a href="<?php echo esc_url( ALS_Settings::store_url() ); ?>" class="alp-logo"><img src="<?php echo esc_url( ALS_URL . 'assets/img/logo.svg' ); ?>" alt="ARIAGH.AIWRITER" width="200" height="32"></a>
			<nav>
				<a href="#features">امکانات</a>
				<a href="#how">نحوه کار</a>
				<a href="#pricing">قیمت‌ها</a>
				<a href="#faq">سوالات</a>
				<a class="alp-btn alp-btn-sm alp-btn-ghost" href="<?php echo esc_url( $account ); ?>">حساب کاربری</a>
			</nav>
		</div>
	</header>

	<section class="alp-hero">
		<div class="alp-wrap alp-hero-in">
			<div class="alp-hero-text">
				<span class="alp-pill"><?php echo call_user_func( $I, 'spark' ); // phpcs:ignore ?> افزونه وردپرس تولید خودکار محتوا<?php echo $rel ? ' · نسخه ' . esc_html( $rel['version'] ) : ''; ?></span>
				<h1><?php echo esc_html( $s['hero_title'] ); ?></h1>
				<p><?php echo esc_html( $s['hero_text'] ); ?></p>
				<div class="alp-cta">
					<a class="alp-btn alp-btn-primary alp-btn-lg" href="<?php echo esc_url( $buy ); ?>">خرید لایسنس</a>
					<a class="alp-btn alp-btn-ghost alp-btn-lg" href="#how">ببینید چطور کار می‌کند</a>
				</div>
				<ul class="alp-trust">
					<li><?php echo call_user_func( $I, 'check' ); // phpcs:ignore ?> تحویل فوری</li>
					<li><?php echo call_user_func( $I, 'check' ); // phpcs:ignore ?> <?php echo esc_html( (int) $s['trial_days'] ); ?> روز آزمایش رایگان</li>
					<li><?php echo call_user_func( $I, 'check' ); // phpcs:ignore ?> به‌روزرسانی خودکار</li>
				</ul>
			</div>
			<div class="alp-mock" aria-hidden="true">
				<div class="alp-mock-bar"><i></i><i></i><i></i><img src="<?php echo esc_url( ALS_URL . 'assets/img/logo.svg' ); ?>" alt=""></div>
				<div class="alp-mock-body">
					<div class="alp-mock-now"><span class="alp-dot"></span><div><b>الان: در حال نوشتن مقاله</b><small>«راهنمای کامل انتخاب قهوه اسپرسو برای خانه»</small></div></div>
					<div class="alp-mock-row"><span>کلمه کلیدی</span><b>قهوه اسپرسو خانگی</b></div>
					<div class="alp-mock-row"><span>ساختار</span><b>۲٬۱۰۰ کلمه · ۹ سرفصل · FAQ</b></div>
					<div class="alp-mock-row"><span>سئو</span><b class="alp-ok">عنوان، متا، اسکیما</b></div>
					<div class="alp-mock-tl">
						<div><em>امروز ۱۴:۰۰</em>بهترین آسیاب قهوه برقی</div>
						<div><em>فردا ۰۲:۰۰</em>تفاوت عربیکا و روبوستا</div>
						<div><em>فردا ۱۴:۰۰</em>نگهداری صحیح دانه قهوه</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="alp-strip">
		<div class="alp-wrap">
			<span>سازگار با</span>
			<?php foreach ( $providers as $p ) : ?><b><?php echo esc_html( $p ); ?></b><?php endforeach; ?>
		</div>
	</section>

	<section class="alp-sec" id="features">
		<div class="alp-wrap">
			<div class="alp-head"><h2>هر چیزی که برای تولید محتوای حرفه‌ای لازم دارید</h2><p>از پیدا کردن موضوع تا انتشار؛ یک بار تنظیم کنید و محتوای سایت همیشه تازه بماند.</p></div>
			<div class="alp-grid">
				<?php foreach ( $features as $f ) : ?>
					<div class="alp-card"><span class="alp-card-ic"><?php echo call_user_func( $I, $f[0] ); // phpcs:ignore ?></span><h3><?php echo esc_html( $f[1] ); ?></h3><p><?php echo esc_html( $f[2] ); ?></p></div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<section class="alp-sec alp-sec-alt" id="how">
		<div class="alp-wrap">
			<div class="alp-head"><h2>راه‌اندازی در ۵ دقیقه</h2><p>بدون دانش فنی؛ همه مراحل داخل افزونه با راهنمای تصویری و لینک مستقیم.</p></div>
			<ol class="alp-steps">
				<li><b>نصب و فعال‌سازی</b><span>افزونه را نصب کنید و کلید لایسنس را وارد کنید.</span></li>
				<li><b>اتصال کلادفلر</b><span>با یک توکن، ورکر و زمان‌بندی خودکار روی حساب رایگان کلادفلر شما ساخته می‌شود.</span></li>
				<li><b>انتخاب هوش مصنوعی</b><span>کلید API یا اکانت اشتراکی Claude/ChatGPT خود را وصل کنید.</span></li>
				<li><b>تحلیل و شروع</b><span>«تحلیل هوشمند سایت» را بزنید؛ موضوعات با کلمه کلیدی ساخته و طبق برنامه نوشته می‌شوند.</span></li>
			</ol>
		</div>
	</section>

	<section class="alp-sec" id="pricing">
		<div class="alp-wrap">
			<div class="alp-head"><h2>پلن مناسب خود را انتخاب کنید</h2><p>پرداخت یک‌باره برای دوره اعتبار، بدون هزینه پنهان.</p></div>
			<?php echo ALS_Shortcodes::pricing(); // phpcs:ignore ?>
		</div>
	</section>

	<section class="alp-sec alp-sec-alt" id="faq">
		<div class="alp-wrap alp-narrow">
			<div class="alp-head"><h2>سوالات پرتکرار</h2></div>
			<?php foreach ( $faq as $q ) : ?>
				<details class="alp-faq"><summary><?php echo esc_html( $q[0] ); ?></summary><p><?php echo esc_html( $q[1] ); ?></p></details>
			<?php endforeach; ?>
		</div>
	</section>

	<section class="alp-final">
		<div class="alp-wrap">
			<img src="<?php echo esc_url( ALS_URL . 'assets/img/logo-white.svg' ); ?>" alt="ARIAGH.AIWRITER" width="260" height="42">
			<h2>تولید محتوای سایت را به هوش مصنوعی بسپارید</h2>
			<a class="alp-btn alp-btn-white alp-btn-lg" href="<?php echo esc_url( $buy ); ?>">همین حالا شروع کنید</a>
		</div>
	</section>

	<footer class="alp-foot">
		<div class="alp-wrap">
			<span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> ARIAGH · همه حقوق محفوظ است.</span>
			<span>
				<?php if ( $s['support_url'] ) : ?><a href="<?php echo esc_url( $s['support_url'] ); ?>">پشتیبانی</a><?php endif; ?>
				<?php if ( $s['docs_url'] ) : ?><a href="<?php echo esc_url( $s['docs_url'] ); ?>">راهنما</a><?php endif; ?>
				<a href="<?php echo esc_url( $account ); ?>">لایسنس‌های من</a>
			</span>
		</div>
	</footer>
</div>
