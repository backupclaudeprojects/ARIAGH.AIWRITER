<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$s        = ALS_Settings::all();
$post_url = admin_url( 'admin-post.php' );
$pages    = get_pages( array( 'post_status' => 'publish' ) );
?>
<div class="als-cols">
	<section class="als-card">
		<h2>تنظیمات فروشگاه</h2>
		<form method="post" action="<?php echo esc_url( $post_url ); ?>" class="als-form">
			<?php wp_nonce_field( 'als_settings' ); ?><input type="hidden" name="action" value="als_save_settings">
			<?php ALS_Admin::field( 's[product_name]', 'نام محصول', $s['product_name'] ); ?>
			<label class="als-f"><span>صفحه فروش</span><select name="s[landing_page]"><option value="0">—</option><?php foreach ( $pages as $p ) : ?><option value="<?php echo esc_attr( $p->ID ); ?>" <?php selected( (int) $s['landing_page'], $p->ID ); ?>><?php echo esc_html( $p->post_title ); ?></option><?php endforeach; ?></select><small>صفحه‌ای که شورت‌کد [ariagh_landing] دارد</small></label>
			<?php ALS_Admin::field( 's[landing_canvas]', 'نمایش تمام‌صفحه (بدون هدر و فوتر قالب)', $s['landing_canvas'], 'checkbox' ); ?>
			<?php ALS_Admin::field( 's[hero_title]', 'تیتر اصلی صفحه فروش', $s['hero_title'] ); ?>
			<?php ALS_Admin::field( 's[hero_text]', 'متن معرفی', $s['hero_text'], 'textarea' ); ?>
			<?php ALS_Admin::field( 's[brand_color]', 'رنگ برند', $s['brand_color'], 'color' ); ?>
			<?php ALS_Admin::field( 's[buy_url]', 'لینک خرید (اختیاری)', $s['buy_url'], 'url', 'پیش‌فرض: بخش قیمت‌های صفحه فروش' ); ?>
			<?php ALS_Admin::field( 's[support_url]', 'لینک پشتیبانی / تیکت', $s['support_url'], 'url' ); ?>
			<?php ALS_Admin::field( 's[docs_url]', 'لینک راهنما / آموزش', $s['docs_url'], 'url' ); ?>
			<div class="als-grid2">
				<?php ALS_Admin::field( 's[trial_days]', 'روزهای آزمایشی', $s['trial_days'], 'number', '0 = بدون دوره آزمایشی' ); ?>
				<?php ALS_Admin::field( 's[trial_articles]', 'مقالات آزمایشی', $s['trial_articles'], 'number' ); ?>
				<?php ALS_Admin::field( 's[grace_days]', 'مهلت آفلاین (روز)', $s['grace_days'], 'number', 'اگر سایت مشتری به سرور شما دسترسی نداشته باشد، تا این مدت کار می‌کند' ); ?>
			</div>
			<?php ALS_Admin::field( 's[dev_free]', 'سایت‌های لوکال/تست/staging سهمیه مصرف نکنند', $s['dev_free'], 'checkbox' ); ?>
			<?php ALS_Admin::field( 's[email_manual]', 'پیش‌فرض ارسال ایمیل برای لایسنس دستی', $s['email_manual'], 'checkbox' ); ?>
			<button class="button button-primary">ذخیره</button>
		</form>
	</section>
	<section class="als-card">
		<h2>اتصال افزونه مشتریان</h2>
		<p class="als-muted">این مقادیر هنگام دانلود، داخل افزونه مشتری قرار می‌گیرند. نیازی به ویرایش دستی فایل نیست.</p>
		<table class="als-table">
			<?php foreach ( ALS_Settings::client_config() as $k => $v ) : ?>
				<tr><td><code><?php echo esc_html( $k ); ?></code></td><td dir="ltr" style="word-break:break-all"><?php echo esc_html( is_scalar( $v ) ? (string) $v : '' ); ?></td></tr>
			<?php endforeach; ?>
		</table>
		<h2 style="margin-top:22px">کلید امضا</h2>
		<p class="als-muted">ساخته‌شده در <?php echo esc_html( ALS_Keys::created() ? wp_date( 'Y/m/d H:i', ALS_Keys::created() ) : '—' ); ?>. کلید خصوصی رمزنگاری‌شده در دیتابیس ذخیره است و هرگز از سرور خارج نمی‌شود.</p>
		<details class="als-danger-zone"><summary>ساخت کلید جدید (فقط در صورت افشای کلید)</summary>
			<p>پس از تعویض، همه نسخه‌های نصب‌شده فعلی لایسنس را نامعتبر می‌دانند تا مشتری نسخه جدید را از حساب کاربری دانلود کند.</p>
			<form method="post" action="<?php echo esc_url( $post_url ); ?>" onsubmit="return confirm('مطمئن هستید؟');"><?php wp_nonce_field( 'als_keys' ); ?><input type="hidden" name="action" value="als_regen_keys"><button class="button als-danger">ساخت کلید جدید</button></form>
		</details>
	</section>
</div>
