<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$post_url = admin_url( 'admin-post.php' );
$all      = ALS_Releases::all();
$latest   = ALS_Releases::latest();
?>
<div class="als-cols">
	<section class="als-card">
		<h2>انتشار نسخه جدید</h2>
		<p class="als-muted">ZIP افزونه ARIAGH.AIWRITER (پوشه <code><?php echo esc_html( ALS_CLIENT_SLUG ); ?></code>) را بارگذاری کنید. شماره نسخه از هدر افزونه خوانده می‌شود. هنگام دانلود، فایل <code>license-config.php</code> با آدرس همین سرور و کلید عمومی شما داخل آن قرار می‌گیرد.</p>
		<form method="post" action="<?php echo esc_url( $post_url ); ?>" enctype="multipart/form-data" class="als-form">
			<?php wp_nonce_field( 'als_release' ); ?><input type="hidden" name="action" value="als_upload_release">
			<label class="als-f"><span>فایل ZIP</span><input type="file" name="zip" accept=".zip" required></label>
			<?php ALS_Admin::field( 'tested', 'تست‌شده تا وردپرس', get_bloginfo( 'version' ) ); ?>
			<?php ALS_Admin::field( 'changelog', 'تغییرات این نسخه (HTML ساده مجاز)', '', 'textarea' ); ?>
			<button class="button button-primary">انتشار</button>
		</form>
	</section>
	<section class="als-card">
		<h2>نسخه‌ها</h2>
		<?php if ( $latest ) : ?>
			<form method="post" action="<?php echo esc_url( $post_url ); ?>" style="margin-bottom:12px">
				<?php wp_nonce_field( 'als_build' ); ?><input type="hidden" name="action" value="als_download_build">
				<button class="button">دانلود نسخه برندشده <?php echo esc_html( $latest['version'] ); ?> (برای تست خودتان)</button>
			</form>
		<?php endif; ?>
		<table class="als-table">
			<thead><tr><th>نسخه</th><th>تاریخ</th><th>نیازمندی</th><th></th></tr></thead>
			<tbody>
			<?php foreach ( $all as $r ) : ?>
				<tr>
					<td><b><?php echo esc_html( $r['version'] ); ?></b><?php echo $latest && $latest['version'] === $r['version'] ? ' <span class="als-tag is-ok">جاری</span>' : ''; ?></td>
					<td><?php echo esc_html( wp_date( 'Y/m/d', (int) $r['date'] ) ); ?></td>
					<td>WP <?php echo esc_html( $r['requires'] ); ?>+ · PHP <?php echo esc_html( $r['requires_php'] ); ?>+</td>
					<td><form method="post" action="<?php echo esc_url( $post_url ); ?>" onsubmit="return confirm('این نسخه حذف شود؟');"><?php wp_nonce_field( 'als_release_del' ); ?><input type="hidden" name="action" value="als_delete_release"><input type="hidden" name="version" value="<?php echo esc_attr( $r['version'] ); ?>"><button class="button-link als-danger">حذف</button></form></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( ! $all ) : ?><tr><td colspan="4" class="als-muted">هنوز نسخه‌ای منتشر نشده است.</td></tr><?php endif; ?>
			</tbody>
		</table>
	</section>
</div>
