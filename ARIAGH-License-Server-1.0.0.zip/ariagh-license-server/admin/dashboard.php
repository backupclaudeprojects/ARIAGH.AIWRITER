<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$st      = ALS_Licenses::stats();
$rel     = ALS_Releases::latest();
$woo     = class_exists( 'WooCommerce' );
$plans   = $woo ? ALS_Woo::plans() : array();
$landing = (int) ALS_Settings::get( 'landing_page' );
$has_lp  = $landing && get_post( $landing );
$checks  = array(
	array( (bool) ALS_Keys::public_key(), 'کلید امضای Ed25519 ساخته شد', '' ),
	array( (bool) $rel, 'نسخه افزونه برای فروش بارگذاری شده' . ( $rel ? ' (' . $rel['version'] . ')' : '' ), ALS_Admin::url( 'releases' ) ),
	array( $woo, 'ووکامرس نصب و فعال است (برای پرداخت آنلاین و درگاه)', admin_url( 'plugin-install.php?s=woocommerce&tab=search&type=term' ) ),
	array( (bool) $plans, 'حداقل یک محصول با گزینه «لایسنس AIWRITER» ساخته شده', $woo ? admin_url( 'post-new.php?post_type=product' ) : '' ),
	array( $has_lp, 'صفحه فروش ساخته شده', '' ),
	array( (bool) ALS_Settings::get( 'support_url' ), 'لینک پشتیبانی تنظیم شده', ALS_Admin::url( 'settings' ) ),
);
?>
<div class="als-stats">
	<div><small>کل لایسنس‌ها</small><b><?php echo esc_html( number_format_i18n( $st['total'] ) ); ?></b></div>
	<div><small>لایسنس فعال</small><b><?php echo esc_html( number_format_i18n( $st['active'] ) ); ?></b></div>
	<div><small>سایت‌های فعال</small><b><?php echo esc_html( number_format_i18n( $st['sites'] ) ); ?></b></div>
	<div><small>انقضا تا ۳۰ روز</small><b><?php echo esc_html( number_format_i18n( $st['expiring'] ) ); ?></b></div>
	<div><small>فروش این ماه</small><b><?php echo esc_html( number_format_i18n( $st['month'] ) ); ?></b></div>
</div>

<div class="als-cols">
	<section class="als-card">
		<h2>راه‌اندازی فروشگاه</h2>
		<ul class="als-check">
			<?php foreach ( $checks as $c ) : ?>
				<li class="<?php echo $c[0] ? 'is-ok' : ''; ?>"><i></i><span><?php echo esc_html( $c[1] ); ?></span><?php echo ( ! $c[0] && $c[2] ) ? '<a href="' . esc_url( $c[2] ) . '">انجام</a>' : ''; ?></li>
			<?php endforeach; ?>
		</ul>
		<?php if ( ! $has_lp ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'als_landing' ); ?><input type="hidden" name="action" value="als_create_landing">
				<button class="button button-primary button-hero">ساخت صفحه فروش حرفه‌ای با یک کلیک</button>
			</form>
		<?php else : ?>
			<p><a class="button button-primary" href="<?php echo esc_url( get_permalink( $landing ) ); ?>" target="_blank">مشاهده صفحه فروش</a> <a class="button" href="<?php echo esc_url( get_edit_post_link( $landing ) ); ?>">ویرایش صفحه</a></p>
		<?php endif; ?>
	</section>
	<section class="als-card">
		<h2>روند فروش چطور کار می‌کند؟</h2>
		<ol class="als-flow">
			<li>مشتری در صفحه فروش پلن را انتخاب و از درگاه ووکامرس (زرین‌پال، آیدی‌پی، بانک‌ها…) پرداخت می‌کند.</li>
			<li>بلافاصله کلید لایسنس صادر و در صفحه تشکر، ایمیل سفارش و «حساب کاربری ← لایسنس‌های من» نمایش داده می‌شود.</li>
			<li>مشتری افزونه را از حساب کاربری دانلود می‌کند؛ این فایل به‌صورت خودکار به همین سرور و کلید عمومی شما متصل است.</li>
			<li>کلید را در افزونه وارد می‌کند؛ دامنه ثبت و توکن امضاشده صادر می‌شود. افزونه روزانه وضعیت را بررسی می‌کند.</li>
			<li>با انتشار نسخه جدید در تب «نسخه‌ها»، همه مشتریان دارای لایسنس معتبر به‌روزرسانی یک‌کلیکی دریافت می‌کنند.</li>
			<li>استرداد یا لغو سفارش، لایسنس را باطل می‌کند؛ ۷ روز قبل از انقضا ایمیل یادآوری تمدید ارسال می‌شود.</li>
		</ol>
		<p class="als-muted">شورت‌کدها: <code>[ariagh_landing]</code> صفحه فروش کامل · <code>[ariagh_pricing]</code> فقط جدول قیمت</p>
	</section>
</div>
