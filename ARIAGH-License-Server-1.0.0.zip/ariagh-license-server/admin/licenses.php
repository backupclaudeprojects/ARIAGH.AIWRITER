<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$post_url = admin_url( 'admin-post.php' );
$id       = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0; // phpcs:ignore
$lic      = $id ? ALS_Licenses::get( $id ) : null;

if ( $lic ) :
	global $wpdb;
	$acts   = ALS_Licenses::activations( $id );
	$events = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ALS_DB::t( 'events' ) . ' WHERE license_id = %d ORDER BY id DESC LIMIT 50', $id ), ARRAY_A ); // phpcs:ignore
	list( $code, $msg ) = ALS_Licenses::problem( $lic );
	?>
	<p><a href="<?php echo esc_url( ALS_Admin::url( 'licenses' ) ); ?>">← بازگشت به فهرست</a></p>
	<div class="als-cols">
		<section class="als-card">
			<h2><code class="als-key"><?php echo esc_html( $lic['license_key'] ); ?></code> <span class="als-tag <?php echo $code ? 'is-bad' : 'is-ok'; ?>"><?php echo esc_html( $code ? $msg : 'فعال' ); ?></span></h2>
			<form method="post" action="<?php echo esc_url( $post_url ); ?>" class="als-form">
				<?php wp_nonce_field( 'als_update' ); ?>
				<input type="hidden" name="action" value="als_update_license"><input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
				<div class="als-grid2">
					<?php ALS_Admin::field( 'email', 'ایمیل مشتری', $lic['customer_email'], 'email' ); ?>
					<?php ALS_Admin::field( 'name', 'نام مشتری', $lic['customer_name'] ); ?>
					<?php ALS_Admin::field( 'plan', 'پلن', $lic['plan'] ); ?>
					<?php ALS_Admin::field( 'sites', 'تعداد سایت (0 = نامحدود)', $lic['sites'], 'number' ); ?>
					<?php ALS_Admin::field( 'expires', 'تاریخ انقضا (خالی = دائمی)', $lic['expires_at'] ? gmdate( 'Y-m-d', (int) $lic['expires_at'] ) : '', 'date' ); ?>
					<label class="als-f"><span>وضعیت</span><select name="status"><option value="active" <?php selected( $lic['status'], 'active' ); ?>>فعال</option><option value="revoked" <?php selected( $lic['status'], 'revoked' ); ?>>باطل‌شده</option></select></label>
					<label class="als-f"><span>تمدید سریع</span><select name="extend"><option value="">—</option><option value="1">۱ ماه</option><option value="3">۳ ماه</option><option value="6">۶ ماه</option><option value="12">۱۲ ماه</option></select></label>
					<?php ALS_Admin::field( 'resend', 'ارسال مجدد ایمیل لایسنس', 0, 'checkbox' ); ?>
				</div>
				<?php ALS_Admin::field( 'notes', 'یادداشت داخلی', $lic['notes'], 'textarea' ); ?>
				<p class="als-muted">سفارش: <?php echo $lic['order_id'] ? '<a href="' . esc_url( admin_url( 'post.php?post=' . (int) $lic['order_id'] . '&action=edit' ) ) . '">#' . esc_html( $lic['order_id'] ) . '</a>' : 'دستی'; ?> · ایجاد: <?php echo esc_html( $lic['created_at'] ); ?> UTC</p>
				<button class="button button-primary">ذخیره تغییرات</button>
			</form>
			<form method="post" action="<?php echo esc_url( $post_url ); ?>" onsubmit="return confirm('این لایسنس و همه فعال‌سازی‌های آن حذف شود؟');" style="margin-top:10px">
				<?php wp_nonce_field( 'als_delete' ); ?><input type="hidden" name="action" value="als_delete_license"><input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
				<button class="button-link als-danger">حذف لایسنس</button>
			</form>
		</section>
		<section class="als-card">
			<h2>سایت‌های فعال (<?php echo esc_html( ALS_Licenses::used_sites( $id ) . ' از ' . ( (int) $lic['sites'] ? (int) $lic['sites'] : 'نامحدود' ) ); ?>)</h2>
			<?php if ( ! $acts ) : ?><p class="als-muted">هنوز فعال‌سازی نشده است.</p><?php endif; ?>
			<table class="als-table">
				<?php foreach ( $acts as $a ) : ?>
					<tr>
						<td dir="ltr"><a href="<?php echo esc_url( $a['site_url'] ); ?>" target="_blank"><?php echo esc_html( $a['domain'] ); ?></a><?php echo $a['is_dev'] ? ' <em>تست</em>' : ''; ?></td>
						<td>v<?php echo esc_html( $a['version'] ); ?> · WP <?php echo esc_html( $a['wp'] ); ?> · PHP <?php echo esc_html( $a['php'] ); ?></td>
						<td><?php echo esc_html( $a['last_check'] ); ?></td>
						<td><form method="post" action="<?php echo esc_url( $post_url ); ?>"><?php wp_nonce_field( 'als_act' ); ?><input type="hidden" name="action" value="als_remove_activation"><input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>"><input type="hidden" name="domain" value="<?php echo esc_attr( $a['domain'] ); ?>"><button class="button button-small">آزادسازی</button></form></td>
					</tr>
				<?php endforeach; ?>
			</table>
			<h2 style="margin-top:22px">رویدادها</h2>
			<ul class="als-events">
				<?php foreach ( (array) $events as $e ) : ?>
					<li><time><?php echo esc_html( $e['created_at'] ); ?></time> <b><?php echo esc_html( $e['type'] ); ?></b> <?php echo esc_html( $e['message'] ); ?> <small dir="ltr"><?php echo esc_html( $e['ip'] ); ?></small></li>
				<?php endforeach; ?>
			</ul>
		</section>
	</div>
	<?php
	return;
endif;

$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
$status = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : ''; // phpcs:ignore
$page   = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore
$r      = ALS_Licenses::query( array( 'search' => $search, 'status' => $status, 'page' => $page ) );
?>
<div class="als-cols als-cols-wide">
	<section class="als-card">
		<form method="get" class="als-toolbar">
			<input type="hidden" name="page" value="als"><input type="hidden" name="tab" value="licenses">
			<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="جستجوی کلید، ایمیل، نام یا شماره سفارش">
			<select name="status"><option value="">همه</option><option value="active" <?php selected( $status, 'active' ); ?>>فعال</option><option value="revoked" <?php selected( $status, 'revoked' ); ?>>باطل‌شده</option><option value="expired" <?php selected( $status, 'expired' ); ?>>منقضی</option></select>
			<button class="button">فیلتر</button>
			<span class="als-muted"><?php echo esc_html( number_format_i18n( $r['total'] ) ); ?> لایسنس</span>
		</form>
		<table class="als-table">
			<thead><tr><th>کلید</th><th>مشتری</th><th>پلن</th><th>سایت</th><th>اعتبار</th><th>وضعیت</th></tr></thead>
			<tbody>
			<?php foreach ( $r['rows'] as $l ) : list( $c ) = ALS_Licenses::problem( $l ); ?>
				<tr>
					<td><a href="<?php echo esc_url( ALS_Admin::url( 'licenses', array( 'id' => $l['id'] ) ) ); ?>"><code class="als-key"><?php echo esc_html( $l['license_key'] ); ?></code></a></td>
					<td><?php echo esc_html( $l['customer_name'] ? $l['customer_name'] : '—' ); ?><br><small dir="ltr"><?php echo esc_html( $l['customer_email'] ); ?></small></td>
					<td><?php echo esc_html( $l['plan'] ); ?></td>
					<td><?php echo esc_html( $l['used'] . ' / ' . ( (int) $l['sites'] ? (int) $l['sites'] : '∞' ) ); ?></td>
					<td><?php echo esc_html( (int) $l['expires_at'] ? wp_date( 'Y/m/d', (int) $l['expires_at'] ) : 'دائمی' ); ?></td>
					<td><span class="als-tag <?php echo $c ? 'is-bad' : 'is-ok'; ?>"><?php echo esc_html( $c ? ( 'expired' === $c ? 'منقضی' : 'باطل' ) : 'فعال' ); ?></span></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( ! $r['rows'] ) : ?><tr><td colspan="6" class="als-muted">لایسنسی یافت نشد.</td></tr><?php endif; ?>
			</tbody>
		</table>
		<?php if ( $r['pages'] > 1 ) : ?>
			<p class="als-pages"><?php for ( $i = 1; $i <= $r['pages']; $i++ ) : ?><a class="<?php echo $i === $page ? 'is-on' : ''; ?>" href="<?php echo esc_url( ALS_Admin::url( 'licenses', array( 'paged' => $i, 's' => $search, 'status' => $status ) ) ); ?>"><?php echo esc_html( $i ); ?></a><?php endfor; ?></p>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( $post_url ); ?>"><?php wp_nonce_field( 'als_export' ); ?><input type="hidden" name="action" value="als_export"><button class="button">خروجی CSV</button></form>
	</section>
	<section class="als-card">
		<h2>صدور لایسنس دستی</h2>
		<p class="als-muted">برای فروش حضوری، کارت‌به‌کارت، هدیه یا همکاران. لایسنس‌های فروش آنلاین خودکار صادر می‌شوند.</p>
		<form method="post" action="<?php echo esc_url( $post_url ); ?>" class="als-form">
			<?php wp_nonce_field( 'als_create' ); ?><input type="hidden" name="action" value="als_create_license">
			<?php ALS_Admin::field( 'email', 'ایمیل مشتری', '', 'email' ); ?>
			<?php ALS_Admin::field( 'name', 'نام مشتری', '' ); ?>
			<?php ALS_Admin::field( 'plan', 'پلن', 'استاندارد' ); ?>
			<div class="als-grid2">
				<?php ALS_Admin::field( 'sites', 'تعداد سایت', 1, 'number', '0 = نامحدود' ); ?>
				<?php ALS_Admin::field( 'months', 'اعتبار (ماه)', 12, 'number', '0 = دائمی' ); ?>
			</div>
			<?php ALS_Admin::field( 'notes', 'یادداشت', '', 'textarea' ); ?>
			<?php ALS_Admin::field( 'send', 'ارسال ایمیل لایسنس به مشتری', (int) ALS_Settings::get( 'email_manual' ), 'checkbox' ); ?>
			<button class="button button-primary">صدور لایسنس</button>
		</form>
	</section>
</div>
