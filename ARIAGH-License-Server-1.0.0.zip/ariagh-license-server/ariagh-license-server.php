<?php
/**
 * Plugin Name:       ARIAGH License Server
 * Description:       فروشگاه و سرور لایسنس ARIAGH.AIWRITER: صدور خودکار لایسنس با ووکامرس، فعال‌سازی دامنه، امضای Ed25519، به‌روزرسانی خودکار مشتریان، صفحه فروش و پنل «لایسنس‌های من».
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            ARIAGH
 * License:           GPL-2.0-or-later
 * Text Domain:       ariagh-license-server
 * Update URI:        ariagh-license-server
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ALS_VERSION', '1.0.0' );
define( 'ALS_FILE', __FILE__ );
define( 'ALS_DIR', plugin_dir_path( __FILE__ ) );
define( 'ALS_URL', plugin_dir_url( __FILE__ ) );
define( 'ALS_PRODUCT', 'ariagh-aiwriter' );
define( 'ALS_CLIENT_SLUG', 'aria-ai-writer' );

require_once ALS_DIR . 'includes/class-als-db.php';
require_once ALS_DIR . 'includes/class-als-settings.php';
require_once ALS_DIR . 'includes/class-als-keys.php';
require_once ALS_DIR . 'includes/class-als-licenses.php';
require_once ALS_DIR . 'includes/class-als-releases.php';
require_once ALS_DIR . 'includes/class-als-api.php';
require_once ALS_DIR . 'includes/class-als-woo.php';
require_once ALS_DIR . 'includes/class-als-shortcodes.php';
require_once ALS_DIR . 'includes/class-als-admin.php';

register_activation_hook( __FILE__, array( 'ALS_DB', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'ALS_DB', 'deactivate' ) );

add_action(
	'plugins_loaded',
	function () {
		ALS_DB::maybe_upgrade();
		ALS_API::init();
		ALS_Woo::init();
		ALS_Shortcodes::init();
		if ( is_admin() ) {
			ALS_Admin::init();
		}
	}
);
