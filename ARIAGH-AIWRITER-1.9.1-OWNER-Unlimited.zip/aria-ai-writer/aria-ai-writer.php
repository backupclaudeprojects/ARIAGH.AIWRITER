<?php
/**
 * Plugin Name:       ARIAGH.AIWRITER
 * Description:       نویسنده هوشمند مقالات سئو برای وردپرس: تولید خودکار مقالات حرفه‌ای با هوش مصنوعی، زمان‌بندی روی Cloudflare، تحلیل هوشمند سایت و رقبا، و ذخیره در پیش‌نویس برای تایید شما.
 * Version:           1.9.1
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            ARIAGH
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       aria-ai-writer
 * Domain Path:       /languages
 * Update URI:        ariagh-aiwriter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AAW_VERSION', '1.9.1' );
define( 'AAW_DB_VERSION', '1.0.0' );
define( 'AAW_FILE', __FILE__ );
define( 'AAW_DIR', plugin_dir_path( __FILE__ ) );
define( 'AAW_URL', plugin_dir_url( __FILE__ ) );
define( 'AAW_SLUG', 'aria-ai-writer' );
define( 'AAW_CAP', 'aaw_manage' );

require_once AAW_DIR . 'includes/class-aaw-crypto.php';
require_once AAW_DIR . 'includes/class-aaw-settings.php';
require_once AAW_DIR . 'includes/class-aaw-providers.php';
require_once AAW_DIR . 'includes/class-aaw-icons.php';
require_once AAW_DIR . 'includes/class-aaw-topics.php';
require_once AAW_DIR . 'includes/class-aaw-dedupe.php';
require_once AAW_DIR . 'includes/class-aaw-logs.php';
require_once AAW_DIR . 'includes/class-aaw-errors.php';
require_once AAW_DIR . 'includes/class-aaw-security.php';
require_once AAW_DIR . 'includes/class-aaw-license.php';
require_once AAW_DIR . 'includes/class-aaw-transfer.php';
require_once AAW_DIR . 'includes/class-aaw-cloudflare.php';
require_once AAW_DIR . 'includes/class-aaw-github.php';
require_once AAW_DIR . 'includes/class-aaw-pull.php';
require_once AAW_DIR . 'includes/class-aaw-activity.php';
require_once AAW_DIR . 'includes/class-aaw-bg.php';
require_once AAW_DIR . 'includes/class-aaw-images.php';
require_once AAW_DIR . 'includes/class-aaw-knowledge.php';
require_once AAW_DIR . 'includes/class-aaw-products.php';
require_once AAW_DIR . 'includes/class-aaw-revise.php';
require_once AAW_DIR . 'includes/class-aaw-priority.php';
require_once AAW_DIR . 'includes/class-aaw-sitedata.php';
require_once AAW_DIR . 'includes/class-aaw-gsc.php';
require_once AAW_DIR . 'includes/class-aaw-merge.php';
require_once AAW_DIR . 'includes/class-aaw-proc.php';
require_once AAW_DIR . 'includes/class-aaw-local.php';
require_once AAW_DIR . 'includes/class-aaw-analyzer.php';
require_once AAW_DIR . 'includes/class-aaw-timeline.php';
require_once AAW_DIR . 'includes/class-aaw-prompt.php';
require_once AAW_DIR . 'includes/class-aaw-post-builder.php';
require_once AAW_DIR . 'includes/class-aaw-notifier.php';
require_once AAW_DIR . 'includes/class-aaw-rest.php';
require_once AAW_DIR . 'includes/class-aaw-features.php';
require_once AAW_DIR . 'includes/class-aaw-admin.php';
require_once AAW_DIR . 'includes/class-aaw-ajax.php';
require_once AAW_DIR . 'includes/class-aaw-installer.php';
require_once AAW_DIR . 'includes/class-aaw-plugin.php';

register_activation_hook( __FILE__, array( 'AAW_Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'AAW_Installer', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'AAW_Plugin', 'instance' ) );
