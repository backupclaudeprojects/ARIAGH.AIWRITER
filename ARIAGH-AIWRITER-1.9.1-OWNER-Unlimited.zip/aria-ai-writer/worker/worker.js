/**
 * ARIAGH.AIWRITER – Cloudflare Worker
 * ------------------------------------------------------------
 * - Runs on a Cron Trigger (schedule is managed from the WordPress plugin).
 * - Pulls the next topic + compiled prompts from WordPress (HMAC signed).
 * - Calls the configured AI provider (keys live ONLY in Cloudflare Secrets),
 *   with retries and a fallback provider chain.
 * - Optionally generates a featured image (Workers AI / OpenAI Images).
 * - Pushes the finished article back to WordPress as a draft.
 *
 * Bindings (set automatically by the plugin on deploy):
 *   AAW_KV (KV), AI (Workers AI, optional), WP_API, ALLOWED_ORIGIN, SITE_URL, AAW_VERSION
 * Secrets:
 *   AAW_SHARED_SECRET, AAW_KEY_<PROVIDER> …
 */

const SIGN_WINDOW = 300; // seconds
const enc = new TextEncoder();

const CODE_VERSION = '1.9.1';

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const cors = corsHeaders(env, request);

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors });
    }
    if (request.method === 'GET' && (url.pathname === '/' || url.pathname === '/health')) {
      return json({ ok: true, service: 'aria-ai-writer', version: env.AAW_VERSION || 'dev', code: CODE_VERSION, bg: !!env.AAW_JOBS, gzip: true, parts: true, chunks: true, relay: true, shrink: !!env.IMAGES, time: Date.now() }, 200, cors);
    }
    // Unauthenticated upload-speed probe used by the plugin's network diagnosis (body discarded).
    if (request.method === 'POST' && url.pathname === '/ping') {
      const t0 = Date.now();
      const buf = await request.arrayBuffer();
      return json({ ok: true, bytes: buf.byteLength, ms: Date.now() - t0 }, 200, cors);
    }
    if (request.method !== 'POST') {
      return json({ ok: false, error: 'Method not allowed' }, 405, cors);
    }

    const route = url.pathname.replace(/^\/+|\/+$/g, '');
    let body;
    try { body = await readBody(request, env); } catch (e) { return json({ ok: false, error: 'Body: ' + errMsg(e) }, 400, cors); }
    const auth = await verifySigned(env, request, route, body);
    if (auth !== true) {
      return json({ ok: false, error: auth }, 401, cors);
    }
    let payload = {};
    try { payload = body ? JSON.parse(body) : {}; } catch (e) { return json({ ok: false, error: 'Invalid JSON' }, 400, cors); }

    const handle = async () => {
      switch (route) {
        case 'run': {
          const result = await runCycle(env, 'manual', payload);
          return [{ ok: true, result }, 200];
        }
        case 'test': {
          const t0 = Date.now();
          const p = payload.provider;
          const r = await callAI(env, p, [
            { role: 'system', content: 'You are a connectivity test.' },
            { role: 'user', content: 'Reply with exactly: OK' },
          ], { temperature: 0, max_tokens: 60, timeout: 60, retries: 0, json_mode: false });
          return [{ ok: true, text: (r.text || '').slice(0, 200), ms: Date.now() - t0, usage: r.usage }, 200];
        }
        case 'models': {
          const list = await listModels(env, payload.provider);
          return [{ ok: true, models: list }, 200];
        }
        case 'status': {
          return [{ ok: true, ...(await status(env)) }, 200];
        }
        case 'suggest': {
          const ideas = await generateIdeas(env, payload.runtime, payload.prompt);
          return [{ ok: true, topics: ideas }, 200];
        }
        case 'generate': {
          const out = await generateArticle(env, payload.runtime, payload.job);
          return [{ ok: true, article: out.article, meta: out.meta }, 200];
        }
        case 'revise': {
          const article = await reviseArticle(env, payload.runtime, payload.system, payload.prompt);
          return [{ ok: true, article }, 200];
        }
        case 'image': {
          const image = await generateImage(env, payload.cfg || {}, payload.article || {}, payload.refs || {});
          return [{ ok: true, image }, 200];
        }
        case 'codex_auth': {
          if (!env.AAW_KV) return [{ ok: false, error: 'KV binding missing' }, 500];
          if (payload.action === 'put' && typeof payload.data === 'string' && payload.data.length < 64000) {
            JSON.parse(payload.data);
            await env.AAW_KV.put('codex_auth', payload.data);
            return [{ ok: true }, 200];
          }
          return [{ ok: true, data: (await env.AAW_KV.get('codex_auth')) || '' }, 200];
        }
        case 'login_status': {
          // ChatGPT sign-in progress (one-time code shown in WordPress), kept 1 hour.
          if (!env.AAW_KV) return [{ ok: false, error: 'KV binding missing' }, 500];
          const id = String(payload.id || '').replace(/[^a-z0-9]/gi, '').slice(0, 40);
          if (!id) return [{ ok: false, error: 'id required' }, 400];
          if (payload.action === 'put') {
            const d = payload.data || {};
            const clean = { state: String(d.state || '').slice(0, 20), url: String(d.url || '').slice(0, 300), code: String(d.code || '').slice(0, 20), error: String(d.error || '').slice(0, 600), detail: String(d.detail || '').slice(0, 600), at: Number(d.at) || Date.now() };
            await env.AAW_KV.put('ls:' + id, JSON.stringify(clean), { expirationTtl: 3600 });
            return [{ ok: true }, 200];
          }
          const v = await env.AAW_KV.get('ls:' + id);
          return [{ ok: true, status: v ? JSON.parse(v) : { state: 'waiting' } }, 200];
        }
        // ---- Local/Pull mode mailbox (WordPress <-> GitHub runner via KV) ----
        case 'queue_put':
        case 'queue_get':
        case 'result_put':
        case 'result_list':
        case 'result_ack': {
          if (!env.AAW_KV) return [{ ok: false, error: 'KV binding missing' }, 500];
          const id = String(payload.id || '').replace(/[^a-z0-9]/gi, '').slice(0, 40);
          if (route === 'queue_put') {
            if (!id) return [{ ok: false, error: 'id required' }, 400];
            await env.AAW_KV.put('pq:' + id, JSON.stringify(payload.payload || {}), { expirationTtl: 86400 });
            return [{ ok: true }, 200];
          }
          if (route === 'queue_get') {
            const v = id ? await env.AAW_KV.get('pq:' + id) : null;
            if (v) return [{ ok: true, payload: JSON.parse(v) }, 200];
            return [{ ok: false, error: 'job not found (expired?)' }, 404];
          }
          if (route === 'result_put') {
            if (!id) return [{ ok: false, error: 'id required' }, 400];
            // Big images become separate blobs so the mailbox itself stays tiny.
            await storeMailbox(env, id, payload.data || {});
            return [{ ok: true }, 200];
          }
          if (route === 'result_list') {
            // Slow / time-limited hosts: only small mailboxes are inlined; bigger ones are
            // fetched with result_get in short ranged requests (payload.compact = new plugins).
            const list = await env.AAW_KV.list({ prefix: 'pr:', limit: 20 });
            const items = [];
            let budget = payload.compact ? Math.max(4096, Number(payload.inline_max) || 12000) : Infinity;
            for (const k of list.keys) {
              const v = await env.AAW_KV.get(k.name);
              if (!v) continue;
              if (v.length <= budget) { items.push({ id: k.name.slice(3), size: v.length, data: JSON.parse(v) }); budget -= v.length; }
              else items.push({ id: k.name.slice(3), size: v.length, big: true });
            }
            return [{ ok: true, items }, 200];
          }
          const ids = Array.isArray(payload.ids) ? payload.ids : [];
          for (const x of ids.slice(0, 50)) {
            const clean = String(x).replace(/[^a-z0-9]/gi, '');
            try {
              const v = await env.AAW_KV.get('pr:' + clean);
              const blobs = v ? (JSON.parse(v)._blobs || []) : [];
              for (const b of blobs.slice(0, 40)) await env.AAW_KV.delete('bl:' + String(b).replace(/[^a-z0-9]/gi, ''));
            } catch (_) { /* ignore */ }
            await env.AAW_KV.delete('pr:' + clean);
            await env.AAW_KV.delete('pq:' + clean);
          }
          return [{ ok: true }, 200];
        }
        case 'gsc': {
          // Google Search Console (read-only): sites | report | text.
          if (payload.action === 'sites') {
            const oa = await gscOAuth(env);
            return [{ ok: true, sites: await gscSites(env), email: oa ? (oa.email || '') : gscCreds(env).client_email, mode: oa ? 'oauth' : 'sa' }, 200];
          }
          const site = String(payload.site || '');
          if (!site) return [{ ok: false, error: 'property required' }, 400];
          const rep = payload.action === 'report' ? await gscReport(env, site, Math.min(480, Math.max(7, Number(payload.days) || 90))) : await gscCached(env, site);
          if (payload.action === 'report' && env.AAW_KV) await env.AAW_KV.put('gsc:report', JSON.stringify(rep));
          if (payload.action === 'text') return [{ ok: true, text: gscText(rep) }, 200];
          const body = JSON.stringify(rep);
          return [{ ok: true, size: body.length, totals: rep.totals, counts: { top: rep.top.length, striking: rep.striking.length, low_ctr: rep.low_ctr.length, cannibal: rep.cannibal.length, pages: rep.pages.length } }, 200];
        }
        case 'gsc_oauth': {
          // Sign in with a Google account (OAuth Client ID/Secret). The browser returns to WordPress
          // with ?code=…; WordPress hands the code here and Cloudflare exchanges it (Google is never
          // contacted from the host). Only the refresh token is kept, in this worker's KV.
          if (!env.AAW_KV) return [{ ok: false, error: 'KV binding missing' }, 500];
          if (payload.action === 'disconnect') { await env.AAW_KV.delete('gsc_oauth'); gscTok = { t: '', exp: 0 }; return [{ ok: true }, 200]; }
          if (payload.action === 'status') { const oa = await gscOAuth(env); return [{ ok: true, connected: !!oa, email: oa ? oa.email || '' : '', client: !!env.AAW_GSC_CLIENT_ID }, 200]; }
          if (!env.AAW_GSC_CLIENT_ID || !env.AAW_GSC_CLIENT_SECRET) return [{ ok: false, error: 'Client ID / Client Secret گوگل هنوز روی ورکر ثبت نشده است (چند ثانیه بعد از ذخیره دوباره تلاش کنید).' }, 400];
          const code = String(payload.code || ''); const redirect = String(payload.redirect_uri || '');
          if (!code || !/^https:\/\//.test(redirect)) return [{ ok: false, error: 'code / redirect_uri required' }, 400];
          const r = await gscGoogleToken({ grant_type: 'authorization_code', code, redirect_uri: redirect, client_id: env.AAW_GSC_CLIENT_ID, client_secret: env.AAW_GSC_CLIENT_SECRET });
          if (!r.ok || !r.d.access_token) return [{ ok: false, error: gscOAuthErr(r.d, r.status) }, 400];
          let email = '';
          try { if (r.d.id_token) email = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(r.d.id_token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')), (ch) => ch.charCodeAt(0)))).email || ''; } catch (_) { /* optional */ }
          const prev = await gscOAuth(env);
          const refresh = r.d.refresh_token || (prev && prev.refresh_token);
          if (!refresh) return [{ ok: false, error: 'گوگل refresh token نداد. در myaccount.google.com/permissions دسترسی این برنامه را حذف و دوباره «ورود با حساب گوگل» را بزنید.' }, 400];
          if (!String(r.d.scope || 'webmasters').includes('webmasters')) return [{ ok: false, error: 'اجازه دسترسی به سرچ کنسول داده نشد؛ در صفحه گوگل تیک «View Search Console data» را بزنید.' }, 400];
          await env.AAW_KV.put('gsc_oauth', JSON.stringify({ refresh_token: refresh, email, at: Date.now() }));
          gscTok = { t: r.d.access_token, exp: Date.now() + (Number(r.d.expires_in) || 3600) * 1000, mode: 'oauth' };
          return [{ ok: true, email }, 200];
        }
        case 'gsc_get': {
          // Ranged read of the stored report (slow hosts download it in short pieces).
          if (!env.AAW_KV) return [{ ok: false, error: 'KV binding missing' }, 500];
          const v = await env.AAW_KV.get('gsc:report');
          if (v === null) return [{ ok: false, code: 'not_found', error: 'report not found' }, 404];
          const off = Math.max(0, Number(payload.offset) || 0);
          const len = Math.min(1048576, Math.max(1024, Number(payload.len) || 32768));
          return [{ ok: true, data: v.slice(off, off + len), total: v.length }, 200];
        }
        case 'result_get': {
          // One slice of a stored mailbox (JSON text), for hosts that cut long downloads.
          if (!env.AAW_KV) return [{ ok: false, error: 'KV binding missing' }, 500];
          const id = String(payload.id || '').replace(/[^a-z0-9]/gi, '').slice(0, 40);
          const v = id ? await env.AAW_KV.get('pr:' + id) : null;
          if (v === null) return [{ ok: false, code: 'not_found', error: 'result not found (expired?)' }, 404];
          const off = Math.max(0, Number(payload.offset) || 0);
          const len = Math.min(1048576, Math.max(1024, Number(payload.len) || 32768));
          return [{ ok: true, data: v.slice(off, off + len), total: v.length }, 200];
        }
        case 'blob_del': {
          if (!env.AAW_KV) return [{ ok: false, error: 'KV binding missing' }, 500];
          for (const k of (Array.isArray(payload.keys) ? payload.keys : []).slice(0, 40)) await env.AAW_KV.delete('bl:' + String(k).replace(/[^a-z0-9]/gi, ''));
          return [{ ok: true }, 200];
        }
        case 'relay': {
          // Big uploads from slow hosts (GitHub files, worker updates): the host sends a small
          // gzip'd, chunked request here and Cloudflare performs the real call at full speed.
          const target = String(payload.url || '');
          if (!/^https:\/\/(api\.github\.com|api\.cloudflare\.com)\//.test(target)) return [{ ok: false, error: 'relay target not allowed' }, 400];
          const method = String(payload.method || 'GET').toUpperCase();
          const headers = {};
          for (const [k, v] of Object.entries(payload.headers || {})) if (/^[a-z0-9-]{1,40}$/i.test(k) && !/^(host|content-length|connection)$/i.test(k)) headers[k] = String(v);
          if (!headers['User-Agent']) headers['User-Agent'] = 'ARIAGH-AIWRITER-Relay';
          const init = { method, headers };
          if (method !== 'GET' && method !== 'HEAD' && payload.body !== undefined && payload.body !== null) init.body = typeof payload.body === 'string' ? payload.body : JSON.stringify(payload.body);
          const res = await timedFetch(target, init, 120);
          const text = await res.text();
          return [{ ok: true, status: res.status, body: text.slice(0, 300000) }, 200];
        }
        case 'site_put': {
          // Compact site index built by the GitHub runner from the site backup (links + dedupe for API engines).
          if (!env.AAW_KV) return [{ ok: false, error: 'KV binding missing' }, 500];
          if (!payload.index || !Array.isArray(payload.index.posts)) return [{ ok: false, error: 'index required' }, 400];
          await env.AAW_KV.put('site:index', JSON.stringify(payload.index));
          siteCache = { at: 0, v: null };
          return [{ ok: true, counts: payload.index.counts || {} }, 200];
        }
        case 'complete': {
          const r = await completeAny(env, payload.runtime || {}, payload.system || '', payload.prompt || '', payload.params || {});
          return [{ ok: true, ...r }, 200];
        }
        case 'competitors': {
          return [{ ok: true, ...(await fetchCompetitors(payload.urls || [])) }, 200];
        }
        case 'analyze': {
          const out = await analyzeSite(env, payload);
          return [{ ok: true, ...out }, 200];
        }
        case 'diag': {
          return [{ ok: true, diag: await diagnose(env) }, 200];
        }
        // ---- Background jobs (Durable Object alarm, up to 15 min, no long client connection) ----
        case 'bg_start': {
          if (!env.AAW_JOBS) return [{ ok: false, code: 'no_bg', error: 'Background jobs are not enabled on this worker (redeploy from the plugin).' }, 501];
          if (!env.AAW_KV) return [{ ok: false, error: 'KV binding missing' }, 500];
          const id = String(payload.id || '').replace(/[^a-z0-9]/gi, '').slice(0, 40);
          if (!id || !BG_KINDS.includes(payload.kind)) return [{ ok: false, error: 'id and valid kind required' }, 400];
          await env.AAW_KV.put('bj:' + id, JSON.stringify({ status: 'queued', kind: payload.kind, at: Date.now() }), { expirationTtl: 86400 });
          const stub = env.AAW_JOBS.get(env.AAW_JOBS.idFromName(id));
          const r = await stub.fetch('https://jobs/start', { method: 'POST', body: JSON.stringify({ id, kind: payload.kind, payload: payload.payload || {}, mailbox: !!payload.mailbox }) });
          if (!r.ok) return [{ ok: false, error: 'Could not schedule background job: ' + (await r.text()).slice(0, 200) }, 500];
          return [{ ok: true, id, queued: true }, 200];
        }
        // Small signed pieces of a large request (slow/limited upstream links): stored for 1 hour.
        case 'part': {
          if (!env.AAW_KV) return [{ ok: false, error: 'KV binding missing' }, 500];
          const t = String(payload.t || '').replace(/[^a-z0-9]/gi, '').slice(0, 40);
          const n = Number(payload.n);
          if (!t || !Number.isInteger(n) || n < 0 || n > 400 || typeof payload.data !== 'string') return [{ ok: false, error: 'bad part' }, 400];
          await env.AAW_KV.put('pt:' + t + ':' + n, payload.data, { expirationTtl: 3600 });
          return [{ ok: true }, 200];
        }
        case 'blob_get': {
          if (!env.AAW_KV) return [{ ok: false, error: 'KV binding missing' }, 500];
          const key = String(payload.key || '').replace(/[^a-z0-9]/gi, '').slice(0, 60);
          const v = key ? await env.AAW_KV.get('bl:' + key) : null;
          if (v === null) return [{ ok: false, code: 'not_found', error: 'blob not found (expired?)' }, 404];
          const off = Math.max(0, Number(payload.offset) || 0);
          const len = Math.min(1048576, Math.max(1024, Number(payload.len) || 262144));
          if (payload.del && off + len >= v.length) env.AAW_KV.delete('bl:' + key).catch(() => {});
          return [{ ok: true, data: v.slice(off, off + len), total: v.length }, 200];
        }
        case 'bg_get': {
          if (!env.AAW_KV) return [{ ok: false, error: 'KV binding missing' }, 500];
          const id = String(payload.id || '').replace(/[^a-z0-9]/gi, '').slice(0, 40);
          const v = id ? await env.AAW_KV.get('bj:' + id) : null;
          if (!v) return [{ ok: false, code: 'not_found', error: 'background job not found (expired?)' }, 404];
          return [{ ok: true, job: JSON.parse(v) }, 200];
        }
        case 'unlock': {
          if (env.AAW_KV) await env.AAW_KV.delete('lock');
          return [{ ok: true }, 200];
        }
        default:
          return [{ ok: false, error: 'Unknown route' }, 404];
      }
    };

    // Long-running routes can stream: keep-alive bytes every few seconds so that
    // hosting proxies / NAT / firewalls never see an idle connection (prevents
    // "cURL error 52: Empty reply from server" and timeouts on long AI calls).
    const LONG = ['run', 'test', 'models', 'suggest', 'generate', 'image', 'competitors', 'analyze', 'diag', 'revise', 'complete', 'relay'];
    if (request.headers.get('X-AAW-Stream') === '1' && LONG.includes(route)) {
      return streamed(ctx, async () => {
        const [data] = await handle();
        return data;
      }, cors, Number(env.AAW_KEEPALIVE_MS) || 5000);
    }
    try {
      const [data, status] = await handle();
      return json(data, status, cors);
    } catch (err) {
      return json({ ok: false, error: errMsg(err) }, 500, cors);
    }
  },

  async scheduled(event, env, ctx) {
    ctx.waitUntil(
      runCycle(env, 'cron', { cron: event.cron }).catch(async (e) => {
        await remember(env, { at: Date.now(), trigger: 'cron', status: 'error', error: errMsg(e) });
      })
    );
  },
};

/* ============================================================
 * Main cycle
 * ============================================================ */

async function runCycle(env, trigger, opts = {}) {
  const started = Date.now();
  if (!env.WP_API) throw new Error('WP_API binding is missing. Redeploy from the plugin.');

  // Soft lock (prevents overlapping cron executions).
  if (env.AAW_KV && trigger === 'cron') {
    const lock = await env.AAW_KV.get('lock');
    if (lock && Date.now() - Number(lock) < 14 * 60 * 1000) {
      return { status: 'locked' };
    }
    await env.AAW_KV.put('lock', String(Date.now()), { expirationTtl: 900 });
  }

  const summary = { trigger, status: 'ok', drafts: [], errors: [], at: started };
  try {
    let job = await wpCall(env, 'job', { trigger, topic_id: opts.topic_id || 0 });

    if (job.status === 'need_topics' && job.ideas) {
      const ideas = await generateIdeas(env, job.runtime, job.ideas.prompt);
      if (ideas.length) {
        await wpCall(env, 'topics', { topics: ideas });
        summary.ideas = ideas.length;
      }
      job = await wpCall(env, 'job', { trigger, no_ideas: true });
    }

    if (job.status !== 'ok') {
      summary.status = job.status;
      summary.reason = job.reason || '';
      if (job.url) summary.url = job.url;
      await remember(env, summary);
      return summary;
    }

    for (const j of job.jobs) {
      const t0 = Date.now();
      let meta = {};
      try {
        const out = await generateArticle(env, job.runtime, j);
        meta = out.meta;
        const article = out.article;

        if (job.runtime.image && job.runtime.image.enabled) {
          try {
            const img = await generateImage(env, job.runtime.image, article, j.images || {});
            if (img && img.inline) { article.inline_images = img.inline; delete img.inline; }
            article.image = img;
          } catch (e) {
            meta.image_error = errMsg(e);
          }
        }
        meta.duration_ms = Date.now() - t0;
        const res = await wpCall(env, 'draft', { topic_id: j.topic.id, article, meta });
        summary.drafts.push({ topic: j.topic.title, post_id: res.post_id, title: res.title, edit_url: res.edit_url });
      } catch (e) {
        const msg = errMsg(e);
        summary.errors.push({ topic: j.topic.title, error: msg });
        meta.duration_ms = Date.now() - t0;
        try { await wpCall(env, 'fail', { topic_id: j.topic.id, error: msg, meta }); } catch (_) { /* ignore */ }
      }
    }
    summary.status = summary.errors.length && !summary.drafts.length ? 'error' : 'ok';
  } catch (e) {
    summary.status = 'error';
    summary.errors.push({ error: errMsg(e) });
  } finally {
    summary.ms = Date.now() - started;
    if (env.AAW_KV && trigger === 'cron') {
      try { await env.AAW_KV.delete('lock'); } catch (_) { /* ignore */ }
    }
  }
  await remember(env, summary);
  return summary;
}



/* ============================================================
 * Google Search Console (service account → signed JWT → read-only Search Analytics)
 * Runs on Cloudflare: Google APIs are reached from here, never from the WordPress host.
 * ============================================================ */
let gscTok = { t: '', exp: 0 };
const b64u = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const b64uStr = (s) => b64u(new TextEncoder().encode(s));
function gscCreds(env) {
  if (!env.AAW_GSC_KEY) throw new Error(env.AAW_GSC_CLIENT_ID ? 'سرچ کنسول هنوز با حساب گوگل وصل نشده است؛ «ورود با حساب گوگل» را بزنید.' : 'سرچ کنسول وصل نیست (نه Client ID ثبت شده نه کلید Service Account).');
  let j; try { j = JSON.parse(env.AAW_GSC_KEY); } catch (_) { throw new Error('کلید سرچ کنسول (JSON) خراب است؛ دوباره ذخیره کنید.'); }
  if (!j.client_email || !j.private_key) throw new Error('فایل JSON سرچ کنسول کامل نیست (client_email/private_key).');
  return j;
}
async function gscOAuth(env) {
  if (!env.AAW_GSC_CLIENT_ID || !env.AAW_GSC_CLIENT_SECRET || !env.AAW_KV) return null;
  try { const v = JSON.parse((await env.AAW_KV.get('gsc_oauth')) || 'null'); return v && v.refresh_token ? v : null; } catch (_) { return null; }
}
async function gscGoogleToken(form) {
  const res = await timedFetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(form).toString() }, 30);
  const d = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, d };
}
const gscOAuthErr = (d, status) => {
  const e = String(d.error || status);
  if (e === 'invalid_grant') return 'اجازه دسترسی گوگل منقضی یا لغو شده است (invalid_grant). «ورود با حساب گوگل» را دوباره بزنید؛ اگر هر ۷ روز تکرار می‌شود، در Google Auth Platform → Audience برنامه را Publish (In production) کنید.';
  if (e === 'invalid_client' || e === 'unauthorized_client') return 'Client ID یا Client Secret اشتباه است (' + e + '). هر دو را دوباره از Google Auth Platform → Clients کپی و ذخیره کنید.';
  if (e === 'redirect_uri_mismatch') return 'آدرس بازگشت (Redirect URI) در Google Cloud با آدرس نمایش‌داده‌شده در افزونه یکی نیست (redirect_uri_mismatch).';
  return 'گوگل اجازه را نداد: ' + (d.error_description || e);
};
async function gscToken(env) {
  const oa = await gscOAuth(env);
  const mode = oa ? 'oauth' : 'sa';
  if (gscTok.t && gscTok.mode === mode && Date.now() < gscTok.exp - 60000) return gscTok.t;
  if (oa) {
    const r = await gscGoogleToken({ grant_type: 'refresh_token', refresh_token: oa.refresh_token, client_id: env.AAW_GSC_CLIENT_ID, client_secret: env.AAW_GSC_CLIENT_SECRET });
    if (!r.ok || !r.d.access_token) throw new Error('Search Console: ' + gscOAuthErr(r.d, r.status));
    gscTok = { t: r.d.access_token, exp: Date.now() + (Number(r.d.expires_in) || 3600) * 1000, mode };
    return gscTok.t;
  }
  const c = gscCreds(env);
  const now = Math.floor(Date.now() / 1000);
  const head = b64uStr(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claim = b64uStr(JSON.stringify({ iss: c.client_email, scope: 'https://www.googleapis.com/auth/webmasters.readonly', aud: 'https://oauth2.googleapis.com/token', iat: now, exp: now + 3600 }));
  const pem = String(c.private_key).replace(/\\n/g, '\n').replace(/-----[^-]+-----/g, '').replace(/[^A-Za-z0-9+/=]/g, '');
  let key;
  try {
    const der = Uint8Array.from(atob(pem), (ch) => ch.charCodeAt(0));
    key = await crypto.subtle.importKey('pkcs8', der, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
  } catch (_) {
    throw new Error('Search Console: کلید خصوصی Service Account (private_key) خراب ذخیره شده است (Invalid PKCS8). فایل JSON را دوباره کامل جای‌گذاری و ذخیره کنید، یا از روش «Client ID و Client Secret» استفاده کنید.');
  }
  const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, new TextEncoder().encode(head + '.' + claim));
  const jwt = head + '.' + claim + '.' + b64u(sig);
  const res = await timedFetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'grant_type=' + encodeURIComponent('urn:ietf:params:oauth:grant-type:jwt-bearer') + '&assertion=' + jwt }, 30);
  const d = await res.json().catch(() => ({}));
  if (!res.ok || !d.access_token) throw new Error('ورود به گوگل با Service Account ناموفق بود: ' + (d.error_description || d.error || res.status));
  gscTok = { t: d.access_token, exp: Date.now() + (Number(d.expires_in) || 3600) * 1000, mode };
  return gscTok.t;
}
async function gscApi(env, path, body) {
  const t = await gscToken(env);
  const res = await timedFetch('https://www.googleapis.com/webmasters/v3/' + path, { method: body ? 'POST' : 'GET', headers: { Authorization: 'Bearer ' + t, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined }, 60);
  const d = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = (d.error && d.error.message) || res.status;
    if (res.status === 403) throw new Error('سرچ کنسول دسترسی نداد (403): ایمیل Service Account را در Search Console → Settings → Users and permissions به این property اضافه کنید. ' + msg);
    throw new Error('Search Console: ' + msg);
  }
  return d;
}
async function gscSites(env) {
  const d = await gscApi(env, 'sites');
  return (d.siteEntry || []).map((s) => ({ url: s.siteUrl, level: s.permissionLevel }));
}
const gscDay = (n) => new Date(Date.now() - n * 86400000).toISOString().slice(0, 10);
async function gscReport(env, site, days = 90) {
  const range = { startDate: gscDay(days + 3), endDate: gscDay(3) }; // Last ~3 days are not final in GSC.
  const q = (dimensions, rowLimit) => gscApi(env, 'sites/' + encodeURIComponent(site) + '/searchAnalytics/query', { ...range, dimensions, rowLimit, dataState: 'final' });
  const [qs, ps, qp] = await Promise.all([q(['query'], 1000), q(['page'], 500), q(['query', 'page'], 5000)]);
  const row = (r) => ({ k: r.keys, c: r.clicks || 0, i: r.impressions || 0, ctr: Math.round((r.ctr || 0) * 1000) / 10, p: Math.round((r.position || 0) * 10) / 10 });
  const queries = (qs.rows || []).map(row).map((r) => ({ q: r.k[0], c: r.c, i: r.i, ctr: r.ctr, p: r.p }));
  const pages = (ps.rows || []).map(row).map((r) => ({ u: r.k[0], c: r.c, i: r.i, ctr: r.ctr, p: r.p }));
  const totals = queries.reduce((a, r) => ({ c: a.c + r.c, i: a.i + r.i }), { c: 0, i: 0 });
  const striking = queries.filter((r) => r.p >= 4.5 && r.p <= 20 && r.i >= 20).sort((a, b) => b.i - a.i).slice(0, 60);
  const lowCtr = queries.filter((r) => r.p > 0 && r.p < 5 && r.i >= 50 && r.ctr < (r.p < 2 ? 15 : r.p < 3.5 ? 8 : 4)).sort((a, b) => b.i - a.i).slice(0, 40);
  const top = [...queries].sort((a, b) => b.c - a.c || b.i - a.i).slice(0, 60);
  const byQ = new Map();
  for (const r of (qp.rows || []).map(row)) {
    const [query, page] = r.k;
    if (!byQ.has(query)) byQ.set(query, []);
    byQ.get(query).push({ u: page.split('#')[0], c: r.c, i: r.i, p: r.p });
  }
  const cannibal = [];
  for (const [query, list] of byQ) {
    const tot = list.reduce((a, x) => a + x.i, 0);
    const strong = list.filter((x) => x.i >= Math.max(10, tot * 0.12));
    const urls = [...new Set(strong.map((x) => x.u))];
    if (urls.length >= 2 && tot >= 30) cannibal.push({ q: query, i: tot, pages: strong.sort((a, b) => b.i - a.i).slice(0, 4) });
  }
  cannibal.sort((a, b) => b.i - a.i);
  return { site, days, at: Date.now(), range, totals, top, striking, low_ctr: lowCtr, cannibal: cannibal.slice(0, 80), pages: pages.slice(0, 300) };
}
function gscText(rep) {
  if (!rep || !rep.top) return '';
  const f = (r) => `- «${r.q}» — ${r.i} نمایش، ${r.c} کلیک، CTR ${r.ctr}٪، جایگاه ${r.p}`;
  const o = [`\n# داده‌های واقعی گوگل سرچ کنسول (${rep.days} روز اخیر، ${rep.totals.c} کلیک / ${rep.totals.i} نمایش)`];
  if (rep.striking.length) o.push('## فرصت‌های نزدیک به صفحه اول (جایگاه ۵ تا ۲۰ با نمایش بالا) — بالاترین اولویت برای مقاله جدید یا تقویت مقاله موجود\n' + rep.striking.slice(0, 35).map(f).join('\n'));
  if (rep.low_ctr.length) o.push('## جایگاه خوب ولی CTR پایین (عنوان/توضیحات متا باید جذاب‌تر شود)\n' + rep.low_ctr.slice(0, 20).map(f).join('\n'));
  o.push('## پرکلیک‌ترین جستجوهای فعلی\n' + rep.top.slice(0, 30).map(f).join('\n'));
  if (rep.cannibal.length) o.push('## همپوشانی (چند صفحه برای یک جستجو رقابت می‌کنند؛ مقاله تکراری جدید نساز)\n' + rep.cannibal.slice(0, 15).map((c) => `- «${c.q}»: ` + c.pages.map((p) => p.u).join(' ، ')).join('\n'));
  o.push('موضوعات پیشنهادی را بر اساس همین جستجوهای واقعی کاربران بنویس؛ برای فرصت‌هایی که مقاله دارند «تقویت/بازنویسی» پیشنهاد بده نه مقاله تکراری.');
  return o.join('\n');
}
async function gscCached(env, site, maxAgeMs = 12 * 3600000) {
  if (!env.AAW_KV) return gscReport(env, site);
  try {
    const v = JSON.parse((await env.AAW_KV.get('gsc:report')) || 'null');
    if (v && v.site === site && Date.now() - v.at < maxAgeMs) return v;
  } catch (_) { /* refresh */ }
  const rep = await gscReport(env, site);
  await env.AAW_KV.put('gsc:report', JSON.stringify(rep));
  return rep;
}

/* ============================================================
 * Site database (built on GitHub from the public site; stored in KV)
 * ============================================================ */
let siteCache = { at: 0, v: null };
async function siteIndex(env) {
  if (!env.AAW_KV) return null;
  if (siteCache.at && Date.now() - siteCache.at < 300000) return siteCache.v;
  let v = null;
  try { v = JSON.parse((await env.AAW_KV.get('site:index')) || 'null'); } catch (_) { v = null; }
  siteCache = { at: Date.now(), v };
  return v;
}
/* ---------- related content for one article (same logic as the worker) ---------- */
const STOP = new Set(['و', 'در', 'به', 'از', 'که', 'با', 'را', 'این', 'برای', 'آن', 'یا', 'تا', 'هم', 'چه', 'چی', 'چگونه', 'چطور', 'های', 'ها', 'می', 'است', 'کنیم', 'کرد', 'بر', 'یک', 'هر', 'بهترین', 'راهنمای', 'کامل', 'the', 'a', 'an', 'of', 'to', 'in', 'for', 'and', 'how', 'is', 'on', 'with', 'best']);
const toks = (s) => String(s || '').toLowerCase().replace(/[‌]/g, ' ').replace(/[^\p{L}\p{N}\s]/gu, ' ').split(/\s+/).filter((w) => w.length > 1 && !STOP.has(w));
const CTX_MARK = '## داده‌های واقعی سایت';
function siteContext(idx, title, keywords, existing = '') {
  if (!idx || !Array.isArray(idx.posts)) return '';
  const q = new Set(toks(title + ' ' + (Array.isArray(keywords) ? keywords.join(' ') : keywords || '')));
  if (!q.size) return '';
  const sc = (text) => { const s = new Set(toks(text)); let n = 0; for (const w of s) if (q.has(w)) n++; return s.size ? n / Math.sqrt(s.size * q.size) : 0; };
  const tq = new Set(toks(title));
  const titleSim = (t) => { const s = new Set(toks(t)); let n = 0; for (const w of s) if (tq.has(w)) n++; return s.size && tq.size ? (2 * n) / (s.size + tq.size) : 0; };
  const posts = idx.posts.map((p) => ({ p, s: sc(`${p.t} ${p.t} ${(p.c || []).join(' ')} ${(p.tg || []).join(' ')}`) })).filter((x) => x.s > 0.08).sort((a, b) => b.s - a.s);
  const dups = idx.posts.filter((p) => titleSim(p.t) >= 0.7).slice(0, 3);
  const cats = (idx.categories || []).map((c) => ({ c, s: sc(c.n) })).filter((x) => x.s > 0 && x.c.u).sort((a, b) => b.s - a.s).slice(0, 3);
  const lines = [`\n${CTX_MARK} (نسخه پشتیبان GitHub، ${String(idx.crawled_at || '').slice(0, 10)})`];
  if (dups.length) lines.push('هشدار تکرار: این مقاله‌ها موضوع بسیار نزدیکی دارند. مقاله تکراری ننویس؛ زاویه و نیت جستجوی متفاوتی انتخاب کن و به آن‌ها لینک بده:\n' + dups.map((p) => `- ${p.t} => ${p.u}`).join('\n'));
  const rel = posts.filter((x) => !dups.includes(x.p)).slice(0, 6);
  if (rel.length) lines.push('### مقالات مرتبط موجود برای لینک داخلی (۲ تا ۴ لینک با انکر طبیعی و دقیقاً همین آدرس‌ها)\n' + rel.map((x) => `- ${x.p.t} => ${x.p.u}`).join('\n'));
  if (cats.length) lines.push('### دسته‌بندی‌های مرتبط\n' + cats.map((x) => `- ${x.c.n} => ${x.c.u}`).join('\n'));
  if (!/محصولات واقعی فروشگاه/.test(existing) && Array.isArray(idx.products)) {
    const pr = idx.products.map((p) => ({ p, s: sc(`${p.n} ${p.n} ${(p.c || []).join(' ')}`) + (p.s ? 0.01 : 0) })).filter((x) => x.s > 0.09).sort((a, b) => b.s - a.s).slice(0, 4);
    if (pr.length) lines.push('### محصولات مرتبط فروشگاه (با همین آدرس لینک بده؛ قیمت دیگری ننویس؛ برای ناموجود دعوت به خرید نکن)\n' + pr.map((x) => `- ${x.p.n} => ${x.p.u}${x.p.p ? ' | قیمت: ' + x.p.p : ''}${x.p.s ? '' : ' | ناموجود'}`).join('\n'));
  }
  if (lines.length === 1) return '';
  lines.push('هیچ آدرسی از خودت نساز؛ فقط از آدرس‌های بالا استفاده کن.');
  return lines.join('\n') + '\n';
}


/** Plain completion with the first working API provider (used by GitHub jobs without a subscription engine). */
async function completeAny(env, runtime, system, prompt, params = {}) {
  let lastErr = null;
  for (const prov of (runtime && runtime.providers) || []) {
    if (prov.format === 'github_runner') continue;
    try {
      const r = await callAI(env, prov, [{ role: 'system', content: system }, { role: 'user', content: prompt }], { ...(runtime.params || {}), ...params });
      return { text: r.text || '', usage: r.usage, provider: prov.id, model: prov.model };
    } catch (e) { lastErr = e; }
  }
  throw new Error('هیچ هوش مصنوعی API پاسخ نداد: ' + (lastErr ? errMsg(lastErr) : 'زنجیره خالی است'));
}

/* ============================================================
 * Article generation
 * ============================================================ */

async function generateArticle(env, runtime, job) {
  const params = runtime.params || {};
  const chain = runtime.providers || [];
  if (!chain.length) throw new Error('هیچ پرووایدر هوش مصنوعی تنظیم نشده است.');

  const meta = { tokens_in: 0, tokens_out: 0, fallbacks: [] };
  let lastErr = null;
  if (job && job.prompts && !String(job.prompts.user || '').includes(CTX_MARK)) {
    const idx = await siteIndex(env);
    const add = idx ? siteContext(idx, (job.topic && job.topic.title) || '', (job.topic && job.topic.keywords) || '', String(job.prompts.system || '') + job.prompts.user) : '';
    if (add) { job = { ...job, prompts: { ...job.prompts, user: job.prompts.user + add } }; meta.site_data = idx.crawled_at || true; }
  }

  for (const provider of chain) {
    try {
      const system = job.prompts.system;
      let user = job.prompts.user;

      if (params.two_pass && job.prompts.outline) {
        try {
          const o = await callAI(env, provider, [
            { role: 'system', content: system },
            { role: 'user', content: job.prompts.outline },
          ], { ...params, max_tokens: Math.min(3000, params.max_tokens || 3000) });
          addUsage(meta, o.usage);
          const outline = parseJSON(o.text);
          if (outline && (outline.outline || outline.title)) {
            user += '\n\nطرح کلی (Outline) مصوب که باید دقیقاً بر اساس آن بنویسی:\n' + JSON.stringify(outline);
            meta.outline = true;
          }
        } catch (e) {
          meta.outline_error = errMsg(e);
        }
      }

      const r = await callAI(env, provider, [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ], params);
      addUsage(meta, r.usage);

      let article = parseJSON(r.text);
      if (!article || !article.content_html) {
        // Second chance: ask the same model to repair its output into valid JSON.
        const fix = await callAI(env, provider, [
          { role: 'system', content: 'Convert the following article into ONE valid JSON object with keys: title, seo_title, meta_description, slug, focus_keyword, secondary_keywords, tags, category, excerpt, content_html, faq, image_prompt, image_alt. Return JSON only.' },
          { role: 'user', content: r.text.slice(0, 60000) },
        ], { ...params, temperature: 0 });
        addUsage(meta, fix.usage);
        article = parseJSON(fix.text);
      }
      if (!article || !article.content_html) {
        const looksHtml = /<(p|h2|ul)\b/i.test(r.text);
        if (!looksHtml) throw new Error('خروجی مدل قابل تبدیل به مقاله نبود.');
        article = { title: job.topic.title, content_html: r.text };
      }
      if (typeof article.content_html !== 'string') article.content_html = String(article.content_html);
      meta.provider = provider.id;
      meta.model = provider.model;
      return { article, meta };
    } catch (e) {
      lastErr = e;
      meta.fallbacks.push({ provider: provider.id, error: errMsg(e).slice(0, 300) });
    }
  }
  throw new Error('همه پرووایدرها ناموفق بودند: ' + (lastErr ? errMsg(lastErr) : ''));
}

async function generateIdeas(env, runtime, prompt) {
  const chain = (runtime && runtime.providers) || [];
  if (runtime && runtime.gsc && (env.AAW_GSC_KEY || env.AAW_GSC_CLIENT_ID)) {
    try { prompt += gscText(await gscCached(env, runtime.gsc)); } catch (_) { /* ideas still work without it */ }
  }
  let lastErr = null;
  for (const p of chain) {
    try {
      const r = await callAI(env, p, [
        { role: 'system', content: 'You are an SEO content strategist. Return JSON only.' },
        { role: 'user', content: prompt },
      ], { ...(runtime.params || {}), max_tokens: 2500, temperature: 0.8 });
      const data = parseJSON(r.text);
      const list = (data && (data.topics || data.ideas)) || [];
      return list
        .map((t) => (typeof t === 'string' ? { title: t, keywords: [] } : { title: String(t.title || '').trim(), keywords: t.keywords || [] }))
        .filter((t) => t.title);
    } catch (e) { lastErr = e; }
  }
  throw new Error('تولید ایده موضوع ناموفق بود: ' + (lastErr ? errMsg(lastErr) : 'no provider'));
}

/* ============================================================
 * Provider adapters
 * ============================================================ */

function getKey(env, provider) {
  if (!provider.needs_key) return '';
  const key = env[provider.secret];
  if (!key) throw new Error(`کلید API پرووایدر ${provider.name} در Secrets کلادفلر (${provider.secret}) یافت نشد.`);
  return key;
}

async function callAI(env, provider, messages, params = {}) {
  if (!provider) throw new Error('Provider missing');
  const retries = Number.isFinite(params.retries) ? params.retries : 2;
  let attempt = 0;
  let lastErr;
  while (attempt <= retries) {
    try {
      if (provider.format === 'workers_ai') return await callWorkersAI(env, provider, messages, params);
      if (provider.format === 'claude_code') return await callClaudePro(env, provider, messages, params);
      if (provider.format === 'github_runner') throw new Error(provider.name + ' فقط از طریق GitHub Runner اجرا می‌شود.');
      if (provider.format === 'anthropic') return await callAnthropic(env, provider, messages, params);
      return await callOpenAI(env, provider, messages, params);
    } catch (e) {
      lastErr = e;
      if (!e.retryable || attempt === retries) break;
      await sleep(Math.min(20000, 2000 * Math.pow(2, attempt)));
      attempt++;
    }
  }
  throw lastErr;
}

function buildUrl(provider) {
  let u = (provider.base_url || '').replace(/\/+$/, '') + (provider.path || '/chat/completions');
  if (provider.query) u += (u.includes('?') ? '&' : '?') + provider.query;
  return u;
}

function authHeaders(provider, key) {
  const h = {};
  if (!key) return h;
  switch (provider.auth_header) {
    case 'x-api-key': h['x-api-key'] = key; break;
    case 'api-key': h['api-key'] = key; break;
    case 'none': break;
    default: h['Authorization'] = 'Bearer ' + key;
  }
  return h;
}

async function callOpenAI(env, provider, messages, params, variant = {}) {
  const key = getKey(env, provider);
  const body = { model: provider.model, messages };
  if (!variant.noTemperature && params.temperature !== undefined) body.temperature = params.temperature;
  if (!variant.noTemperature && params.top_p !== undefined && params.top_p < 1) body.top_p = params.top_p;
  if (params.max_tokens) {
    if (variant.completionTokens) body.max_completion_tokens = params.max_tokens;
    else body.max_tokens = params.max_tokens;
  }
  if (params.json_mode && provider.json_mode && !variant.noJson) body.response_format = { type: 'json_object' };

  const headers = { 'Content-Type': 'application/json', ...authHeaders(provider, key), ...(provider.headers || {}) };
  if (provider.id === 'openrouter') {
    headers['HTTP-Referer'] = env.SITE_URL || '';
    headers['X-Title'] = 'ARIAGH.AIWRITER';
  }
  const res = await timedFetch(buildUrl(provider), { method: 'POST', headers, body: JSON.stringify(body) }, params.timeout);
  const text = await res.text();
  if (!res.ok) {
    const msg = extractError(text) || `HTTP ${res.status}`;
    // Auto-adapt to newer models / strict providers.
    if (res.status === 400 && !variant.completionTokens && /max_tokens/i.test(msg) && /max_completion_tokens|not supported|unsupported/i.test(msg)) {
      return callOpenAI(env, provider, messages, params, { ...variant, completionTokens: true });
    }
    if (res.status === 400 && !variant.noTemperature && /temperature|top_p/i.test(msg)) {
      return callOpenAI(env, provider, messages, params, { ...variant, noTemperature: true });
    }
    if (res.status === 400 && !variant.noJson && /response_format|json/i.test(msg)) {
      return callOpenAI(env, provider, messages, params, { ...variant, noJson: true });
    }
    throw httpError(provider, res.status, msg);
  }
  let data;
  try { data = JSON.parse(text); } catch (e) { throw new Error(`${provider.name}: پاسخ JSON نامعتبر`); }
  const choice = data.choices && data.choices[0];
  let content = choice && choice.message ? choice.message.content : '';
  if (Array.isArray(content)) content = content.map((c) => c.text || '').join('');
  if (!content) throw Object.assign(new Error(`${provider.name}: پاسخ خالی (finish_reason: ${choice ? choice.finish_reason : 'n/a'})`), { retryable: true });
  return {
    text: content,
    usage: { in: (data.usage && (data.usage.prompt_tokens || data.usage.input_tokens)) || 0, out: (data.usage && (data.usage.completion_tokens || data.usage.output_tokens)) || 0 },
  };
}

async function callAnthropic(env, provider, messages, params) {
  const key = getKey(env, provider);
  const system = messages.filter((m) => m.role === 'system').map((m) => m.content).join('\n\n');
  const msgs = messages.filter((m) => m.role !== 'system').map((m) => ({ role: m.role, content: m.content }));
  const body = { model: provider.model, max_tokens: params.max_tokens || 8000, messages: msgs };
  if (system) body.system = system.length > 4000 ? [{ type: 'text', text: system, cache_control: { type: 'ephemeral' } }] : system;
  if (params.temperature !== undefined) body.temperature = Math.min(1, params.temperature);
  const headers = { 'Content-Type': 'application/json', 'anthropic-version': '2023-06-01', ...authHeaders(provider, key), ...(provider.headers || {}) };
  const res = await timedFetch(buildUrl(provider), { method: 'POST', headers, body: JSON.stringify(body) }, params.timeout);
  const text = await res.text();
  if (!res.ok) throw httpError(provider, res.status, extractError(text) || `HTTP ${res.status}`);
  const data = JSON.parse(text);
  const content = (data.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('');
  if (!content) throw Object.assign(new Error(`${provider.name}: پاسخ خالی`), { retryable: true });
  return { text: content, usage: { in: (data.usage && data.usage.input_tokens) || 0, out: (data.usage && data.usage.output_tokens) || 0 } };
}

/**
 * Claude Pro/Max subscription through the "aria-claude-pro" runner
 * (Claude Code headless inside a Cloudflare Container), reached via Service Binding.
 */
async function callClaudePro(env, provider, messages, params) {
  if (!env.CLAUDE_PRO) throw new Error('Claude Pro به ورکر متصل نیست. در افزونه، بخش Claude Pro را «اتصال» کنید.');
  const system = messages.filter((m) => m.role === 'system').map((m) => m.content).join('\n\n');
  const prompt = messages.filter((m) => m.role !== 'system').map((m) => m.content).join('\n\n');
  const body = JSON.stringify({
    system,
    prompt,
    model: provider.model || 'sonnet',
    fallback_model: provider.fallback_model || '',
    timeout: Math.min(840, Math.max(Number(params.timeout) || 0, 480)),
  });
  const headers = await signHeaders(env, 'generate', body);
  let res;
  try {
    res = await env.CLAUDE_PRO.fetch('https://aria-claude-pro/generate', { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body });
  } catch (e) {
    throw Object.assign(new Error('Claude Pro runner: ' + errMsg(e)), { retryable: true });
  }
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch (_) { /* ignore */ }
  if (!res.ok || !data || !data.ok) {
    const msg = (data && data.error) || text.slice(0, 300) || `HTTP ${res.status}`;
    const e = new Error(`Claude Pro (HTTP ${res.status}): ${msg}`);
    e.status = res.status;
    e.retryable = res.status === 502 || res.status === 503 || res.status === 504;
    throw e;
  }
  if (!data.text) throw Object.assign(new Error('Claude Pro: پاسخ خالی'), { retryable: true });
  return { text: data.text, usage: data.usage || { in: 0, out: 0 } };
}

async function callWorkersAI(env, provider, messages, params) {
  if (!env.AI) throw new Error('Workers AI به ورکر متصل نیست. در افزونه گزینه «اتصال Workers AI» را فعال و ورکر را دوباره مستقر کنید.');
  const input = { messages, max_tokens: Math.min(params.max_tokens || 4096, 8192) };
  if (params.temperature !== undefined) input.temperature = params.temperature;
  let out;
  try {
    out = await env.AI.run(provider.model, input);
  } catch (e) {
    throw Object.assign(new Error('Workers AI: ' + errMsg(e)), { retryable: true });
  }
  let text = out && out.response !== undefined ? out.response : out && out.result && out.result.response;
  if (text && typeof text === 'object') text = JSON.stringify(text);
  if (!text && out && out.choices) text = out.choices[0].message.content;
  if (!text) throw Object.assign(new Error('Workers AI: پاسخ خالی'), { retryable: true });
  const u = (out && out.usage) || {};
  return { text: String(text), usage: { in: u.prompt_tokens || 0, out: u.completion_tokens || 0 } };
}

async function listModels(env, provider) {
  if (!provider) throw new Error('Provider missing');
  if (provider.format === 'claude_code') return ['sonnet', 'opus', 'haiku'];
  if (provider.format === 'workers_ai') {
    return [
      '@cf/meta/llama-3.3-70b-instruct-fp8-fast',
      '@cf/meta/llama-4-scout-17b-16e-instruct',
      '@cf/meta/llama-3.1-8b-instruct-fast',
      '@cf/qwen/qwq-32b',
      '@cf/qwen/qwen2.5-coder-32b-instruct',
      '@cf/mistralai/mistral-small-3.1-24b-instruct',
      '@cf/google/gemma-3-12b-it',
      '@cf/deepseek-ai/deepseek-r1-distill-qwen-32b',
    ];
  }
  const key = getKey(env, provider);
  const headers = { ...authHeaders(provider, key), ...(provider.headers || {}) };
  if (provider.format === 'anthropic') headers['anthropic-version'] = '2023-06-01';
  let url = (provider.base_url || '').replace(/\/+$/, '') + '/models';
  if (provider.query) url += '?' + provider.query;
  const res = await timedFetch(url, { headers }, 30);
  const text = await res.text();
  if (!res.ok) throw httpError(provider, res.status, extractError(text) || `HTTP ${res.status}`);
  const data = JSON.parse(text);
  const arr = data.data || data.models || [];
  return arr.map((m) => (typeof m === 'string' ? m : m.id || m.name)).filter(Boolean).sort();
}

/* ============================================================
 * Images
 * ============================================================ */

/* ============================================================
 * Images – featured + inline, theme-aware, product-reference aware
 * ============================================================ */

// Per-engine reference limits (count / per-file bytes). Products first, then style refs.
const IMG_LIMITS = {
  workers_ai: { refs: 0, bytes: 0 },
  openai: { refs: 16, bytes: 25 * 1024 * 1024 },
  gemini: { refs: 3, bytes: 7 * 1024 * 1024 },
  gemini_pro: { refs: 14, bytes: 7 * 1024 * 1024 },
  higgsfield: { refs: 8, bytes: 10 * 1024 * 1024 },
  fal: { refs: 6, bytes: 8 * 1024 * 1024 },
  custom: { refs: 4, bytes: 10 * 1024 * 1024 },
};

function imgLimit(cfg) {
  if (cfg.engine === 'gemini' && /(^|-)3|pro/i.test(cfg.model || '')) return IMG_LIMITS.gemini_pro;
  return IMG_LIMITS[cfg.engine] || IMG_LIMITS.workers_ai;
}

/** Choose references within the engine limits: product photos first, then a few style samples. */
function pickRefs(cfg, refs) {
  const lim = imgLimit(cfg);
  const max = Math.min(lim.refs, Number(cfg.max_refs || lim.refs));
  const ok = (r) => r && r.b64 && (r.b64.length * 0.75) <= lim.bytes;
  const products = (refs.products || []).filter(ok);
  const styles = (refs.styles || []).filter(ok);
  if (!max) return { list: [], products: [], styles: [] };
  const styleSlots = products.length ? Math.min(styles.length, Math.max(1, Math.floor(max / 4))) : Math.min(styles.length, max);
  const p = products.slice(0, Math.max(0, max - styleSlots));
  const st = styles.slice(0, max - p.length);
  return { list: [...p, ...st], products: p, styles: st };
}

function imagePrompt(cfg, article, picked, refs, focus) {
  const parts = [];
  parts.push(article.image_prompt || article.title || '');
  if (focus) parts.push('Scene for the section: ' + focus);
  const names = (refs.product_names || []).filter(Boolean);
  if (names.length) {
    parts.push(picked.products.length
      ? `Show these exact products as they appear in reference images 1-${picked.products.length} (same packaging, label, color and shape; do not invent new products): ${names.slice(0, picked.products.length).join(', ')}.`
      : `Feature these products naturally: ${names.slice(0, 3).join(', ')}.`);
  }
  if (picked.styles.length) {
    parts.push(`Reference images ${picked.products.length + 1}-${picked.list.length} are existing images from the same website: match their color palette, lighting, props, mood and photographic style exactly so the new image fits the site's visual theme.`);
  }
  if (cfg.theme) parts.push('Site visual theme: ' + cfg.theme);
  if (cfg.style) parts.push(cfg.style);
  parts.push('No text, no letters, no watermark, no logo distortion.');
  return parts.filter(Boolean).join(' ').slice(0, 3800);
}

function aspectOf(cfg) {
  const size = cfg.size || '1536x1024';
  if (size === '1024x1024') return '1:1';
  if (size === '1024x1536') return '2:3';
  return '3:2';
}

function imgKey(env, cfg) {
  const name = cfg.secret;
  if (!name) return '';
  const key = env[name];
  if (!key) throw new Error(`کلید موتور تصویر (${name}) در Secrets کلادفلر یافت نشد. در تب «تصاویر» کلید را ذخیره کنید.`);
  return key;
}

function b64ToBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function urlToImage(url) {
  const res = await timedFetch(url, {}, 60);
  if (!res.ok) throw new Error('Image download HTTP ' + res.status);
  const mime = (res.headers.get('content-type') || 'image/png').split(';')[0];
  return { base64: bytesToBase64(new Uint8Array(await res.arrayBuffer())), mime };
}

async function renderOne(env, cfg, prompt, picked) {
  const engine = cfg.engine || cfg.provider || 'workers_ai';

  if (engine === 'openai' || engine === 'custom') {
    const base = (engine === 'openai' ? ((cfg.openai && cfg.openai.base_url) || 'https://api.openai.com/v1') : (cfg.base_url || '')).replace(/\/+$/, '');
    const key = engine === 'openai' ? (cfg.openai ? getKey(env, cfg.openai) : imgKey(env, cfg)) : imgKey(env, cfg);
    const model = cfg.model || cfg.openai_model || 'gpt-image-1';
    let res;
    if (picked.list.length) {
      const fd = new FormData();
      fd.append('model', model); fd.append('prompt', prompt); fd.append('n', '1'); fd.append('size', cfg.size || '1536x1024');
      if (engine === 'openai' && /^gpt-image/i.test(model)) { fd.append('output_format', 'jpeg'); fd.append('output_compression', '85'); }
      picked.list.forEach((r, i) => fd.append('image[]', new Blob([b64ToBytes(r.b64)], { type: r.mime || 'image/jpeg' }), 'ref' + i + '.jpg'));
      res = await timedFetch(base + '/images/edits', { method: 'POST', headers: { Authorization: 'Bearer ' + key }, body: fd }, 240);
    } else {
      const body = { model, prompt, n: 1, size: cfg.size || '1536x1024' };
      if (engine === 'openai' && /^gpt-image/i.test(model)) { body.output_format = 'jpeg'; body.output_compression = 85; }
      if (/^dall-e/i.test(model)) { body.response_format = 'b64_json'; if (model === 'dall-e-3') body.size = body.size === '1536x1024' ? '1792x1024' : body.size === '1024x1536' ? '1024x1792' : body.size; }
      res = await timedFetch(base + '/images/generations', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key }, body: JSON.stringify(body) }, 240);
    }
    const text = await res.text();
    if (!res.ok) throw new Error('Images (' + engine + '): ' + (extractError(text) || res.status));
    const item = (JSON.parse(text).data || [])[0];
    if (item && item.b64_json) return { base64: item.b64_json, mime: item.b64_json.startsWith('/9j/') ? 'image/jpeg' : 'image/png' };
    if (item && item.url) return urlToImage(item.url);
    throw new Error('Images: empty response');
  }

  if (engine === 'gemini') {
    const key = imgKey(env, cfg);
    const model = cfg.model || 'gemini-2.5-flash-image';
    const parts = [{ text: prompt }];
    picked.list.forEach((r) => parts.push({ inline_data: { mime_type: r.mime || 'image/jpeg', data: r.b64 } }));
    const body = { contents: [{ role: 'user', parts }], generationConfig: { responseModalities: ['IMAGE'], imageConfig: { aspectRatio: aspectOf(cfg) } } };
    const res = await timedFetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify(body) }, 240);
    const text = await res.text();
    if (!res.ok) throw new Error('Gemini Image: ' + (extractError(text) || res.status));
    const cand = (JSON.parse(text).candidates || [])[0];
    const part = cand && cand.content && (cand.content.parts || []).find((x) => x.inline_data || x.inlineData);
    const d = part && (part.inline_data || part.inlineData);
    if (!d) throw new Error('Gemini Image: no image returned' + (cand && cand.finishReason ? ' (' + cand.finishReason + ')' : ''));
    return { base64: d.data, mime: d.mime_type || d.mimeType || 'image/png' };
  }

  if (engine === 'higgsfield') {
    const key = imgKey(env, cfg); // "KEY_ID:KEY_SECRET"
    const auth = { Authorization: 'Key ' + key };
    const urls = [];
    for (const r of picked.list) {
      const up = await timedFetch('https://api.higgsfield.ai/files/generate-upload-url', { method: 'POST', headers: { ...auth, 'Content-Type': 'application/json' }, body: JSON.stringify({ content_type: r.mime || 'image/jpeg' }) }, 30);
      const u = await up.json().catch(() => ({}));
      if (!up.ok || !u.upload_url) throw new Error('Higgsfield upload: ' + (extractError(JSON.stringify(u)) || up.status));
      const put = await timedFetch(u.upload_url, { method: 'PUT', headers: u.upload_headers || { 'Content-Type': r.mime || 'image/jpeg' }, body: b64ToBytes(r.b64) }, 60);
      if (!put.ok) throw new Error('Higgsfield upload PUT HTTP ' + put.status);
      urls.push(u.public_url);
    }
    const endpoint = cfg.model && cfg.model.startsWith('/') ? cfg.model : (urls.length ? '/marketing-studio/image' : '/higgsfield-ai/soul/standard');
    const body = endpoint === '/higgsfield-ai/soul/standard'
      ? { prompt, aspect_ratio: aspectOf(cfg), resolution: '2K', num_images: 1 }
      : { prompt, aspect_ratio: aspectOf(cfg), resolution: '2k', quality: 'high', image_urls: urls };
    const sub = await timedFetch('https://api.higgsfield.ai' + endpoint, { method: 'POST', headers: { ...auth, 'Content-Type': 'application/json' }, body: JSON.stringify(body) }, 60);
    const sj = await sub.json().catch(() => ({}));
    if (!sub.ok) throw new Error('Higgsfield: ' + (extractError(JSON.stringify(sj)) || sub.status));
    const statusUrl = sj.status_url || ('https://api.higgsfield.ai/requests/' + sj.request_id + '/status');
    for (let i = 0; i < 90; i++) {
      if (sj.images && sj.images.length) break;
      await sleep(i < 5 ? 3000 : 6000);
      const st = await timedFetch(statusUrl, { headers: auth }, 30);
      const sd = await st.json().catch(() => ({}));
      if (sd.status === 'completed' && sd.images && sd.images.length) return urlToImage(sd.images[0].url);
      if (['failed', 'nsfw', 'canceled'].includes(sd.status)) throw new Error('Higgsfield: ' + sd.status + (sd.error ? ' – ' + sd.error : ''));
    }
    if (sj.images && sj.images.length) return urlToImage(sj.images[0].url);
    throw new Error('Higgsfield: timed out waiting for the image');
  }

  if (engine === 'fal') {
    const key = imgKey(env, cfg);
    const model = cfg.model || (picked.list.length ? 'fal-ai/nano-banana/edit' : 'fal-ai/flux/schnell');
    const input = { prompt, output_format: 'jpeg' };
    if (picked.list.length) input.image_urls = picked.list.map((r) => `data:${r.mime || 'image/jpeg'};base64,${r.b64}`);
    else input.image_size = aspectOf(cfg) === '1:1' ? 'square_hd' : aspectOf(cfg) === '2:3' ? 'portrait_4_3' : 'landscape_4_3';
    const sub = await timedFetch('https://queue.fal.run/' + model, { method: 'POST', headers: { Authorization: 'Key ' + key, 'Content-Type': 'application/json' }, body: JSON.stringify(input) }, 60);
    const sj = await sub.json().catch(() => ({}));
    if (!sub.ok) throw new Error('fal.ai: ' + (extractError(JSON.stringify(sj)) || sub.status));
    for (let i = 0; i < 90; i++) {
      await sleep(i < 5 ? 2500 : 5000);
      const st = await timedFetch(sj.status_url, { headers: { Authorization: 'Key ' + key } }, 30);
      const sd = await st.json().catch(() => ({}));
      if (sd.status === 'COMPLETED') {
        const rr = await timedFetch(sj.response_url, { headers: { Authorization: 'Key ' + key } }, 30);
        const out = await rr.json();
        const img = (out.images || [])[0] || out.image;
        if (!img || !img.url) throw new Error('fal.ai: no image');
        return img.url.startsWith('data:') ? { base64: img.url.split(',')[1], mime: img.url.slice(5, img.url.indexOf(';')) } : urlToImage(img.url);
      }
      if (sd.status === 'FAILED' || sd.error) throw new Error('fal.ai: ' + (sd.error || 'failed'));
    }
    throw new Error('fal.ai: timed out');
  }

  // Default: Cloudflare Workers AI (free). Text-to-image: theme + product names go into the prompt.
  if (!env.AI) throw new Error('Workers AI binding missing (تب کلادفلر → اتصال Workers AI را روشن و استقرار مجدد کنید)');
  const model = cfg.model && cfg.model.startsWith('@cf/') ? cfg.model : '@cf/black-forest-labs/flux-1-schnell';
  const input = /flux/i.test(model) ? { prompt: prompt.slice(0, 2000), steps: 8 } : { prompt: prompt.slice(0, 2000), num_steps: 20, width: 1024, height: 768 };
  const out = await env.AI.run(model, input);
  if (out && typeof out.image === 'string') return { base64: out.image, mime: 'image/jpeg' };
  const bytes = out instanceof Uint8Array ? out : new Uint8Array(await new Response(out).arrayBuffer());
  return { base64: bytesToBase64(bytes), mime: 'image/png' };
}

/**
 * Featured image (+ optional inline images placed after H2 sections).
 * refs = { products:[{b64,mime}], styles:[{b64,mime}], product_names:[...] } prepared by WordPress.
 */
async function resolveRefs(list) {
  const out = [];
  for (const r of list || []) {
    if (r && r.b64) { out.push(r); continue; }
    if (r && r.url) {
      try {
        const res = await timedFetch(r.url, { headers: { 'User-Agent': 'AriaAIWriter-Worker/refs' } }, 25);
        if (!res.ok) continue;
        const buf = new Uint8Array(await res.arrayBuffer());
        if (buf.length > 100) out.push({ b64: bytesToBase64(buf), mime: (res.headers.get('content-type') || 'image/jpeg').split(';')[0] });
      } catch (_) { /* unreachable reference: skip */ }
    }
  }
  return out;
}

/** Image with the priority list: primary engine, then each fallback engine (same article). */
async function generateImage(env, cfg, article, refs = {}) {
  const list = [cfg].concat(Array.isArray(cfg && cfg.fallbacks) ? cfg.fallbacks : []);
  const tried = [];
  for (const c0 of list) {
    const c = c0 === cfg ? { ...cfg } : { ...cfg, ...c0 };
    delete c.fallbacks;
    try {
      const img = await generateImageOne(env, c, article, refs);
      if (tried.length) img.fallbacks = tried;
      return img;
    } catch (e) { tried.push({ engine: c.engine || c.provider || 'workers_ai', error: errMsg(e).slice(0, 300) }); }
  }
  throw new Error('همه موتورهای تصویر ناموفق بودند: ' + tried.map((t) => t.engine + ': ' + t.error).join(' | '));
}

async function generateImageOne(env, cfg, article, refs = {}) {
  if (cfg.provider && !cfg.engine) cfg = { ...cfg, engine: cfg.provider };
  if (refs && (refs.products || refs.styles) && imgLimit(cfg).refs > 0) {
    refs = { ...refs, products: await resolveRefs(refs.products), styles: await resolveRefs(refs.styles) };
  }
  const picked = pickRefs(cfg, refs || {});
  const featured = await renderOne(env, cfg, imagePrompt(cfg, article, picked, refs || {}, ''), picked);
  featured.engine = cfg.engine || 'workers_ai';
  featured.refs_used = picked.list.length;
  const n = Math.max(0, Math.min(4, Number(cfg.inline_count || 0)));
  if (n) {
    const heads = String(article.content_html || '').match(/<h2[^>]*>[\s\S]*?<\/h2>/gi) || [];
    const step = heads.length > n ? Math.floor(heads.length / (n + 1)) || 1 : 1;
    const inline = [];
    for (let i = 0; i < n && i * step + step - 1 < heads.length; i++) {
      const idx = i * step + (step - 1) + (heads.length > n ? 1 : 0);
      const h = stripTags(heads[Math.min(idx, heads.length - 1)]);
      try {
        const img = await renderOne(env, cfg, imagePrompt(cfg, article, picked, refs || {}, h), picked);
        inline.push({ ...img, after_h2: Math.min(idx, heads.length - 1), alt: h });
      } catch (e) { inline.push({ error: errMsg(e) }); }
    }
    featured.inline = inline.filter((x) => x.base64);
  }
  return featured;
}

/* ============================================================
 * Learn once, reuse: SEO playbook and site visual theme
 * ============================================================ */

/** Apply the editor's instructions to an existing article (returns the full article JSON). */
async function reviseArticle(env, runtime, system, prompt) {
  let lastErr = null;
  for (const prov of (runtime && runtime.providers) || []) {
    if (prov.format === 'github_runner') continue;
    try {
      const r = await callAI(env, prov, [{ role: 'system', content: system }, { role: 'user', content: prompt }], { ...(runtime.params || {}), json_mode: true, temperature: 0.4 });
      const a = parseJSON(r.text);
      if (!a || !a.content_html) throw new Error('خروجی اصلاح ساختار مقاله نداشت.');
      a._meta = { provider: prov.id, model: prov.model, usage: r.usage };
      return a;
    } catch (e) { lastErr = e; }
  }
  throw new Error('اصلاح مقاله ناموفق بود: ' + (lastErr ? errMsg(lastErr) : 'هیچ پرووایدر API در زنجیره نیست'));
}

async function learnSeo(env, p) {
  const sources = (p.sources || []).filter((u) => /^https?:\/\//i.test(u)).slice(0, 14);
  const notes = [];
  const used = [];
  for (const u of sources) {
    try {
      const html = await fetchText(u, 15);
      const title = stripTags((html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || '').slice(0, 140);
      const main = (html.match(/<(article|main)[^>]*>([\s\S]*?)<\/\1>/i) || [])[2] || html;
      const text = stripTags(main).slice(0, 5500);
      if (text.length > 400) { notes.push(`### ${title || u}\n${u}\n${text}`); used.push(u); }
    } catch (_) { /* skip unreachable source */ }
  }
  const today = new Date().toISOString().slice(0, 10);
  const prompt = `امروز ${today} است. تو یک متخصص ارشد سئو هستی. از منابع زیر (راهنماهای رسمی گوگل، مقالات معتبر بین‌المللی و ایرانی)${p.web ? ' و جستجوی زنده وب برای آخرین به‌روزرسانی‌های الگوریتم گوگل' : ''} یک «دستورالعمل فشرده و عملی نوشتن مقاله سئو» برای سایت «${p.site || ''}» در حوزه «${p.niche || ''}» به زبان ${p.language === 'en' ? 'انگلیسی' : 'فارسی'} استخراج کن.
فقط نکاتی که در نوشتن و ساختار مقاله قابل اجراست؛ خلاصه، بدون تکرار، حداکثر ۹۰۰ کلمه. بخش‌ها: ۱) اصول محتوای مفید و E-E-A-T ۲) ساختار، عنوان، متا، سرفصل‌ها و طول ۳) کلمه کلیدی، نیت جستجو و موضوعات مرتبط (بدون Keyword stuffing) ۴) بهینه‌سازی برای AI Overviews و موتورهای پاسخ (GEO): پاسخ مستقیم، تعریف‌ها، جدول، فهرست ۵) اسکیما و FAQ ۶) لینک داخلی/خارجی ۷) نکات خاص زبان فارسی و جستجوی کاربران ایرانی ۸) کارهای ممنوع طبق سیاست‌های اسپم گوگل ۹) چک‌لیست نهایی.
فقط JSON: {"playbook":"متن markdown","highlights":["۵ تغییر/نکته مهم اخیر"],"version":"${today}"}

منابع:
${notes.join('\n\n').slice(0, 60000) || '(منبعی دریافت نشد؛ از دانش به‌روز خود استفاده کن و این را در highlights ذکر کن)'}`;
  let lastErr = null;
  for (const prov of (p.runtime && p.runtime.providers) || []) {
    try {
      const r = await callAI(env, prov, [{ role: 'system', content: 'You are a senior SEO strategist. Return JSON only.' }, { role: 'user', content: prompt }], { ...(p.runtime.params || {}), max_tokens: 4000, temperature: 0.3 });
      const data = parseJSON(r.text) || {};
      const playbook = String(data.playbook || '').trim();
      if (playbook.length < 300) throw new Error('playbook too short');
      return { playbook: playbook.slice(0, 9000), highlights: (data.highlights || []).slice(0, 8), version: data.version || today, sources: used, engine: prov.id, model: prov.model, usage: r.usage };
    } catch (e) { lastErr = e; }
  }
  throw new Error('یادگیری سئو ناموفق بود: ' + (lastErr ? errMsg(lastErr) : 'no provider'));
}

async function learnStyle(env, p) {
  const imgs = (await resolveRefs(p.styles || [])).slice(0, 4);
  const looks = [];
  if (env.AI) {
    for (const im of imgs) {
      try {
        const out = await env.AI.run('@cf/llava-hf/llava-1.5-7b-hf', { image: Array.from(b64ToBytes(im.b64)), prompt: 'Describe the photographic style of this image for an art director: color palette, lighting, background, props, composition, mood. 60 words.', max_tokens: 160 });
        const d = (out && (out.description || out.response)) || '';
        if (d) looks.push(String(d).trim());
      } catch (_) { /* vision unavailable */ }
    }
  }
  const prompt = `Write ONE concise image-generation style guide (max 70 words, English, comma-separated descriptors) that captures the shared visual theme of a website${p.niche ? ' about ' + p.niche : ''}${p.brand ? ' (brand: ' + p.brand + ')' : ''}.
Product names: ${(p.products || []).slice(0, 12).join(', ') || 'n/a'}.
Brand colors: ${(p.colors || []).join(', ') || 'n/a'}.
Observed existing images:\n${looks.map((l, i) => `${i + 1}. ${l}`).join('\n') || '(no vision descriptions available – infer a fitting, consistent style)'}
Return JSON only: {"theme":"..."}`;
  let lastErr = null;
  for (const prov of (p.runtime && p.runtime.providers) || []) {
    try {
      const r = await callAI(env, prov, [{ role: 'system', content: 'You are an art director. Return JSON only.' }, { role: 'user', content: prompt }], { ...(p.runtime.params || {}), max_tokens: 400, temperature: 0.4 });
      const data = parseJSON(r.text) || {};
      if (data.theme) return { theme: String(data.theme).slice(0, 600), observed: looks.length };
    } catch (e) { lastErr = e; }
  }
  if (looks.length) return { theme: looks.join(' ').slice(0, 600), observed: looks.length };
  throw new Error('یادگیری تم تصویری ناموفق بود: ' + (lastErr ? errMsg(lastErr) : 'no provider'));
}

/* ============================================================
 * WordPress communication (HMAC)
 * ============================================================ */

async function wpCall(env, route, payload) {
  const body = JSON.stringify(payload || {});
  const headers = await signHeaders(env, route, body);
  const res = await timedFetch(env.WP_API.replace(/\/+$/, '') + '/' + route, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'User-Agent': 'AriaAIWriter-Worker/' + (env.AAW_VERSION || '1'), ...headers },
    body,
  }, 120);
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch (_) { /* ignore */ }
  if (!res.ok) {
    const msg = (data && (data.error || data.message)) || text.slice(0, 200) || `HTTP ${res.status}`;
    const m = String(msg).match(/error code: (10\d\d)/);
    const hints = {
      '1016': 'کلادفلر نتوانست آدرس (DNS) سایت شما را از داخل شبکه خودش پیدا کند. در تب کلادفلر دکمه «عیب‌یابی اتصال» را بزنید.',
      '1003': 'آدرس سایت به‌صورت IP یا نامعتبر تنظیم شده است.',
      '1020': 'فایروال کلادفلرِ سایت شما (WAF) درخواست ورکر را مسدود کرد؛ مسیر /wp-json/aaw/v1/ را مستثنا کنید.',
      '1010': 'قوانین امنیتی کلادفلر سایت شما (Browser Integrity Check) درخواست را مسدود کرد.',
    };
    throw new Error(`WordPress (${route}): ${msg}` + (m && hints[m[1]] ? ' — ' + hints[m[1]] : ''));
  }
  if (!data) throw new Error(`WordPress (${route}): پاسخ نامعتبر – احتمالاً فایروال یا کش جلوی REST API را گرفته است.`);
  return data;
}

async function hmacHex(secret, message) {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(message));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function signHeaders(env, route, body) {
  if (!env.AAW_SHARED_SECRET) throw new Error('AAW_SHARED_SECRET secret is missing. Redeploy from the plugin.');
  const ts = Math.floor(Date.now() / 1000);
  const nonce = randomId(20);
  const sig = await hmacHex(env.AAW_SHARED_SECRET, `${ts}.${nonce}.${route}.${body}`);
  return { 'X-AAW-Timestamp': String(ts), 'X-AAW-Nonce': nonce, 'X-AAW-Signature': sig };
}

const seenNonces = new Map();
/**
 * Request body: plain text, gzip (X-AAW-Encoding: gzip) or reassembled from
 * previously uploaded parts (X-AAW-Parts: token:count). The HMAC is always over the
 * original uncompressed JSON.
 */
async function readBody(request, env) {
  const parts = request.headers.get('X-AAW-Parts');
  let bytes;
  if (parts) {
    const [t, cnt] = parts.split(':');
    const count = Number(cnt);
    if (!env.AAW_KV || !/^[a-z0-9]{6,40}$/i.test(t || '') || !Number.isInteger(count) || count < 1 || count > 400) throw new Error('invalid parts header');
    const chunks = [];
    let total = 0;
    for (let i = 0; i < count; i++) {
      const b64 = await env.AAW_KV.get('pt:' + t + ':' + i);
      if (b64 === null) throw new Error('missing part ' + i + ' (upload incomplete or expired)');
      const c = b64ToBytes(b64); chunks.push(c); total += c.length;
    }
    bytes = new Uint8Array(total);
    let off = 0;
    for (const c of chunks) { bytes.set(c, off); off += c.length; }
    for (let i = 0; i < count; i++) env.AAW_KV.delete('pt:' + t + ':' + i).catch(() => {});
  } else {
    bytes = new Uint8Array(await request.arrayBuffer());
  }
  if ((request.headers.get('X-AAW-Encoding') || '').toLowerCase() === 'gzip') {
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
    return await new Response(stream).text();
  }
  return new TextDecoder().decode(bytes);
}

async function verifySigned(env, request, route, body) {
  if (!env.AAW_SHARED_SECRET) return 'Worker is not configured (missing shared secret).';
  const ts = Number(request.headers.get('X-AAW-Timestamp') || 0);
  const nonce = request.headers.get('X-AAW-Nonce') || '';
  const sig = request.headers.get('X-AAW-Signature') || '';
  if (!ts || !nonce || !sig) return 'Missing signature';
  if (Math.abs(Date.now() / 1000 - ts) > SIGN_WINDOW) return 'Signature expired';
  if (seenNonces.has(nonce)) return 'Replay detected';
  const expected = await hmacHex(env.AAW_SHARED_SECRET, `${ts}.${nonce}.${route}.${body}`);
  if (!timingSafeEqual(expected, sig)) return 'Bad signature';
  seenNonces.set(nonce, ts);
  if (seenNonces.size > 500) {
    const cutoff = Date.now() / 1000 - SIGN_WINDOW;
    for (const [k, v] of seenNonces) if (v < cutoff) seenNonces.delete(k);
  }
  return true;
}

/* ============================================================
 * Status & history
 * ============================================================ */

/* ============================================================
 * Smart site analysis & competitor research
 * ============================================================ */

function stripTags(s) {
  return String(s || '').replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
}

async function fetchText(url, seconds = 12) {
  const res = await timedFetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; AriaAIWriter/1.4; +content research)', Accept: 'text/html,application/xml;q=0.9,*/*;q=0.8' }, redirect: 'follow' }, seconds);
  if (!res.ok) throw new Error('HTTP ' + res.status);
  return (await res.text()).slice(0, 200000);
}

function slugTitle(u) {
  try {
    const parts = new URL(u).pathname.split('/').filter(Boolean);
    const last = parts.pop() || '';
    return decodeURIComponent(last).replace(/[-_]+/g, ' ').replace(/\.(html?|php)$/i, '').trim();
  } catch (_) { return ''; }
}

async function fetchCompetitors(urls) {
  const list = (Array.isArray(urls) ? urls : []).map((u) => String(u).trim()).filter(Boolean).slice(0, 5);
  const results = [];
  for (let raw of list) {
    if (!/^https?:\/\//i.test(raw)) raw = 'https://' + raw;
    let origin;
    try { origin = new URL(raw).origin; } catch (_) { continue; }
    const item = { url: origin, title: '', description: '', headings: [], articles: [], error: '' };
    try {
      const html = await fetchText(origin);
      item.title = stripTags((html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || '').slice(0, 160);
      item.description = ((html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']*)/i) || [])[1] || '').slice(0, 300);
      const hs = html.match(/<h[1-3][^>]*>[\s\S]*?<\/h[1-3]>/gi) || [];
      item.headings = hs.map(stripTags).filter((x) => x && x.length < 140).slice(0, 25);
    } catch (e) { item.error = 'home: ' + errMsg(e); }
    try {
      let xml = '';
      for (const path of ['/sitemap_index.xml', '/sitemap.xml', '/wp-sitemap.xml']) {
        try { xml = await fetchText(origin + path, 10); if (/<loc>/i.test(xml)) break; } catch (_) { xml = ''; }
      }
      let locs = (xml.match(/<loc>([^<]+)<\/loc>/gi) || []).map((l) => l.replace(/<\/?loc>/gi, '').trim());
      const child = locs.find((l) => /post-sitemap|posts-post|blog|article/i.test(l)) || (locs.every((l) => /\.xml/i.test(l)) ? locs[0] : '');
      if (child && /\.xml/i.test(child)) {
        try { const x2 = await fetchText(child, 10); locs = (x2.match(/<loc>([^<]+)<\/loc>/gi) || []).map((l) => l.replace(/<\/?loc>/gi, '').trim()); } catch (_) { /* ignore */ }
      }
      item.articles = locs.filter((l) => !/\.xml|\/(tag|category|author|page)\//i.test(l)).map(slugTitle).filter((t) => t && t.length > 3).slice(0, 60);
    } catch (e) { item.error += ' sitemap: ' + errMsg(e); }
    results.push(item);
  }
  let text = '';
  for (const r of results) {
    text += `\n### رقیب: ${r.url}\n`;
    if (r.title) text += `عنوان سایت: ${r.title}\n`;
    if (r.description) text += `توضیحات: ${r.description}\n`;
    if (r.headings.length) text += `تیترهای صفحه اصلی: ${r.headings.join(' | ')}\n`;
    if (r.articles.length) text += `مقالات/صفحات (از نقشه سایت): ${r.articles.join(' | ')}\n`;
    if (!r.title && !r.articles.length) text += `(دریافت اطلاعات ناموفق بود: ${r.error})\n`;
  }
  return { competitors: results, text, fetched: results.filter((r) => r.title || r.articles.length).length };
}

async function analyzeSite(env, payload) {
  const runtime = payload.runtime || {};
  const chain = (runtime.providers || []).filter((p) => p.format !== 'github_runner');
  if (!chain.length) throw new Error('برای تحلیل، حداقل یک پرووایدر API یا Workers AI لازم است.');
  let prompt = String(payload.prompt || '');
  if (payload.gsc && (env.AAW_GSC_KEY || env.AAW_GSC_CLIENT_ID)) {
    try { prompt += gscText(await gscCached(env, payload.gsc)); } catch (e) { prompt += '\n(داده سرچ کنسول دریافت نشد: ' + errMsg(e).slice(0, 160) + ')'; }
  }
  let comp = { fetched: 0, text: '' };
  if (Array.isArray(payload.competitors) && payload.competitors.length) {
    comp = await fetchCompetitors(payload.competitors);
    if (comp.text) prompt += '\n\n# داده‌های واقعی جمع‌آوری‌شده از سایت رقبا' + comp.text;
  }
  const params = { ...(runtime.params || {}), max_tokens: Math.max(8000, (runtime.params && runtime.params.max_tokens) || 0), timeout: 300, temperature: 0.6 };
  let lastErr;
  for (const p0 of chain) {
    const p = { ...p0 };
    const web = !!payload.web && (p.id === 'perplexity' || p.id === 'openrouter');
    if (web && p.id === 'openrouter' && !/:online$/.test(p.model)) p.model += ':online';
    try {
      const r = await callAI(env, p, [{ role: 'system', content: payload.system || '' }, { role: 'user', content: prompt }], params);
      let analysis = parseJSON(r.text);
      if (!analysis || !analysis.topics) {
        const fix = await callAI(env, p, [{ role: 'system', content: 'Return the same content as ONE valid JSON object with keys summary, audience, business_type, pillars, gaps, competitors, trends, seo_notes, topics. JSON only.' }, { role: 'user', content: r.text.slice(0, 60000) }], { ...params, temperature: 0 });
        analysis = parseJSON(fix.text);
      }
      if (!analysis || !analysis.topics) throw new Error('خروجی تحلیل قابل پردازش نبود.');
      return { analysis, meta: { provider: p0.id, model: p.model, web: web || p.id === 'perplexity', competitors_fetched: comp.fetched, tokens_in: r.usage.in, tokens_out: r.usage.out } };
    } catch (e) { lastErr = e; }
  }
  throw new Error('تحلیل ناموفق بود: ' + (lastErr ? errMsg(lastErr) : ''));
}

async function diagnose(env) {
  const out = { wp_api: env.WP_API || '', site_url: env.SITE_URL || '' };
  let host = '';
  try { host = new URL(env.WP_API).hostname; } catch (e) { out.url_error = 'WP_API نامعتبر است: ' + env.WP_API; return out; }
  out.host = host;
  out.dns = {};
  for (const type of ['A', 'AAAA', 'CNAME']) {
    try {
      const r = await fetch(`https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(host)}&type=${type}`, { headers: { accept: 'application/dns-json' } });
      const d = await r.json();
      out.dns[type] = { status: d.Status, answers: (d.Answer || []).map((a) => a.data) };
    } catch (e) { out.dns[type] = { error: errMsg(e) }; }
  }
  const ips = (out.dns.A && out.dns.A.answers || []).filter((x) => /^\d+\.\d+\.\d+\.\d+$/.test(x));
  out.private_ip = ips.some((ip) => /^(10\.|127\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.)/.test(ip));
  const t0 = Date.now();
  try {
    const res = await fetch(env.WP_API.replace(/\/+$/, '') + '/ping', { method: 'POST', headers: { 'Content-Type': 'application/json', 'User-Agent': 'AriaAIWriter-Worker/diag' }, body: '{}', redirect: 'manual' });
    const text = await res.text();
    out.http = { status: res.status, ms: Date.now() - t0, server: res.headers.get('server') || '', cf_ray: res.headers.get('cf-ray') || '', location: res.headers.get('location') || '', body: text.slice(0, 300) };
  } catch (e) {
    out.http = { error: errMsg(e), ms: Date.now() - t0 };
  }
  return out;
}

async function status(env) {
  const keys = Object.keys(env).filter((k) => k.startsWith('AAW_KEY_'));
  let runs = [];
  if (env.AAW_KV) {
    try { runs = JSON.parse((await env.AAW_KV.get('runs')) || '[]'); } catch (_) { runs = []; }
  }
  return {
    version: env.AAW_VERSION || 'dev',
    wp_api: env.WP_API || '',
    ai_binding: !!env.AI,
    claude_pro_binding: !!env.CLAUDE_PRO,
    kv_binding: !!env.AAW_KV,
    shared_secret: !!env.AAW_SHARED_SECRET,
    secrets: keys,
    runs: runs.slice(0, 15),
  };
}

async function remember(env, summary) {
  if (!env.AAW_KV) return;
  try {
    const runs = JSON.parse((await env.AAW_KV.get('runs')) || '[]');
    runs.unshift(summary);
    await env.AAW_KV.put('runs', JSON.stringify(runs.slice(0, 30)));
    await env.AAW_KV.put('last_run', JSON.stringify(summary));
  } catch (_) { /* ignore */ }
}

/* ============================================================
 * Utilities
 * ============================================================ */

function parseJSON(text) {
  if (!text) return null;
  let t = String(text).trim();
  t = t.replace(/^﻿/, '');
  // Remove <think> blocks produced by reasoning models.
  t = t.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
  const fence = t.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) t = fence[1].trim();
  const first = t.indexOf('{');
  const last = t.lastIndexOf('}');
  if (first === -1 || last <= first) return null;
  const candidate = t.slice(first, last + 1);
  try { return JSON.parse(candidate); } catch (_) { /* try repairs */ }
  try {
    return JSON.parse(escapeControlCharsInStrings(candidate).replace(/,\s*([}\]])/g, '$1'));
  } catch (_) {
    return null;
  }
}

function escapeControlCharsInStrings(src) {
  let out = '';
  let inStr = false;
  let esc = false;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (inStr) {
      if (esc) { out += ch; esc = false; continue; }
      if (ch === '\\') { out += ch; esc = true; continue; }
      if (ch === '"') { inStr = false; out += ch; continue; }
      const code = ch.charCodeAt(0);
      if (code < 0x20) {
        out += ch === '\n' ? '\\n' : ch === '\t' ? '\\t' : ch === '\r' ? '' : ' ';
        continue;
      }
      out += ch;
    } else {
      if (ch === '"') inStr = true;
      out += ch;
    }
  }
  return out;
}

function addUsage(meta, u) {
  if (!u) return;
  meta.tokens_in += u.in || 0;
  meta.tokens_out += u.out || 0;
}

async function timedFetch(url, init = {}, seconds = 120) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), Math.max(5, seconds || 120) * 1000);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } catch (e) {
    const err = new Error(e && e.name === 'AbortError' ? `Timeout after ${seconds}s: ${new URL(url).host}` : 'Network error: ' + errMsg(e));
    err.retryable = true;
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

function httpError(provider, status, msg) {
  const e = new Error(`${provider.name} (HTTP ${status}): ${msg}`);
  e.status = status;
  e.retryable = status === 429 || status === 408 || status >= 500;
  return e;
}

function extractError(text) {
  try {
    const d = JSON.parse(text);
    if (typeof d.error === 'string') return d.error;
    if (d.error && d.error.message) return d.error.message;
    if (d.message) return d.message;
    if (d.detail) return typeof d.detail === 'string' ? d.detail : JSON.stringify(d.detail);
  } catch (_) { /* ignore */ }
  return (text || '').slice(0, 300);
}

function corsHeaders(env, request) {
  const origin = request.headers.get('Origin') || '';
  const allowed = (env.ALLOWED_ORIGIN || '').replace(/\/+$/, '');
  return {
    'Access-Control-Allow-Origin': allowed && origin === allowed ? origin : allowed || '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-AAW-Timestamp, X-AAW-Nonce, X-AAW-Signature, X-AAW-Stream, X-AAW-Encoding, X-AAW-Parts',
    'Access-Control-Max-Age': '86400',
    Vary: 'Origin',
  };
}

function streamed(ctx, work, headers = {}, every = 5000) {
  const { readable, writable } = new TransformStream();
  const w = writable.getWriter();
  const space = enc.encode(' ');
  w.write(space).catch(() => {});
  const tick = setInterval(() => { w.write(space).catch(() => {}); }, every);
  const done = (async () => {
    let out;
    try { out = await work(); } catch (e) { out = { ok: false, error: errMsg(e) }; }
    clearInterval(tick);
    try { await w.write(enc.encode(JSON.stringify(out))); await w.close(); } catch (_) { /* client gone */ }
  })();
  if (ctx && ctx.waitUntil) ctx.waitUntil(done);
  return new Response(readable, { status: 200, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store, no-transform', 'X-Accel-Buffering': 'no', 'X-AAW-Stream': '1', ...headers } });
}

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', ...headers } });
}

function timingSafeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

function randomId(n) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const bytes = crypto.getRandomValues(new Uint8Array(n));
  return [...bytes].map((b) => chars[b % chars.length]).join('');
}

function bytesToBase64(bytes) {
  let bin = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  return btoa(bin);
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
function errMsg(e) { return (e && (e.message || String(e))) || 'Unknown error'; }


/* ============================================================
 * Background jobs – Durable Object alarm (max 15 min wall time).
 * WordPress / the browser only make short requests (start + poll),
 * so hosting/network limits on connection length never matter.
 * ============================================================ */

const BG_KINDS = ['analyze', 'generate', 'run', 'suggest', 'image', 'seo_learn', 'style_learn', 'revise', 'post_image'];

export class AawJobs {
  constructor(state, env) { this.state = state; this.env = env; }

  async fetch(request) {
    const job = await request.json();
    await this.state.storage.put('job', job);
    await this.state.storage.setAlarm(Date.now() + 50);
    return new Response('{"ok":true}', { headers: { 'Content-Type': 'application/json' } });
  }

  async alarm() {
    const job = await this.state.storage.get('job');
    if (!job) return;
    await this.state.storage.delete('job');
    await runBackground(this.env, job);
  }
}


/* ============================================================
 * Mailbox storage for slow hosts: big images → separate blobs (optionally shrunk to WebP)
 * ============================================================ */
async function shrinkImage(env, img) {
  // Cloudflare Images binding (when the account has it): PNG of 1–3 MB → WebP of ~150 KB.
  if (!env.IMAGES || !img || !img.base64 || img.base64.length < 160000) return img;
  try {
    const bytes = b64ToBytes(img.base64);
    const stream = new Response(bytes).body;
    const out = await env.IMAGES.input(stream).transform({ width: 1600, fit: 'scale-down' }).output({ format: 'image/webp', quality: 82 });
    const buf = new Uint8Array(await out.response().arrayBuffer());
    if (buf.length > 1000 && buf.length * 1.37 < img.base64.length) {
      let bin = '';
      for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
      return { ...img, base64: btoa(bin), mime: 'image/webp', shrunk: true };
    }
  } catch (_) { /* keep original */ }
  return img;
}

async function storeMailbox(env, id, mailbox) {
  let k = 0;
  const blobs = [];
  const stash = async (img) => {
    if (!img || !img.base64) return img;
    img = await shrinkImage(env, img);
    if (img.base64.length < 24000) return img;
    const key = String(id).replace(/[^a-z0-9]/gi, '') + 'x' + (k++);
    await env.AAW_KV.put('bl:' + key, img.base64, { expirationTtl: 259200 });
    blobs.push(key);
    const { base64, ...rest } = img;
    return { ...rest, blob: key, size: base64.length };
  };
  for (const im of mailbox.images || []) {
    im.image = await stash(im.image);
    for (let i = 0; i < (im.inline || []).length; i++) im.inline[i] = await stash(im.inline[i]);
  }
  for (const r of mailbox.results || []) {
    if (r.article && r.article.image) r.article.image = await stash(r.article.image);
    if (r.article && Array.isArray(r.article.inline_images)) {
      for (let i = 0; i < r.article.inline_images.length; i++) r.article.inline_images[i] = await stash(r.article.inline_images[i]);
    }
  }
  if (blobs.length) mailbox._blobs = blobs;
  await env.AAW_KV.put('pr:' + id, JSON.stringify(mailbox), { expirationTtl: 259200 });
}

async function bgSet(env, id, data) {
  await env.AAW_KV.put('bj:' + id, JSON.stringify(data), { expirationTtl: 86400 });
}

async function runBackground(env, job) {
  const started = Date.now();
  const base = { kind: job.kind, at: started };
  await bgSet(env, job.id, { ...base, status: 'running', step: 'start' });
  const progress = (step) => bgSet(env, job.id, { ...base, status: 'running', step }).catch(() => {});
  let result; let mailbox = null;
  try {
    const p = job.payload || {};
    switch (job.kind) {
      case 'analyze': {
        await progress('ai');
        const out = await analyzeSite(env, p);
        result = out;
        mailbox = { analysis: { result: out.analysis, meta: out.meta } };
        break;
      }
      case 'generate': {
        const results = [];
        for (const j of (p.jobs || [])) {
          const t0 = Date.now();
          await progress('write:' + (j.topic && j.topic.id));
          try {
            const out = await generateArticle(env, p.runtime, j);
            const article = out.article; const meta = out.meta || {};
            if (p.runtime && p.runtime.image && p.runtime.image.enabled) {
              await progress('image:' + (j.topic && j.topic.id));
              try {
                const img = await generateImage(env, p.runtime.image, article, j.images || {});
                if (img) article.image = img;
                if (img && img.inline) { article.inline_images = img.inline; delete img.inline; }
              } catch (e) { meta.image_error = errMsg(e); }
            }
            meta.duration_ms = Date.now() - t0; meta.runner = 'cloudflare-bg';
            results.push({ topic_id: j.topic && j.topic.id, article, meta });
          } catch (e) {
            results.push({ topic_id: j.topic && j.topic.id, error: errMsg(e), meta: { runner: 'cloudflare-bg' } });
          }
        }
        result = { count: results.length, ok: results.filter((r) => r.article).length };
        mailbox = { results };
        break;
      }
      case 'suggest': {
        const ideas = await generateIdeas(env, p.runtime, p.prompt);
        result = { topics: ideas };
        if (job.mailbox) mailbox = { ideas };
        break;
      }
      case 'run': {
        result = await runCycle(env, 'manual', p);
        break;
      }
      case 'image': {
        result = { image: await generateImage(env, p.cfg || {}, p.article || {}, p.refs || {}) };
        break;
      }
      case 'revise': {
        await progress('revise');
        const article = await reviseArticle(env, p.runtime, p.system, p.prompt);
        result = { post_id: p.post_id, title: article.title || '' };
        mailbox = { revisions: [{ post_id: p.post_id, article, request_id: p.request_id || '' }] };
        break;
      }
      case 'post_image': {
        await progress('image:' + (p.post_id || 0));
        const img = await generateImage(env, p.cfg || {}, p.article || {}, p.refs || {});
        const inline = img.inline || []; delete img.inline;
        result = { post_id: p.post_id, refs_used: img.refs_used, engine: img.engine };
        mailbox = { images: [{ post_id: p.post_id, image: img, inline, prompt: (p.article && p.article.image_prompt) || '', replace_inline: !!p.replace_inline }] };
        break;
      }
      case 'seo_learn': {
        await progress('fetch');
        result = await learnSeo(env, p);
        mailbox = { seo_playbook: result };
        break;
      }
      case 'style_learn': {
        await progress('ai');
        result = await learnStyle(env, p);
        mailbox = { style_theme: result };
        break;
      }
      default:
        throw new Error('Unknown job kind');
    }
    if (job.mailbox && mailbox) {
      await storeMailbox(env, job.id, mailbox);
    }
    await bgSet(env, job.id, { ...base, status: 'done', ms: Date.now() - started, result: job.mailbox ? { delivered: true, ...(result && typeof result === 'object' && !Array.isArray(result) && JSON.stringify(result).length < 20000 ? result : {}) } : result });
  } catch (e) {
    if (job.mailbox) {
      await env.AAW_KV.put('pr:' + job.id, JSON.stringify({ fatal: errMsg(e) }), { expirationTtl: 259200 }).catch(() => {});
    }
    await bgSet(env, job.id, { ...base, status: 'error', ms: Date.now() - started, error: errMsg(e) });
  }
}
