<?php
/**
 * Tab: use the AI chat subscription you already pay for (no API).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$s          = AAW_Settings::all();
$meta       = AAW_Settings::key_meta();
$gh_on      = AAW_GitHub::is_connected();
$cf_on      = AAW_Cloudflare::is_deployed();
$has_claude = isset( $meta['sub_claude'] );
$has_codex  = isset( $meta['sub_codex'] );
$active     = in_array( $s['provider'], array( 'sub_claude', 'sub_codex' ), true ) ? $s['provider'] : '';
$roles_cl   = AAW_Priority::roles( 'sub_claude' );
$roles_cx   = AAW_Priority::roles( 'sub_codex' );
$role_txt   = function ( $r, $img = true ) {
	$o = array();
	$o[] = $r['text'] ? 'محتوا: اولویت ' . number_format_i18n( $r['text'] ) : 'محتوا: خاموش';
	if ( $img ) {
		$o[] = $r['image'] ? 'تصویر: اولویت ' . number_format_i18n( $r['image'] ) : 'تصویر: خاموش';
	}
	return ' · ' . implode( ' · ', $o );
};
if ( ! $active && ( $roles_cl['text'] || $roles_cx['text'] ) ) {
	$active = $roles_cl['text'] ? 'sub_claude' : 'sub_codex';
}
$engine     = 'sub_codex' === $active || ( ! $has_claude && $has_codex ) ? 'codex' : 'claude';
$gh_token   = AAW_GitHub::token();

$links = array(
	'gh_action'  => 'https://code.claude.com/docs/en/github-actions',
	'setup_tok'  => 'https://code.claude.com/docs/en/authentication#generate-a-long-lived-token',
	'plan_usage' => 'https://support.claude.com/en/articles/15036540-use-the-claude-agent-sdk-with-your-claude-plan',
	'codex_ci'   => 'https://learn.chatgpt.com/docs/auth/ci-cd-auth',
	'node'       => 'https://nodejs.org/en/download',
	'gh_signup'  => 'https://github.com/signup',
	'gh_classic' => 'https://github.com/settings/tokens/new?scopes=repo,workflow&description=ARIAGH%20AIWRITER',
	'gh_fine'    => 'https://github.com/settings/personal-access-tokens/new',
	'gh_billing' => 'https://docs.github.com/en/billing/managing-billing-for-your-products/managing-billing-for-github-actions/about-billing-for-github-actions',
);

/** Small helper for copyable command blocks. */
$cmd = function ( $lines ) {
	$text = implode( "\n", (array) $lines );
	echo '<div class="aaw-cmd"><pre dir="ltr">' . esc_html( $text ) . '</pre><button type="button" class="aaw-icon-btn" data-copy="' . esc_attr( $text ) . '" title="کپی">' . AAW_Icons::get( 'copy', 15 ) . '</button></div>'; // phpcs:ignore
};

AAW_Admin::head( 'اکانت اشتراکی (بدون API)', 'برای کسانی که اکانت چت هوش مصنوعی (Claude Pro/Max یا ChatGPT Plus/Pro) خریده‌اند ولی API پولی ندارند.', 'user' );
?>

<section class="aaw-card aaw-sub-hero">
	<div class="aaw-card-body">
		<div class="aaw-sub-hero-top">
			<div>
				<h2>با همان اکانت چتی که خریده‌اید، مقاله بنویسید</h2>
				<p>افزونه به‌جای API پولی، از <b>ابزارهای رسمی خود سازنده‌ها</b> (Claude Code و OpenAI Codex) استفاده می‌کند که اجازه ورود با اکانت اشتراکی را می‌دهند. این ابزارها روی سرورهای رایگان GitHub اجرا می‌شوند و زمان‌بندی را ورکر رایگان کلادفلر انجام می‌دهد.</p>
				<div class="aaw-badges">
					<span class="aaw-chip is-ok"><?php AAW_Icons::e( 'check-circle', 14 ); ?> بدون هزینه اضافه</span>
					<span class="aaw-chip is-ok"><?php AAW_Icons::e( 'shield', 14 ); ?> روش رسمی و مجاز</span>
					<span class="aaw-chip is-info"><?php AAW_Icons::e( 'key', 14 ); ?> بدون نیاز به API</span>
					<span class="aaw-chip is-info"><?php AAW_Icons::e( 'lock', 14 ); ?> توکن فقط در Secrets خصوصی</span>
				</div>
			</div>
		</div>
		<div class="aaw-flow">
			<div class="aaw-flow-step"><span><?php AAW_Icons::e( 'clock', 20 ); ?></span><b>کلادفلر (رایگان)</b><small>هر N ساعت زمان اجرا را اعلام می‌کند</small></div>
			<i><?php AAW_Icons::e( 'chevron-left', 18 ); ?></i>
			<div class="aaw-flow-step"><span><?php AAW_Icons::e( 'server', 20 ); ?></span><b>GitHub Actions (رایگان)</b><small>یک ماشین موقت روشن می‌شود</small></div>
			<i><?php AAW_Icons::e( 'chevron-left', 18 ); ?></i>
			<div class="aaw-flow-step is-accent"><span><?php AAW_Icons::e( 'sparkles', 20 ); ?></span><b>اکانت شما</b><small>Claude Code یا Codex با اشتراک شما می‌نویسد</small></div>
			<i><?php AAW_Icons::e( 'chevron-left', 18 ); ?></i>
			<div class="aaw-flow-step"><span><?php AAW_Icons::e( 'review', 20 ); ?></span><b>وردپرس</b><small>پیش‌نویس سئوشده منتظر تایید شما</small></div>
		</div>
	</div>
</section>

<div class="aaw-sub-accounts" data-engine-pick>
	<label class="aaw-sub-account <?php echo 'claude' === $engine ? 'is-picked' : ''; ?>">
		<input type="radio" name="sub_engine" value="claude" <?php checked( $engine, 'claude' ); ?>>
		<span class="aaw-mono-badge" style="--c:#c96442">CL</span>
		<div>
			<b>Claude Pro / Max <em class="aaw-badge b-done">پیشنهادی</em></b>
			<small>روش رسمی Anthropic برای GitHub Actions با توکن اشتراک · راه‌اندازی ساده‌تر · فارسی‌نویسی عالی</small>
			<span class="aaw-sub-state"><?php echo $has_claude ? AAW_Icons::get( 'check-circle', 14 ) . ' توکن ثبت شده' : AAW_Icons::get( 'key', 14 ) . ' توکن ثبت نشده'; // phpcs:ignore ?><?php echo $has_claude ? esc_html( $role_txt( $roles_cl, false ) ) : ''; ?></span>
		</div>
	</label>
	<label class="aaw-sub-account <?php echo 'codex' === $engine ? 'is-picked' : ''; ?>">
		<input type="radio" name="sub_engine" value="codex" <?php checked( $engine, 'codex' ); ?>>
		<span class="aaw-mono-badge" style="--c:#10a37f">GP</span>
		<div>
			<b>ChatGPT Plus / Pro</b>
			<small>از طریق OpenAI Codex با ورود ChatGPT · مستندات OpenAI آن را «روش پیشرفته» معرفی کرده است</small>
			<span class="aaw-sub-state"><?php echo $has_codex ? AAW_Icons::get( 'check-circle', 14 ) . ' auth.json ثبت شده' : AAW_Icons::get( 'key', 14 ) . ' ثبت نشده'; // phpcs:ignore ?><?php echo $has_codex ? esc_html( $role_txt( $roles_cx ) ) : ''; ?></span>
		</div>
	</label>
</div>

<div class="aaw-sub-steps">

	<!-- STEP 1 -->
	<section class="aaw-card aaw-sub-step <?php echo $cf_on ? 'is-done' : ''; ?>">
		<div class="aaw-sub-step-num"><?php echo $cf_on ? AAW_Icons::get( 'check', 16 ) : '۱'; // phpcs:ignore ?></div>
		<div class="aaw-card-body">
			<h3>ورکر کلادفلر (زمان‌بند رایگان)</h3>
			<?php if ( AAW_Pull::active() ) : ?>
				<div class="aaw-alert is-info"><?php AAW_Icons::e( 'server', 16 ); ?><div><b>اتصال معکوس فعال است:</b> سایت شما لازم نیست روی اینترنت باشد. GitHub مقاله را در کلادفلر می‌گذارد و افزونه خودش آن را برمی‌دارد (با باز بودن پیشخوان یا دکمه «دریافت نتایج»).</div></div>
			<?php endif; ?>
			<p class="aaw-muted">ورکر کلادفلر زمان اجرا را مدیریت می‌کند و تصویر شاخص رایگان (Workers AI) می‌سازد. پلن رایگان کلادفلر کافی است.</p>
			<?php if ( $cf_on ) : ?>
				<div class="aaw-alert is-ok"><?php AAW_Icons::e( 'check-circle', 16 ); ?><div>ورکر فعال است: <code dir="ltr"><?php echo esc_html( AAW_Cloudflare::endpoint() ); ?></code></div></div>
			<?php else : ?>
				<div class="aaw-alert is-warn"><?php AAW_Icons::e( 'alert', 16 ); ?><div>ابتدا در <a href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=cloudflare' ) ); ?>">تب کلادفلر</a> توکن را وارد و «استقرار ورکر» را بزنید (حدود ۲ دقیقه).</div></div>
			<?php endif; ?>
		</div>
	</section>

	<!-- STEP 2 -->
	<section class="aaw-card aaw-sub-step <?php echo $gh_on ? 'is-done' : ''; ?>">
		<div class="aaw-sub-step-num"><?php echo $gh_on ? AAW_Icons::get( 'check', 16 ) : '۲'; // phpcs:ignore ?></div>
		<div class="aaw-card-body">
			<h3>اتصال GitHub (سرور رایگان اجرای کار)</h3>
			<div class="aaw-grid aaw-grid-2">
				<ol class="aaw-guide">
					<li>اگر حساب GitHub ندارید، <a href="<?php echo esc_url( $links['gh_signup'] ); ?>" target="_blank" rel="noopener">از اینجا رایگان بسازید</a>.</li>
					<li><a href="<?php echo esc_url( $links['gh_classic'] ); ?>" target="_blank" rel="noopener"><b>این لینک</b></a> را باز کنید؛ دسترسی‌های لازم (<code dir="ltr">repo</code> و <code dir="ltr">workflow</code>) از قبل تیک خورده‌اند. مدت اعتبار (Expiration) را دلخواه انتخاب و «Generate token» را بزنید.</li>
					<li>توکنی که با <code dir="ltr">ghp_</code> شروع می‌شود را کپی و اینجا وارد کنید.</li>
					<li>افزونه خودکار یک <b>مخزن خصوصی</b> می‌سازد، فایل‌های اجرا را در آن قرار می‌دهد و Secrets امن را تنظیم می‌کند.</li>
				</ol>
				<form data-gh-form autocomplete="off">
					<label class="aaw-label">توکن GitHub</label>
					<div class="aaw-pass">
						<input class="aaw-input" type="password" name="token" dir="ltr" placeholder="<?php echo esc_attr( $gh_token ? AAW_Crypto::mask( $gh_token ) : 'ghp_…' ); ?>">
						<button type="button" class="aaw-icon-btn" data-toggle-pass><?php AAW_Icons::e( 'eye', 16 ); ?></button>
					</div>
					<label class="aaw-label">نام مخزن خصوصی</label>
					<input class="aaw-input" name="repo" dir="ltr" value="<?php echo esc_attr( $s['gh_repo'] ); ?>">
					<button type="submit" class="aaw-btn aaw-btn-primary aaw-btn-block"><?php AAW_Icons::e( 'link', 16 ); ?> <?php echo $gh_on ? 'اتصال مجدد / به‌روزرسانی' : 'اتصال و ساخت خودکار مخزن'; ?></button>
					<?php if ( $gh_on ) : ?>
						<div class="aaw-kv aaw-mt">
							<div><small>مخزن</small><a href="<?php echo esc_url( AAW_GitHub::repo_url() ); ?>" target="_blank" rel="noopener" dir="ltr"><?php echo esc_html( $s['gh_owner'] . '/' . $s['gh_repo'] ); ?></a></div>
							<div><small>اجراها</small><a href="<?php echo esc_url( AAW_GitHub::repo_url() . '/actions' ); ?>" target="_blank" rel="noopener">مشاهده در GitHub Actions</a></div>
						</div>
					<?php endif; ?>
					<details class="aaw-more">
						<summary>ترجیح می‌دهید توکن محدودتر (Fine-grained) بسازید؟</summary>
						<p>ابتدا یک مخزن خصوصی خالی با همین نام بسازید، سپس <a href="<?php echo esc_url( $links['gh_fine'] ); ?>" target="_blank" rel="noopener">توکن Fine-grained</a> فقط برای همان مخزن با دسترسی‌های <code dir="ltr">Contents</code>، <code dir="ltr">Secrets</code>، <code dir="ltr">Actions</code> و <code dir="ltr">Workflows</code> روی «Read and write» بسازید.</p>
					</details>
				</form>
			</div>
		</div>
	</section>

	<!-- STEP 3 -->
	<section class="aaw-card aaw-sub-step <?php echo ( 'claude' === $engine ? $has_claude : $has_codex ) ? 'is-done' : ''; ?>">
		<div class="aaw-sub-step-num">۳</div>
		<div class="aaw-card-body">
			<h3>اتصال اکانت اشتراکی شما</h3>

			<div data-engine-panel="claude" <?php echo 'claude' === $engine ? '' : 'hidden'; ?>>
				<div class="aaw-grid aaw-grid-2">
					<div>
						<ol class="aaw-guide">
							<li><a href="<?php echo esc_url( $links['node'] ); ?>" target="_blank" rel="noopener">Node.js</a> را روی کامپیوتر خودتان نصب کنید (نسخه LTS).</li>
							<li>PowerShell یا Terminal را باز کنید و این دستور را اجرا کنید:<?php $cmd( 'npm install -g @anthropic-ai/claude-code' ); ?></li>
							<li>سپس این دستور را بزنید؛ مرورگر باز می‌شود، با همان اکانت Claude Pro/Max وارد شوید و «Authorize» را بزنید:<?php $cmd( 'claude setup-token' ); ?></li>
							<li>توکنی که در ترمینال چاپ می‌شود و با <code dir="ltr">sk-ant-oat01-</code> شروع می‌شود را کپی کنید. این توکن <b>یک سال</b> اعتبار دارد.</li>
						</ol>
						<p class="aaw-muted"><?php AAW_Icons::e( 'info', 14 ); ?> مرجع رسمی: <a href="<?php echo esc_url( $links['setup_tok'] ); ?>" target="_blank" rel="noopener">راهنمای setup-token</a> و <a href="<?php echo esc_url( $links['gh_action'] ); ?>" target="_blank" rel="noopener">Claude Code GitHub Actions</a> (بخش «CLAUDE_CODE_OAUTH_TOKEN … available on Pro, Max»).</p>
					</div>
					<form data-sub-form="claude" autocomplete="off">
						<label class="aaw-label">توکن اشتراک Claude</label>
						<div class="aaw-pass">
							<input class="aaw-input" type="password" name="value" dir="ltr" placeholder="<?php echo esc_attr( $has_claude ? $meta['sub_claude']['mask'] : 'sk-ant-oat01-…' ); ?>">
							<button type="button" class="aaw-icon-btn" data-toggle-pass><?php AAW_Icons::e( 'eye', 16 ); ?></button>
						</div>
						<label class="aaw-label">مدل</label>
						<div class="aaw-seg">
							<?php foreach ( array( 'sonnet' => 'Sonnet (پیشنهادی)', 'opus' => 'Opus (قوی‌تر، سهمیه بیشتر)', 'haiku' => 'Haiku (سریع)' ) as $k => $l ) : ?>
								<label><input type="radio" name="model" value="<?php echo esc_attr( $k ); ?>" <?php checked( AAW_Providers::model_for( 'sub_claude' ), $k ); ?>><span><?php echo esc_html( $l ); ?></span></label>
							<?php endforeach; ?>
						</div>
						<label class="aaw-check"><input type="checkbox" name="make_primary" value="1" <?php checked( ! $has_codex || $roles_cl['text'] ); ?>> برای تولید محتوا استفاده شود (اولویت اول لیست محتوا)</label>
						<label class="aaw-check"><input type="checkbox" name="fallback_free" value="1" checked> اگر سهمیه تمام شد، Workers AI رایگان جایگزین شود</label>
						<button type="submit" class="aaw-btn aaw-btn-primary aaw-btn-block" <?php disabled( ! $gh_on ); ?>><?php AAW_Icons::e( 'lock', 16 ); ?> ذخیره امن در GitHub Secrets</button>
					</form>
				</div>
			</div>

			<div data-engine-panel="codex" <?php echo 'codex' === $engine ? '' : 'hidden'; ?>>
				<?php include AAW_DIR . 'admin/views/partials-codex-login.php'; $aaw_codex_login_box( $gh_on, $has_codex ); ?>
				<details class="aaw-cx-manual">
				<summary>روش دستی (پیشرفته): وارد کردن فایل auth.json از کامپیوتر خودتان</summary>
				<div class="aaw-grid aaw-grid-2">
					<div>
						<ol class="aaw-guide">
							<li><a href="<?php echo esc_url( $links['node'] ); ?>" target="_blank" rel="noopener">Node.js</a> را نصب کنید، سپس در PowerShell:<?php $cmd( 'npm install -g @openai/codex' ); ?></li>
							<li>تنظیم ذخیره اعتبارنامه در فایل (یک‌بار):<?php $cmd( array( 'mkdir $env:USERPROFILE\.codex -Force', "Set-Content \$env:USERPROFILE\\.codex\\config.toml 'cli_auth_credentials_store = \"file\"'" ) ); ?></li>
							<li>ورود با اکانت ChatGPT (گزینه <b>Sign in with ChatGPT</b> را انتخاب کنید):<?php $cmd( 'codex login' ); ?></li>
							<li>فایل اعتبارنامه را باز کنید و <b>کل محتوا</b> را (از <code>{</code> تا <code>}</code>) کپی کنید:<?php $cmd( 'notepad $env:USERPROFILE\.codex\auth.json' ); ?></li>
							<li>بعد از ذخیره در افزونه، فایل <code dir="ltr">auth.json</code> را از کامپیوتر <b>پاک کنید</b> (دستور logout نزنید). OpenAI توصیه می‌کند هر نسخه فقط روی یک سیستم استفاده شود.</li>
						</ol>
						<p class="aaw-muted"><?php AAW_Icons::e( 'info', 14 ); ?> مرجع رسمی: <a href="<?php echo esc_url( $links['codex_ci'] ); ?>" target="_blank" rel="noopener">Maintain Codex account auth in CI/CD</a>. توکن هر حدود ۸ روز خودکار تمدید و نسخه جدید در KV کلادفلر ذخیره می‌شود.</p>
					</div>
					<form data-sub-form="codex" autocomplete="off">
						<label class="aaw-label">محتوای کامل auth.json</label>
						<textarea class="aaw-input aaw-mono" name="value" rows="6" dir="ltr" placeholder='{"auth_mode":"chatgpt","tokens":{...},"last_refresh":"..."}'></textarea>
						<label class="aaw-label">مدل <small>(خالی = پیش‌فرض پلن شما)</small></label>
						<input class="aaw-input" name="model" dir="ltr" value="<?php echo esc_attr( AAW_Providers::model_for( 'sub_codex' ) ); ?>" placeholder="gpt-5">
						<label class="aaw-check"><input type="checkbox" name="make_primary" value="1" <?php checked( ! $has_claude && ! $roles_cl['text'] ); ?>> برای تولید محتوا استفاده شود (اولویت اول لیست محتوا)</label>
						<label class="aaw-check"><input type="checkbox" name="image_role" value="1" <?php checked( (bool) $roles_cx['image'] || $has_claude ); ?>> برای ساخت تصویر مقالات استفاده شود (اولویت اول لیست تصویر)</label>
						<label class="aaw-check"><input type="checkbox" name="fallback_free" value="1" checked> اگر سهمیه تمام شد، Workers AI رایگان جایگزین شود</label>
						<button type="submit" class="aaw-btn aaw-btn-primary aaw-btn-block" <?php disabled( ! $gh_on ); ?>><?php AAW_Icons::e( 'lock', 16 ); ?> ذخیره امن در GitHub Secrets و KV</button>
					</form>
				</div>
				</details>
			</div>
			<?php if ( ! $gh_on ) : ?>
				<p class="aaw-muted aaw-mt"><?php AAW_Icons::e( 'alert', 14 ); ?> دکمه ذخیره بعد از اتصال GitHub (مرحله ۲) فعال می‌شود.</p>
			<?php endif; ?>
		</div>
	</section>

	<!-- STEP 4 -->
	<section class="aaw-card aaw-sub-step <?php echo $active ? 'is-done' : ''; ?>">
		<div class="aaw-sub-step-num">۴</div>
		<div class="aaw-card-body">
			<div class="aaw-row-between">
				<h3>تست، فعال‌سازی و اجراها</h3>
				<div class="aaw-btn-row">
					<button type="button" class="aaw-btn aaw-btn-ghost" data-action="gh-test" <?php disabled( ! $gh_on ); ?>><?php AAW_Icons::e( 'zap', 16 ); ?> تست اتصال اکانت</button>
					<button type="button" class="aaw-btn aaw-btn-primary" data-action="run-now" <?php disabled( ! ( $gh_on && $active ) ); ?>><?php AAW_Icons::e( 'play', 16 ); ?> تولید فوری مقاله</button>
				</div>
			</div>
			<div class="aaw-sub-roles" data-sub-roles>
				<p class="aaw-muted">هر دو اکانت می‌توانند هم‌زمان وصل بمانند. مشخص کنید هر کدام چه کاری انجام دهد؛ ترتیب دقیق در دو تب اصلی تنظیم می‌شود.</p>
				<?php
				foreach ( array( 'sub_claude' => array( 'Claude Pro / Max', $has_claude, $roles_cl, false, '#c96442' ), 'sub_codex' => array( 'ChatGPT Plus / Pro', $has_codex, $roles_cx, true, '#10a37f' ) ) as $sid => $x ) :
					?>
					<div class="aaw-sub-role <?php echo $x[1] ? '' : 'is-off'; ?>" data-sub-role="<?php echo esc_attr( $sid ); ?>">
						<span class="aaw-mono-badge" style="--c:<?php echo esc_attr( $x[4] ); ?>"><?php echo 'sub_codex' === $sid ? 'GP' : 'CL'; ?></span>
						<div class="aaw-sub-role-name"><b><?php echo esc_html( $x[0] ); ?></b><small><?php echo $x[1] ? 'وصل است' : 'هنوز وصل نشده (مرحله ۳)'; ?></small></div>
						<label class="aaw-switch-line"><input type="checkbox" data-role="text" <?php checked( (bool) $x[2]['text'] ); ?> <?php disabled( ! $x[1] ); ?>><span class="aaw-switch-ui"></span> تولید محتوا<?php echo $x[2]['text'] ? ' <em class="aaw-badge b-done">اولویت ' . esc_html( number_format_i18n( $x[2]['text'] ) ) . '</em>' : ''; // phpcs:ignore ?></label>
						<?php if ( $x[3] ) : ?>
							<label class="aaw-switch-line"><input type="checkbox" data-role="image" <?php checked( (bool) $x[2]['image'] ); ?> <?php disabled( ! $x[1] ); ?>><span class="aaw-switch-ui"></span> ساخت تصویر<?php echo $x[2]['image'] ? ' <em class="aaw-badge b-done">اولویت ' . esc_html( number_format_i18n( $x[2]['image'] ) ) . '</em>' : ''; // phpcs:ignore ?></label>
						<?php else : ?>
							<span class="aaw-muted aaw-sub-role-na">ساخت تصویر ندارد</span>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
				<div class="aaw-btn-row aaw-mt">
					<a class="aaw-btn aaw-btn-sm aaw-btn-ghost" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=text_ai' ) ); ?>"><?php AAW_Icons::e( 'content', 14 ); ?> ترتیب هوش مصنوعی محتوا</a>
					<a class="aaw-btn aaw-btn-sm aaw-btn-ghost" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=image_ai' ) ); ?>"><?php AAW_Icons::e( 'image', 14 ); ?> ترتیب هوش مصنوعی تصویر</a>
				</div>
			</div>
			<div class="aaw-table-wrap">
				<table class="aaw-table">
					<thead><tr><th>زمان</th><th>وضعیت</th><th>نوع</th><th>مدت</th><th></th></tr></thead>
					<tbody data-gh-runs><tr><td colspan="5" class="aaw-muted"><?php echo $gh_on ? 'در حال دریافت…' : 'بعد از اتصال GitHub اجراها اینجا نمایش داده می‌شوند.'; ?></td></tr></tbody>
				</table>
			</div>
			<div class="aaw-row-between aaw-mt">
				<small class="aaw-muted" data-gh-secrets></small>
				<div class="aaw-btn-row">
					<?php if ( AAW_Pull::active() ) : ?>
						<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-dark" data-action="pull-poll" <?php disabled( ! $gh_on ); ?>><?php AAW_Icons::e( 'download', 14 ); ?> دریافت نتایج (اتصال معکوس)</button>
					<?php endif; ?>
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="gh-sync" <?php disabled( ! $gh_on ); ?>><?php AAW_Icons::e( 'refresh', 14 ); ?> به‌روزرسانی فایل‌های Runner</button>
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost is-danger" data-action="gh-disconnect" <?php disabled( ! $gh_on ); ?>><?php AAW_Icons::e( 'x', 14 ); ?> قطع اتصال</button>
				</div>
			</div>
		</div>
	</section>
</div>

<div class="aaw-grid aaw-grid-2">
	<?php AAW_Admin::card_open( 'هزینه و محدودیت‌ها', '', 'info' ); ?>
	<table class="aaw-info">
		<tr><th>نوشتن مقاله</th><td>از سهمیه اشتراکی که قبلاً خریده‌اید (همان سهمیه چت)</td></tr>
		<tr><th>GitHub Actions</th><td>رایگان؛ هر مقاله حدود ۲ تا ۵ دقیقه · <a href="<?php echo esc_url( $links['gh_billing'] ); ?>" target="_blank" rel="noopener">سهمیه رایگان GitHub</a></td></tr>
		<tr><th>کلادفلر</th><td>پلن رایگان (زمان‌بند + تصویر شاخص Workers AI)</td></tr>
		<tr><th>پیشنهاد</th><td>۱ تا ۴ مقاله در روز تا سهمیه چت شما آزاد بماند</td></tr>
		<tr><th>تمدید</th><td>Claude: سالی یک‌بار <code dir="ltr">claude setup-token</code> · ChatGPT: خودکار</td></tr>
	</table>
	<?php AAW_Admin::card_close(); ?>

	<?php AAW_Admin::card_open( 'سؤالات متداول', '', 'book' ); ?>
	<div class="aaw-faq-admin">
		<details><summary>آیا این کار قانونی است؟</summary><p>بله. Anthropic در <a href="<?php echo esc_url( $links['gh_action'] ); ?>" target="_blank" rel="noopener">مستند رسمی GitHub Actions</a> ورود با توکن اشتراک را برای اجرای خودکار (حتی زمان‌بندی‌شده) پشتیبانی می‌کند و در <a href="<?php echo esc_url( $links['plan_usage'] ); ?>" target="_blank" rel="noopener">راهنمای پلن‌ها</a> گفته این مصرف از سهمیه عادی اشتراک کم می‌شود. OpenAI هم <a href="<?php echo esc_url( $links['codex_ci'] ); ?>" target="_blank" rel="noopener">روش CI/CD با اکانت ChatGPT</a> را مستند کرده است. هیچ اسکرپینگ یا ورود جعلی به سایت چت انجام نمی‌شود.</p></details>
		<details><summary>توکن من کجا ذخیره می‌شود و امن است؟</summary><p>فقط در Secrets رمزنگاری‌شده مخزن خصوصی GitHub شما (و برای ChatGPT یک نسخه در KV کلادفلر). وردپرس فقط نمای ماسک‌شده را نگه می‌دارد. مخزن حتماً خصوصی ساخته می‌شود و اگر عمومی باشد افزونه ادامه نمی‌دهد.</p></details>
		<details><summary>اگر سهمیه اشتراک تمام شود چه می‌شود؟</summary><p>Runner خطا را تشخیص می‌دهد و اگر پرووایدر پشتیبان (مثلاً Workers AI رایگان) تنظیم کرده باشید، مقاله با آن نوشته می‌شود؛ وگرنه موضوع در اجرای بعدی دوباره تلاش می‌شود.</p></details>
		<details><summary>آیا روی چت روزمره‌ام اثر دارد؟</summary><p>مصرف مشترک است. هر مقاله کامل تقریباً مثل یک گفتگوی طولانی در claude.ai یا ChatGPT حساب می‌شود. اگر همزمان زیاد چت می‌کنید، تعداد مقاله روزانه را کم کنید.</p></details>
		<details><summary>از ایران کار می‌کند؟</summary><p>اجرای اصلی روی سرورهای GitHub (خارج از ایران) انجام می‌شود. فقط برای یک‌بار اجرای <code>claude setup-token</code> یا <code>codex login</code> روی کامپیوتر خودتان ممکن است به تغییر شبکه نیاز داشته باشید.</p></details>
		<details><summary>اجرا در GitHub شروع نشد؟</summary><p>در جدول اجراها یا صفحه Actions مخزن، پیام خطا را ببینید. رایج‌ترین دلایل: توکن GitHub بدون دسترسی workflow، منقضی شدن توکن اشتراک، یا غیرفعال بودن Actions در تنظیمات مخزن.</p></details>
		<details><summary>چطور کاملاً متوقفش کنم؟</summary><p>«قطع اتصال» را بزنید تا موتور اصلی به پرووایدر دیگری برگردد. برای حذف کامل، مخزن را از GitHub پاک کنید و در Claude/ChatGPT نشست‌های فعال را لغو کنید.</p></details>
	</div>
	<?php AAW_Admin::card_close(); ?>
</div>

<details class="aaw-card aaw-advanced">
	<summary><?php AAW_Icons::e( 'settings', 16 ); ?> روش جایگزین پیشرفته: اجرای Claude Pro روی Cloudflare Containers (نیازمند پلن ۵ دلاری کلادفلر)</summary>
	<div class="aaw-card-body">
<?php
$cp_on    = (bool) $s['claude_pro_enabled'];
$cp_token = isset( $meta['claude_pro'] );
?>
		<div class="aaw-cp-status">
			<span class="aaw-chip <?php echo $cp_on ? 'is-ok' : 'is-warn'; ?>"><?php AAW_Icons::e( $cp_on ? 'check-circle' : 'alert', 15 ); ?> <?php echo $cp_on ? 'متصل به ورکر اصلی' : 'متصل نشده'; ?></span>
			<span class="aaw-chip <?php echo $cp_token ? 'is-ok' : ''; ?>"><?php AAW_Icons::e( 'key', 15 ); ?> <?php echo $cp_token ? 'توکن: ' . esc_html( $meta['claude_pro']['mask'] ) : 'توکن ثبت نشده'; ?></span>
		</div>
		<div class="aaw-grid aaw-grid-2">
			<ol class="aaw-guide">
				<li>پلن <b>Workers Paid</b> کلادفلر را فعال کنید.</li>
				<li><a href="<?php echo esc_url( AAW_URL . 'runner/aria-claude-pro-runner.zip' ); ?>" download>بسته Runner کانتینری</a> را دانلود و طبق README آن با GitHub Actions مستقر کنید.</li>
				<li>توکن <code dir="ltr">claude setup-token</code> را اینجا وارد و «اتصال» را بزنید.</li>
			</ol>
			<form data-claude-pro-form autocomplete="off">
				<label class="aaw-label">توکن اشتراک Claude</label>
				<div class="aaw-pass">
					<input class="aaw-input" type="password" name="token" dir="ltr" placeholder="<?php echo esc_attr( $cp_token ? $meta['claude_pro']['mask'] : 'sk-ant-oat01-…' ); ?>">
					<button type="button" class="aaw-icon-btn" data-toggle-pass><?php AAW_Icons::e( 'eye', 16 ); ?></button>
				</div>
				<div class="aaw-grid aaw-grid-2">
					<div><label class="aaw-label">نام ورکر Runner</label><input class="aaw-input" name="runner_name" dir="ltr" value="<?php echo esc_attr( $s['runner_name'] ); ?>"></div>
					<div><label class="aaw-label">مدل جایگزین</label><div class="aaw-select-wrap"><select class="aaw-input" name="fallback">
						<?php foreach ( array( '' => 'هیچ', 'haiku' => 'Haiku', 'sonnet' => 'Sonnet', 'opus' => 'Opus' ) as $k => $l ) : ?>
							<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $s['claude_pro_fallback'], $k ); ?>><?php echo esc_html( $l ); ?></option>
						<?php endforeach; ?>
					</select><?php AAW_Icons::e( 'chevron-down', 16, 'aaw-select-ic' ); ?></div></div>
				</div>
				<label class="aaw-check"><input type="checkbox" name="make_active" value="1"> پرووایدر اصلی شود</label>
				<div class="aaw-btn-row">
					<button type="submit" class="aaw-btn aaw-btn-dark"><?php AAW_Icons::e( 'link', 16 ); ?> <?php echo $cp_on ? 'به‌روزرسانی اتصال' : 'اتصال'; ?></button>
					<?php if ( $cp_on ) : ?>
						<button type="button" class="aaw-btn aaw-btn-ghost" data-action="claude-pro-test"><?php AAW_Icons::e( 'zap', 16 ); ?> تست</button>
						<button type="button" class="aaw-btn aaw-btn-ghost is-danger" data-action="claude-pro-disconnect"><?php AAW_Icons::e( 'x', 16 ); ?> قطع</button>
					<?php endif; ?>
				</div>
			</form>
		</div>
	</div>
</details>
