<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
AAW_Admin::head( 'صف بازبینی', 'مقالات تولیدشده در پیش‌نویس منتظر تایید شما هستند؛ پیش‌نمایش، ویرایش، انتشار یا زمان‌بندی کنید.', 'review', '<button type="button" class="aaw-btn aaw-btn-ghost" data-action="review-refresh">' . AAW_Icons::get( 'refresh', 16 ) . ' به‌روزرسانی</button>' );
?>
<div class="aaw-toolbar">
	<div class="aaw-tabs-pill" data-review-filter>
		<button type="button" class="is-active" data-status="">در انتظار تایید</button>
		<button type="button" data-status="future">زمان‌بندی‌شده</button>
		<button type="button" data-status="publish">منتشرشده</button>
	</div>
	<div class="aaw-search"><?php AAW_Icons::e( 'search', 16 ); ?><input type="search" class="aaw-input" placeholder="جستجو در عنوان‌ها…" data-review-search></div>
</div>
<div class="aaw-review-list" data-review-list>
	<div class="aaw-skeleton aaw-skeleton-lg"></div>
	<div class="aaw-skeleton aaw-skeleton-lg"></div>
</div>
