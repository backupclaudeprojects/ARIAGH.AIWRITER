<?php
/** One-click ChatGPT sign-in box (device code on GitHub; nothing to install). */
$aaw_codex_login_box = function ( $gh_on, $has_codex ) {
	?>
	<div class="aaw-cx-login" data-codex-login>
		<div class="aaw-cx-login-head">
			<span class="aaw-mono-badge" style="--c:#10a37f">GP</span>
			<div><b>ورود با اکانت ChatGPT (بدون نصب هیچ برنامه‌ای)</b><small><?php echo $has_codex ? 'اکانت ChatGPT وصل است؛ برای عوض کردن اکانت دوباره وارد شوید.' : 'با همان اکانت ChatGPT Plus/Pro که در سایت chatgpt.com دارید؛ کلید API لازم نیست.'; ?></small></div>
		</div>
		<ol class="aaw-guide">
			<li>فقط یک‌بار: در ChatGPT به <a href="https://chatgpt.com/#settings/Security" target="_blank" rel="noopener">Settings → Security</a> بروید و گزینه <b dir="ltr">Allow device code login</b> را روشن کنید. (حساب تیمی: مدیر Workspace باید فعالش کند.)</li>
			<li>دکمه زیر را بزنید؛ حدود یک دقیقه بعد یک <b>لینک و کد تأیید</b> همین‌جا نمایش داده می‌شود.</li>
			<li>لینک را باز کنید، با اکانت ChatGPT وارد شوید و کد را وارد کنید. تمام؛ اکانت خودکار وصل می‌شود.</li>
		</ol>
		<div class="aaw-cx-login-opts">
			<label class="aaw-check"><input type="checkbox" data-cx-image checked> برای ساخت تصویر مقالات استفاده شود</label>
			<label class="aaw-check"><input type="checkbox" data-cx-text> برای نوشتن مقاله هم استفاده شود</label>
		</div>
		<button type="button" class="aaw-btn aaw-btn-primary aaw-btn-block aaw-btn-lg" data-action="codex-login" <?php disabled( ! $gh_on ); ?>><?php AAW_Icons::e( 'user', 18 ); ?> ورود با اکانت ChatGPT و دریافت کد تأیید</button>
		<?php if ( ! $gh_on ) : ?>
			<p class="aaw-muted"><?php AAW_Icons::e( 'alert', 14 ); ?> ابتدا GitHub را در تب «اکانت اشتراکی» وصل کنید (یک‌بار).</p>
		<?php endif; ?>
		<div class="aaw-cx-login-out" data-cx-out hidden></div>
		<p class="aaw-muted aaw-cx-note"><?php AAW_Icons::e( 'info', 13 ); ?> چرا «Codex»؟ Codex فقط راه رسمی OpenAI برای استفاده خودکار از اشتراک ChatGPT است؛ کدنویسی نمی‌کند. تصاویر با همان مدل تصویرسازی ChatGPT ساخته و از سهمیه اشتراک شما کم می‌شود. اعتبارنامه فقط در KV کلادفلر خودتان ذخیره و خودکار تمدید می‌شود.</p>
	</div>
	<?php
};
