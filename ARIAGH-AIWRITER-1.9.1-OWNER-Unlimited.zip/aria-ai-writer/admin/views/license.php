<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$lic   = AAW_License::check( false );
$cfg   = AAW_License::config();
$trial = $lic['trial'];
$p     = $lic['license'];
$badge = 'active' === $lic['status'] ? 'is-active' : ( 'trial' === $lic['status'] ? 'is-trial' : 'is-bad' );
$plans = AAW_License::plans();
AAW_Admin::head( 'لایسنس و حساب', 'فعال‌سازی لایسنس رسمی، مشاهده وضعیت اشتراک، به‌روزرسانی خودکار و پشتیبانی.', 'key' );
?>
<div class="aaw-lic-hero">
	<div class="aaw-lic-brand">
		<img src="<?php echo esc_url( AAW_URL . 'assets/img/logo-white.svg' ); ?>" alt="ARIAGH.AIWRITER">
		<h2>نویسنده هوشمند مقالات سئو برای وردپرس</h2>
		<p>با لایسنس رسمی، تولید خودکار بدون محدودیت، به‌روزرسانی‌های یک‌کلیکی از داخل پیشخوان و پشتیبانی مستقیم دریافت می‌کنید.</p>
		<ul>
			<li><?php AAW_Icons::e( 'check-circle', 16 ); ?> تولید نامحدود مقاله</li>
			<li><?php AAW_Icons::e( 'check-circle', 16 ); ?> تحلیل هوشمند سایت و رقبا</li>
			<li><?php AAW_Icons::e( 'check-circle', 16 ); ?> بیش از ۲۰ موتور هوش مصنوعی</li>
			<li><?php AAW_Icons::e( 'check-circle', 16 ); ?> اکانت اشتراکی Claude و ChatGPT</li>
			<li><?php AAW_Icons::e( 'check-circle', 16 ); ?> به‌روزرسانی خودکار</li>
			<li><?php AAW_Icons::e( 'check-circle', 16 ); ?> پشتیبانی فنی</li>
		</ul>
	</div>
	<section class="aaw-card">
		<div class="aaw-card-body aaw-lic-status">
			<span class="aaw-lic-badge <?php echo esc_attr( $badge ); ?>"><?php AAW_Icons::e( 'active' === $lic['status'] ? 'shield' : ( 'trial' === $lic['status'] ? 'sparkles' : 'lock' ), 18 ); ?> <?php echo esc_html( $lic['label'] ); ?></span>
			<p class="aaw-muted" style="margin:0"><?php echo esc_html( $lic['message'] ); ?></p>

			<?php if ( 'trial' === $lic['status'] || 'trial_ended' === $lic['status'] ) : ?>
				<?php $used = $trial['max_articles'] ? min( 100, round( 100 * $trial['articles'] / $trial['max_articles'] ) ) : 100; ?>
				<div>
					<small class="aaw-muted">مقالات آزمایشی: <?php echo esc_html( number_format_i18n( $trial['articles'] ) . ' از ' . number_format_i18n( $trial['max_articles'] ) ); ?> · <?php echo esc_html( number_format_i18n( $trial['days_left'] ) ); ?> روز باقی‌مانده</small>
					<div class="aaw-lic-meter"><i style="width:<?php echo esc_attr( $used ); ?>%"></i></div>
				</div>
			<?php endif; ?>

			<?php if ( AAW_License::is_owner() ) : ?>
				<div class="aaw-lic-grid">
					<div><small>نسخه</small><b>مالک</b></div>
					<div><small>سایت‌ها</small><b>نامحدود</b></div>
					<div><small>اعتبار</small><b>دائمی</b></div>
					<div><small>تعداد مقاله</small><b>نامحدود</b></div>
				</div>
			<?php elseif ( 'active' === $lic['status'] || ( $p && 'invalid' !== $lic['status'] ) ) : ?>
				<div class="aaw-lic-grid">
					<div><small>کلید</small><b dir="ltr"><?php echo esc_html( $lic['key_mask'] ); ?></b></div>
					<div><small>پلن</small><b><?php echo esc_html( ! empty( $p['plan'] ) ? $p['plan'] : '—' ); ?></b></div>
					<div><small>دامنه</small><b dir="ltr"><?php echo esc_html( $lic['domain'] ); ?></b></div>
					<div><small>سایت‌ها</small><b><?php echo esc_html( isset( $p['activations'] ) ? number_format_i18n( (int) $p['activations'] ) . ' از ' . ( empty( $p['sites'] ) ? 'نامحدود' : number_format_i18n( (int) $p['sites'] ) ) : '—' ); ?></b></div>
					<div><small>اعتبار</small><b><?php echo esc_html( empty( $p['expires'] ) ? 'دائمی' : wp_date( 'Y/m/d', (int) $p['expires'] ) ); ?></b></div>
					<div><small>آخرین بررسی</small><b><?php echo esc_html( $lic['last_check'] ? wp_date( 'Y/m/d H:i', $lic['last_check'] ) : '—' ); ?></b></div>
				</div>
				<div class="aaw-btn-row">
					<button type="button" class="aaw-btn aaw-btn-ghost" data-action="license-check"><?php AAW_Icons::e( 'refresh', 16 ); ?> بررسی مجدد</button>
					<button type="button" class="aaw-btn aaw-btn-ghost is-danger" data-action="license-deactivate"><?php AAW_Icons::e( 'power', 16 ); ?> غیرفعال‌سازی روی این سایت</button>
					<?php if ( $cfg['account_url'] ) : ?>
						<a class="aaw-btn aaw-btn-ghost" href="<?php echo esc_url( $cfg['account_url'] ); ?>" target="_blank" rel="noopener"><?php AAW_Icons::e( 'user', 16 ); ?> حساب کاربری</a>
					<?php endif; ?>
				</div>
			<?php else : ?>
				<form data-license-form autocomplete="off">
					<label class="aaw-label" for="aaw-license-key">کلید لایسنس</label>
					<div class="aaw-lic-key">
						<input class="aaw-input" id="aaw-license-key" name="key" dir="ltr" placeholder="AIW-XXXX-XXXX-XXXX-XXXX" required>
						<button type="submit" class="aaw-btn aaw-btn-primary"><?php AAW_Icons::e( 'key', 16 ); ?> فعال‌سازی</button>
					</div>
					<p class="aaw-help">کلید پس از خرید در ایمیل و در صفحه «لایسنس‌های من» حساب کاربری فروشگاه نمایش داده می‌شود. هر کلید به تعداد سایت‌های پلن خود قابل فعال‌سازی است؛ سایت‌های تست و staging شمرده نمی‌شوند.</p>
				</form>
				<?php if ( $cfg['buy_url'] ) : ?>
					<a class="aaw-btn aaw-btn-dark aaw-btn-block" href="<?php echo esc_url( $cfg['buy_url'] ); ?>" target="_blank" rel="noopener"><?php AAW_Icons::e( 'zap', 16 ); ?> خرید لایسنس</a>
				<?php endif; ?>
			<?php endif; ?>

			<?php if ( $lic['last_error'] ) : ?>
				<div class="aaw-alert is-warn"><?php AAW_Icons::e( 'alert', 16 ); ?><div><?php echo esc_html( $lic['last_error'] ); ?></div></div>
			<?php endif; ?>
			<?php if ( ! $lic['configured'] && ! AAW_License::is_owner() ) : ?>
				<div class="aaw-alert is-warn"><?php AAW_Icons::e( 'info', 16 ); ?><div>این نسخه به سرور لایسنس متصل نیست و فقط در حالت آزمایشی کار می‌کند. نسخه رسمی را از فروشگاه ARIAGH دریافت کنید.</div></div>
			<?php endif; ?>
		</div>
	</section>
</div>

<?php if ( $plans ) : ?>
	<?php AAW_Admin::card_open( 'پلن‌ها', 'قیمت‌ها مستقیم از فروشگاه رسمی خوانده می‌شود', 'zap' ); ?>
	<div class="aaw-plans">
		<?php foreach ( $plans as $pl ) : ?>
			<div class="aaw-plan <?php echo $pl['featured'] ? 'is-featured' : ''; ?>">
				<?php if ( $pl['featured'] ) : ?><span class="aaw-plan-tag">پیشنهاد ویژه</span><?php endif; ?>
				<h3><?php echo esc_html( $pl['name'] ); ?></h3>
				<div class="aaw-next-time" style="font-size:24px"><?php echo esc_html( $pl['price'] ); ?></div>
				<div class="aaw-plan-sites"><?php echo esc_html( ( $pl['sites'] ? number_format_i18n( $pl['sites'] ) . ' سایت' : 'سایت نامحدود' ) . ( $pl['period'] ? ' · ' . $pl['period'] : '' ) ); ?></div>
				<?php if ( $pl['features'] ) : ?>
					<ul><?php foreach ( $pl['features'] as $f ) : ?><li><?php AAW_Icons::e( 'check', 14 ); ?><?php echo esc_html( $f ); ?></li><?php endforeach; ?></ul>
				<?php endif; ?>
				<a class="aaw-btn <?php echo $pl['featured'] ? 'aaw-btn-primary' : 'aaw-btn-ghost'; ?> aaw-btn-block" href="<?php echo esc_url( $pl['url'] ); ?>" target="_blank" rel="noopener">خرید این پلن</a>
			</div>
		<?php endforeach; ?>
	</div>
	<?php AAW_Admin::card_close(); ?>
<?php endif; ?>

<div class="aaw-grid aaw-grid-2">
	<div>
		<?php AAW_Admin::card_open( 'به‌روزرسانی خودکار', 'نسخه‌های جدید مثل افزونه‌های مخزن وردپرس در صفحه افزونه‌ها نمایش داده می‌شوند', 'download' ); ?>
		<?php $u = AAW_License::remote_info(); ?>
		<div class="aaw-kv">
			<div><small>نسخه نصب‌شده</small><code dir="ltr"><?php echo esc_html( AAW_VERSION ); ?></code></div>
			<div><small>آخرین نسخه</small><code dir="ltr"><?php echo esc_html( ! empty( $u['version'] ) ? $u['version'] : '—' ); ?></code></div>
		</div>
		<?php if ( ! empty( $u['version'] ) && version_compare( $u['version'], AAW_VERSION, '>' ) ) : ?>
			<a class="aaw-btn aaw-btn-primary aaw-btn-block" href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>"><?php AAW_Icons::e( 'download', 16 ); ?> به‌روزرسانی به <?php echo esc_html( $u['version'] ); ?></a>
		<?php else : ?>
			<p class="aaw-muted">افزونه به‌روز است. بررسی خودکار هر ۱۲ ساعت انجام می‌شود.</p>
		<?php endif; ?>
		<?php AAW_Admin::card_close(); ?>
	</div>
	<div>
		<?php AAW_Admin::card_open( 'پشتیبانی و راهنما', '', 'book' ); ?>
		<ul class="aaw-guide">
			<?php if ( $cfg['docs_url'] ) : ?><li><a href="<?php echo esc_url( $cfg['docs_url'] ); ?>" target="_blank" rel="noopener">مستندات و آموزش‌های ویدئویی</a></li><?php endif; ?>
			<?php if ( $cfg['support_url'] ) : ?><li><a href="<?php echo esc_url( $cfg['support_url'] ); ?>" target="_blank" rel="noopener">ثبت تیکت پشتیبانی</a></li><?php endif; ?>
			<?php if ( $cfg['account_url'] ) : ?><li><a href="<?php echo esc_url( $cfg['account_url'] ); ?>" target="_blank" rel="noopener">مدیریت لایسنس‌ها و دانلود نسخه‌ها</a></li><?php endif; ?>
			<li>هنگام ارسال تیکت، خروجی «عیب‌یابی» تب کلادفلر و نسخه افزونه (<?php echo esc_html( AAW_VERSION ); ?>) را ضمیمه کنید.</li>
			<li>برای انتقال لایسنس به دامنه جدید، ابتدا روی سایت قبلی «غیرفعال‌سازی» را بزنید یا از حساب کاربری فروشگاه دامنه را آزاد کنید.</li>
		</ul>
		<?php AAW_Admin::card_close(); ?>
	</div>
</div>
