<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$items = AAW_Priority::text_items();
$gh    = AAW_GitHub::is_connected();
$sd    = AAW_SiteData::status();
AAW_Admin::head( 'هوش مصنوعی تولید محتوا', 'هوش مصنوعی‌هایی که مقاله می‌نویسند و ترتیب استفاده از آن‌ها. اولی همیشه اول امتحان می‌شود؛ اگر خطا داد یا سهمیه‌اش تمام شد، بعدی.', 'content', '<a class="aaw-btn aaw-btn-ghost" href="' . esc_url( admin_url( 'admin.php?page=aaw&tab=ai' ) ) . '">' . AAW_Icons::get( 'key', 16 ) . ' کلیدهای API</a>' );
?>
<div class="aaw-grid aaw-grid-main-side">
	<div>
		<?php AAW_Admin::card_open( 'اولویت هوش مصنوعی‌ها', 'بکشید و رها کنید تا ترتیب عوض شود؛ با کلید کنار هر مورد آن را روشن یا خاموش کنید', 'layers' ); ?>
		<?php AAW_Admin::prio_list( 'text', $items ); ?>
		<div class="aaw-row-between aaw-mt">
			<small class="aaw-muted">موارد خاموش هرگز استفاده نمی‌شوند. اکانت‌های اشتراکی از طریق GitHub Actions اجرا می‌شوند؛ بقیه روی ورکر کلادفلر.</small>
			<button type="button" class="aaw-btn aaw-btn-primary" data-action="prio-save" data-kind="text"><?php AAW_Icons::e( 'check', 16 ); ?> ذخیره ترتیب</button>
		</div>
		<?php AAW_Admin::card_close(); ?>
	</div>
	<div>
		<?php AAW_Admin::card_open( 'اکانت‌های اشتراکی', 'Claude و ChatGPT بدون کلید API', 'user' ); ?>
		<?php
		$meta = AAW_Settings::key_meta();
		foreach ( array( 'sub_claude' => 'Claude Pro / Max', 'sub_codex' => 'ChatGPT Plus / Pro' ) as $sid => $nm ) :
			$r = AAW_Priority::roles( $sid );
			?>
			<div class="aaw-kv-row">
				<b><?php echo esc_html( $nm ); ?></b>
				<span>
					<?php if ( ! isset( $meta[ $sid ] ) || ! $gh ) : ?>
						<em class="aaw-chip is-warn">وصل نیست</em>
					<?php else : ?>
						<em class="aaw-chip <?php echo $r['text'] ? 'is-ok' : ''; ?>">محتوا: <?php echo $r['text'] ? 'اولویت ' . esc_html( number_format_i18n( $r['text'] ) ) : 'خاموش'; ?></em>
						<?php if ( 'sub_codex' === $sid ) : ?>
							<em class="aaw-chip <?php echo $r['image'] ? 'is-ok' : ''; ?>">تصویر: <?php echo $r['image'] ? 'اولویت ' . esc_html( number_format_i18n( $r['image'] ) ) : 'خاموش'; ?></em>
						<?php endif; ?>
					<?php endif; ?>
				</span>
			</div>
		<?php endforeach; ?>
		<p class="aaw-muted">هر دو اکانت می‌توانند وصل بمانند. مثلاً Claude را فقط اینجا (محتوا) و ChatGPT را فقط در تب «هوش مصنوعی تولید تصویر» روشن کنید تا هر کدام فقط کار خودش را انجام دهد.</p>
		<a class="aaw-btn aaw-btn-sm aaw-btn-ghost" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=subscription' ) ); ?>"><?php AAW_Icons::e( 'user', 14 ); ?> اتصال و راهنمای اکانت اشتراکی</a>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'دیتابیس سایت در GitHub', 'هوش مصنوعی لینک محصولات، دسته‌ها و مقالات قبلی را از اینجا می‌بیند', 'database' ); ?>
		<?php if ( ! empty( $sd['data']['counts'] ) ) : ?>
			<div class="aaw-kv">
				<div><small>مقالات</small><code><?php echo esc_html( number_format_i18n( $sd['data']['counts']['posts'] ?? 0 ) ); ?></code></div>
				<div><small>محصولات</small><code><?php echo esc_html( number_format_i18n( $sd['data']['counts']['products'] ?? 0 ) ); ?></code></div>
				<div><small>به‌روزرسانی</small><code><?php echo esc_html( $sd['ago'] . ' پیش' ); ?></code></div>
			</div>
		<?php else : ?>
			<p class="aaw-muted"><?php echo $sd['available'] ? 'هنوز نسخه پشتیبانی ساخته نشده؛ در تب «تحلیل هوشمند سایت» تحلیل را اجرا کنید.' : 'برای ساخت دیتابیس، GitHub را در تب «اکانت اشتراکی» وصل کنید (اکانت اشتراکی لازم نیست).'; ?></p>
		<?php endif; ?>
		<a class="aaw-btn aaw-btn-sm aaw-btn-ghost" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=strategy' ) ); ?>"><?php AAW_Icons::e( 'wand', 14 ); ?> تحلیل سایت</a>
		<?php AAW_Admin::card_close(); ?>
	</div>
</div>
