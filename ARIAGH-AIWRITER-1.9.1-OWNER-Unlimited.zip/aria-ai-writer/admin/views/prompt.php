<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$s = AAW_Settings::all();
AAW_Admin::head( 'پرامپت هوش مصنوعی', 'دستورالعمل اصلی که در هر اجرا برای تولید محتوا به هوش مصنوعی داده می‌شود. قوانین سئو و ساختار به‌صورت خودکار به آن اضافه می‌شوند.', 'prompt' );
?>
<form class="aaw-form" data-settings>
	<div class="aaw-grid aaw-grid-2-1">
		<div>
			<?php AAW_Admin::card_open( 'پرامپت اصلی (Master Prompt)', 'از متغیرها برای شخصی‌سازی پویا استفاده کنید', 'prompt' ); ?>
			<div class="aaw-row-between aaw-mb">
				<div class="aaw-select-wrap aaw-w-auto">
					<select class="aaw-input" data-preset>
						<option value="">انتخاب قالب آماده…</option>
						<?php foreach ( AAW_Prompt::presets() as $k => $p ) : ?>
							<option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $p['label'] ); ?></option>
						<?php endforeach; ?>
					</select><?php AAW_Icons::e( 'chevron-down', 16, 'aaw-select-ic' ); ?>
				</div>
				<div class="aaw-btn-row">
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="prompt-reset"><?php AAW_Icons::e( 'undo', 14 ); ?> پیش‌فرض</button>
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="prompt-copy"><?php AAW_Icons::e( 'copy', 14 ); ?> کپی</button>
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="prompt-fullscreen"><?php AAW_Icons::e( 'external', 14 ); ?> تمام‌صفحه</button>
				</div>
			</div>
			<input type="hidden" name="prompt_preset" value="<?php echo esc_attr( $s['prompt_preset'] ); ?>">
			<textarea class="aaw-input aaw-prompt" name="system_prompt" rows="20" dir="auto" data-prompt><?php echo esc_textarea( AAW_Prompt::is_legacy_default( $s['system_prompt'] ) ? AAW_Prompt::default_prompt() : $s['system_prompt'] ); ?></textarea>
			<div class="aaw-row-between aaw-muted">
				<span data-prompt-count>0 کاراکتر</span>
				<span>متغیرها هنگام اجرا با مقادیر واقعی جایگزین می‌شوند</span>
			</div>
			<?php AAW_Admin::card_close(); ?>
		</div>
		<div>
			<?php AAW_Admin::card_open( 'متغیرها', 'برای درج در محل نشانگر کلیک کنید', 'hash' ); ?>
			<div class="aaw-var-list">
				<?php foreach ( AAW_Prompt::variables() as $v => $label ) : ?>
					<button type="button" class="aaw-var" data-insert="<?php echo esc_attr( $v ); ?>"><code dir="ltr"><?php echo esc_html( $v ); ?></code><span><?php echo esc_html( $label ); ?></span></button>
				<?php endforeach; ?>
			</div>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'پیش‌نمایش و تست', 'پرامپت نهایی را ببینید یا یک مقاله آزمایشی بسازید', 'eye' ); ?>
			<label class="aaw-label">موضوع آزمایشی</label>
			<input class="aaw-input" data-test-topic placeholder="مثلاً: مزایای چای سبز برای سلامتی" dir="auto">
			<label class="aaw-label">کلمات کلیدی</label>
			<input class="aaw-input" data-test-keywords placeholder="چای سبز، خواص چای سبز" dir="auto">
			<div class="aaw-btn-col">
				<button type="button" class="aaw-btn aaw-btn-ghost aaw-btn-block" data-action="prompt-preview"><?php AAW_Icons::e( 'eye', 16 ); ?> مشاهده پرامپت نهایی</button>
				<button type="button" class="aaw-btn aaw-btn-dark aaw-btn-block" data-action="prompt-generate"><?php AAW_Icons::e( 'sparkles', 16 ); ?> تولید مقاله آزمایشی</button>
			</div>
			<small class="aaw-muted">تولید آزمایشی از ورکر کلادفلر و پرووایدر فعال استفاده می‌کند و فقط در صورت تایید شما پیش‌نویس ذخیره می‌شود.</small>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'دستورالعمل تکمیلی', '', 'edit' ); ?>
			<?php AAW_Admin::textarea( 'custom_instructions', 'قوانین اضافه', 'به انتهای همه پرامپت‌ها افزوده می‌شود', 'مثلاً: همیشه به ارسال رایگان اشاره کن', 4 ); ?>
			<?php AAW_Admin::textarea( 'forbidden_words', 'کلمات ممنوع', 'هر خط یا با کاما', "ارزان‌ترین\nتضمینی", 3 ); ?>
			<?php AAW_Admin::card_close(); ?>
		</div>
	</div>
	<?php AAW_Admin::save_bar( 'ذخیره پرامپت' ); ?>
</form>
