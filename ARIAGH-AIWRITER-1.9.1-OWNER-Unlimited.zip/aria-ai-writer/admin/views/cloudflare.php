<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$s          = AAW_Settings::all();
$token      = AAW_Cloudflare::token();
$configured = AAW_Cloudflare::is_configured();
$deployed   = AAW_Cloudflare::is_deployed();
AAW_Admin::head( 'اتصال کلادفلر', 'ورکر، زمان‌بندی Cron، Secrets و فضای KV مستقیماً از همین صفحه روی حساب کلادفلر شما ساخته و مدیریت می‌شوند.', 'cloud' );
?>
<div class="aaw-steps">
	<div class="aaw-step <?php echo $configured ? 'is-done' : 'is-current'; ?>"><span>۱</span><b>اتصال حساب</b></div>
	<div class="aaw-step <?php echo $deployed ? 'is-done' : ( $configured ? 'is-current' : '' ); ?>"><span>۲</span><b>استقرار ورکر</b></div>
	<div class="aaw-step <?php echo $deployed ? 'is-current' : ''; ?>"><span>۳</span><b>ثبت کلید AI</b></div>
</div>

<?php if ( AAW_Pull::active() ) : ?>
	<div class="aaw-alert is-info"><?php AAW_Icons::e( 'server', 18 ); ?><div><b>اتصال معکوس فعال است.</b> ورکر کلادفلر به سایت شما درخواست نمی‌فرستد؛ وردپرس خودش نتایج را از ورکر دریافت می‌کند. این حالت برای سایت‌هایی است که پشت فایروال هستند یا ورود درخواست خارجی را مسدود کرده‌اند.</div></div>
<?php elseif ( AAW_Pull::site_is_local() ) : ?>
	<div class="aaw-alert is-warn"><?php AAW_Icons::e( 'alert', 18 ); ?><div><b>آدرس سایت عمومی نیست</b> (<?php echo esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ); ?>). برای اجرای زمان‌بندی کلادفلر، سایت باید با دامنه عمومی در دسترس باشد؛ در غیر این صورت در کارت «حالت اتصال» گزینه «اتصال معکوس» را انتخاب کنید.</div></div>
<?php endif; ?>

<div class="aaw-grid aaw-grid-2">
	<div>
		<?php AAW_Admin::card_open( 'اطلاعات حساب کلادفلر', 'توکن رمزنگاری‌شده (AES-256-GCM) ذخیره می‌شود', 'key' ); ?>
		<form data-cf-form autocomplete="off">
			<label class="aaw-label">API Token</label>
			<div class="aaw-pass">
				<input class="aaw-input" type="password" name="token" dir="ltr" placeholder="<?php echo esc_attr( $token ? AAW_Crypto::mask( $token ) : 'توکن API کلادفلر' ); ?>">
				<button type="button" class="aaw-icon-btn" data-toggle-pass><?php AAW_Icons::e( 'eye', 16 ); ?></button>
			</div>
			<label class="aaw-label">Account ID</label>
			<div class="aaw-combo">
				<input class="aaw-input" name="account_id" dir="ltr" value="<?php echo esc_attr( $s['cf_account_id'] ); ?>" placeholder="32 کاراکتر هگز">
				<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="cf-accounts"><?php AAW_Icons::e( 'search', 14 ); ?> یافتن</button>
			</div>
			<div data-accounts></div>
			<label class="aaw-label">نام ورکر</label>
			<input class="aaw-input" name="worker_name" dir="ltr" value="<?php echo esc_attr( $s['worker_name'] ); ?>">
			<button type="submit" class="aaw-btn aaw-btn-primary aaw-btn-block"><?php AAW_Icons::e( 'shield', 16 ); ?> ذخیره و بررسی توکن</button>
		</form>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'راهنمای ساخت توکن', '', 'info' ); ?>
		<ol class="aaw-guide">
			<li>به <a href="https://dash.cloudflare.com/profile/api-tokens" target="_blank" rel="noopener">صفحه API Tokens کلادفلر</a> بروید و «Create Token» ← «Create Custom Token» را بزنید.</li>
			<li>این دسترسی‌ها را در بخش Account اضافه کنید:
				<ul>
					<li><code dir="ltr">Workers Scripts : Edit</code></li>
					<li><code dir="ltr">Workers KV Storage : Edit</code></li>
					<li><code dir="ltr">Account Settings : Read</code> <small>(برای دکمه «یافتن»)</small></li>
				</ul>
			</li>
			<li>در Account Resources حساب خود را انتخاب و توکن را بسازید، سپس اینجا وارد کنید.</li>
			<li>Account ID در صفحه Overview هر دامنه یا Workers قابل مشاهده است.</li>
		</ol>
		<?php AAW_Admin::card_close(); ?>
	</div>
	<div>
		<?php AAW_Admin::card_open( 'ورکر', $deployed ? 'مستقر شده در ' . wp_date( 'Y/m/d H:i', (int) $s['deployed_at'] ) : 'هنوز مستقر نشده', 'server' ); ?>
		<div class="aaw-kv">
			<div><small>آدرس ورکر</small><code dir="ltr"><?php echo esc_html( $s['worker_url'] ? $s['worker_url'] : '—' ); ?></code></div>
			<div><small>فضای KV</small><code dir="ltr"><?php echo esc_html( $s['kv_namespace_id'] ? $s['kv_namespace_id'] : '—' ); ?></code></div>
			<div><small>نسخه</small><code dir="ltr"><?php echo esc_html( $s['deployed_version'] ? $s['deployed_version'] : '—' ); ?></code></div>
			<div><small>مسیر REST وردپرس</small><code dir="ltr"><?php echo esc_html( rest_url( 'aaw/v1' ) ); ?></code></div>
		</div>
		<form class="aaw-form aaw-form-inline" data-settings>
			<?php AAW_Admin::toggle( 'bind_workers_ai', 'اتصال Workers AI', 'مدل‌های رایگان متن و تصویر کلادفلر · پس از تغییر، استقرار مجدد کنید' ); ?>
			<?php AAW_Admin::text( 'worker_custom_url', 'دامنه اختصاصی ورکر (اختیاری)', 'اگر workers.dev در شبکه شما فیلتر است، یک Custom Domain در کلادفلر به ورکر وصل کنید و اینجا وارد کنید', 'https://ai.yourdomain.com', 'url' ); ?>
			<?php AAW_Admin::toggle( 'kv_sync', 'پشتیبان‌گیری خودکار در KV', 'تنظیمات و موضوعات در کلادفلر هم ذخیره شوند' ); ?>
			<button type="submit" class="aaw-btn aaw-btn-sm aaw-btn-ghost"><?php AAW_Icons::e( 'save', 14 ); ?> ذخیره</button>
		</form>
		<div class="aaw-btn-grid">
			<button type="button" class="aaw-btn aaw-btn-primary" data-action="cf-deploy" <?php disabled( ! $configured ); ?>><?php AAW_Icons::e( 'rocket', 16 ); ?> <?php echo $deployed ? 'استقرار مجدد' : 'استقرار ورکر'; ?></button>
			<button type="button" class="aaw-btn aaw-btn-ghost" data-action="cf-status" <?php disabled( ! $configured ); ?>><?php AAW_Icons::e( 'activity', 16 ); ?> بررسی وضعیت</button>
			<button type="button" class="aaw-btn aaw-btn-ghost" data-action="cf-sync" <?php disabled( ! $deployed ); ?>><?php AAW_Icons::e( 'upload', 16 ); ?> پشتیبان در KV</button>
			<button type="button" class="aaw-btn aaw-btn-ghost" data-action="cf-restore" <?php disabled( ! $deployed ); ?>><?php AAW_Icons::e( 'download', 16 ); ?> بازیابی از KV</button>
			<button type="button" class="aaw-btn aaw-btn-ghost" data-action="cf-rotate" <?php disabled( ! $configured ); ?>><?php AAW_Icons::e( 'refresh', 16 ); ?> تعویض کلید امضا</button>
			<button type="button" class="aaw-btn aaw-btn-ghost" data-action="worker-unlock" <?php disabled( ! $deployed ); ?>><?php AAW_Icons::e( 'lock', 16 ); ?> آزادسازی قفل</button>
		</div>
		<div class="aaw-status-panel" data-cf-status hidden></div>
		<details class="aaw-danger-zone">
			<summary><?php AAW_Icons::e( 'alert', 15 ); ?> منطقه خطر</summary>
			<p>حذف ورکر، همه Secrets و Cron آن را از کلادفلر پاک می‌کند.</p>
			<button type="button" class="aaw-btn aaw-btn-danger" data-action="cf-delete" <?php disabled( ! $deployed ); ?>><?php AAW_Icons::e( 'trash', 16 ); ?> حذف ورکر</button>
		</details>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'حالت اتصال', 'نحوه ارتباط ورکر کلادفلر با سایت', 'server' ); ?>
		<form class="aaw-form aaw-form-inline" data-settings>
			<?php AAW_Admin::segmented( 'connection_mode', 'چه کسی به چه کسی وصل شود؟', array( 'push' => 'مستقیم (پیشنهادی)', 'pull' => 'اتصال معکوس', 'auto' => 'خودکار' ) ); ?>
			<button type="submit" class="aaw-btn aaw-btn-sm aaw-btn-ghost"><?php AAW_Icons::e( 'save', 14 ); ?> ذخیره</button>
		</form>
		<ul class="aaw-guide">
			<li><b>مستقیم (پیشنهادی):</b> ورکر کلادفلر سر وقت به REST افزونه وصل می‌شود، موضوع را می‌گیرد و مقاله را تحویل می‌دهد. زمان‌بندی دقیق با Cron کلادفلر، مستقل از بازدید سایت.</li>
			<li><b>اتصال معکوس:</b> برای سایت‌هایی که ورود درخواست از بیرون را مسدود کرده‌اند (فایروال هاست، شبکه داخلی سازمان). وردپرس خودش به ورکر وصل می‌شود و نتایج را برمی‌دارد؛ زمان‌بندی با WP-Cron انجام می‌شود.</li>
			<li><b>خودکار:</b> اگر آدرس سایت عمومی نباشد، اتصال معکوس و در غیر این صورت اتصال مستقیم استفاده می‌شود.</li>
		</ul>
		<div class="aaw-alert <?php echo AAW_Pull::active() ? 'is-info' : 'is-ok'; ?>"><?php AAW_Icons::e( 'info', 16 ); ?><div>حالت فعلی: <b><?php echo AAW_Pull::active() ? 'اتصال معکوس' : 'مستقیم'; ?></b><?php echo AAW_Pull::active() ? ' — Cron کلادفلر خاموش است و زمان‌بندی را وردپرس انجام می‌دهد.' : ''; ?></div></div>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'عیب‌یابی اتصال ورکر ↔ وردپرس', 'اگر خطایی مثل error code: 1016 دیدید، اینجا علت دقیق را پیدا کنید', 'activity' ); ?>
		<p class="aaw-muted">این تست از داخل خود ورکر کلادفلر، DNS دامنه شما را با 1.1.1.1 بررسی می‌کند و یک درخواست واقعی به REST افزونه می‌فرستد.</p>
		<button type="button" class="aaw-btn aaw-btn-dark aaw-btn-block" data-action="diagnose" <?php disabled( ! $deployed ); ?>><?php AAW_Icons::e( 'search', 16 ); ?> اجرای عیب‌یابی</button>
		<div class="aaw-status-panel" data-diagnose hidden></div>
		<form class="aaw-form aaw-form-inline" data-settings>
			<?php AAW_Admin::text( 'wp_api_override', 'آدرس REST برای ورکر (اختیاری)', 'فقط اگر عیب‌یابی گفت؛ مثلاً نسخه با www یا https://site.com/?rest_route=/aaw/v1 · بعد از ذخیره «استقرار مجدد» بزنید', rest_url( 'aaw/v1' ), 'url' ); ?>
			<button type="submit" class="aaw-btn aaw-btn-sm aaw-btn-ghost"><?php AAW_Icons::e( 'save', 14 ); ?> ذخیره</button>
		</form>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'استقرار دستی (اختیاری)', 'اگر ترجیح می‌دهید با Wrangler مستقر کنید', 'terminal' ); ?>
		<p class="aaw-muted">فایل‌های ورکر در پوشه <code>worker</code> افزونه قرار دارند. پس از استقرار دستی، کلید امضا را به‌عنوان Secret با نام <code dir="ltr">AAW_SHARED_SECRET</code> ثبت و آدرس ورکر را در تنظیمات قرار دهید.</p>
		<label class="aaw-label">کلید امضای مشترک (AAW_SHARED_SECRET)</label>
		<div class="aaw-combo">
			<input class="aaw-input" type="password" readonly dir="ltr" value="••••••••••••••••" data-shared-secret>
			<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="reveal-secret"><?php AAW_Icons::e( 'copy', 14 ); ?> نمایش و کپی</button>
		</div>
		<label class="aaw-label">آدرس ورکر دستی</label>
		<div class="aaw-combo">
			<input class="aaw-input" dir="ltr" placeholder="https://aria-ai-writer.xxx.workers.dev" data-manual-url>
			<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="manual-worker"><?php AAW_Icons::e( 'link', 14 ); ?> اتصال</button>
		</div>
		<div class="aaw-btn-row aaw-mt">
			<a class="aaw-btn aaw-btn-sm aaw-btn-ghost" href="<?php echo esc_url( AAW_URL . 'worker/worker.js' ); ?>" download><?php AAW_Icons::e( 'download', 14 ); ?> worker.js</a>
			<a class="aaw-btn aaw-btn-sm aaw-btn-ghost" href="<?php echo esc_url( AAW_URL . 'worker/wrangler.toml' ); ?>" download><?php AAW_Icons::e( 'download', 14 ); ?> wrangler.toml</a>
		</div>
		<?php AAW_Admin::card_close(); ?>
	</div>
</div>
