<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$counts   = AAW_Topics::counts();
$stats    = AAW_Logs::stats( 30 );
$review   = AAW_Plugin::pending_review_count();
$s        = AAW_Settings::all();
$meta     = AAW_Settings::key_meta();
$provider = AAW_Providers::get( $s['provider'] );
$has_key  = isset( $meta[ $s['provider'] ] ) || ( $provider && ! $provider['requires_key'] );
$checks   = array(
	array( AAW_Cloudflare::is_configured(), 'اتصال به حساب کلادفلر', 'cloudflare' ),
	array( AAW_Cloudflare::is_deployed(), 'استقرار ورکر و فعال‌سازی Cron', 'cloudflare' ),
	array( $has_key, 'ثبت کلید API هوش مصنوعی در Secrets', 'ai' ),
	array( '' !== trim( $s['niche'] ), 'تعریف موضوع و حوزه سایت', 'content' ),
	array( $counts['total'] > 0 || $s['auto_topics'], 'افزودن موضوعات یا فعال‌سازی ایده‌پردازی خودکار', 'topics' ),
);
$done_checks = count( array_filter( wp_list_pluck( $checks, 0 ) ) );

$last_analysis = AAW_Analyzer::get();
AAW_Admin::head( 'داشبورد', 'وضعیت کلی تولید محتوای خودکار سایت شما', 'dashboard' );
?>
<section class="aaw-card aaw-now aaw-now-compact" data-now>
	<div class="aaw-card-body"><div class="aaw-skeleton"></div></div>
</section>

<a class="aaw-cta" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=strategy' . ( $last_analysis ? '' : '&start=1' ) ) ); ?>">
	<span class="aaw-cta-ic"><?php AAW_Icons::e( 'wand', 26 ); ?></span>
	<div>
		<b>تحلیل هوشمند سایت و ساخت برنامه محتوا</b>
		<small>هوش مصنوعی مقالات، محصولات، دسته‌ها و رقبا را بررسی می‌کند و بهترین موضوعات جدید با کلمات کلیدی را پیشنهاد می‌دهد.<?php echo $last_analysis ? ' آخرین تحلیل: ' . esc_html( wp_date( 'Y/m/d H:i', (int) $last_analysis['time'] ) ) . ' · ' . count( $last_analysis['result']['topics'] ) . ' موضوع' : ''; ?></small>
	</div>
	<span class="aaw-btn aaw-btn-primary"><?php AAW_Icons::e( 'sparkles', 16 ); ?> <?php echo $last_analysis ? 'مشاهده / تحلیل دوباره' : 'شروع تحلیل'; ?></span>
</a>

<div class="aaw-stats">
	<a class="aaw-stat" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=review' ) ); ?>">
		<span class="aaw-stat-ic is-violet"><?php AAW_Icons::e( 'review', 20 ); ?></span>
		<div><small>در انتظار تایید شما</small><strong data-stat="review"><?php echo esc_html( number_format_i18n( $review ) ); ?></strong></div>
	</a>
	<a class="aaw-stat" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=topics' ) ); ?>">
		<span class="aaw-stat-ic is-blue"><?php AAW_Icons::e( 'list', 20 ); ?></span>
		<div><small>موضوعات در صف</small><strong><?php echo esc_html( number_format_i18n( $counts['pending'] ) ); ?></strong></div>
	</a>
	<div class="aaw-stat">
		<span class="aaw-stat-ic is-green"><?php AAW_Icons::e( 'check-circle', 20 ); ?></span>
		<div><small>مقالات تولیدشده</small><strong><?php echo esc_html( number_format_i18n( $counts['done'] ) ); ?></strong></div>
	</div>
	<div class="aaw-stat">
		<span class="aaw-stat-ic is-amber"><?php AAW_Icons::e( 'trending', 20 ); ?></span>
		<div><small>نرخ موفقیت ۳۰ روز</small><strong><?php echo esc_html( number_format_i18n( $stats['rate'] ) ); ?>٪</strong></div>
	</div>
</div>

<div class="aaw-grid aaw-grid-2-1">
	<div>
		<?php AAW_Admin::card_open( 'فعالیت ۱۴ روز اخیر', 'تعداد مقالات موفق و خطاها در هر روز', 'activity' ); ?>
		<div class="aaw-chart" data-daily="<?php echo esc_attr( wp_json_encode( $stats['daily'] ) ); ?>"></div>
		<div class="aaw-mini-stats">
			<div><small>توکن ورودی</small><b><?php echo esc_html( number_format_i18n( $stats['tokens_in'] ) ); ?></b></div>
			<div><small>توکن خروجی</small><b><?php echo esc_html( number_format_i18n( $stats['tokens_out'] ) ); ?></b></div>
			<div><small>میانگین زمان تولید</small><b><?php echo esc_html( $stats['avg_ms'] ? number_format_i18n( round( $stats['avg_ms'] / 1000 ) ) . ' ثانیه' : '—' ); ?></b></div>
			<div><small>خطاهای ۳۰ روز</small><b><?php echo esc_html( number_format_i18n( $stats['fail'] ) ); ?></b></div>
		</div>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'خط زمانی', 'برنامه پیش‌رو و آخرین مقالات تولیدشده', 'calendar' ); ?>
		<div class="aaw-tl-mini" data-timeline-mini>
			<div class="aaw-skeleton"></div><div class="aaw-skeleton"></div><div class="aaw-skeleton"></div>
		</div>
		<a class="aaw-btn aaw-btn-ghost aaw-btn-block" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=timeline' ) ); ?>"><?php AAW_Icons::e( 'calendar', 16 ); ?> مشاهده خط زمانی کامل</a>
		<?php AAW_Admin::card_close(); ?>
	</div>
	<div>
		<?php AAW_Admin::card_open( 'اجرای بعدی', '', 'clock', 'aaw-card-next' ); ?>
		<div class="aaw-next">
			<div class="aaw-next-time" data-countdown="<?php echo esc_attr( AAW_Cloudflare::next_run_ts() ); ?>" data-long="1"><?php echo $s['paused'] ? 'متوقف است' : '—'; ?></div>
			<small><?php echo esc_html( 'custom' === $s['cron_mode'] ? 'Cron سفارشی' : 'هر ' . number_format_i18n( $s['interval_hours'] ) . ' ساعت · ' . number_format_i18n( $s['posts_per_run'] ) . ' مقاله در هر اجرا' ); ?></small>
			<div class="aaw-btn-row">
				<button type="button" class="aaw-btn aaw-btn-primary" data-action="run-now"><?php AAW_Icons::e( 'play', 16 ); ?> اجرای فوری</button>
				<a class="aaw-btn aaw-btn-ghost" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=schedule' ) ); ?>"><?php AAW_Icons::e( 'settings', 16 ); ?> زمان‌بندی</a>
			</div>
		</div>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'راه‌اندازی', $done_checks . ' از ' . count( $checks ) . ' مرحله کامل شده', 'rocket' ); ?>
		<div class="aaw-progress"><span style="width:<?php echo (int) round( 100 * $done_checks / count( $checks ) ); ?>%"></span></div>
		<ul class="aaw-checklist">
			<?php foreach ( $checks as $c ) : ?>
				<li class="<?php echo $c[0] ? 'is-done' : ''; ?>">
					<span class="aaw-check-dot"><?php AAW_Icons::e( $c[0] ? 'check' : 'chevron-left', 14 ); ?></span>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=' . $c[2] ) ); ?>"><?php echo esc_html( $c[1] ); ?></a>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'موتور فعال', '', 'cpu' ); ?>
		<div class="aaw-engine">
			<b><?php echo esc_html( $provider ? $provider['name'] : '—' ); ?></b>
			<code dir="ltr"><?php echo esc_html( $s['model'] ? $s['model'] : AAW_Providers::model_for( $s['provider'] ) ); ?></code>
			<?php if ( $s['fallbacks'] ) : ?>
				<small>پشتیبان: <?php echo esc_html( implode( '، ', array_map( function ( $id ) { $p = AAW_Providers::get( $id ); return $p ? $p['name'] : $id; }, $s['fallbacks'] ) ) ); ?></small>
			<?php endif; ?>
		</div>
		<?php AAW_Admin::card_close(); ?>
	</div>
</div>
