<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$s       = AAW_Settings::all();
$engines = AAW_Images::engines();
$current = AAW_Images::engine();
$meta    = AAW_Settings::key_meta();
$theme   = get_option( AAW_Images::THEME, array() );
$styles  = AAW_Images::style_attachments( 4 );
$pimgs   = array_filter( array_map( 'absint', preg_split( '/[\s,]+/', (string) AAW_Settings::get( 'image_product_ids' ) ) ) );
AAW_Admin::head( 'تنظیمات تصاویر', 'سبک، مرجع‌ها و تم تصویری. تصویر شاخص و تصاویر داخل متن، هماهنگ با تم سایت و با عکس واقعی محصولاتی که در مقاله آمده‌اند.', 'image' );
?>
<div class="aaw-alert is-info"><?php AAW_Icons::e( 'info', 18 ); ?><div>
	<b>چطور کار می‌کند؟</b> برای هر مقاله، افزونه محصولات مرتبط را پیدا می‌کند و عکس آن‌ها را به‌عنوان مرجع می‌فرستد تا همان محصول (بسته‌بندی، رنگ، برچسب) در تصویر بیاید. چند تصویر موجود سایت هم به‌عنوان نمونه تم ارسال می‌شود. تعداد و حجم مرجع‌ها خودکار با محدودیت هر موتور تنظیم می‌شود (مثلاً OpenAI تا ۱۶، Gemini 2.5 تا ۳، Workers AI بدون مرجع). عکس‌های مرجع یک‌بار کوچک و ذخیره می‌شوند تا سایت کند نشود.
</div></div>

<form class="aaw-form" data-settings>
	<div class="aaw-grid aaw-grid-2">
		<div>
			<?php AAW_Admin::card_open( 'موتور ساخت تصویر', 'انتخاب و ترتیب موتورها در تب اصلی «هوش مصنوعی تولید تصویر»', 'cpu' ); ?>
			<a class="aaw-alert is-info aaw-sub-banner" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=image_ai' ) ); ?>">
				<?php AAW_Icons::e( 'image', 18 ); ?>
				<div><b>ترتیب فعلی:</b> <?php echo esc_html( $s['featured_image'] ? implode( ' ← ', array_map( function ( $id ) use ( $engines ) { return $engines[ $id ]['name']; }, AAW_Priority::image_chain() ) ) : 'تولید تصویر خاموش است' ); ?><br><small>روشن/خاموش کردن، اولویت‌بندی، مدل و کلید هر موتور در تب «هوش مصنوعی تولید تصویر» است.</small></div>
			</a>
			<?php AAW_Admin::text( 'image_custom_url', 'Base URL سرویس سازگار با OpenAI', 'فقط برای «سرویس دلخواه»؛ مثل https://api.avalai.ir/v1', 'https://…/v1', 'url' ); ?>
			<?php AAW_Admin::select( 'image_size', 'ابعاد', array( '1536x1024' => 'افقی 3:2 (پیشنهادی)', '1024x1024' => 'مربع', '1024x1536' => 'عمودی 2:3' ) ); ?>
			<?php AAW_Admin::card_close(); ?>

		</div>
		<div>
			<?php AAW_Admin::card_open( 'مرجع‌ها: محصولات و تم سایت', '', 'layers' ); ?>
			<?php AAW_Admin::number( 'image_product_refs', 'عکس محصولات مرتبط', 'محصولاتی که عنوان/کلمه کلیدی‌شان با موضوع مقاله مرتبط است', 0, 8 ); ?>
			<?php AAW_Admin::number( 'image_style_refs', 'نمونه تصاویر تم سایت', 'چند تصویر از مقالات قبلی برای هماهنگی رنگ و حال‌وهوا', 0, 4 ); ?>
			<?php AAW_Admin::number( 'image_max_refs', 'سقف کل مرجع در هر تصویر', 'کمتر = سریع‌تر و ارزان‌تر؛ همیشه به سقف خود موتور هم محدود می‌شود', 0, 16 ); ?>
			<?php AAW_Admin::text( 'image_style_ids', 'تصاویر تم انتخابی (شناسه رسانه)', 'خالی = تصاویر شاخص آخرین مقالات. مثال: 120, 98, 75', '' ); ?>
			<div class="aaw-btn-row aaw-mb">
				<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="pick-style-media"><?php AAW_Icons::e( 'image', 14 ); ?> انتخاب تصاویر تم از رسانه وردپرس</button>
				<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="clear-style-media"><?php AAW_Icons::e( 'x', 14 ); ?> حالت خودکار</button>
			</div>
			<div class="aaw-ref-thumbs" data-style-thumbs><?php foreach ( $styles as $att ) : ?><?php echo wp_get_attachment_image( $att, array( 72, 72 ), false, array( 'title' => '#' . $att ) ); ?><?php endforeach; ?></div>
			<hr class="aaw-hr">
			<?php AAW_Admin::text( 'image_product_ids', 'عکس‌های مرجع محصولات (شناسه رسانه)', 'عکس محصولاتی که همیشه می‌توانند در تصاویر استفاده شوند؛ قبل از محصولات مرتبط خودکار ارسال می‌شوند. خالی = فقط محصولات مرتبط خودکار.', '' ); ?>
			<div class="aaw-btn-row aaw-mb">
				<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="pick-product-media"><?php AAW_Icons::e( 'image', 14 ); ?> انتخاب عکس محصولات از رسانه وردپرس</button>
				<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="clear-product-media"><?php AAW_Icons::e( 'x', 14 ); ?> پاک کردن</button>
			</div>
			<div class="aaw-ref-thumbs" data-product-thumbs><?php foreach ( array_slice( $pimgs, 0, 12 ) as $att ) : ?><?php echo wp_get_attachment_image( $att, array( 72, 72 ), false, array( 'title' => '#' . $att ) ); ?><?php endforeach; ?></div>
			<?php AAW_Admin::number( 'image_inline_count', 'تصاویر داخل متن', 'علاوه بر تصویر شاخص؛ بعد از پاراگراف اول سرفصل‌ها قرار می‌گیرند', 0, 4 ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'تم تصویری سایت', 'یک‌بار یاد گرفته می‌شود و برای همه تصاویر استفاده می‌شود (صرفه‌جویی در توکن)', 'wand' ); ?>
			<?php AAW_Admin::toggle( 'image_use_theme', 'استفاده از تم یادگرفته‌شده' ); ?>
			<?php AAW_Admin::text( 'image_brand_colors', 'رنگ‌های برند (اختیاری)', 'مثال: کرم، سبز زیتونی، چوب طبیعی' ); ?>
			<div class="aaw-theme-box" data-theme-box><?php echo ! empty( $theme['theme'] ) ? '<b>تم فعلی:</b> ' . esc_html( $theme['theme'] ) . '<br><small class="aaw-muted">یادگیری: ' . esc_html( wp_date( 'Y/m/d H:i', (int) $theme['at'] ) ) . '</small>' : '<span class="aaw-muted">هنوز تمی یاد گرفته نشده است.</span>'; ?></div>
			<button type="button" class="aaw-btn aaw-btn-ghost aaw-btn-block" data-action="style-learn"><?php AAW_Icons::e( 'sparkles', 16 ); ?> یادگیری تم از تصاویر سایت</button>
			<?php AAW_Admin::textarea( 'image_style', 'سبک تکمیلی', 'به انتهای پرامپت همه تصاویر اضافه می‌شود', '', 2 ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'پیام ساخت تصویر به ChatGPT', 'وقتی تصویر با اکانت ChatGPT ساخته می‌شود (GitHub یا مستقیم روی سرور)', 'send' ); ?>
			<p class="aaw-muted">افزونه مثل یک کاربر عادی همین پیام را همراه عکس محصولات و نمونه تصاویر مقاله‌های قبلی برای ChatGPT می‌فرستد. متغیرها: <code>{title}</code> عنوان مقاله، <code>{keyword}</code> کلمه کلیدی، <code>{description}</code> توضیح تصویر که هوش مصنوعی نویسنده ساخته، <code>{article}</code> خلاصه متن مقاله، <code>{products}</code> نام محصولات مرجع، <code>{style}</code> سبک تکمیلی، <code>{refs}</code> تعداد عکس‌های پیوست.</p>
			<?php AAW_Admin::textarea( 'image_chat_prompt', 'متن پیام', 'خالی = متن پیش‌فرض (پایین)', AAW_Local::default_image_prompt(), 7 ); ?>
			<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="image-prompt-default"><?php AAW_Icons::e( 'undo', 14 ); ?> قرار دادن متن پیش‌فرض</button>
			<?php AAW_Admin::toggle( 'image_alt_keyword', 'افزودن کلمه کلیدی به متن جایگزین (Alt)' ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'تست تصویر', 'با همان تنظیمات و مرجع‌های واقعی', 'play' ); ?>
			<div class="aaw-combo">
				<input class="aaw-input" data-img-test-title placeholder="موضوع آزمایشی، مثلاً «طرز سرو کیمچی با برنج»">
				<button type="button" class="aaw-btn aaw-btn-primary" data-action="img-test"><?php AAW_Icons::e( 'image', 16 ); ?> ساخت تصویر</button>
			</div>
			<div data-img-test-out class="aaw-img-test"></div>
			<?php AAW_Admin::card_close(); ?>
		</div>
	</div>
	<?php AAW_Admin::save_bar(); ?>
</form>
