<?php
/**
 * Tab: AI engines installed on THIS server (direct, no GitHub / Cloudflare).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
AAW_Admin::head(
	'موتور هوش مصنوعی روی سرور',
	'نصب، ورود، تست و عیب‌یابی Claude Code و OpenAI Codex روی همین سرور. وقتی روش اجرای یک اکانت «مستقیم از همین سرور» باشد، افزونه مثل یک کاربر عادی برای همان هوش مصنوعی پیام (و برای ChatGPT عکس‌های مرجع) می‌فرستد و هیچ کاری به GitHub یا کلادفلر نمی‌رود.',
	'cpu',
	'<button type="button" class="aaw-btn aaw-btn-ghost" data-action="eng-refresh">' . AAW_Icons::get( 'refresh', 16 ) . ' بررسی دوباره</button>'
);
?>
<div class="aaw-engines" data-engines>
	<div class="aaw-empty"><?php AAW_Icons::e( 'loader', 22 ); ?><p>در حال بررسی سرور…</p></div>
</div>

<div class="aaw-grid aaw-grid-main-side aaw-mt">
	<div>
		<?php AAW_Admin::card_open( 'آخرین کارهای اجراشده روی سرور', 'مقاله، تصویر، اصلاح، تحلیل و تست', 'activity' ); ?>
		<div data-eng-jobs><small class="aaw-muted">—</small></div>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'بررسی‌های سرور', 'از داخل خود PHP — همان محیطی که هوش مصنوعی در آن اجرا می‌شود', 'server' ); ?>
		<div data-eng-env><small class="aaw-muted">—</small></div>
		<?php AAW_Admin::card_close(); ?>
	</div>
	<div>
		<?php AAW_Admin::card_open( 'این روش چطور کار می‌کند؟', '', 'info' ); ?>
		<ol class="aaw-sub-guide">
			<li><b>نصب:</b> برنامه رسمی OpenAI Codex یا Claude Code با یک دکمه (npm) روی همین هاست نصب می‌شود. هاست باید Node.js نسخه ۱۸+ و اجازه اجرای برنامه (proc_open) داشته باشد — معمولاً VPS یا هاست cPanel با «Setup Node.js App».</li>
			<li><b>ورود مثل کاربر واقعی:</b> برای ChatGPT دکمه «ورود با اکانت ChatGPT» یک لینک و کد یک‌بارمصرف می‌دهد؛ صفحه رسمی OpenAI در پنجره خود شما باز می‌شود و ایمیل، رمز و تأیید دومرحله‌ای را همان‌جا وارد می‌کنید. برای Claude توکن رسمی <code dir="ltr">claude setup-token</code> را وارد می‌کنید. روش دوم: جای‌گذاری <code dir="ltr">auth.json</code> یا توکن از کامپیوتر خودتان.</li>
			<li><b>پیام مثل کاربر عادی:</b> هر مقاله، اصلاح، تحلیل و تصویر به‌صورت یک پیام عادی برای همان هوش مصنوعی ارسال می‌شود؛ با همان قوانین، پرامپت‌ها، اطلاعات سایت، لینک محصولات و دانش سئو که در حالت GitHub استفاده می‌شود. برای تصویر، عکس محصولات و نمونه تصاویر مقاله‌های قبلی هم پیوست می‌شود (تنظیم در «تنظیمات تصاویر»).</li>
			<li><b>در اپ‌های دیگر دیده نمی‌شود:</b> درخواست‌ها بدون ذخیره گفتگو اجرا می‌شوند (<code dir="ltr">--ephemeral</code> و <code dir="ltr">--no-session-persistence</code>)، پس در تاریخچه چت ChatGPT/Claude در گوشی یا کامپیوترهای دیگرِ همان اکانت نمایش داده نمی‌شوند. سهمیه همان اشتراک مصرف می‌شود.</li>
			<li><b>مستقیم یعنی واقعاً مستقیم:</b> وقتی روش اجرا «مستقیم از همین سرور» است، اگر برنامه نصب یا وارد نشده باشد کار با پیام خطای روشن متوقف می‌شود و بی‌صدا به GitHub نمی‌رود.</li>
		</ol>
		<div class="aaw-alert is-warn"><?php AAW_Icons::e( 'alert', 16 ); ?><div><b>هاست‌های ایران:</b> سرورهای OpenAI و Anthropic برای IP ایران بسته‌اند و بسیاری از هاست‌های ایرانی اتصال‌های بین‌المللی را بعد از چند ثانیه قطع می‌کنند. روی چنین هاستی «تست اتصال» علت دقیق را نشان می‌دهد؛ در این حالت روش «از طریق GitHub» را نگه دارید.</div></div>
		<p class="aaw-muted"><?php AAW_Icons::e( 'lock', 13 ); ?> رمز عبور شما هیچ‌وقت به افزونه داده نمی‌شود: OpenAI و Anthropic ورود برنامه‌ها با ایمیل و رمز را مجاز نمی‌دانند و ورود خودکار با رمز با کپچا/تأیید دومرحله‌ای متوقف می‌شود و ممکن است باعث مسدود شدن اکانت شود. ورود فقط از صفحه رسمی خودشان انجام می‌شود.</p>
		<?php AAW_Admin::card_close(); ?>

		<details class="aaw-card aaw-eng-adv">
			<summary><b>تنظیمات پیشرفته</b></summary>
			<form class="aaw-form" data-eng-settings>
				<label class="aaw-label">مسیر Node.js <small>(خالی = خودکار)</small></label>
				<input class="aaw-input aaw-mono" dir="ltr" name="local_node_path" value="<?php echo esc_attr( AAW_Settings::get( 'local_node_path' ) ); ?>" placeholder="/opt/alt/alt-nodejs22/root/usr/bin/node">
				<label class="aaw-label">مسیر برنامه Codex <small>(خالی = خودکار)</small></label>
				<input class="aaw-input aaw-mono" dir="ltr" name="local_bin_codex" value="<?php echo esc_attr( AAW_Settings::get( 'local_bin_codex' ) ); ?>" placeholder="/home/user/.local/bin/codex">
				<label class="aaw-label">مسیر برنامه Claude Code <small>(خالی = خودکار)</small></label>
				<input class="aaw-input aaw-mono" dir="ltr" name="local_bin_claude" value="<?php echo esc_attr( AAW_Settings::get( 'local_bin_claude' ) ); ?>" placeholder="/home/user/.local/bin/claude">
				<label class="aaw-label">حداکثر زمان هر درخواست (دقیقه)</label>
				<input class="aaw-input" type="number" min="5" max="60" name="local_timeout" value="<?php echo esc_attr( AAW_Settings::get( 'local_timeout' ) ); ?>">
				<button type="button" class="aaw-btn aaw-btn-primary aaw-mt-sm" data-action="eng-settings-save"><?php AAW_Icons::e( 'check', 16 ); ?> ذخیره</button>
			</form>
		</details>
	</div>
</div>
