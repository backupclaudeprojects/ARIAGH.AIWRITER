<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$meta      = AAW_Settings::key_meta();
$has_key   = isset( $meta['gsc'] );
$site      = AAW_GSC::site();
$rep       = AAW_GSC::report();
$deployed  = AAW_Cloudflare::is_deployed();
AAW_Admin::head( 'سرچ کنسول و ادغام مقالات', 'کلمات و جستجوهای واقعی سایت از گوگل سرچ کنسول برای پیشنهاد بهترین مقاله‌ها، و پیدا کردن مقاله‌های تکراری/رقیب و ادغام خودکار آن‌ها با ریدایرکت ۳۰۱.', 'trending' );
?>
<?php $gsc_notice = AAW_GSC::notice(); if ( $gsc_notice ) : ?>
	<div class="aaw-alert <?php echo 'success' === $gsc_notice[0] ? 'is-ok' : 'is-error'; ?>" style="white-space:pre-line"><?php AAW_Icons::e( 'success' === $gsc_notice[0] ? 'check' : 'alert', 16 ); ?><div><?php echo esc_html( $gsc_notice[1] ); ?></div></div>
<?php endif; ?>
<div class="aaw-gsc" data-gsc data-connected="<?php echo AAW_GSC::connected() ? '1' : '0'; ?>">
<div class="aaw-grid aaw-grid-main-side">
	<div>
		<?php AAW_Admin::card_open( 'فرصت‌های سرچ کنسول', $site ? 'property: ' . $site : 'ابتدا اتصال را انجام دهید', 'trending' ); ?>
		<?php if ( AAW_GSC::connected() ) : ?>
			<div class="aaw-row-between">
				<small class="aaw-muted" data-gsc-at><?php echo ! empty( $rep['at'] ) ? esc_html( 'آخرین دریافت: ' . human_time_diff( (int) ( $rep['at'] / 1000 ) ) . ' پیش · ' . number_format_i18n( (int) ( $rep['totals']['c'] ?? 0 ) ) . ' کلیک، ' . number_format_i18n( (int) ( $rep['totals']['i'] ?? 0 ) ) . ' نمایش در ' . (int) ( $rep['days'] ?? 90 ) . ' روز' ) : 'هنوز داده‌ای دریافت نشده است.'; ?></small>
				<div class="aaw-btn-row">
					<select class="aaw-input aaw-input-sm" data-gsc-days><option value="28">۲۸ روز</option><option value="90" selected>۳ ماه</option><option value="180">۶ ماه</option><option value="480">۱۶ ماه</option></select>
					<button type="button" class="aaw-btn aaw-btn-primary" data-action="gsc-refresh"><?php AAW_Icons::e( 'refresh', 16 ); ?> دریافت داده از سرچ کنسول</button>
				</div>
			</div>
			<div data-gsc-report><?php if ( ! $rep ) : ?><div class="aaw-empty"><?php AAW_Icons::e( 'trending', 28 ); ?><p>«دریافت داده از سرچ کنسول» را بزنید.</p></div><?php endif; ?></div>
			<p class="aaw-muted"><?php AAW_Icons::e( 'info', 13 ); ?> وقتی سرچ کنسول وصل است، «تحلیل هوشمند سایت» و ایده‌پردازی خودکار موضوعات هم از همین داده‌ها استفاده می‌کنند.</p>
		<?php else : ?>
			<div class="aaw-empty"><?php AAW_Icons::e( 'trending', 28 ); ?><p>بعد از اتصال (کادر کناری)، جستجوهایی که سایت در آن‌ها نزدیک صفحه اول است، صفحاتی که CTR پایین دارند و پرکلیک‌ترین کلمات این‌جا نمایش داده می‌شوند.</p></div>
		<?php endif; ?>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'مقاله‌های تکراری و رقیب (همپوشانی)', 'مقاله‌هایی که برای یک جستجو با هم رقابت می‌کنند یا موضوعشان یکی است', 'layers' ); ?>
		<div class="aaw-row-between">
			<small class="aaw-muted">با «ادغام»، هوش مصنوعی مطالب دو مقاله را در مقاله قوی‌تر یکی می‌کند؛ مقاله دیگر با ریدایرکت ۳۰۱ به آن منتقل و پیش‌نویس می‌شود و لینک‌های داخلی سایت اصلاح می‌شوند. همیشه قابل بازگردانی است.</small>
			<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="merge-scan"><?php AAW_Icons::e( 'search', 14 ); ?> بررسی دوباره</button>
		</div>
		<div data-merge-list><div class="aaw-empty"><?php AAW_Icons::e( 'loader', 22 ); ?><p>در حال بررسی…</p></div></div>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'ادغام‌های انجام‌شده و ریدایرکت‌ها', '', 'link' ); ?>
		<div data-merge-history><small class="aaw-muted">—</small></div>
		<?php AAW_Admin::card_close(); ?>
	</div>
	<div>
		<?php
		$client_id = (string) AAW_Settings::get( 'gsc_client_id' );
		$redirect  = AAW_GSC::redirect_uri();
		?>
		<?php AAW_Admin::card_open( 'اتصال به گوگل سرچ کنسول', $has_key ? 'وصل: ' . $meta['gsc']['mask'] : 'یک‌بار، حدود ۵ دقیقه', 'key' ); ?>
		<?php if ( ! $deployed ) : ?>
			<div class="aaw-alert is-warn"><?php AAW_Icons::e( 'alert', 16 ); ?><div>ابتدا ورکر کلادفلر را مستقر کنید؛ ارتباط با گوگل از کلادفلر انجام می‌شود، نه از هاست.</div></div>
		<?php endif; ?>
		<?php if ( $has_key ) : ?>
			<div class="aaw-alert is-ok"><?php AAW_Icons::e( 'check', 16 ); ?><div>وصل است: <b dir="ltr"><?php echo esc_html( $meta['gsc']['mask'] ); ?></b></div></div>
		<?php endif; ?>

		<h4 class="aaw-gsc-h">روش ۱ (پیشنهادی): ورود با حساب گوگل — Client ID و Client Secret</h4>
		<ol class="aaw-guide">
			<li>با حساب گوگلی که سرچ کنسول سایت را دارد به <a href="https://console.cloud.google.com/projectcreate" target="_blank" rel="noopener">Google Cloud Console</a> بروید و یک پروژه بسازید (رایگان؛ مثلاً نام <code>aiwriter</code>) و بالای صفحه همان پروژه را انتخاب کنید.</li>
			<li><a href="https://console.cloud.google.com/apis/library/searchconsole.googleapis.com" target="_blank" rel="noopener">Google Search Console API</a> را باز و <b>Enable</b> کنید.</li>
			<li>به <a href="https://console.cloud.google.com/auth/overview" target="_blank" rel="noopener">Google Auth Platform</a> (همان OAuth consent screen) بروید → <b>Get started</b>: نام برنامه (مثلاً ARIAGH AIWRITER) و ایمیل خودتان → <b>Audience: External</b> → ایمیل تماس → تیک موافقت → <b>Create</b>.</li>
			<li>در منوی <a href="https://console.cloud.google.com/auth/audience" target="_blank" rel="noopener">Audience</a> روی <b>Publish app</b> و بعد <b>Confirm</b> بزنید تا وضعیت <b>In production</b> شود (اگر در حالت Testing بماند، گوگل هر ۷ روز اتصال را قطع می‌کند). نیازی به ارسال برای تأیید گوگل (Verification) نیست.</li>
			<li>در منوی <a href="https://console.cloud.google.com/auth/clients" target="_blank" rel="noopener">Clients</a> → <b>Create client</b> → Application type: <b>Web application</b> → نام دلخواه → در بخش <b>Authorized redirect URIs</b> روی <b>Add URI</b> بزنید و دقیقاً این آدرس را جای‌گذاری کنید:
				<div class="aaw-combo aaw-mt-sm"><input class="aaw-input aaw-mono" dir="ltr" readonly value="<?php echo esc_attr( $redirect ); ?>" onclick="this.select()"><button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-copy="<?php echo esc_attr( $redirect ); ?>"><?php AAW_Icons::e( 'copy', 14 ); ?> کپی</button></div>
				(بخش Authorized JavaScript origins را خالی بگذارید) → <b>Create</b>.</li>
			<li>پنجره‌ای با <b>Client ID</b> و <b>Client secret</b> باز می‌شود (بعداً هم با کلیک روی نام کلاینت در دسترس است). هر دو را پایین وارد و ذخیره کنید.</li>
			<li><b>«ورود با حساب گوگل»</b> را بزنید، همان حساب صاحب سرچ کنسول را انتخاب کنید. اگر پیام <i dir="ltr">Google hasn't verified this app</i> آمد، روی <b>Advanced</b> و بعد <b dir="ltr">Go to … (unsafe)</b> بزنید (برنامه مال خودتان است) → تیک <b dir="ltr">View Search Console data</b> → <b>Continue</b>. به همین صفحه برمی‌گردید و property سایت خودکار انتخاب می‌شود.</li>
		</ol>
		<div class="aaw-field-stack">
			<label class="aaw-label">Client ID</label>
			<input class="aaw-input aaw-mono" dir="ltr" data-gsc-client-id value="<?php echo esc_attr( $client_id ); ?>" placeholder="1234567890-xxxx.apps.googleusercontent.com" autocomplete="off">
			<label class="aaw-label aaw-mt-sm">Client secret</label>
			<input class="aaw-input aaw-mono" dir="ltr" type="password" data-gsc-client-secret placeholder="<?php echo esc_attr( isset( $meta['gsc_client'] ) ? 'ذخیره شده (برای تغییر، مقدار جدید وارد کنید)' : 'GOCSPX-…' ); ?>" autocomplete="off">
		</div>
		<div class="aaw-btn-row aaw-mt-sm">
			<button type="button" class="aaw-btn aaw-btn-dark" data-action="gsc-client-save" <?php disabled( ! $deployed ); ?>><?php AAW_Icons::e( 'lock', 16 ); ?> ذخیره امن</button>
			<button type="button" class="aaw-btn aaw-btn-primary" data-action="gsc-google-login" <?php disabled( ! $deployed || '' === $client_id ); ?>><?php AAW_Icons::e( 'user', 16 ); ?> ورود با حساب گوگل</button>
		</div>

		<details class="aaw-mt aaw-gsc-alt">
			<summary><b>روش ۲ (پیشرفته): کلید Service Account (فایل JSON)</b></summary>
			<ol class="aaw-guide">
				<li>در همان پروژه Google Cloud، API سرچ کنسول را Enable کنید (مرحله ۲ بالا).</li>
				<li>در <a href="https://console.cloud.google.com/iam-admin/serviceaccounts" target="_blank" rel="noopener">IAM → Service Accounts</a> یک Service Account بسازید (نقش لازم نیست).</li>
				<li>روی آن بزنید → تب <b>Keys</b> → <b>Add key → Create new key → JSON</b>. یک فایل دانلود می‌شود.</li>
				<li>ایمیل Service Account (مثل <code dir="ltr">name@project.iam.gserviceaccount.com</code>) را در <a href="https://search.google.com/search-console/users" target="_blank" rel="noopener">Search Console → Settings → Users and permissions</a> با <b>Add user</b> اضافه کنید.</li>
				<li>فایل JSON را با Notepad باز کنید، کل محتوا را (Ctrl+A) کپی و این‌جا جای‌گذاری و ذخیره کنید.</li>
			</ol>
			<textarea class="aaw-input aaw-mono" rows="5" dir="ltr" data-gsc-json placeholder='{"type":"service_account","project_id":"…","private_key":"-----BEGIN PRIVATE KEY-----…","client_email":"…@….iam.gserviceaccount.com", …}'></textarea>
			<button type="button" class="aaw-btn aaw-btn-ghost aaw-btn-block" data-action="gsc-key-save" <?php disabled( ! $deployed ); ?>><?php AAW_Icons::e( 'lock', 16 ); ?> ذخیره کلید JSON و اتصال</button>
		</details>

		<div class="aaw-mt" data-gsc-sites <?php echo $has_key ? '' : 'hidden'; ?>>
			<label class="aaw-label">Property سرچ کنسول</label>
			<div class="aaw-combo">
				<select class="aaw-input" data-gsc-site><?php if ( $site ) : ?><option value="<?php echo esc_attr( $site ); ?>" selected><?php echo esc_html( $site ); ?></option><?php endif; ?></select>
				<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="gsc-sites"><?php AAW_Icons::e( 'refresh', 14 ); ?></button>
				<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-dark" data-action="gsc-site-save"><?php AAW_Icons::e( 'check', 14 ); ?> ذخیره</button>
			</div>
			<?php if ( $has_key ) : ?><button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost aaw-mt-sm" data-action="gsc-disconnect"><?php AAW_Icons::e( 'x', 14 ); ?> قطع اتصال</button><?php endif; ?>
		</div>
		<p class="aaw-muted aaw-mt"><?php AAW_Icons::e( 'info', 13 ); ?> دسترسی فقط خواندنی است؛ افزونه هیچ تغییری در سرچ کنسول نمی‌دهد. Client Secret و اجازه دسترسی فقط در کلادفلر شما نگهداری می‌شوند و همه درخواست‌های گوگل از کلادفلر انجام می‌شود، نه از هاست. اگر Google Cloud باز نشد، این مراحل را با مرورگری انجام دهید که به آن دسترسی دارد.</p>
		<?php AAW_Admin::card_close(); ?>
	</div>
</div>
</div>
