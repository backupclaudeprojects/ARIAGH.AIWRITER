<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$s         = AAW_Settings::all();
$providers = AAW_Providers::all();
$meta      = AAW_Settings::key_meta();
$deployed  = AAW_Cloudflare::is_deployed();
AAW_Admin::head( 'کلیدهای API و تنظیمات مدل', 'کلیدها و تنظیمات فنی مدل‌های متنی. کلیدهای API مستقیماً در Secrets ورکر کلادفلر ذخیره می‌شوند و هرگز در دیتابیس وردپرس نگهداری نمی‌شوند.', 'cpu' );
if ( ! $deployed ) :
	?>
	<div class="aaw-alert is-warn"><?php AAW_Icons::e( 'alert', 18 ); ?><div><b>ورکر هنوز مستقر نشده است.</b> برای ذخیره امن کلیدها ابتدا از <a href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=cloudflare' ) ); ?>">تب کلادفلر</a> اتصال و استقرار را انجام دهید.</div></div>
<?php endif; ?>

<a class="aaw-alert is-info aaw-sub-banner" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=subscription' ) ); ?>">
	<?php AAW_Icons::e( 'sparkles', 18 ); ?>
	<div><b>اکانت Claude Pro یا ChatGPT Plus دارید ولی API ندارید؟</b> در تب «اکانت اشتراکی» یاد بگیرید چطور رایگان و قانونی با همان اکانت چت، مقاله تولید کنید.</div>
</a>

<form class="aaw-form" data-settings data-ai-form>
	<?php AAW_Admin::card_open( 'تنظیمات مدل‌های متنی', 'انتخاب و ترتیب هوش مصنوعی‌ها به تب اصلی «هوش مصنوعی تولید محتوا» منتقل شد', 'zap' ); ?>
	<a class="aaw-alert is-info aaw-sub-banner" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=text_ai' ) ); ?>">
		<?php AAW_Icons::e( 'content', 18 ); ?>
		<div><b>ترتیب فعلی:</b> <?php echo esc_html( implode( ' ← ', array_map( function ( $id ) { $p = AAW_Providers::get( $id ); return $p ? $p['name'] : $id; }, AAW_Priority::text_chain() ) ) ); ?><br><small>برای تغییر اولویت (اشتراکی، API، رایگان) به تب «هوش مصنوعی تولید محتوا» بروید. این صفحه فقط کلیدها و تنظیمات فنی است.</small></div>
	</a>
	<div class="aaw-divider"></div>
	<div class="aaw-grid aaw-grid-2">
		<div>
			<?php AAW_Admin::range( 'temperature', 'خلاقیت (Temperature)', 0, 2, 0.05 ); ?>
			<?php AAW_Admin::range( 'top_p', 'Top P', 0, 1, 0.05 ); ?>
			<?php AAW_Admin::number( 'max_tokens', 'حداکثر توکن خروجی', '', 500, 64000, 500 ); ?>
		</div>
		<div>
			<?php AAW_Admin::toggle( 'two_pass', 'تولید دو مرحله‌ای', 'ابتدا Outline سپس مقاله (کیفیت بالاتر)' ); ?>
			<?php AAW_Admin::toggle( 'json_mode', 'حالت JSON ساخت‌یافته' ); ?>
			<?php AAW_Admin::number( 'request_timeout', 'مهلت هر درخواست', '', 20, 600, 10, 'ثانیه' ); ?>
			<?php AAW_Admin::number( 'retries', 'تلاش مجدد در خطا', '', 0, 5 ); ?>
		</div>
	</div>
	<?php AAW_Admin::card_close(); ?>
	<?php AAW_Admin::save_bar( 'ذخیره تنظیمات هوش مصنوعی' ); ?>
</form>

<div class="aaw-section-head">
	<h2><?php AAW_Icons::e( 'key', 18 ); ?> پرووایدرها و کلیدهای API</h2>
	<div class="aaw-search"><?php AAW_Icons::e( 'search', 16 ); ?><input type="search" class="aaw-input" placeholder="جستجوی پرووایدر…" data-provider-search></div>
</div>
<div class="aaw-provider-grid" data-provider-grid>
	<?php foreach ( $providers as $id => $p ) : if ( 'github_runner' === $p['format'] ) { continue; } $has = isset( $meta[ $id ] ) || ! $p['requires_key']; ?>
		<div class="aaw-provider <?php echo $has ? 'has-key' : ''; ?> <?php echo $id === $s['provider'] ? 'is-active' : ''; ?>" data-provider="<?php echo esc_attr( $id ); ?>" data-name="<?php echo esc_attr( strtolower( $p['name'] ) ); ?>">
			<div class="aaw-provider-head">
				<span class="aaw-mono-badge" style="--c:<?php echo esc_attr( $p['color'] ); ?>"><?php echo esc_html( mb_strtoupper( mb_substr( preg_replace( '/[^A-Za-z]/', '', $p['name'] ) ?: $p['name'], 0, 2 ) ) ); ?></span>
				<div>
					<b><?php echo esc_html( $p['name'] ); ?></b>
					<small><?php echo esc_html( $p['badge'] ); ?></small>
				</div>
				<span class="aaw-provider-state" title="<?php echo $has ? 'کلید ثبت شده' : 'بدون کلید'; ?>"><?php AAW_Icons::e( $has ? 'check-circle' : 'key', 18 ); ?></span>
			</div>
			<code class="aaw-provider-url" dir="ltr"><?php echo esc_html( $p['base_url'] ? $p['base_url'] : 'env.AI (Workers AI binding)' ); ?></code>
			<?php if ( $p['requires_key'] ) : ?>
				<div class="aaw-key-row">
					<div class="aaw-pass">
						<input type="password" class="aaw-input" placeholder="<?php echo esc_attr( isset( $meta[ $id ] ) ? $meta[ $id ]['mask'] : 'کلید API را وارد کنید' ); ?>" dir="ltr" autocomplete="off" data-key-input>
						<button type="button" class="aaw-icon-btn" data-toggle-pass aria-label="نمایش"><?php AAW_Icons::e( 'eye', 16 ); ?></button>
					</div>
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-dark" data-action="key-save"><?php AAW_Icons::e( 'lock', 14 ); ?> ذخیره</button>
				</div>
				<?php if ( isset( $meta[ $id ] ) ) : ?>
					<small class="aaw-muted">ثبت‌شده در Secrets کلادفلر · <?php echo esc_html( human_time_diff( $meta[ $id ]['time'] ) ); ?> پیش</small>
				<?php endif; ?>
			<?php else : ?>
				<div class="aaw-note-ok"><?php AAW_Icons::e( 'shield', 14 ); ?> بدون نیاز به کلید؛ از سهمیه Workers AI حساب شما استفاده می‌شود.</div>
			<?php endif; ?>
			<div class="aaw-provider-actions">
				<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="provider-use" title="اولویت اول لیست محتوا شود"><?php AAW_Icons::e( 'target', 14 ); ?> اولویت اول</button>
				<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="provider-test"><?php AAW_Icons::e( 'zap', 14 ); ?> تست</button>
				<?php if ( isset( $meta[ $id ] ) ) : ?>
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost is-danger" data-action="key-delete"><?php AAW_Icons::e( 'trash', 14 ); ?></button>
				<?php endif; ?>
				<?php if ( ! empty( $p['custom'] ) ) : ?>
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="custom-edit"><?php AAW_Icons::e( 'edit', 14 ); ?></button>
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost is-danger" data-action="custom-delete"><?php AAW_Icons::e( 'x', 14 ); ?></button>
				<?php elseif ( $p['key_url'] ) : ?>
					<a class="aaw-btn aaw-btn-sm aaw-btn-ghost" href="<?php echo esc_url( $p['key_url'] ); ?>" target="_blank" rel="noopener"><?php AAW_Icons::e( 'external', 14 ); ?> دریافت کلید</a>
				<?php endif; ?>
			</div>
		</div>
	<?php endforeach; ?>
	<button type="button" class="aaw-provider aaw-provider-add" data-action="custom-new">
		<span class="aaw-add-ic"><?php AAW_Icons::e( 'plus', 22 ); ?></span>
		<b>افزودن پرووایدر شخصی</b>
		<small>هر API سازگار با OpenAI یا Anthropic با Base URL دلخواه (Ollama، vLLM، Azure، LiteLLM، سرویس‌های ایرانی…)</small>
	</button>
</div>

<template id="aaw-custom-form">
	<form class="aaw-custom-form" autocomplete="off">
		<input type="hidden" name="id">
		<div class="aaw-grid aaw-grid-2">
			<div><label class="aaw-label">نام نمایشی</label><input class="aaw-input" name="name" required placeholder="My LLM Server"></div>
			<div><label class="aaw-label">فرمت API</label><div class="aaw-select-wrap"><select class="aaw-input" name="format"><option value="openai">OpenAI-compatible (chat/completions)</option><option value="anthropic">Anthropic Messages</option></select><?php AAW_Icons::e( 'chevron-down', 16, 'aaw-select-ic' ); ?></div></div>
		</div>
		<label class="aaw-label">Base URL</label>
		<input class="aaw-input" name="base_url" required dir="ltr" placeholder="https://api.example.com/v1">
		<div class="aaw-grid aaw-grid-2">
			<div><label class="aaw-label">مسیر Endpoint</label><input class="aaw-input" name="path" dir="ltr" placeholder="/chat/completions"></div>
			<div><label class="aaw-label">Query string <small>(اختیاری)</small></label><input class="aaw-input" name="query" dir="ltr" placeholder="api-version=2024-10-21"></div>
		</div>
		<div class="aaw-grid aaw-grid-2">
			<div><label class="aaw-label">مدل پیش‌فرض</label><input class="aaw-input" name="default_model" dir="ltr" placeholder="llama3.1:70b"></div>
			<div><label class="aaw-label">نوع احراز هویت</label><div class="aaw-select-wrap"><select class="aaw-input" name="auth_header"><option value="authorization">Authorization: Bearer</option><option value="x-api-key">x-api-key</option><option value="api-key">api-key (Azure)</option><option value="none">بدون کلید</option></select><?php AAW_Icons::e( 'chevron-down', 16, 'aaw-select-ic' ); ?></div></div>
		</div>
		<label class="aaw-label">کلید API <small>(در Secrets کلادفلر ذخیره می‌شود)</small></label>
		<input class="aaw-input" name="key" type="password" dir="ltr" placeholder="sk-...">
		<label class="aaw-label">هدرهای اضافه <small>(هر خط Name: Value)</small></label>
		<textarea class="aaw-input aaw-mono" name="headers" rows="2" dir="ltr" placeholder="HTTP-Referer: https://mysite.com"></textarea>
		<div class="aaw-row-between">
			<label class="aaw-check"><input type="checkbox" name="json_mode" value="1"> پشتیبانی از response_format JSON</label>
			<input type="color" name="color" value="#475569" title="رنگ نشان">
		</div>
	</form>
</template>
