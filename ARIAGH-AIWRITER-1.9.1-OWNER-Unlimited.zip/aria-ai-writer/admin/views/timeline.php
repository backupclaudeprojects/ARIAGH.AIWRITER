<?php
/**
 * Tab: timeline of past and future articles.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
AAW_Admin::head( 'خط زمانی تولید محتوا', 'ببینید هوش مصنوعی تا امروز چه مقالاتی نوشته، الان چه می‌کند و در آینده چه موضوعی را در چه زمانی خواهد نوشت.', 'calendar', '<button type="button" class="aaw-btn aaw-btn-ghost" data-action="timeline-refresh">' . AAW_Icons::get( 'refresh', 16 ) . ' به‌روزرسانی</button>' );
?>
<section class="aaw-card aaw-now" data-now>
	<div class="aaw-card-body"><div class="aaw-skeleton"></div></div>
</section>
<div class="aaw-toolbar">
	<div class="aaw-tabs-pill" data-tl-filter>
		<button type="button" class="is-active" data-f="all">همه</button>
		<button type="button" data-f="future">برنامه آینده</button>
		<button type="button" data-f="past">تولیدشده‌ها</button>
	</div>
	<div class="aaw-btn-row">
		<a class="aaw-btn aaw-btn-ghost" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=topics' ) ); ?>"><?php AAW_Icons::e( 'list', 16 ); ?> مدیریت ترتیب موضوعات</a>
		<a class="aaw-btn aaw-btn-ghost" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=schedule' ) ); ?>"><?php AAW_Icons::e( 'clock', 16 ); ?> تغییر زمان‌بندی</a>
	</div>
</div>
<div class="aaw-tl" data-timeline><div class="aaw-skeleton aaw-skeleton-lg"></div></div>
