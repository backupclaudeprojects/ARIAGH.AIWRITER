<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$s     = AAW_Settings::all();
$exprs = AAW_Cloudflare::cron_expressions();
$runs  = array();
$from  = time();
if ( $exprs ) {
	for ( $i = 0; $i < 6; $i++ ) {
		$best = 0;
		foreach ( $exprs as $e ) {
			$t = AAW_Cloudflare::next_from_expr( $e, $from );
			if ( $t && ( ! $best || $t < $best ) ) {
				$best = $t;
			}
		}
		if ( ! $best ) {
			break;
		}
		$runs[] = $best;
		$from   = $best;
	}
}
AAW_Admin::head( 'زمان‌بندی اجرا', 'ورکر کلادفلر طبق این زمان‌بندی اجرا می‌شود. با ذخیره، Cron Trigger کلادفلر به‌صورت خودکار به‌روز می‌شود.', 'clock' );
?>
<form class="aaw-form" data-settings>
	<div class="aaw-grid aaw-grid-2-1">
		<div>
			<?php AAW_Admin::card_open( 'وضعیت', '', 'power' ); ?>
			<?php AAW_Admin::toggle( 'enabled', 'تولید خودکار فعال باشد', 'کلید اصلی افزونه' ); ?>
			<?php AAW_Admin::toggle( 'paused', 'توقف موقت زمان‌بندی', 'Cron کلادفلر خالی می‌شود؛ اجرای دستی همچنان کار می‌کند' ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'فاصله اجرا', 'زمان‌ها بر اساس UTC در کلادفلر ثبت می‌شوند', 'calendar' ); ?>
			<?php AAW_Admin::segmented( 'cron_mode', 'حالت', array( 'interval' => 'هر چند ساعت', 'custom' => 'Cron سفارشی' ) ); ?>
			<div class="aaw-field" data-show-if="cron_mode=interval">
				<div class="aaw-field-label"><label>هر چند ساعت یک‌بار</label><small>فاصله دلخواه ۱ تا ۱۶۸ ساعت</small></div>
				<div class="aaw-field-control">
					<div class="aaw-interval-chips" data-interval-chips>
						<?php foreach ( array( 1, 2, 3, 4, 6, 8, 12, 24, 48, 72, 168 ) as $h ) : ?>
							<button type="button" data-h="<?php echo esc_attr( $h ); ?>" class="<?php echo (int) $s['interval_hours'] === $h ? 'is-active' : ''; ?>"><?php echo esc_html( $h < 24 ? number_format_i18n( $h ) . ' ساعت' : number_format_i18n( $h / 24 ) . ' روز' ); ?></button>
						<?php endforeach; ?>
					</div>
					<div class="aaw-input-group aaw-mt"><input class="aaw-input aaw-input-sm" type="number" name="interval_hours" min="1" max="168" value="<?php echo esc_attr( $s['interval_hours'] ); ?>"><span class="aaw-suffix">ساعت</span></div>
				</div>
			</div>
			<div data-show-if="cron_mode=interval"><?php AAW_Admin::number( 'run_minute', 'دقیقه اجرا', 'مثلاً ۱۵ یعنی ساعت X:15', 0, 59 ); ?></div>
			<div data-show-if="cron_mode=custom"><?php AAW_Admin::textarea( 'custom_cron', 'عبارت‌های Cron', 'حداکثر ۳ عبارت، هر خط یکی (UTC). مثال: 30 4 * * 1-5', "0 5 * * *\n0 17 * * *", 3 ); ?></div>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'رفتار اجرا', '', 'settings' ); ?>
			<?php AAW_Admin::number( 'posts_per_run', 'تعداد مقاله در هر اجرا', '', 1, 5 ); ?>
			<?php AAW_Admin::number( 'daily_limit', 'سقف مقاله در روز', '۰ یعنی نامحدود', 0, 100 ); ?>
			<?php AAW_Admin::toggle( 'auto_topics', 'ایده‌پردازی خودکار', 'وقتی صف خالی شد AI موضوع جدید پیشنهاد و تولید می‌کند' ); ?>
			<?php AAW_Admin::number( 'auto_topics_count', 'تعداد ایده در هر نوبت', '', 1, 30 ); ?>
			<?php AAW_Admin::toggle( 'retry_failed', 'تلاش مجدد موضوعات ناموفق' ); ?>
			<?php AAW_Admin::number( 'max_attempts', 'حداکثر دفعات تلاش هر موضوع', '', 1, 10 ); ?>
			<?php AAW_Admin::card_close(); ?>
		</div>
		<div>
			<?php AAW_Admin::card_open( 'اجراهای بعدی', 'به وقت سایت شما', 'clock' ); ?>
			<?php if ( $runs ) : ?>
				<ol class="aaw-timeline">
					<?php foreach ( $runs as $i => $t ) : ?>
						<li class="<?php echo 0 === $i ? 'is-next' : ''; ?>"><b><?php echo esc_html( wp_date( 'l', $t ) ); ?></b><span><?php echo esc_html( wp_date( 'Y/m/d · H:i', $t ) ); ?></span></li>
					<?php endforeach; ?>
				</ol>
				<?php if ( AAW_Cloudflare::needs_gating() ) : ?>
					<small class="aaw-muted">این فاصله بر ۲۴ بخش‌پذیر نیست؛ ورکر هر ساعت/روز بیدار می‌شود و وردپرس فقط در زمان مقرر اجازه تولید می‌دهد.</small>
				<?php endif; ?>
			<?php else : ?>
				<div class="aaw-empty"><?php AAW_Icons::e( 'pause', 28 ); ?><p>زمان‌بندی غیرفعال است.</p></div>
			<?php endif; ?>
			<div class="aaw-codebox"><small>Cron فعلی</small><code dir="ltr"><?php echo esc_html( $exprs ? implode( ' | ', $exprs ) : '—' ); ?></code></div>
			<button type="button" class="aaw-btn aaw-btn-ghost aaw-btn-block" data-action="cf-schedule"><?php AAW_Icons::e( 'refresh', 16 ); ?> اعمال مجدد در کلادفلر</button>
			<?php AAW_Admin::card_close(); ?>
		</div>
	</div>
	<?php AAW_Admin::save_bar( 'ذخیره و اعمال زمان‌بندی' ); ?>
</form>
