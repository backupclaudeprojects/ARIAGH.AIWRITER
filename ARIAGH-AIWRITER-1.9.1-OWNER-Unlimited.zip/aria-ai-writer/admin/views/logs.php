<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$actions = '<button type="button" class="aaw-btn aaw-btn-ghost" data-action="logs-export">' . AAW_Icons::get( 'download', 16 ) . ' خروجی CSV</button>'
	. '<button type="button" class="aaw-btn aaw-btn-ghost is-danger" data-action="logs-clear">' . AAW_Icons::get( 'trash', 16 ) . ' پاک کردن</button>';
AAW_Admin::head( 'گزارش‌ها', 'همه رویدادهای تولید، استقرار، خطاها و مصرف توکن.', 'activity', $actions );
?>
<div class="aaw-toolbar">
	<div class="aaw-tabs-pill" data-log-level>
		<button type="button" class="is-active" data-level="">همه</button>
		<button type="button" data-level="success">موفق</button>
		<button type="button" data-level="info">اطلاعات</button>
		<button type="button" data-level="warning">هشدار</button>
		<button type="button" data-level="error">خطا</button>
	</div>
	<div class="aaw-btn-row">
		<div class="aaw-select-wrap aaw-w-auto"><select class="aaw-input" data-log-event>
			<option value="">همه رویدادها</option>
			<option value="draft">ساخت پیش‌نویس</option>
			<option value="run">اجرا</option>
			<option value="deploy">استقرار</option>
			<option value="schedule">زمان‌بندی</option>
			<option value="secret">کلیدها</option>
			<option value="test">تست</option>
			<option value="approve">تایید</option>
			<option value="duplicate">تکراری</option>
			<option value="topics">موضوعات</option>
			<option value="image">تصویر</option>
		</select><?php AAW_Icons::e( 'chevron-down', 16, 'aaw-select-ic' ); ?></div>
		<div class="aaw-search"><?php AAW_Icons::e( 'search', 16 ); ?><input type="search" class="aaw-input" placeholder="جستجو…" data-log-search></div>
	</div>
</div>
<section class="aaw-card aaw-card-flush">
	<div class="aaw-table-wrap">
		<table class="aaw-table">
			<thead><tr><th>زمان</th><th>وضعیت</th><th>رویداد</th><th>پیام</th><th>مدل</th><th>مدت</th><th>توکن</th></tr></thead>
			<tbody data-logs><tr><td colspan="7"><div class="aaw-skeleton"></div></td></tr></tbody>
		</table>
	</div>
	<div class="aaw-pager" data-log-pager></div>
</section>
