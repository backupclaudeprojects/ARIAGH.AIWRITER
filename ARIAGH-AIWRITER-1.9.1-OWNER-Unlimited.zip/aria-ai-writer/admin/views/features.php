<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$groups = AAW_Features::groups();
$total  = AAW_Features::count();
AAW_Admin::head( 'قابلیت‌ها', number_format_i18n( $total ) . ' قابلیت پیاده‌سازی‌شده در افزونه و ورکر', 'layers' );
?>
<div class="aaw-toolbar">
	<div class="aaw-search aaw-search-wide"><?php AAW_Icons::e( 'search', 16 ); ?><input type="search" class="aaw-input" placeholder="جستجو در قابلیت‌ها…" data-feature-search></div>
	<span class="aaw-muted" data-feature-count><?php echo esc_html( number_format_i18n( $total ) ); ?> مورد</span>
</div>
<div class="aaw-features">
	<?php $n = 0; foreach ( $groups as $g ) : ?>
		<section class="aaw-card aaw-feature-group">
			<div class="aaw-card-head"><div class="aaw-card-title"><span class="aaw-card-ic"><?php AAW_Icons::e( $g['icon'], 18 ); ?></span><div><h2><?php echo esc_html( $g['title'] ); ?></h2><p><?php echo esc_html( number_format_i18n( count( $g['items'] ) ) ); ?> قابلیت</p></div></div></div>
			<ol class="aaw-feature-list" start="<?php echo esc_attr( $n + 1 ); ?>">
				<?php foreach ( $g['items'] as $item ) : $n++; ?>
					<li><span class="aaw-fnum"><?php echo esc_html( number_format_i18n( $n ) ); ?></span><?php echo esc_html( $item ); ?></li>
				<?php endforeach; ?>
			</ol>
		</section>
	<?php endforeach; ?>
</div>
