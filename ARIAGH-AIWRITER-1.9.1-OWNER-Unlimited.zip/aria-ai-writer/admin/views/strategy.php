<?php
/**
 * Tab: smart site analysis & content strategy.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$s        = AAW_Settings::all();
$record   = AAW_Analyzer::get();
$provider = AAW_Providers::get( $s['provider'] );
$web      = AAW_Analyzer::web_capable();
AAW_Analyzer::check_stale(); // A dead job is resolved before the page is drawn.
$pending  = (bool) get_option( 'aaw_analysis_pending' );
$a_error  = (string) get_option( 'aaw_analysis_error', '' );
$a_job    = get_option( AAW_Analyzer::JOB );
$sd       = AAW_SiteData::status();
AAW_Admin::head( 'تحلیل هوشمند سایت', 'هوش مصنوعی کل سایت، محصولات، دسته‌ها و رقبا را بررسی می‌کند و یک برنامه محتوای کامل با بهترین موضوعات و کلمات کلیدی می‌سازد.', 'wand' );
?>
<div class="aaw-strategy" data-strategy data-record="<?php echo esc_attr( wp_json_encode( $record ) ); ?>" data-pending="<?php echo $pending ? '1' : '0'; ?>" data-started="<?php echo esc_attr( is_array( $a_job ) ? (int) $a_job['t'] : 0 ); ?>" data-mode="<?php echo esc_attr( is_array( $a_job ) ? $a_job['mode'] : '' ); ?>" data-error="<?php echo esc_attr( $pending ? '' : $a_error ); ?>" data-autostart="<?php echo isset( $_GET['start'] ) ? '1' : '0'; // phpcs:ignore ?>">

	<section class="aaw-card aaw-sub-hero">
		<div class="aaw-card-body">
			<h2>هوش مصنوعی چه کار می‌کند؟</h2>
			<div class="aaw-flow">
				<div class="aaw-flow-step"><span><?php AAW_Icons::e( 'database', 20 ); ?></span><b>۱. خواندن سایت</b><small><?php echo $sd['available'] ? 'GitHub کل سایت را می‌خواند و نسخه پشتیبان می‌سازد' : 'مقالات، برگه‌ها، محصولات، دسته‌ها و برچسب‌ها'; ?></small></div>
				<i><?php AAW_Icons::e( 'chevron-left', 18 ); ?></i>
				<div class="aaw-flow-step"><span><?php AAW_Icons::e( 'globe', 20 ); ?></span><b>۲. بررسی رقبا</b><small>صفحه اصلی و نقشه سایت رقبایی که وارد می‌کنید</small></div>
				<i><?php AAW_Icons::e( 'chevron-left', 18 ); ?></i>
				<div class="aaw-flow-step is-accent"><span><?php AAW_Icons::e( 'sparkles', 20 ); ?></span><b>۳. تحلیل استراتژیک</b><small>شکاف محتوا، ستون‌ها، روندهای روز، نیت جستجو</small></div>
				<i><?php AAW_Icons::e( 'chevron-left', 18 ); ?></i>
				<div class="aaw-flow-step"><span><?php AAW_Icons::e( 'list', 20 ); ?></span><b>۴. برنامه محتوا</b><small>موضوعات اولویت‌بندی‌شده با کلمات کلیدی، آماده افزودن به صف</small></div>
			</div>
		</div>
	</section>

	<div class="aaw-grid aaw-grid-1-2">
		<div>
			<?php AAW_Admin::card_open( 'شروع تحلیل جدید', '', 'play' ); ?>
			<form data-analysis-form autocomplete="off">
				<div class="aaw-engine-chip">
					<span class="aaw-chip is-info"><?php AAW_Icons::e( 'cpu', 14 ); ?> موتور: <?php echo esc_html( $provider ? $provider['name'] : '—' ); ?></span>
					<span class="aaw-chip <?php echo $web ? 'is-ok' : ''; ?>" title="<?php echo $web ? 'این موتور می‌تواند در اینترنت جستجو کند' : 'این موتور به اینترنت دسترسی ندارد؛ از دانش خودش و داده‌های رقبا استفاده می‌کند'; ?>"><?php AAW_Icons::e( 'globe', 14 ); ?> جستجوی زنده وب: <?php echo $web ? 'فعال' : 'غیرفعال'; ?></span>
				</div>
				<?php if ( ! $web ) : ?>
					<p class="aaw-muted"><?php AAW_Icons::e( 'info', 14 ); ?> برای تحلیل با اطلاعات لحظه‌ای اینترنت، موتور اصلی را Claude Pro/Max (اکانت اشتراکی)، Perplexity یا OpenRouter قرار دهید. در غیر این صورت داده‌های واقعی رقبا (پایین) همچنان جمع‌آوری و تحلیل می‌شود.</p>
				<?php endif; ?>
				<label class="aaw-label">سایت رقبا <small>(اختیاری، حداکثر ۵ آدرس، هر خط یکی)</small></label>
				<textarea class="aaw-input" name="competitors" rows="4" dir="ltr" placeholder="digikala.com/mag&#10;competitor2.ir"></textarea>
				<label class="aaw-label">تعداد موضوع پیشنهادی</label>
				<div class="aaw-range"><input type="range" name="count" min="5" max="50" step="5" value="20"><output>20</output></div>
				<label class="aaw-label">تمرکز ویژه <small>(اختیاری)</small></label>
				<input class="aaw-input" name="hint" placeholder="مثلاً: فروش محصولات پرسود، مناسبت یلدا، مقالات راهنمای خرید" dir="auto">
				<button type="submit" class="aaw-btn aaw-btn-primary aaw-btn-block aaw-btn-lg" <?php disabled( $pending ); ?>><?php AAW_Icons::e( 'wand', 18 ); ?> شروع تحلیل هوشمند</button>
				<small class="aaw-muted">بسته به حجم سایت و موتور، ۱ تا ۵ دقیقه طول می‌کشد. در حالت اکانت اشتراکی اجرا در GitHub انجام می‌شود و می‌توانید صفحه را ترک کنید.</small>
			</form>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'نسخه پشتیبان سایت در GitHub', 'دیتابیس هوش مصنوعی برای لینک‌دهی و جلوگیری از مقاله تکراری', 'database' ); ?>
			<div data-site-data>
			<?php if ( $sd['available'] ) : ?>
				<p class="aaw-muted">با «شروع تحلیل»، هاست شما فقط یک درخواست کوچک به GitHub می‌فرستد. GitHub خودش کل سایت (متن همه مقالات، برگه‌ها، محصولات با قیمت و موجودی، دسته‌ها و برچسب‌ها) را می‌خواند، یک نسخه پشتیبان متنی کامل در مخزن خصوصی شما (شاخه <code dir="ltr">aaw-data</code>) می‌سازد و هر بار نسخه قبلی را حذف و جایگزین می‌کند. هوش مصنوعی هنگام نوشتن هر مقاله لینک محصولات، دسته‌ها و مقالات قبلی را از همان‌جا می‌بیند.</p>
				<?php if ( ! empty( $sd['data']['counts'] ) ) : $c = $sd['data']['counts']; ?>
					<div class="aaw-kv">
						<div><small>مقالات</small><code><?php echo esc_html( number_format_i18n( $c['posts'] ?? 0 ) ); ?></code></div>
						<div><small>محصولات</small><code><?php echo esc_html( number_format_i18n( $c['products'] ?? 0 ) ); ?></code></div>
						<div><small>برگه‌ها</small><code><?php echo esc_html( number_format_i18n( $c['pages'] ?? 0 ) ); ?></code></div>
						<div><small>دسته‌ها</small><code><?php echo esc_html( number_format_i18n( $c['categories'] ?? 0 ) ); ?></code></div>
						<div><small>آخرین به‌روزرسانی</small><code><?php echo esc_html( $sd['ago'] . ' پیش' ); ?></code></div>
						<div><small>روش خواندن</small><code><?php echo 'sitemap' === ( $sd['data']['source'] ?? '' ) ? 'نقشه سایت' : 'REST API'; ?></code></div>
					</div>
					<?php foreach ( (array) ( $sd['data']['notes'] ?? array() ) as $n ) : ?>
						<p class="aaw-muted"><?php AAW_Icons::e( 'info', 13 ); ?> <?php echo esc_html( $n ); ?></p>
					<?php endforeach; ?>
				<?php endif; ?>
				<?php if ( $sd['error'] ) : ?>
					<div class="aaw-alert is-error"><?php AAW_Icons::e( 'alert', 16 ); ?><div><?php echo nl2br( esc_html( $sd['error'] ) ); ?></div></div>
				<?php endif; ?>
				<?php if ( $sd['crawling'] ) : ?>
					<div class="aaw-alert is-info"><?php AAW_Icons::e( 'loader', 16 ); ?><div>GitHub در حال خواندن سایت است… (پیشرفت در «فعالیت زنده»)</div></div>
				<?php endif; ?>
				<div class="aaw-btn-row">
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="site-crawl" <?php disabled( $sd['crawling'] ); ?>><?php AAW_Icons::e( 'refresh', 14 ); ?> فقط به‌روزرسانی نسخه پشتیبان</button>
					<a class="aaw-btn aaw-btn-sm aaw-btn-ghost" href="<?php echo esc_url( $sd['url'] ); ?>" target="_blank" rel="noopener"><?php AAW_Icons::e( 'external', 14 ); ?> مشاهده در GitHub</a>
				</div>
				<small class="aaw-muted">موتور اجرای تحلیل در GitHub: <?php echo 'none' === $sd['engine'] ? 'هوش مصنوعی‌های API روی کلادفلر (طبق اولویت تب محتوا)' : ( 'codex' === $sd['engine'] ? 'اکانت اشتراکی ChatGPT' : 'اکانت اشتراکی Claude' ); ?></small>
			<?php else : ?>
				<div class="aaw-alert is-warn"><?php AAW_Icons::e( 'alert', 16 ); ?><div>برای اینکه سایت از GitHub خوانده شود (بدون فشار به هاست)، GitHub را در <a href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=subscription' ) ); ?>">تب اکانت اشتراکی</a> وصل کنید؛ داشتن اکانت اشتراکی لازم نیست. تا آن موقع تحلیل به روش قبلی (ارسال اطلاعات از هاست) انجام می‌شود.</div></div>
			<?php endif; ?>
			</div>
			<?php AAW_Admin::card_close(); ?>
		</div>
		<div>
			<section class="aaw-card" data-analysis-progress hidden>
				<div class="aaw-card-body">
					<div class="aaw-row-between"><h3 class="aaw-h3" data-analysis-title><?php AAW_Icons::e( 'activity', 18 ); ?> در حال انجام…</h3><span class="aaw-row"><span class="aaw-muted" data-elapsed-a>۰ ثانیه</span> <button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="analysis-cancel"><?php AAW_Icons::e( 'x', 14 ); ?> لغو</button></span></div>
					<ol class="aaw-progress-steps">
						<li data-step="collect"><span class="dot"></span><div><b>جمع‌آوری اطلاعات سایت</b><small data-step-note></small></div></li>
						<li data-step="competitors"><span class="dot"></span><div><b>بررسی سایت رقبا</b><small data-step-note></small></div></li>
						<li data-step="ai"><span class="dot"></span><div><b>تحلیل استراتژیک با هوش مصنوعی</b><small data-step-note></small></div></li>
						<li data-step="done"><span class="dot"></span><div><b>آماده‌سازی برنامه محتوا</b><small data-step-note></small></div></li>
					</ol>
				</div>
			</section>
			<div data-analysis-report>
				<?php if ( ! $record ) : ?>
					<section class="aaw-card"><div class="aaw-empty"><?php AAW_Icons::e( 'wand', 30 ); ?><p>هنوز تحلیلی انجام نشده است. «شروع تحلیل هوشمند» را بزنید.</p></div></section>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
