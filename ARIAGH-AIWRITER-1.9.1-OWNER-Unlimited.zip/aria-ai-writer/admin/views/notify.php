<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$tg = AAW_Settings::secure_get( 'telegram_token' );
AAW_Admin::head( 'اعلان‌ها', 'وقتی مقاله جدید آماده تایید شد یا خطایی رخ داد باخبر شوید.', 'bell', '<button type="button" class="aaw-btn aaw-btn-ghost" data-action="test-notify">' . AAW_Icons::get( 'send', 16 ) . ' ارسال آزمایشی</button>' );
?>
<form class="aaw-form" data-settings>
	<div class="aaw-grid aaw-grid-2">
		<div>
			<?php AAW_Admin::card_open( 'ایمیل', '', 'send' ); ?>
			<?php AAW_Admin::toggle( 'notify_email', 'ارسال ایمیل برای پیش‌نویس جدید' ); ?>
			<?php AAW_Admin::text( 'notify_email_to', 'ایمیل گیرنده', 'خالی = ایمیل مدیر سایت', get_option( 'admin_email' ), 'email' ); ?>
			<?php AAW_Admin::toggle( 'notify_on_fail', 'اعلان خطاها' ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'تلگرام', 'ارسال پیام از طریق ربات شخصی', 'send' ); ?>
			<?php AAW_Admin::toggle( 'telegram_enabled', 'فعال‌سازی تلگرام' ); ?>
			<div class="aaw-field">
				<div class="aaw-field-label"><label>توکن ربات</label><small>از BotFather · رمزنگاری‌شده ذخیره می‌شود</small></div>
				<div class="aaw-field-control"><input class="aaw-input" type="password" name="telegram_token" dir="ltr" placeholder="<?php echo esc_attr( $tg ? AAW_Crypto::mask( $tg ) : '123456:ABC-DEF…' ); ?>"></div>
			</div>
			<?php AAW_Admin::text( 'telegram_chat', 'Chat ID', 'آیدی عددی کاربر یا کانال', '-100…' ); ?>
			<?php AAW_Admin::card_close(); ?>
		</div>
		<div>
			<?php AAW_Admin::card_open( 'وب‌هوک', 'ارسال رویدادها به Slack، Discord، n8n، Zapier و…', 'link' ); ?>
			<?php AAW_Admin::text( 'webhook_url', 'آدرس وب‌هوک', 'بدنه JSON با امضای X-AAW-Signature', 'https://', 'url' ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'داخل وردپرس', '', 'dashboard' ); ?>
			<?php AAW_Admin::toggle( 'dashboard_widget', 'ویجت پیشخوان وردپرس' ); ?>
			<?php AAW_Admin::toggle( 'admin_bar', 'شمارنده بازبینی در نوار مدیریت' ); ?>
			<?php AAW_Admin::toggle( 'posts_column', 'ستون «هوش مصنوعی» در لیست نوشته‌ها' ); ?>
			<?php AAW_Admin::card_close(); ?>
		</div>
	</div>
	<?php AAW_Admin::save_bar(); ?>
</form>
