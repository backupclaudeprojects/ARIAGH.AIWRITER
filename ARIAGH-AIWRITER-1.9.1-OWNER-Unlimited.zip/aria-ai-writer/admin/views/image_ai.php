<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$s       = AAW_Settings::all();
$items   = AAW_Priority::image_items();
$engines = AAW_Images::engines();
$current = AAW_Images::engine();
$meta    = AAW_Settings::key_meta();
AAW_Admin::head( 'هوش مصنوعی تولید تصویر', 'موتورهایی که تصویر شاخص و تصاویر داخل مقاله را می‌سازند و ترتیب استفاده از آن‌ها. اگر اولی خطا بدهد، بعدی امتحان می‌شود.', 'image', '<a class="aaw-btn aaw-btn-ghost" href="' . esc_url( admin_url( 'admin.php?page=aaw&tab=images' ) ) . '">' . AAW_Icons::get( 'settings', 16 ) . ' سبک، مرجع‌ها و تم</a>' );
?>
<div class="aaw-grid aaw-grid-main-side">
	<div>
		<?php AAW_Admin::card_open( 'اولویت موتورهای تصویر', 'بکشید و رها کنید؛ با کلید کنار هر مورد روشن یا خاموشش کنید', 'layers' ); ?>
		<label class="aaw-prio-master"><span class="aaw-switch"><input type="checkbox" data-prio-enabled <?php checked( (bool) $s['featured_image'] ); ?>><span></span></span> <b>تولید تصویر برای مقالات</b> <small class="aaw-muted">(خاموش = مقاله بدون تصویر ساخته می‌شود)</small></label>
		<div data-prio-wrap <?php echo $s['featured_image'] ? '' : 'class="is-disabled"'; ?>>
			<?php AAW_Admin::prio_list( 'image', $items ); ?>
		</div>
		<form class="aaw-form aaw-mt" data-settings>
			<?php AAW_Admin::toggle( 'image_free_fallback', 'اگر همه موتورهای بالا ناموفق شدند، Workers AI رایگان تصویر بسازد', 'مثلاً وقتی موجودی Higgsfield یا OpenAI تمام شده؛ مقاله هیچ‌وقت بی‌تصویر نمی‌ماند.' ); ?>
			<?php AAW_Admin::save_bar( 'ذخیره' ); ?>
		</form>
		<div class="aaw-row-between aaw-mt">
			<small class="aaw-muted">اکانت ChatGPT تصویر را بعد از ساخت پیش‌نویس از طریق GitHub می‌سازد (۲ تا ۵ دقیقه)؛ بقیه هم‌زمان با مقاله روی کلادفلر.</small>
			<button type="button" class="aaw-btn aaw-btn-primary" data-action="prio-save" data-kind="image"><?php AAW_Icons::e( 'check', 16 ); ?> ذخیره ترتیب</button>
		</div>
		<div data-img-test-out class="aaw-img-test-out"></div>
		<?php AAW_Admin::card_close(); ?>

		<div id="aaw-img-keys"></div>
		<?php AAW_Admin::card_open( 'کلید موتورهای تصویر', 'مستقیم در Secrets کلادفلر ذخیره می‌شود', 'key' ); ?>
		<?php foreach ( $engines as $id => $e ) : ?>
			<?php
			if ( '' === $e['secret'] ) {
				continue;
			}
			$meta_id = in_array( $id, array( 'openai', 'gemini' ), true ) ? $id : 'img_' . $id;
			?>
			<div class="aaw-field">
				<div class="aaw-field-label"><label><?php echo esc_html( $e['name'] ); ?></label>
					<small><?php echo in_array( $id, array( 'openai', 'gemini' ), true ) ? 'مشترک با کلیدهای API متنی' : esc_html( $e['secret'] ); ?><?php if ( $e['link'] ) : ?> · <a href="<?php echo esc_url( $e['link'] ); ?>" target="_blank" rel="noopener">دریافت کلید</a><?php endif; ?></small>
				</div>
				<div class="aaw-field-control aaw-combo">
					<input class="aaw-input" type="password" dir="ltr" data-img-key="<?php echo esc_attr( $id ); ?>" placeholder="<?php echo esc_attr( isset( $meta[ $meta_id ] ) ? $meta[ $meta_id ]['mask'] : ( 'higgsfield' === $id ? 'KEY_ID:KEY_SECRET' : 'کلید API' ) ); ?>" autocomplete="off">
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="img-key-save" data-engine="<?php echo esc_attr( $id ); ?>"><?php AAW_Icons::e( 'save', 14 ); ?> ذخیره</button>
				</div>
			</div>
		<?php endforeach; ?>
		<p class="aaw-muted">برای «سرویس سازگار با OpenAI» آدرس Base URL را در <a href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=images' ) ); ?>">تنظیمات تصاویر</a> وارد کنید. Google Flow و اشتراک‌های تصویرسازی (Midjourney، اشتراک Higgsfield) رابط رسمی خودکار ندارند؛ از کلید Google AI Studio یا Higgsfield API استفاده کنید.</p>
		<?php AAW_Admin::card_close(); ?>
	</div>
	<div>
		<?php
		$gh_ok    = AAW_GitHub::is_connected();
		$codex_ok = isset( $meta['sub_codex'] );
		$sub_url  = admin_url( 'admin.php?page=aaw&tab=subscription' );
		$r        = AAW_Priority::roles( 'sub_codex' );
		?>
		<?php AAW_Admin::card_open( 'تصویر با اکانت ChatGPT (بدون API)', 'برای کسانی که ChatGPT Plus/Pro دارند', 'user' ); ?>
		<div class="aaw-kv">
			<div><small>GitHub</small><code><?php echo $gh_ok ? 'وصل است' : 'وصل نیست'; ?></code></div>
			<div><small>ورود ChatGPT</small><code><?php echo $codex_ok ? 'ثبت شده' : 'ثبت نشده'; ?></code></div>
			<div><small>در این لیست</small><code><?php echo $r['image'] ? 'اولویت ' . esc_html( number_format_i18n( $r['image'] ) ) : 'خاموش'; ?></code></div>
		</div>
		<ol class="aaw-sub-guide">
			<li><b>چطور کار می‌کند؟</b> ابزار رسمی <a href="https://github.com/openai/codex" target="_blank" rel="noopener">OpenAI Codex</a> قابلیت داخلی ساخت تصویر (gpt-image) دارد که با ورود اکانت ChatGPT کار می‌کند و از سهمیه اشتراک کم می‌شود. برای هر مقاله یک اجرای GitHub Actions ساخته می‌شود و تصویر با عکس محصولات و نمونه تم سایت ساخته و تصویر شاخص می‌شود.</li>
			<li><b>GitHub را وصل کنید</b> در <a href="<?php echo esc_url( $sub_url ); ?>">تب اکانت اشتراکی</a> (توکن با دسترسی repo و workflow؛ <a href="https://github.com/settings/tokens/new?scopes=repo,workflow&description=ARIAGH%20AIWRITER" target="_blank" rel="noopener">ساخت مستقیم توکن</a>). <?php echo $gh_ok ? '✔' : ''; ?></li>
			<li><b>اکانت ChatGPT را وصل کنید:</b> با دکمه پایین همین کادر؛ فقط با اکانت ChatGPT وارد می‌شوید و یک کد تأیید وارد می‌کنید (بدون نصب برنامه). <?php echo $codex_ok ? '✔' : ''; ?></li>
			<li><b>در همین لیست روشنش کنید</b> و به اولویت دلخواه بکشید. اگر نمی‌خواهید ChatGPT مقاله هم بنویسد، در تب «هوش مصنوعی تولید محتوا» خاموشش بگذارید.</li>
			<li><b>تست:</b> در صف بازبینی روی یک مقاله «فقط تصویر جدید» را بزنید و پیشرفت را در <a href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=activity' ) ); ?>">فعالیت زنده</a> ببینید.</li>
			<li><b>محدودیت:</b> هر تصویر ۳ تا ۵ برابر یک پیام متنی از سهمیه Codex مصرف می‌کند و حداکثر ۸ مرجع ارسال می‌شود. برای تعداد زیاد، Workers AI (رایگان) را بعد از آن در لیست روشن بگذارید تا اگر سهمیه تمام شد جایگزین شود.</li>
		</ol>
		<?php include AAW_DIR . 'admin/views/partials-codex-login.php'; $aaw_codex_login_box( $gh_ok, $codex_ok ); ?>
		<?php AAW_Admin::card_close(); ?>
	</div>
</div>
