<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$detected = AAW_Post_Builder::detect_seo_plugin();
$authors  = array( 0 => 'اولین مدیر سایت' );
foreach ( get_users( array( 'capability' => 'edit_posts', 'number' => 100, 'fields' => array( 'ID', 'display_name' ) ) ) as $u ) {
	$authors[ $u->ID ] = $u->display_name;
}
$types = array();
foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $pt ) {
	if ( 'attachment' !== $pt->name ) {
		$types[ $pt->name ] = $pt->labels->singular_name;
	}
}
AAW_Admin::head( 'سئو و انتشار', 'بهینه‌سازی خودکار برای موتورهای جستجو و نحوه ذخیره مقاله در وردپرس.', 'seo' );
?>
<form class="aaw-form" data-settings>
	<div class="aaw-grid aaw-grid-2">
		<div>
			<?php AAW_Admin::card_open( 'افزونه سئو', 'افزونه شناسایی‌شده: ' . ( 'none' === $detected ? 'هیچ‌کدام' : $detected ), 'target' ); ?>
			<?php AAW_Admin::select( 'seo_plugin', 'ثبت متادیتا در', array( 'auto' => 'تشخیص خودکار', 'yoast' => 'Yoast SEO', 'rankmath' => 'Rank Math', 'aioseo' => 'All in One SEO', 'seopress' => 'SEOPress', 'none' => 'هیچ‌کدام' ) ); ?>
			<?php AAW_Admin::number( 'seo_title_max', 'حداکثر طول عنوان سئو', '', 30, 90, 1, 'کاراکتر' ); ?>
			<?php AAW_Admin::number( 'meta_desc_max', 'حداکثر طول توضیحات متا', '', 80, 320, 1, 'کاراکتر' ); ?>
			<?php AAW_Admin::range( 'keyword_density', 'تراکم کلمه کلیدی (٪)', 0.3, 3, 0.1 ); ?>
			<?php AAW_Admin::number( 'lsi_count', 'تعداد کلمات LSI', 'کلمات مرتبط معنایی', 0, 30 ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'نامک (Slug)', '', 'link' ); ?>
			<?php AAW_Admin::segmented( 'slug_mode', 'نوع نامک', array( 'ai_english' => 'انگلیسی (AI)', 'persian' => 'کلمه کلیدی', 'title' => 'از عنوان' ) ); ?>
			<?php AAW_Admin::number( 'slug_max_words', 'حداکثر کلمات نامک', '', 2, 15 ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'لینک‌سازی', '', 'link' ); ?>
			<?php AAW_Admin::segmented( 'internal_links_mode', 'لینک داخلی', array( 'ai' => 'هوشمند AI', 'auto' => 'تطبیق خودکار', 'both' => 'هر دو', 'off' => 'خاموش' ) ); ?>
			<?php AAW_Admin::number( 'internal_links_count', 'تعداد لینک داخلی', '', 0, 15 ); ?>
			<?php AAW_Admin::number( 'internal_links_pool', 'تعداد مطالب قابل لینک', 'جدیدترین مطالب منتشرشده', 10, 1000, 10 ); ?>
			<?php AAW_Admin::toggle( 'external_links_nofollow', 'nofollow برای لینک‌های خارجی' ); ?>
			<?php AAW_Admin::toggle( 'external_links_blank', 'باز شدن لینک خارجی در تب جدید' ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'فهرست مطالب و اسکیما', '', 'list' ); ?>
			<?php AAW_Admin::text( 'toc_title', 'عنوان فهرست مطالب' ); ?>
			<?php AAW_Admin::number( 'toc_min_headings', 'حداقل H2 برای نمایش', '', 1, 20 ); ?>
			<?php AAW_Admin::toggle( 'toc_collapsible', 'فهرست بازشونده' ); ?>
			<?php AAW_Admin::toggle( 'toc_numbered', 'شماره‌گذاری فهرست' ); ?>
			<?php AAW_Admin::toggle( 'faq_schema', 'اسکیمای FAQPage', 'نمایش سؤالات در نتایج گوگل' ); ?>
			<?php AAW_Admin::toggle( 'article_schema', 'اسکیمای Article', 'اگر افزونه سئو خودش اسکیما می‌سازد خاموش بماند' ); ?>
			<?php AAW_Admin::card_close(); ?>
		</div>
		<div>
			<?php AAW_Admin::card_open( 'ذخیره در وردپرس', 'مقالات به‌صورت پیش‌فرض پیش‌نویس می‌مانند تا شما تایید کنید', 'save' ); ?>
			<?php AAW_Admin::segmented( 'post_status', 'وضعیت مقاله', array( 'draft' => 'پیش‌نویس', 'pending' => 'در انتظار بررسی', 'future' => 'زمان‌بندی', 'publish' => 'انتشار مستقیم' ) ); ?>
			<?php AAW_Admin::number( 'future_days', 'فاصله انتشار زمان‌بندی‌شده', 'فقط برای حالت زمان‌بندی', 0, 60, 1, 'روز' ); ?>
			<?php AAW_Admin::select( 'post_type', 'نوع نوشته', $types ); ?>
			<?php AAW_Admin::select( 'author_id', 'نویسنده', $authors ); ?>
			<?php AAW_Admin::select( 'comment_status', 'دیدگاه‌ها', array( 'open' => 'باز', 'closed' => 'بسته' ) ); ?>
			<?php AAW_Admin::select( 'post_format', 'قالب نوشته', array( 'standard' => 'استاندارد', 'aside' => 'حاشیه', 'image' => 'تصویر', 'video' => 'ویدیو', 'quote' => 'نقل‌قول', 'link' => 'پیوند', 'gallery' => 'گالری', 'status' => 'وضعیت', 'audio' => 'صوت', 'chat' => 'گفتگو' ) ); ?>
			<?php AAW_Admin::toggle( 'excerpt_enabled', 'تولید چکیده (Excerpt)' ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'دسته و برچسب', '', 'folder' ); ?>
			<?php AAW_Admin::segmented( 'category_mode', 'تعیین دسته', array( 'ai_pick' => 'انتخاب هوشمند AI', 'fixed' => 'دسته ثابت', 'topic' => 'فقط از موضوع' ) ); ?>
			<?php AAW_Admin::select( 'default_category', 'دسته پیش‌فرض', AAW_Admin::categories_choices() ); ?>
			<?php AAW_Admin::toggle( 'create_tags', 'ساخت برچسب خودکار' ); ?>
			<?php AAW_Admin::number( 'tags_max', 'حداکثر برچسب', '', 0, 20 ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'تصاویر مقاله', 'تنظیمات کامل در تب «تصاویر»', 'image' ); ?>
			<?php AAW_Admin::toggle( 'featured_image', 'تولید تصویر شاخص' ); ?>
			<p class="aaw-muted">موتور تصویر (Workers AI، OpenAI، Gemini، Higgsfield و…)، عکس محصولات مقاله، تم تصویری سایت و تصاویر داخل متن در <a href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=images' ) ); ?>">تب تصاویر</a> تنظیم می‌شود.</p>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'لینک به محصولات فروشگاه', 'مقالات فروش‌محور با لینک واقعی به صفحه محصول', 'link' ); ?>
			<?php AAW_Admin::toggle( 'product_links', 'معرفی و لینک محصولات مرتبط در متن', 'نام، آدرس دقیق، قیمت و موجودی محصولات مرتبط به هوش مصنوعی داده می‌شود تا با انکر طبیعی لینک بدهد' ); ?>
			<?php AAW_Admin::number( 'product_links_count', 'تعداد محصولات هر مقاله', 'اول محصولات مرتبط با موضوع، در صورت کمبود پرفروش‌ترین‌ها', 1, 8 ); ?>
			<?php AAW_Admin::toggle( 'product_box', 'باکس «محصولات پیشنهادی» اگر لینکی در متن نبود' ); ?>
			<?php AAW_Admin::text( 'product_box_title', 'عنوان باکس محصولات' ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'جلوگیری از تکرار', '', 'shield' ); ?>
			<?php AAW_Admin::toggle( 'duplicate_check', 'بررسی شباهت با مقالات موجود' ); ?>
			<?php AAW_Admin::range( 'duplicate_threshold', 'آستانه شباهت (٪)', 50, 100, 1, 'شباهت عنوان و کلمه کلیدی با مقالات منتشرشده، پیش‌نویس‌ها، محصولات و صف موضوعات. بالاتر از آستانه = رد؛ مشابه‌ها به هوش مصنوعی معرفی می‌شوند تا زاویه تازه بنویسد و لینک بدهد.' ); ?>
			<?php AAW_Admin::card_close(); ?>
		</div>
	</div>
	<?php AAW_Admin::save_bar(); ?>
</form>
