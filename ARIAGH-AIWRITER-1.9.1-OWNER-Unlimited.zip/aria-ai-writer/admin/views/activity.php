<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
AAW_Admin::head(
	'فعالیت زنده',
	'هر کاری که افزونه و هوش مصنوعی انجام می‌دهند (تست اتصال، نوشتن مقاله، ساخت تصویر، تحلیل، اصلاح، یادگیری) همین‌جا با مرحله فعلی و زمان سپری‌شده نمایش داده می‌شود.',
	'activity',
	'<button type="button" class="aaw-btn aaw-btn-ghost" data-action="activity-clear">' . AAW_Icons::get( 'trash', 16 ) . ' پاک کردن تمام‌شده‌ها</button>'
);
?>
<div class="aaw-live-head">
	<span class="aaw-live-dot"></span>
	<b data-live-summary>در حال دریافت وضعیت…</b>
	<small class="aaw-muted" data-live-updated></small>
</div>
<div class="aaw-grid aaw-grid-2 aaw-live-grid">
	<div>
		<section class="aaw-card">
			<div class="aaw-card-head"><div class="aaw-card-title"><span class="aaw-card-ic"><?php AAW_Icons::e( 'zap', 18 ); ?></span><div><h2>عملیات‌ها</h2><p>در حال انجام بالا، تمام‌شده‌ها پایین</p></div></div></div>
			<div class="aaw-card-body"><div class="aaw-ops" data-ops><div class="aaw-empty"><?php AAW_Icons::e( 'loader', 22 ); ?></div></div></div>
		</section>
	</div>
	<div>
		<section class="aaw-card">
			<div class="aaw-card-head"><div class="aaw-card-title"><span class="aaw-card-ic"><?php AAW_Icons::e( 'clock', 18 ); ?></span><div><h2>الان و نوبت بعدی</h2></div></div></div>
			<div class="aaw-card-body" data-live-now></div>
		</section>
		<section class="aaw-card">
			<div class="aaw-card-head"><div class="aaw-card-title"><span class="aaw-card-ic"><?php AAW_Icons::e( 'list', 18 ); ?></span><div><h2>رویدادهای لحظه‌ای</h2><p>آخرین گزارش‌ها، به‌روزرسانی خودکار</p></div></div></div>
			<div class="aaw-card-body"><ul class="aaw-live-log" data-live-log></ul></div>
		</section>
	</div>
</div>
