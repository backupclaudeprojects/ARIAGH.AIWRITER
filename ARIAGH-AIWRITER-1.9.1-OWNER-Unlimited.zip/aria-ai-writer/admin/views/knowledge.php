<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$k     = AAW_Knowledge::get();
$web   = AAW_Analyzer::web_capable();
$stale = AAW_Knowledge::is_stale();
AAW_Admin::head( 'دانش به‌روز سئو', 'هوش مصنوعی یک‌بار از راهنماهای رسمی گوگل و مقالات برتر ایرانی و بین‌المللی یاد می‌گیرد و همان دستورالعمل را برای همه مقالات استفاده می‌کند.', 'book' );
?>
<div class="aaw-grid aaw-grid-2">
	<div>
		<?php AAW_Admin::card_open( 'وضعیت', '', 'activity' ); ?>
		<div class="aaw-kv">
			<div><small>آخرین یادگیری</small><code><?php echo ! empty( $k['at'] ) ? esc_html( wp_date( 'Y/m/d H:i', (int) $k['at'] ) ) : '—'; ?></code></div>
			<div><small>منابع خوانده‌شده</small><code><?php echo esc_html( number_format_i18n( count( (array) ( $k['sources'] ?? array() ) ) ) ); ?></code></div>
			<div><small>موتور</small><code dir="ltr"><?php echo esc_html( trim( ( $k['engine'] ?? '' ) . ' ' . ( $k['model'] ?? '' ) ) ? trim( ( $k['engine'] ?? '' ) . ' ' . ( $k['model'] ?? '' ) ) : '—' ); ?></code></div>
			<div><small>جستجوی زنده وب</small><code><?php echo $web ? 'فعال' : 'خیر (فقط منابع زیر)'; ?></code></div>
		</div>
		<?php if ( $stale ) : ?>
			<div class="aaw-alert is-warn"><?php AAW_Icons::e( 'alert', 16 ); ?><div><?php echo empty( $k['playbook'] ) ? 'هنوز دانش سئو یاد گرفته نشده است.' : 'دانش سئو قدیمی شده و در اجرای روزانه بعدی خودکار به‌روز می‌شود.'; ?></div></div>
		<?php endif; ?>
		<button type="button" class="aaw-btn aaw-btn-primary aaw-btn-block" data-action="seo-learn"><?php AAW_Icons::e( 'refresh', 16 ); ?> یادگیری / به‌روزرسانی الان</button>
		<?php if ( AAW_SiteData::available() ) : ?>
			<div class="aaw-alert is-ok"><?php AAW_Icons::e( 'database', 16 ); ?><div><b>دیتابیس سئو روی GitHub:</b> با این دکمه هاست فقط یک درخواست کوچک می‌فرستد؛ GitHub منابع را می‌خواند، دستورالعمل را می‌سازد و همه را در پوشه <code dir="ltr">seo/</code> شاخه <code dir="ltr">aaw-data</code> مخزن خصوصی شما ذخیره می‌کند (نسخه قبلی جایگزین می‌شود). <a href="<?php echo esc_url( AAW_SiteData::branch_url( 'seo' ) ); ?>" target="_blank" rel="noopener">مشاهده</a><?php echo 'github' === ( $k['store'] ?? '' ) ? ' · نسخه فعلی از GitHub آمده است.' : ''; ?></div></div>
		<?php endif; ?>
		<p class="aaw-muted"><?php echo AAW_SiteData::available() ? 'زمان: ۲ تا ۶ دقیقه.' : 'این کار روی کلادفلر و در پس‌زمینه انجام می‌شود (۱ تا ۴ دقیقه).'; ?> یک‌بار مصرف توکن دارد و بعد از آن فقط متن خلاصه (حدود ۱ تا ۲ هزار توکن) در ابتدای پرامپت هر مقاله قرار می‌گیرد که در OpenAI، Claude و Gemini به‌صورت خودکار کش می‌شود و ارزان‌تر حساب می‌شود.</p>
		<?php AAW_Admin::card_close(); ?>

		<form class="aaw-form" data-settings>
			<?php AAW_Admin::card_open( 'تنظیمات یادگیری', '', 'settings' ); ?>
			<?php AAW_Admin::toggle( 'seo_learn', 'استفاده از دانش به‌روز سئو در مقالات' ); ?>
			<?php AAW_Admin::number( 'seo_learn_days', 'به‌روزرسانی خودکار هر', '', 7, 180, 1, 'روز' ); ?>
			<?php AAW_Admin::textarea( 'seo_sources', 'منابع یادگیری', 'هر خط یک آدرس. راهنماهای رسمی گوگل + مقالات معتبر بین‌المللی و فارسی؛ می‌توانید منابع دلخواه اضافه کنید.', '', 9 ); ?>
			<?php AAW_Admin::card_close(); ?>
			<?php AAW_Admin::save_bar(); ?>
		</form>
	</div>
	<div>
		<?php AAW_Admin::card_open( 'دستورالعمل فعلی', ! empty( $k['version'] ) ? 'نسخه ' . $k['version'] : '', 'seo' ); ?>
		<?php if ( ! empty( $k['highlights'] ) ) : ?>
			<ul class="aaw-guide"><?php foreach ( $k['highlights'] as $h ) : ?><li><?php echo esc_html( $h ); ?></li><?php endforeach; ?></ul>
		<?php endif; ?>
		<div class="aaw-playbook" dir="auto"><?php echo ! empty( $k['playbook'] ) ? nl2br( esc_html( $k['playbook'] ) ) : '<span class="aaw-muted">پس از یادگیری، متن کامل دستورالعمل اینجا نمایش داده می‌شود.</span>'; ?></div>
		<?php if ( ! empty( $k['sources'] ) ) : ?>
			<details class="aaw-mt"><summary>منابع استفاده‌شده</summary><ul class="aaw-guide"><?php foreach ( $k['sources'] as $u ) : ?><li><a href="<?php echo esc_url( $u ); ?>" target="_blank" rel="noopener" dir="ltr"><?php echo esc_html( $u ); ?></a></li><?php endforeach; ?></ul></details>
		<?php endif; ?>
		<?php AAW_Admin::card_close(); ?>
	</div>
</div>
