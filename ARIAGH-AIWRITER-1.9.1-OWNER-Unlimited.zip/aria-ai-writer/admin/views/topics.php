<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$actions = '<button type="button" class="aaw-btn aaw-btn-ghost" data-action="topics-suggest">' . AAW_Icons::get( 'sparkles', 16 ) . ' پیشنهاد موضوع با AI</button>'
	. '<button type="button" class="aaw-btn aaw-btn-ghost" data-action="topics-import">' . AAW_Icons::get( 'upload', 16 ) . ' ورود CSV</button>'
	. '<button type="button" class="aaw-btn aaw-btn-ghost" data-action="topics-export">' . AAW_Icons::get( 'download', 16 ) . ' خروجی CSV</button>';
AAW_Admin::head( 'موضوعات مقالات', 'لیست موضوعات را بسازید، با کشیدن جابجا کنید؛ هر موضوعی که تولید شود تیک می‌خورد.', 'list', $actions );
?>
<div class="aaw-grid aaw-grid-1-2">
	<div>
		<?php AAW_Admin::card_open( 'افزودن موضوع', 'یک موضوع با جزئیات کامل', 'plus' ); ?>
		<form class="aaw-topic-form" data-topic-form autocomplete="off">
			<label class="aaw-label">عنوان یا موضوع مقاله</label>
			<input class="aaw-input" name="title" required placeholder="مثلاً: راهنمای کامل انتخاب قهوه اسپرسو" dir="auto">
			<label class="aaw-label">کلمات کلیدی <small>(با کاما جدا کنید)</small></label>
			<div class="aaw-tags-input" data-tags="keywords"><input class="aaw-input" placeholder="کلمه + Enter"></div>
			<div class="aaw-grid aaw-grid-2">
				<div>
					<label class="aaw-label">دسته‌بندی</label>
					<div class="aaw-select-wrap"><select class="aaw-input" name="category_id">
						<option value="0">پیش‌فرض تنظیمات</option>
						<?php foreach ( get_categories( array( 'hide_empty' => false ) ) as $c ) : ?>
							<option value="<?php echo esc_attr( $c->term_id ); ?>"><?php echo esc_html( $c->name ); ?></option>
						<?php endforeach; ?>
					</select><?php AAW_Icons::e( 'chevron-down', 16, 'aaw-select-ic' ); ?></div>
				</div>
				<div>
					<label class="aaw-label">تعداد کلمات</label>
					<input class="aaw-input" type="number" name="word_count" min="0" step="100" placeholder="پیش‌فرض">
				</div>
			</div>
			<div class="aaw-grid aaw-grid-2">
				<div>
					<label class="aaw-label">لحن</label>
					<div class="aaw-select-wrap"><select class="aaw-input" name="tone">
						<option value="">پیش‌فرض تنظیمات</option>
						<?php foreach ( AAW_Prompt::tones() as $k => $t ) : ?>
							<option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $t ); ?></option>
						<?php endforeach; ?>
					</select><?php AAW_Icons::e( 'chevron-down', 16, 'aaw-select-ic' ); ?></div>
				</div>
				<div>
					<label class="aaw-label">اولویت</label>
					<div class="aaw-seg aaw-seg-sm">
						<label><input type="radio" name="priority" value="0" checked><span>عادی</span></label>
						<label><input type="radio" name="priority" value="1"><span>بالا</span></label>
						<label><input type="radio" name="priority" value="2"><span>فوری</span></label>
					</div>
				</div>
			</div>
			<label class="aaw-label">توضیحات اختصاصی برای AI <small>(اختیاری)</small></label>
			<textarea class="aaw-input" name="notes" rows="2" placeholder="مثلاً: روی مقایسه قیمت تمرکز کن…" dir="auto"></textarea>
			<label class="aaw-check"><input type="checkbox" name="position_top" value="1"> افزودن به ابتدای صف</label>
			<button type="submit" class="aaw-btn aaw-btn-primary aaw-btn-block"><?php AAW_Icons::e( 'plus', 16 ); ?> افزودن به صف</button>
		</form>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'افزودن گروهی', 'هر خط یک موضوع · فرمت اختیاری: عنوان | کلمات کلیدی | دسته | تعداد کلمات', 'stack' ); ?>
		<form data-bulk-form>
			<textarea class="aaw-input aaw-mono" name="text" rows="7" placeholder="بهترین روش دم‌آوری قهوه در خانه | قهوه دمی, فرنچ پرس | آموزش&#10;تفاوت عربیکا و روبوستا&#10;قهوه ترک چیست؟ | قهوه ترک | | 1800" dir="auto"></textarea>
			<div class="aaw-row-between">
				<label class="aaw-check"><input type="checkbox" name="skip_duplicates" value="1" checked> رد کردن موارد تکراری</label>
				<span class="aaw-muted" data-line-count>۰ خط</span>
			</div>
			<button type="submit" class="aaw-btn aaw-btn-dark aaw-btn-block"><?php AAW_Icons::e( 'upload', 16 ); ?> افزودن همه</button>
		</form>
		<?php AAW_Admin::card_close(); ?>
	</div>

	<div>
		<section class="aaw-card aaw-card-flush">
			<div class="aaw-topics-toolbar">
				<div class="aaw-tabs-pill" data-topic-filter>
					<button type="button" class="is-active" data-status="">همه <em data-c="total">0</em></button>
					<button type="button" data-status="pending">در صف <em data-c="pending">0</em></button>
					<button type="button" data-status="done">تولیدشده <em data-c="done">0</em></button>
					<button type="button" data-status="failed">خطا <em data-c="failed">0</em></button>
					<button type="button" data-status="skipped">ردشده <em data-c="skipped">0</em></button>
					<button type="button" data-status="paused">متوقف <em data-c="paused">0</em></button>
				</div>
				<div class="aaw-search"><?php AAW_Icons::e( 'search', 16 ); ?><input type="search" class="aaw-input" placeholder="جستجو…" data-topic-search></div>
			</div>
			<div class="aaw-bulkbar" data-bulkbar hidden>
				<label class="aaw-check"><input type="checkbox" data-select-all> <span data-selected-count>۰</span> انتخاب شده</label>
				<div class="aaw-btn-row">
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-bulk="pending"><?php AAW_Icons::e( 'refresh', 14 ); ?> بازگشت به صف</button>
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-bulk="paused"><?php AAW_Icons::e( 'pause', 14 ); ?> توقف</button>
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-bulk="skipped"><?php AAW_Icons::e( 'x-circle', 14 ); ?> رد کردن</button>
					<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-danger" data-bulk="delete"><?php AAW_Icons::e( 'trash', 14 ); ?> حذف</button>
				</div>
			</div>
			<div class="aaw-topic-hint"><?php AAW_Icons::e( 'grip', 14 ); ?> برای تغییر ترتیب تولید، ردیف‌ها را بکشید و رها کنید. بالاترین مورد، اولین مقاله بعدی است.</div>
			<ul class="aaw-topics" data-topics>
				<li class="aaw-skeleton"></li><li class="aaw-skeleton"></li><li class="aaw-skeleton"></li>
			</ul>
		</section>
	</div>
</div>
<input type="file" accept=".csv,text/csv" data-csv-file hidden>
