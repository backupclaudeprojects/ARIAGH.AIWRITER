<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
global $wpdb;
$info = array(
	'نسخه افزونه'        => AAW_VERSION,
	'نسخه وردپرس'        => get_bloginfo( 'version' ),
	'نسخه PHP'           => PHP_VERSION,
	'پایگاه داده'        => $wpdb->db_server_info(),
	'OpenSSL'            => function_exists( 'openssl_encrypt' ) ? 'فعال' : 'غیرفعال',
	'DOMDocument'        => class_exists( 'DOMDocument' ) ? 'فعال' : 'غیرفعال',
	'mbstring'           => function_exists( 'mb_strlen' ) ? 'فعال' : 'غیرفعال',
	'REST API'           => rest_url( 'aaw/v1' ),
	'منطقه زمانی سایت'   => wp_timezone_string(),
	'زمان سرور (UTC)'    => gmdate( 'Y-m-d H:i:s' ),
	'افزونه سئو'         => AAW_Post_Builder::detect_seo_plugin(),
	'آخرین تماس ورکر'    => get_option( 'aaw_last_ping' ) ? wp_date( 'Y/m/d H:i', (int) get_option( 'aaw_last_ping' ) ) : '—',
	'آخرین پشتیبان KV'   => get_option( 'aaw_last_kv_sync' ) ? wp_date( 'Y/m/d H:i', (int) get_option( 'aaw_last_kv_sync' ) ) : '—',
	'حداکثر زمان اجرا'  => ini_get( 'max_execution_time' ) . 's',
	'حافظه'              => WP_MEMORY_LIMIT,
);
AAW_Admin::head( 'ابزارها', 'پشتیبان‌گیری، بازیابی، تنظیمات پیشرفته و اطلاعات سیستم.', 'wrench' );
?>
<div class="aaw-grid aaw-grid-2">
	<div>
		<?php AAW_Admin::card_open( 'پشتیبان تنظیمات', 'بدون کلیدها و اطلاعات محرمانه', 'save' ); ?>
		<div class="aaw-btn-col">
			<button type="button" class="aaw-btn aaw-btn-ghost aaw-btn-block" data-action="settings-export"><?php AAW_Icons::e( 'download', 16 ); ?> دریافت فایل JSON تنظیمات</button>
			<button type="button" class="aaw-btn aaw-btn-ghost aaw-btn-block" data-action="settings-import"><?php AAW_Icons::e( 'upload', 16 ); ?> بارگذاری فایل تنظیمات</button>
			<button type="button" class="aaw-btn aaw-btn-ghost aaw-btn-block is-danger" data-action="settings-reset"><?php AAW_Icons::e( 'undo', 16 ); ?> بازگشت به تنظیمات پیش‌فرض</button>
		</div>
		<input type="file" accept=".json,application/json" data-json-file hidden>
		<?php AAW_Admin::card_close(); ?>

		<form class="aaw-form" data-settings>
			<?php AAW_Admin::card_open( 'پیشرفته', '', 'settings' ); ?>
			<?php AAW_Admin::toggle( 'debug', 'حالت اشکال‌زدایی', 'ثبت گزارش‌های جزئی‌تر' ); ?>
			<?php AAW_Admin::number( 'log_retention_days', 'نگهداری گزارش‌ها', '', 1, 3650, 1, 'روز' ); ?>
			<?php if ( current_user_can( 'manage_options' ) ) : ?>
			<?php AAW_Admin::toggle( 'allow_shop_managers', 'دسترسی «مدیر فروشگاه» ووکامرس به افزونه', 'مدیر فروشگاه همه بخش‌ها را می‌بیند و کار می‌کند؛ فقط کارهای حساس امنیتی (نمایش کلید امضا، حذف/چرخش ورکر، بازنشانی و درون‌ریزی تنظیمات، قطع GitHub و غیرفعال‌سازی لایسنس) مخصوص مدیر کل است.' ); ?>
			<?php AAW_Admin::toggle( 'allow_editors', 'دسترسی ویرایشگرها به افزونه' ); ?>
			<?php endif; ?>
			<?php AAW_Admin::toggle( 'load_font', 'بارگذاری فونت وزیرمتن' ); ?>
			<?php AAW_Admin::toggle( 'frontend_css', 'استایل فهرست مطالب و FAQ در سایت' ); ?>
			<?php AAW_Admin::text( 'toc_accent', 'رنگ تاکیدی استایل سایت', '', '#4f46e5', 'color' ); ?>
			<?php AAW_Admin::textarea( 'rest_ip_allow', 'IPهای مجاز REST', 'خالی = همه (امضای HMAC همیشه بررسی می‌شود)', '', 2 ); ?>
			<?php AAW_Admin::number( 'net_part_kb', 'سقف حجم هر تکه ارسال', 'اندازه تکه‌ها خودکار با سرعت واقعی هاست تنظیم می‌شود (هر تکه حدود ۵ ثانیه)؛ این فقط سقف است.', 8, 512, 8, 'KB' ); ?>
			<?php AAW_Admin::select( 'net_relay', 'ارسال فایل‌های بزرگ به GitHub/کلادفلر', array( 'auto' => 'از طریق ورکر کلادفلر (پیشنهادی برای هاست‌های کند)', 'direct' => 'مستقیم از هاست' ) ); ?>
			<?php $ns = AAW_Transfer::speeds(); ?>
			<p class="aaw-muted">سرعت اندازه‌گیری‌شده هاست تا کلادفلر: دریافت <?php echo esc_html( number_format_i18n( round( $ns['down'] / 1024, 1 ), 1 ) ); ?> KB/s · ارسال <?php echo esc_html( number_format_i18n( round( $ns['up'] / 1024, 1 ), 1 ) ); ?> KB/s</p>
			<?php AAW_Admin::select( 'image_ref_transport', 'ارسال عکس‌های مرجع', array( 'auto' => 'خودکار (لینک برای سایت آنلاین)', 'url' => 'همیشه لینک (کلادفلر خودش دانلود کند)', 'inline' => 'ارسال مستقیم فایل' ) ); ?>
			<?php AAW_Admin::toggle( 'delete_on_uninstall', 'حذف کامل داده‌ها هنگام حذف افزونه' ); ?>
			<?php AAW_Admin::card_close(); ?>
			<?php AAW_Admin::save_bar(); ?>
		</form>
	</div>
	<div>
		<?php AAW_Admin::card_open( 'اطلاعات سیستم', '', 'server' ); ?>
		<table class="aaw-info">
			<?php foreach ( $info as $k => $v ) : ?>
				<tr><th><?php echo esc_html( $k ); ?></th><td dir="auto"><?php echo esc_html( $v ); ?></td></tr>
			<?php endforeach; ?>
		</table>
		<button type="button" class="aaw-btn aaw-btn-ghost aaw-btn-sm" data-action="copy-info"><?php AAW_Icons::e( 'copy', 14 ); ?> کپی اطلاعات</button>
		<?php AAW_Admin::card_close(); ?>

		<?php AAW_Admin::card_open( 'میان‌برهای صفحه‌کلید', '', 'keyboard' ); ?>
		<ul class="aaw-shortcuts">
			<li><span><kbd>Ctrl</kbd>+<kbd>S</kbd></span> ذخیره فرم فعلی</li>
			<li><span><kbd>Alt</kbd>+<kbd>R</kbd></span> تولید فوری مقاله</li>
			<li><span><kbd>Alt</kbd>+<kbd>N</kbd></span> تمرکز روی افزودن موضوع</li>
			<li><span><kbd>/</kbd></span> تمرکز روی جستجو</li>
			<li><span><kbd>Esc</kbd></span> بستن پنجره</li>
		</ul>
		<?php AAW_Admin::card_close(); ?>
	</div>
</div>
