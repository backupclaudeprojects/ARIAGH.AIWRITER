<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
AAW_Admin::head( 'ساختار و سبک محتوا', 'موضوع سایت، لحن، طول و اجزای مقالات را تعریف کنید.', 'content' );
?>
<form class="aaw-form" data-settings>
	<div class="aaw-grid aaw-grid-2">
		<div>
			<?php AAW_Admin::card_open( 'هویت سایت', 'هوش مصنوعی بر اساس این اطلاعات می‌نویسد', 'globe' ); ?>
			<?php AAW_Admin::text( 'site_name', 'نام سایت' ); ?>
			<?php AAW_Admin::textarea( 'niche', 'موضوع و حوزه سایت', 'دقیق بنویسید؛ مهم‌ترین ورودی کیفیت محتواست', 'مثلاً: فروشگاه تخصصی قهوه، دستگاه اسپرسو و لوازم باریستا', 3 ); ?>
			<?php AAW_Admin::text( 'audience', 'مخاطب هدف', '', 'مثلاً: علاقه‌مندان قهوه و کافه‌داران' ); ?>
			<?php AAW_Admin::text( 'brand_name', 'نام برند', 'برای ذکر طبیعی در متن' ); ?>
			<?php AAW_Admin::textarea( 'brand_description', 'معرفی کوتاه برند', '', 'مزیت‌های رقابتی، خدمات، شهر…', 2 ); ?>
			<?php AAW_Admin::toggle( 'brand_mention', 'ذکر برند در متن' ); ?>
			<?php AAW_Admin::select( 'language', 'زبان نگارش', AAW_Prompt::languages() ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'لحن و سبک', '', 'type' ); ?>
			<?php AAW_Admin::select( 'tone', 'لحن', AAW_Prompt::tones() ); ?>
			<?php AAW_Admin::segmented( 'reading_level', 'سطح نگارش', array( 'simple' => 'ساده', 'intermediate' => 'متوسط', 'expert' => 'تخصصی' ) ); ?>
			<?php AAW_Admin::segmented( 'pov', 'زاویه دید', array( 'we' => 'ما', 'you' => 'شما', 'neutral' => 'بی‌طرف' ) ); ?>
			<?php AAW_Admin::toggle( 'avoid_cliches', 'حذف عبارات کلیشه‌ای AI', 'متن طبیعی و انسانی‌تر' ); ?>
			<?php AAW_Admin::toggle( 'no_emoji', 'بدون ایموجی', 'ایموجی‌ها از متن حذف می‌شوند' ); ?>
			<?php AAW_Admin::toggle( 'bold_keywords', 'برجسته‌سازی کلمات کلیدی' ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'ویرایش خودکار فارسی', 'پس‌پردازش متن پس از تولید', 'edit' ); ?>
			<?php AAW_Admin::toggle( 'fix_persian_typography', 'اصلاح نیم‌فاصله و فاصله‌گذاری', 'می‌شود، کتاب‌ها، بهترین…' ); ?>
			<?php AAW_Admin::toggle( 'convert_arabic_chars', 'تبدیل ي و ك عربی به ی و ک فارسی' ); ?>
			<?php AAW_Admin::toggle( 'persian_digits', 'تبدیل اعداد به ارقام فارسی' ); ?>
			<?php AAW_Admin::toggle( 'remove_h1', 'تبدیل H1 داخل متن به H2' ); ?>
			<?php AAW_Admin::card_close(); ?>
		</div>
		<div>
			<?php AAW_Admin::card_open( 'طول و ساختار', '', 'stack' ); ?>
			<?php AAW_Admin::number( 'word_count_min', 'حداقل کلمات', '', 300, 10000, 100, 'کلمه' ); ?>
			<?php AAW_Admin::number( 'word_count_max', 'حداکثر کلمات', '', 400, 12000, 100, 'کلمه' ); ?>
			<?php AAW_Admin::number( 'min_quality_words', 'حداقل قابل قبول', 'مقاله کوتاه‌تر رد و دوباره تلاش می‌شود (۰ = غیرفعال)', 0, 5000, 50, 'کلمه' ); ?>
			<?php AAW_Admin::number( 'h2_count', 'تعداد زیرعنوان H2', '', 2, 20 ); ?>
			<?php AAW_Admin::toggle( 'use_h3', 'استفاده از H3' ); ?>
			<?php AAW_Admin::number( 'paragraph_max_sentences', 'حداکثر جمله در پاراگراف', '', 2, 10 ); ?>
			<?php AAW_Admin::card_close(); ?>

			<?php AAW_Admin::card_open( 'اجزای مقاله', 'بخش‌هایی که در هر مقاله گنجانده می‌شوند', 'layers' ); ?>
			<div class="aaw-toggle-grid">
				<?php
				$parts = array(
					'include_intro_hook'    => 'مقدمه با قلاب جذاب',
					'include_key_takeaways' => 'باکس نکات کلیدی',
					'include_toc'           => 'فهرست مطالب خودکار',
					'include_table'         => 'جدول مقایسه‌ای',
					'include_lists'         => 'فهرست‌های گلوله‌ای',
					'include_examples'      => 'مثال‌های کاربردی',
					'include_stats'         => 'آمار و ارقام معتبر',
					'include_pros_cons'     => 'مزایا و معایب',
					'include_howto_steps'   => 'مراحل گام‌به‌گام',
					'include_mistakes'      => 'اشتباهات رایج',
					'include_checklist'     => 'چک‌لیست نهایی',
					'include_glossary'      => 'واژه‌نامه',
					'include_quote'         => 'نقل‌قول برجسته',
					'include_faq'           => 'سؤالات متداول (FAQ)',
					'include_conclusion'    => 'جمع‌بندی',
					'include_cta'           => 'دعوت به اقدام (CTA)',
				);
				foreach ( $parts as $k => $label ) {
					AAW_Admin::toggle( $k, $label );
				}
				?>
			</div>
			<?php AAW_Admin::number( 'faq_count', 'تعداد سؤالات متداول', '', 2, 12 ); ?>
			<?php AAW_Admin::textarea( 'cta_text', 'متن دعوت به اقدام', '', 'مثلاً: برای مشاوره رایگان با کارشناسان ما تماس بگیرید', 2 ); ?>
			<?php AAW_Admin::card_close(); ?>
		</div>
	</div>
	<?php AAW_Admin::save_bar(); ?>
</form>
