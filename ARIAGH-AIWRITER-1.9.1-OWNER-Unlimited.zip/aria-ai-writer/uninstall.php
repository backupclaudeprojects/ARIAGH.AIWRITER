<?php
/**
 * Uninstall cleanup (only when the user enabled "delete data on uninstall").
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$settings = get_option( 'aaw_settings', array() );
if ( empty( $settings['delete_on_uninstall'] ) ) {
	return;
}

global $wpdb;
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}aaw_topics" ); // phpcs:ignore
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}aaw_logs" ); // phpcs:ignore

foreach ( array( 'aaw_settings', 'aaw_secure', 'aaw_custom_providers', 'aaw_key_meta', 'aaw_db_version', 'aaw_last_ping', 'aaw_last_kv_sync', 'aaw_activated_redirect' ) as $opt ) {
	delete_option( $opt );
}
foreach ( array( 'administrator', 'editor' ) as $role_name ) {
	$role = get_role( $role_name );
	if ( $role ) {
		$role->remove_cap( 'aaw_manage' );
	}
}
wp_clear_scheduled_hook( 'aaw_daily' );
