<?php
/**
 * Symmetric encryption for the few credentials that must live in WordPress
 * (Cloudflare API token). AI keys are NEVER stored here – they go to Cloudflare Secrets.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Crypto {

	private static function key() {
		$material = ( defined( 'AUTH_KEY' ) ? AUTH_KEY : '' ) . ( defined( 'SECURE_AUTH_SALT' ) ? SECURE_AUTH_SALT : '' ) . 'aaw-v1';
		if ( function_exists( 'wp_salt' ) ) {
			$material .= wp_salt( 'auth' );
		}
		return hash( 'sha256', $material, true );
	}

	public static function encrypt( $plain ) {
		$plain = (string) $plain;
		if ( '' === $plain ) {
			return '';
		}
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return 'b64:' . base64_encode( $plain );
		}
		$iv  = random_bytes( 12 );
		$tag = '';
		$ct  = openssl_encrypt( $plain, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag );
		if ( false === $ct ) {
			return 'b64:' . base64_encode( $plain );
		}
		return 'gcm:' . base64_encode( $iv . $tag . $ct );
	}

	public static function decrypt( $stored ) {
		$stored = (string) $stored;
		if ( '' === $stored ) {
			return '';
		}
		if ( 0 === strpos( $stored, 'b64:' ) ) {
			return (string) base64_decode( substr( $stored, 4 ) );
		}
		if ( 0 === strpos( $stored, 'gcm:' ) && function_exists( 'openssl_decrypt' ) ) {
			$raw = base64_decode( substr( $stored, 4 ) );
			if ( strlen( $raw ) < 29 ) {
				return '';
			}
			$iv  = substr( $raw, 0, 12 );
			$tag = substr( $raw, 12, 16 );
			$ct  = substr( $raw, 28 );
			$out = openssl_decrypt( $ct, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag );
			return false === $out ? '' : $out;
		}
		return '';
	}

	/** Returns a masked hint such as "sk-p••••••9f2a" */
	public static function mask( $value ) {
		$value = (string) $value;
		$len   = strlen( $value );
		if ( $len <= 8 ) {
			return str_repeat( '•', max( 4, $len ) );
		}
		return substr( $value, 0, 4 ) . str_repeat( '•', 6 ) . substr( $value, -4 );
	}

	public static function random_secret( $bytes = 32 ) {
		return bin2hex( random_bytes( $bytes ) );
	}
}
