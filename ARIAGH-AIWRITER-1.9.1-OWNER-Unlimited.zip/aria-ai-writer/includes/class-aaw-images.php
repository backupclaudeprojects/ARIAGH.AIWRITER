<?php
/**
 * Article images: engines, reference images (products in the article + a few
 * existing site images for the visual theme), per-engine limits and the learned
 * site visual theme (learned once, reused for every image → fewer tokens).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Images {

	const THEME = 'aaw_image_theme';

	/**
	 * Supported engines with their real limits.
	 *
	 * refs     = max reference images the engine accepts per request (0 = text only).
	 * secret   = Cloudflare secret holding the key ('' = none / shared provider key).
	 */
	public static function engines() {
		return array(
			'workers_ai' => array(
				'name'    => 'Cloudflare Workers AI (رایگان، پیش‌فرض)',
				'refs'    => 0,
				'secret'  => '',
				'models'  => array( '@cf/black-forest-labs/flux-1-schnell' => 'FLUX.1 schnell', '@cf/bytedance/stable-diffusion-xl-lightning' => 'SDXL Lightning', '@cf/stabilityai/stable-diffusion-xl-base-1.0' => 'Stable Diffusion XL', '@cf/lykon/dreamshaper-8-lcm' => 'DreamShaper 8' ),
				'note'    => 'بدون کلید و رایگان. تصویر مرجع نمی‌پذیرد؛ به‌جای آن «تم تصویری سایت» (یک‌بار یاد گرفته می‌شود) و نام محصولات در پرامپت قرار می‌گیرد.',
				'link'    => 'https://developers.cloudflare.com/workers-ai/models/',
				'key'     => '',
			),
			'openai'     => array(
				'name'    => 'OpenAI (gpt-image-1)',
				'refs'    => 16,
				'secret'  => AAW_Providers::secret_name( 'openai' ),
				'models'  => array( 'gpt-image-1' => 'gpt-image-1', 'gpt-image-1-mini' => 'gpt-image-1-mini', 'dall-e-3' => 'DALL·E 3 (بدون مرجع)' ),
				'note'    => 'تا ۱۶ تصویر مرجع (عکس محصول + نمونه تم سایت) در هر درخواست؛ هر فایل حداکثر ۲۵ مگابایت. از همان کلید OpenAI تب هوش مصنوعی استفاده می‌شود.',
				'link'    => 'https://platform.openai.com/api-keys',
				'key'     => 'openai',
			),
			'gemini'     => array(
				'name'    => 'Google Gemini Image (Nano Banana / Imagen)',
				'refs'    => 3,
				'secret'  => AAW_Providers::secret_name( 'gemini' ),
				'models'  => array( 'gemini-2.5-flash-image' => 'Gemini 2.5 Flash Image (Nano Banana)', 'gemini-3-pro-image-preview' => 'Gemini 3 Pro Image (تا ۱۴ مرجع)' ),
				'note'    => 'Google Flow رابط API ندارد؛ همان مدل‌های تصویری گوگل از طریق کلید رایگان/پولی Google AI Studio در دسترس است. Gemini 2.5 تا ۳ مرجع و Gemini 3 Pro تا ۱۴ مرجع. از کلید Gemini تب هوش مصنوعی استفاده می‌شود.',
				'link'    => 'https://aistudio.google.com/apikey',
				'key'     => 'gemini',
			),
			'higgsfield' => array(
				'name'    => 'Higgsfield',
				'refs'    => 8,
				'secret'  => 'AAW_IMG_HIGGSFIELD',
				'models'  => array( '/marketing-studio/image' => 'Marketing Studio Image (با مرجع محصول، تا ۱۶)', '/higgsfield-ai/soul/standard' => 'Soul (بدون مرجع)' ),
				'note'    => 'API هیگزفیلد حساب و موجودی دلاری جدا از اشتراک سایت higgsfield.ai دارد (شارژ در open.higgsfield.ai). کلید را به شکل KEY_ID:KEY_SECRET وارد کنید. تصاویر مرجع امن در فضای موقت Higgsfield آپلود می‌شوند (نیازی نیست سایت شما از بیرون در دسترس باشد). اعتبار از حساب Higgsfield شما کسر می‌شود.',
				'link'    => 'https://cloud.higgsfield.ai/api-keys',
				'key'     => 'higgsfield',
			),
			'fal'        => array(
				'name'    => 'fal.ai (Nano Banana / FLUX)',
				'refs'    => 6,
				'secret'  => 'AAW_IMG_FAL',
				'models'  => array( 'fal-ai/nano-banana/edit' => 'Nano Banana Edit (با مرجع)', 'fal-ai/flux/schnell' => 'FLUX schnell (بدون مرجع)' ),
				'note'    => 'تا ۶ مرجع به‌صورت داده درون‌خطی ارسال می‌شود.',
				'link'    => 'https://fal.ai/dashboard/keys',
				'key'     => 'fal',
			),
			'sub_codex'  => array(
				'name'    => 'اکانت اشتراکی ChatGPT Plus/Pro (بدون API)',
				'refs'    => 8,
				'secret'  => '',
				'models'  => array(),
				'note'    => 'با ابزار رسمی Codex و قابلیت داخلی ساخت تصویر آن (gpt-image) از طریق GitHub Actions؛ از سهمیه اشتراک ChatGPT شما کم می‌شود و کلید API لازم نیست. همان اتصال تب «اکانت اشتراکی» (GitHub + ورود ChatGPT) استفاده می‌شود. هر تصویر ۲ تا ۵ دقیقه طول می‌کشد.',
				'link'    => '',
				'key'     => '',
				'sub'     => true,
			),
			'custom'     => array(
				'name'    => 'سرویس سازگار با OpenAI Images (Base URL دلخواه)',
				'refs'    => 4,
				'secret'  => 'AAW_IMG_CUSTOM',
				'models'  => array(),
				'note'    => 'هر سرویسی که /images/generations و /images/edits استاندارد OpenAI را دارد (مثل AvalAI، GapGPT، OpenRouter یا سرور شخصی).',
				'link'    => '',
				'key'     => 'custom',
			),
		);
	}

	public static function engine() {
		$e = AAW_Settings::get( 'image_engine' );
		if ( ! $e || ! isset( self::engines()[ $e ] ) ) {
			$e = 'openai' === AAW_Settings::get( 'image_provider' ) ? 'openai' : 'workers_ai';
		}
		return $e;
	}

	public static function model( $engine = null ) {
		$e      = $engine ? $engine : self::engine();
		$map    = (array) AAW_Settings::get( 'image_models', array() );
		$m      = trim( (string) ( $map[ $e ] ?? '' ) );
		if ( '' === $m && $e === self::engine() ) {
			$m = trim( (string) AAW_Settings::get( 'image_engine_model' ) );
		}
		$engines = self::engines();
		// A model name left over from another engine (e.g. "@cf/…" after switching to OpenAI) breaks the request.
		if ( '' !== $m && ! isset( $engines[ $e ]['models'][ $m ] ) ) {
			foreach ( $engines as $other => $def ) {
				if ( $other !== $e && isset( $def['models'][ $m ] ) ) {
					$m = '';
					break;
				}
			}
			if ( 'workers_ai' !== $e && 0 === strpos( $m, '@cf/' ) ) {
				$m = '';
			}
		}
		if ( 'workers_ai' === $e ) {
			return ( '' !== $m && isset( $engines['workers_ai']['models'][ $m ] ) ) ? $m : (string) AAW_Settings::get( 'image_model' );
		}
		if ( 'openai' === $e && '' === $m ) {
			return (string) AAW_Settings::get( 'image_openai_model' );
		}
		if ( '' === $m ) {
			$models = array_keys( (array) ( $engines[ $e ]['models'] ?? array() ) );
			return $models ? $models[0] : '';
		}
		return $m;
	}

	/** Runtime config sent to the worker (primary engine + API fallbacks from the image priority list). */
	public static function runtime( $engine = null ) {
		$s       = AAW_Settings::all();
		$primary = null === $engine;
		$engine  = $engine ? $engine : self::engine();
		$def     = self::engines()[ $engine ];
		$theme   = get_option( self::THEME, array() );
		$rt      = array(
			// Subscription images are made by a separate GitHub task after the draft exists.
			'enabled'      => (bool) $s['featured_image'] && 'sub_codex' !== $engine,
			'engine'       => $engine,
			'provider'     => $engine, // Back-compat with older workers.
			'model'        => self::model( $engine ),
			'openai_model' => 'openai' === $engine ? self::model( 'openai' ) : $s['image_openai_model'],
			'openai'       => 'openai' === $engine ? AAW_Providers::runtime( 'openai' ) : null,
			'secret'       => $def['secret'],
			'base_url'     => 'custom' === $engine ? untrailingslashit( (string) $s['image_custom_url'] ) : '',
			'size'         => $s['image_size'],
			'style'        => $s['image_style'],
			'theme'        => ( $s['image_use_theme'] && ! empty( $theme['theme'] ) ) ? $theme['theme'] : '',
			'inline_count' => (int) $s['image_inline_count'],
			'max_refs'     => min( (int) $def['refs'], (int) $s['image_max_refs'] ),
		);
		if ( $primary && class_exists( 'AAW_Priority' ) ) {
			$fb = array();
			foreach ( array_slice( AAW_Priority::image_chain(), 1 ) as $id ) {
				if ( 'sub_codex' !== $id && $id !== $engine ) {
					$f = self::runtime( $id );
					unset( $f['enabled'], $f['size'], $f['style'], $f['theme'], $f['inline_count'] );
					$fb[] = $f;
				}
			}
			// Last resort: free Workers AI, so an article never stays without an image because a
			// paid engine ran out of credit (setting «image_free_fallback»).
			if ( 'workers_ai' !== $engine && ! in_array( 'workers_ai', AAW_Priority::image_chain(), true ) && $s['image_free_fallback'] && $s['bind_workers_ai'] ) {
				$f = self::runtime( 'workers_ai' );
				unset( $f['enabled'], $f['size'], $f['style'], $f['theme'], $f['inline_count'] );
				$f['last_resort'] = true;
				$fb[]             = $f;
			}
			if ( $fb ) {
				$rt['fallbacks'] = $fb;
			}
		}
		return $rt;
	}

	/* ---------------------------------------------------------------- */

	/** Directory with cached, resized reference copies (never re-encoded twice). */
	private static function cache_dir() {
		$u = wp_upload_dir( null, false );
		$d = trailingslashit( $u['basedir'] ) . 'aaw-refs/';
		if ( ! is_dir( $d ) ) {
			wp_mkdir_p( $d );
			@file_put_contents( $d . 'index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore
		}
		return $d;
	}

	/**
	 * Resized JPEG (max 768px) of an attachment as base64, cached on disk.
	 *
	 * @return array|null { b64, mime, id }
	 */
	public static function ref_from_attachment( $att_id, $max = 768 ) {
		$att_id = (int) $att_id;
		$file   = $att_id ? get_attached_file( $att_id ) : '';
		if ( ! $file || ! file_exists( $file ) ) {
			return null;
		}
		$cached = self::cache_dir() . $att_id . '-' . $max . '-' . substr( md5( $file . filemtime( $file ) ), 0, 8 ) . '.jpg';
		if ( ! file_exists( $cached ) ) {
			$ed = wp_get_image_editor( $file );
			if ( is_wp_error( $ed ) ) {
				return null;
			}
			$ed->resize( $max, $max, false );
			$ed->set_quality( 80 );
			$saved = $ed->save( $cached, 'image/jpeg' );
			if ( is_wp_error( $saved ) ) {
				return null;
			}
		}
		if ( self::refs_by_url() ) {
			$u = wp_upload_dir( null, false );
			return array( 'url' => trailingslashit( $u['baseurl'] ) . 'aaw-refs/' . basename( $cached ), 'mime' => 'image/jpeg', 'id' => $att_id );
		}
		$bin = file_get_contents( $cached ); // phpcs:ignore
		return $bin ? array( 'b64' => base64_encode( $bin ), 'mime' => 'image/jpeg', 'id' => $att_id ) : null; // phpcs:ignore
	}

	/**
	 * Send reference images as links the worker downloads itself (public sites) instead
	 * of uploading them from WordPress — keeps outgoing requests tiny on slow links.
	 */
	public static function refs_by_url() {
		$mode = AAW_Settings::get( 'image_ref_transport', 'auto' );
		return 'url' === $mode || ( 'auto' === $mode && ! AAW_Pull::site_is_local() );
	}

	/** References in a form a GitHub runner can use (links or inline data). */
	public static function refs_for_remote( array $refs ) {
		return array(
			'products'      => array_values( (array) ( $refs['products'] ?? array() ) ),
			'styles'        => array_values( (array) ( $refs['styles'] ?? array() ) ),
			'product_names' => array_values( (array) ( $refs['product_names'] ?? array() ) ),
		);
	}

	/** Products related to a topic (by text similarity against product titles/keywords). */
	public static function related_products( array $topic, $n = 3 ) {
		if ( $n <= 0 || ! post_type_exists( 'product' ) ) {
			return array();
		}
		$ids = array();
		if ( ! empty( $topic['notes'] ) && preg_match_all( '/product:(\d+)/', (string) $topic['notes'], $m ) ) {
			$ids = array_map( 'intval', $m[1] );
		}
		$near = AAW_Dedupe::nearest( (string) ( $topic['title'] ?? '' ), (string) ( $topic['keywords'] ?? '' ), $n * 2, array( 'product' ) );
		foreach ( $near as $p ) {
			if ( 'publish' === $p['status'] && $p['score'] >= 0.2 ) {
				$ids[] = (int) $p['id'];
			}
		}
		return array_slice( array_values( array_unique( $ids ) ), 0, $n );
	}

	/** Style samples: user-chosen attachments or featured images of recent posts. */
	public static function style_attachments( $n = 2 ) {
		if ( $n <= 0 ) {
			return array();
		}
		$ids = array_filter( array_map( 'absint', preg_split( '/[\s,]+/', (string) AAW_Settings::get( 'image_style_ids' ) ) ) );
		if ( ! $ids ) {
			$posts = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 12, 'fields' => 'ids', 'no_found_rows' => true, 'meta_key' => '_thumbnail_id' ) ); // phpcs:ignore
			foreach ( $posts as $pid ) {
				$t = (int) get_post_thumbnail_id( $pid );
				if ( $t ) {
					$ids[] = $t;
				}
			}
		}
		return array_slice( array_values( array_unique( $ids ) ), 0, $n );
	}

	/**
	 * References for one article within the engine's limits.
	 *
	 * @return array { products:[{b64,mime}], styles:[{b64,mime}], product_names:[] }
	 */
	public static function references_for( array $topic ) {
		$s      = AAW_Settings::all();
		$limit  = (int) self::runtime()['max_refs'];
		$out    = array( 'products' => array(), 'styles' => array(), 'product_names' => array() );
		$p_ids  = self::related_products( $topic, (int) $s['image_product_refs'] );
		foreach ( $p_ids as $pid ) {
			$out['product_names'][] = get_the_title( $pid );
		}
		if ( $limit <= 0 ) {
			return $out; // Text-only engine: names (and the learned theme) are enough.
		}
		// Product photos the owner picked in «تنظیمات تصاویر» come first.
		$chosen = array_slice( array_filter( array_map( 'absint', preg_split( '/[\s,]+/', (string) ( $s['image_product_ids'] ?? '' ) ) ) ), 0, 12 );
		foreach ( $chosen as $att ) {
			if ( count( $out['products'] ) >= max( 1, $limit - 1 ) ) {
				break;
			}
			$r = self::ref_from_attachment( $att );
			if ( $r ) {
				$out['products'][] = $r;
				$parent = (int) wp_get_post_parent_id( $att );
				$name   = $parent && 'product' === get_post_type( $parent ) ? get_the_title( $parent ) : '';
				if ( $name && ! in_array( $name, $out['product_names'], true ) ) {
					$out['product_names'][] = $name;
				}
			}
		}
		foreach ( $p_ids as $pid ) {
			if ( count( $out['products'] ) >= $limit ) {
				break;
			}
			$r = self::ref_from_attachment( get_post_thumbnail_id( $pid ) );
			if ( $r ) {
				$out['products'][] = $r;
			}
		}
		$left = max( 0, $limit - count( $out['products'] ) );
		foreach ( self::style_attachments( min( $left, (int) $s['image_style_refs'] ) ) as $att ) {
			$r = self::ref_from_attachment( $att );
			if ( $r ) {
				$out['styles'][] = $r;
			}
		}
		return $out;
	}

	/** Payload for learning the visual theme once (background job). */
	public static function style_learn_payload() {
		$styles = array();
		foreach ( self::style_attachments( 4 ) as $att ) {
			$r = self::ref_from_attachment( $att, 512 );
			if ( $r ) {
				$styles[] = $r;
			}
		}
		$products = get_posts( array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 12, 'fields' => 'ids', 'no_found_rows' => true ) );
		$s        = AAW_Settings::all();
		return array(
			'runtime'  => AAW_REST::runtime(),
			'styles'   => $styles,
			'products' => array_map( 'get_the_title', $products ),
			'niche'    => $s['niche'],
			'brand'    => $s['brand_name'] ? $s['brand_name'] : $s['site_name'],
			'colors'   => array_filter( array_map( 'trim', explode( ',', (string) $s['image_brand_colors'] ) ) ),
		);
	}

	public static function save_theme( array $r ) {
		if ( empty( $r['theme'] ) ) {
			return false;
		}
		update_option( self::THEME, array( 'theme' => sanitize_textarea_field( $r['theme'] ), 'at' => time(), 'observed' => (int) ( $r['observed'] ?? 0 ) ), false );
		AAW_Logs::add( 'success', 'image', 'تم تصویری سایت یاد گرفته شد و برای همه تصاویر بعدی استفاده می‌شود.' );
		return true;
	}

	/** Insert inline images (already uploaded) after the paragraph that follows the n-th H2. */
	public static function insert_inline( $html, array $figures ) {
		if ( ! $figures ) {
			return $html;
		}
		$parts = preg_split( '#(</h2>)#i', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		// parts: [before, '</h2>', after1, '</h2>', after2, ...]
		foreach ( $figures as $idx => $fig ) {
			$seg = 2 * (int) $idx + 2;
			if ( ! isset( $parts[ $seg ] ) ) {
				continue;
			}
			$pos = stripos( $parts[ $seg ], '</p>' );
			$parts[ $seg ] = false === $pos ? $fig . $parts[ $seg ] : substr( $parts[ $seg ], 0, $pos + 4 ) . $fig . substr( $parts[ $seg ], $pos + 4 );
		}
		return implode( '', $parts );
	}
}
