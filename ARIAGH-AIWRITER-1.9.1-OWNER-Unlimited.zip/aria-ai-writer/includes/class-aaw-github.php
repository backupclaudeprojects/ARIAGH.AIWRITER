<?php
/**
 * GitHub integration for the "subscription account" mode:
 * creates a private repository, pushes the runner + workflow, stores encrypted
 * Actions secrets (libsodium sealed boxes) and dispatches / lists workflow runs.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_GitHub {

	const API      = 'https://api.github.com';
	const WORKFLOW = 'aria-writer.yml';

	public static function token() {
		return AAW_Settings::secure_get( 'gh_token' );
	}

	public static function owner() {
		return (string) AAW_Settings::get( 'gh_owner' );
	}

	public static function repo() {
		return (string) AAW_Settings::get( 'gh_repo', 'aria-ai-runner' );
	}

	public static function is_connected() {
		return '' !== self::token() && '' !== self::owner() && (int) AAW_Settings::get( 'gh_connected_at' ) > 0;
	}

	public static function repo_url() {
		return 'https://github.com/' . rawurlencode( self::owner() ) . '/' . rawurlencode( self::repo() );
	}

	public static function request( $method, $path, $body = null, $token = null ) {
		$token = $token ? $token : self::token();
		if ( '' === (string) $token ) {
			return new WP_Error( 'aaw_gh', 'توکن GitHub تنظیم نشده است.' );
		}
		$args = array(
			'method'  => $method,
			'timeout' => 45,
			'headers' => array(
				'Authorization'        => 'Bearer ' . $token,
				'Accept'               => 'application/vnd.github+json',
				'X-GitHub-Api-Version' => '2022-11-28',
				'User-Agent'           => 'ARIAGH-AIWRITER-WP',
			),
		);
		if ( null !== $body ) {
			$args['body']                    = wp_json_encode( $body );
			$args['headers']['Content-Type'] = 'application/json';
		}
		$t0  = microtime( true );
		$res = null;
		if ( isset( $args['body'] ) && AAW_Cloudflare::use_relay( $args['body'] ) ) {
			// Big upload (runner files) from a slow host → let Cloudflare send it.
			$res = AAW_Cloudflare::relay( $method, self::API . $path, $args['headers'], $args['body'] );
			if ( is_wp_error( $res ) ) {
				$res = null;
			}
		}
		if ( null === $res ) {
			$res = wp_remote_request( self::API . $path, $args );
		}
		if ( is_wp_error( $res ) ) {
			return AAW_Errors::network( $res, self::API . $path, microtime( true ) - $t0, 'GitHub', isset( $args['body'] ) ? strlen( (string) $args['body'] ) : 0 );
		}
		$code = wp_remote_retrieve_response_code( $res );
		$json = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( $code >= 400 ) {
			$msg = is_array( $json ) && isset( $json['message'] ) ? $json['message'] : 'HTTP ' . $code;
			$map = array(
				401 => 'توکن GitHub نامعتبر یا منقضی است.',
				403 => 'توکن GitHub دسترسی کافی ندارد (دسترسی‌های راهنما را بررسی کنید).',
				404 => 'مخزن یا مسیر پیدا نشد یا توکن به آن دسترسی ندارد.',
			);
			return new WP_Error( 'aaw_gh', ( $map[ $code ] ?? 'خطای GitHub' ) . ' (' . $msg . ')', array( 'status' => $code ) );
		}
		return is_array( $json ) ? $json : array( 'status' => $code );
	}

	public static function user( $token = null ) {
		return self::request( 'GET', '/user', null, $token );
	}

	/** Create the private repository if it does not exist yet. */
	public static function ensure_repo() {
		$o = rawurlencode( self::owner() );
		$r = rawurlencode( self::repo() );
		$repo = self::request( 'GET', "/repos/{$o}/{$r}" );
		if ( ! is_wp_error( $repo ) ) {
			if ( empty( $repo['private'] ) ) {
				return new WP_Error( 'aaw_gh', 'مخزن «' . self::repo() . '» عمومی است. برای امنیت توکن اشتراک، فقط مخزن خصوصی مجاز است.' );
			}
			return $repo;
		}
		if ( 404 !== ( $repo->get_error_data()['status'] ?? 0 ) ) {
			return $repo;
		}
		$created = self::request(
			'POST',
			'/user/repos',
			array(
				'name'        => self::repo(),
				'private'     => true,
				'auto_init'   => true,
				'description' => 'ARIAGH.AIWRITER – subscription runner (managed by WordPress plugin)',
			)
		);
		if ( is_wp_error( $created ) ) {
			return new WP_Error( 'aaw_gh', 'ساخت خودکار مخزن ممکن نشد. یک مخزن خصوصی خالی با نام «' . self::repo() . '» بسازید و دوباره تلاش کنید. ' . $created->get_error_message() );
		}
		sleep( 2 ); // Give GitHub a moment to initialise the default branch.
		return $created;
	}

	/** Git blob SHA of a content string (same as GitHub's "sha" of a file). */
	public static function blob_sha( $content ) {
		return sha1( 'blob ' . strlen( $content ) . "\0" . $content );
	}

	/** path => sha of the files on a branch (one small request instead of downloading every file). */
	public static function tree( $branch = '' ) {
		$o   = rawurlencode( self::owner() );
		$r   = rawurlencode( self::repo() );
		$b   = rawurlencode( $branch ? $branch : self::default_branch() );
		$res = self::request( 'GET', "/repos/{$o}/{$r}/git/trees/{$b}?recursive=1" );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$out = array();
		foreach ( (array) ( $res['tree'] ?? array() ) as $t ) {
			if ( 'blob' === ( $t['type'] ?? '' ) ) {
				$out[ $t['path'] ] = $t['sha'];
			}
		}
		return $out;
	}

	public static function put_file( $path, $content, $message, $known = null ) {
		$o    = rawurlencode( self::owner() );
		$r    = rawurlencode( self::repo() );
		$p    = implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) );
		$body = array(
			'message' => $message,
			'content' => base64_encode( $content ),
		);
		if ( is_array( $known ) ) {
			if ( isset( $known[ $path ] ) ) {
				if ( $known[ $path ] === self::blob_sha( $content ) ) {
					return true; // Unchanged – nothing uploaded.
				}
				$body['sha'] = $known[ $path ];
			}
		} else {
			$old = self::request( 'GET', "/repos/{$o}/{$r}/contents/{$p}" );
			if ( ! is_wp_error( $old ) && isset( $old['sha'] ) ) {
				if ( $old['sha'] === self::blob_sha( $content ) || ( isset( $old['content'] ) && base64_decode( str_replace( "\n", '', $old['content'] ) ) === $content ) ) {
					return true; // Unchanged.
				}
				$body['sha'] = $old['sha'];
			}
		}
		$res = self::request( 'PUT', "/repos/{$o}/{$r}/contents/{$p}", $body );
		return is_wp_error( $res ) ? $res : true;
	}

	/** Push runner, workflow and README into the repository. */
	public static function push_files() {
		$dir   = AAW_DIR . 'github-runner/';
		$files = array(
			'.github/workflows/' . self::WORKFLOW => 'aria-writer.yml',
			'runner/runner.mjs'                   => 'runner.mjs',
			'README.md'                           => 'README.md',
		);
		$known = self::tree();
		$known = is_wp_error( $known ) ? null : $known;
		foreach ( $files as $target => $src ) {
			$content = file_get_contents( $dir . $src ); // phpcs:ignore
			$r       = self::put_file( $target, $content, 'ARIAGH.AIWRITER ' . AAW_VERSION . ': update ' . $target, $known );
			if ( is_wp_error( $r ) ) {
				if ( false !== strpos( $target, '.github/' ) ) {
					return new WP_Error( 'aaw_gh', 'نوشتن فایل Workflow رد شد. توکن باید دسترسی «workflow» (یا Workflows: Read and write) داشته باشد. ' . $r->get_error_message() );
				}
				return $r;
			}
		}
		// The workflow stores the site backup / SEO database on branch aaw-data → allow write (best effort).
		$o = rawurlencode( self::owner() );
		$r = rawurlencode( self::repo() );
		self::request( 'PUT', "/repos/{$o}/{$r}/actions/permissions/workflow", array( 'default_workflow_permissions' => 'write', 'can_approve_pull_request_reviews' => false ) );
		AAW_Settings::update( array( 'gh_files_version' => AAW_VERSION ) );
		return true;
	}

	/** Encrypt and store an Actions secret (libsodium sealed box, as required by GitHub). */
	public static function put_secret( $name, $value ) {
		if ( ! function_exists( 'sodium_crypto_box_seal' ) ) {
			return new WP_Error( 'aaw_gh', 'افزونه PHP «sodium» روی هاست فعال نیست؛ برای ذخیره امن Secrets در GitHub لازم است.' );
		}
		$o   = rawurlencode( self::owner() );
		$r   = rawurlencode( self::repo() );
		$key = self::request( 'GET', "/repos/{$o}/{$r}/actions/secrets/public-key" );
		if ( is_wp_error( $key ) ) {
			return $key;
		}
		$sealed = sodium_crypto_box_seal( (string) $value, base64_decode( $key['key'] ) );
		$res    = self::request(
			'PUT',
			"/repos/{$o}/{$r}/actions/secrets/" . rawurlencode( $name ),
			array(
				'encrypted_value' => base64_encode( $sealed ),
				'key_id'          => $key['key_id'],
			)
		);
		return is_wp_error( $res ) ? $res : true;
	}

	public static function delete_secret( $name ) {
		$o = rawurlencode( self::owner() );
		$r = rawurlencode( self::repo() );
		return self::request( 'DELETE', "/repos/{$o}/{$r}/actions/secrets/" . rawurlencode( $name ) );
	}

	public static function list_secrets() {
		$o   = rawurlencode( self::owner() );
		$r   = rawurlencode( self::repo() );
		$res = self::request( 'GET', "/repos/{$o}/{$r}/actions/secrets?per_page=50" );
		return is_wp_error( $res ) ? $res : wp_list_pluck( (array) ( $res['secrets'] ?? array() ), 'name' );
	}

	/** Secrets the runner needs to talk back to WordPress and the Cloudflare worker. */
	public static function sync_base_secrets() {
		$pairs = array(
			'AAW_WP_API'        => AAW_Cloudflare::wp_api(),
			'AAW_SHARED_SECRET' => AAW_Settings::shared_secret(),
			'AAW_WORKER_URL'    => AAW_Cloudflare::endpoint(),
		);
		foreach ( $pairs as $k => $v ) {
			if ( '' === (string) $v ) {
				continue;
			}
			$r = self::put_secret( $k, $v );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		return true;
	}

	public static function default_branch() {
		$b = (string) AAW_Settings::get( 'gh_branch', '' );
		if ( $b ) {
			return $b;
		}
		$o    = rawurlencode( self::owner() );
		$r    = rawurlencode( self::repo() );
		$repo = self::request( 'GET', "/repos/{$o}/{$r}" );
		return is_wp_error( $repo ) ? 'main' : ( $repo['default_branch'] ?? 'main' );
	}

	/** Inputs the workflow receives (used by WordPress and the Cloudflare worker). */
	public static function dispatch_spec( $trigger = 'manual', $topic_id = 0 ) {
		$provider = AAW_Settings::get( 'provider' );
		$p        = AAW_Providers::get( $provider );
		$engine   = ( $p && ! empty( $p['engine'] ) ) ? $p['engine'] : 'claude';
		return array(
			'owner'    => self::owner(),
			'repo'     => self::repo(),
			'workflow' => self::WORKFLOW,
			'ref'      => self::default_branch(),
			'inputs'   => array(
				'trigger'  => (string) $trigger,
				'topic_id' => (string) (int) $topic_id,
				'engine'   => $engine,
				'model'    => (string) AAW_Providers::model_for( $provider ),
			),
		);
	}

	public static function dispatch( $trigger = 'manual', $topic_id = 0, $engine_override = '', $pull_id = '' ) {
		if ( AAW_Settings::get( 'gh_files_version' ) !== AAW_VERSION ) {
			$p = self::push_files(); // Keep workflow inputs in sync with this plugin version.
			if ( is_wp_error( $p ) ) {
				return $p;
			}
		}
		$spec = self::dispatch_spec( $trigger, $topic_id );
		$spec['inputs']['pull_id'] = (string) $pull_id;
		if ( $engine_override ) {
			$spec['inputs']['engine'] = $engine_override;
			$spec['inputs']['model']  = (string) AAW_Providers::model_for( 'codex' === $engine_override ? 'sub_codex' : 'sub_claude' );
		}
		$o   = rawurlencode( $spec['owner'] );
		$r   = rawurlencode( $spec['repo'] );
		$res = self::request( 'POST', "/repos/{$o}/{$r}/actions/workflows/" . self::WORKFLOW . '/dispatches', array( 'ref' => $spec['ref'], 'inputs' => $spec['inputs'] ) );
		return is_wp_error( $res ) ? $res : $spec;
	}

	public static function runs( $limit = 10 ) {
		$o   = rawurlencode( self::owner() );
		$r   = rawurlencode( self::repo() );
		$res = self::request( 'GET', "/repos/{$o}/{$r}/actions/workflows/" . self::WORKFLOW . '/runs?per_page=' . (int) $limit );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$out = array();
		foreach ( (array) ( $res['workflow_runs'] ?? array() ) as $run ) {
			$out[] = array(
				'id'         => $run['id'],
				'status'     => $run['status'],
				'conclusion' => $run['conclusion'],
				'event'      => $run['event'],
				'created'    => wp_date( 'Y/m/d H:i', strtotime( $run['created_at'] ) ),
				'duration'   => ( ! empty( $run['run_started_at'] ) && ! empty( $run['updated_at'] ) ) ? max( 0, strtotime( $run['updated_at'] ) - strtotime( $run['run_started_at'] ) ) : 0,
				'url'        => $run['html_url'],
				'title'      => $run['display_title'] ?? '',
			);
		}
		return $out;
	}
}
