<?php
/**
 * Cloudflare REST API client: token verification, Worker deployment, Secrets, Cron Triggers and KV.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Cloudflare {

	const API = 'https://api.cloudflare.com/client/v4';

	public static function token() {
		return AAW_Settings::secure_get( 'cf_api_token' );
	}

	public static function account() {
		return trim( (string) AAW_Settings::get( 'cf_account_id' ) );
	}

	public static function script() {
		return AAW_Settings::get( 'worker_name', 'aria-ai-writer' );
	}

	public static function is_configured() {
		return '' !== self::token() && '' !== self::account();
	}

	/** REST base the worker / GitHub runner call (override helps behind proxies or odd DNS setups). */
	public static function wp_api() {
		$o = trim( (string) AAW_Settings::get( 'wp_api_override' ) );
		return untrailingslashit( $o ? $o : rest_url( 'aaw/v1' ) );
	}

	/** Public endpoint of the worker (custom domain wins over workers.dev). */
	public static function endpoint() {
		$custom = trim( (string) AAW_Settings::get( 'worker_custom_url' ) );
		return untrailingslashit( $custom ? $custom : (string) AAW_Settings::get( 'worker_url' ) );
	}

	public static function is_deployed() {
		return (int) AAW_Settings::get( 'deployed_at' ) > 0 && '' !== AAW_Settings::get( 'worker_url' );
	}

	/**
	 * Perform an API request.
	 *
	 * @return array|WP_Error Decoded "result" on success.
	 */
	public static function request( $method, $path, $body = null, $content_type = 'application/json', $raw = false ) {
		$token = self::token();
		if ( '' === $token ) {
			return new WP_Error( 'aaw_cf', 'توکن API کلادفلر تنظیم نشده است.' );
		}
		$args = array(
			'method'  => $method,
			'timeout' => 60,
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
			),
		);
		if ( null !== $body ) {
			if ( 'application/json' === $content_type && ! is_string( $body ) ) {
				$body = wp_json_encode( $body );
			}
			$args['body']                    = $body;
			$args['headers']['Content-Type'] = $content_type;
		}
		$t0  = microtime( true );
		$res = null;
		if ( isset( $args['body'] ) && self::use_relay( $args['body'] ) ) {
			$res = self::relay( $method, self::API . $path, $args['headers'], $args['body'] );
			if ( is_wp_error( $res ) ) {
				$res = null; // Old worker / relay unavailable → direct.
			}
		}
		if ( null === $res ) {
			$res = wp_remote_request( self::API . $path, $args );
		}
		if ( is_wp_error( $res ) ) {
			return AAW_Errors::network( $res, self::API . $path, microtime( true ) - $t0, 'API کلادفلر', isset( $args['body'] ) ? strlen( (string) $args['body'] ) : 0 );
		}
		$code = wp_remote_retrieve_response_code( $res );
		$text = wp_remote_retrieve_body( $res );
		if ( $raw ) {
			if ( $code >= 200 && $code < 300 ) {
				return $text;
			}
			return new WP_Error( 'aaw_cf', 'Cloudflare HTTP ' . $code, array( 'status' => $code ) );
		}
		$json = json_decode( $text, true );
		if ( ! is_array( $json ) ) {
			return new WP_Error( 'aaw_cf', 'پاسخ نامعتبر از کلادفلر (HTTP ' . $code . ')' );
		}
		if ( empty( $json['success'] ) ) {
			$msgs = array();
			foreach ( (array) ( $json['errors'] ?? array() ) as $e ) {
				$msgs[] = ( isset( $e['code'] ) ? '[' . $e['code'] . '] ' : '' ) . ( $e['message'] ?? '' );
			}
			return new WP_Error( 'aaw_cf', 'خطای کلادفلر: ' . ( $msgs ? implode( ' | ', $msgs ) : 'HTTP ' . $code ), array( 'status' => $code ) );
		}
		return array_key_exists( 'result', $json ) ? $json['result'] : $json;
	}

	/* ------------------------------ Token ------------------------------ */

	public static function verify_token() {
		$r = self::request( 'GET', '/user/tokens/verify' );
		if ( is_wp_error( $r ) && self::account() ) {
			// Account-owned tokens use a different endpoint.
			$r = self::request( 'GET', '/accounts/' . rawurlencode( self::account() ) . '/tokens/verify' );
		}
		return $r;
	}

	public static function list_accounts() {
		return self::request( 'GET', '/accounts?per_page=50' );
	}

	/* ------------------------------ KV ------------------------------ */

	public static function ensure_kv() {
		$id = AAW_Settings::get( 'kv_namespace_id' );
		$acc = rawurlencode( self::account() );
		if ( $id ) {
			$check = self::request( 'GET', "/accounts/{$acc}/storage/kv/namespaces/" . rawurlencode( $id ) );
			if ( ! is_wp_error( $check ) ) {
				return $id;
			}
		}
		$title = self::script() . '-kv';
		$list  = self::request( 'GET', "/accounts/{$acc}/storage/kv/namespaces?per_page=100" );
		if ( is_array( $list ) ) {
			foreach ( $list as $ns ) {
				if ( isset( $ns['title'] ) && $ns['title'] === $title ) {
					AAW_Settings::update( array( 'kv_namespace_id' => $ns['id'] ) );
					return $ns['id'];
				}
			}
		}
		$created = self::request( 'POST', "/accounts/{$acc}/storage/kv/namespaces", array( 'title' => $title ) );
		if ( is_wp_error( $created ) ) {
			return $created;
		}
		AAW_Settings::update( array( 'kv_namespace_id' => $created['id'] ) );
		return $created['id'];
	}

	public static function kv_put( $key, $value ) {
		$ns = AAW_Settings::get( 'kv_namespace_id' );
		if ( ! $ns ) {
			return new WP_Error( 'aaw_cf', 'فضای KV ساخته نشده است.' );
		}
		$acc = rawurlencode( self::account() );
		return self::request( 'PUT', "/accounts/{$acc}/storage/kv/namespaces/" . rawurlencode( $ns ) . '/values/' . rawurlencode( $key ), is_string( $value ) ? $value : wp_json_encode( $value, JSON_UNESCAPED_UNICODE ), 'text/plain' );
	}

	public static function kv_get( $key ) {
		$ns = AAW_Settings::get( 'kv_namespace_id' );
		if ( ! $ns ) {
			return new WP_Error( 'aaw_cf', 'فضای KV ساخته نشده است.' );
		}
		$acc = rawurlencode( self::account() );
		return self::request( 'GET', "/accounts/{$acc}/storage/kv/namespaces/" . rawurlencode( $ns ) . '/values/' . rawurlencode( $key ), null, 'application/json', true );
	}

	/* ------------------------------ Worker ------------------------------ */

	public static function worker_source( $compact = false ) {
		$file = AAW_DIR . 'worker/worker.js';
		$src  = file_exists( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore
		if ( $compact && '' !== $src ) {
			// Smaller upload for slow hosts: drop comment-only lines and indentation (code unchanged).
			$src   = preg_replace( '#^[ \t]*/\*.*?\*/[ \t]*\n#ms', '', $src );
			$lines = array();
			foreach ( explode( "\n", $src ) as $l ) {
				$t = trim( $l );
				if ( '' !== $t && 0 !== strpos( $t, '//' ) ) {
					$lines[] = $t;
				}
			}
			$src = implode( "\n", $lines );
		}
		return $src;
	}

	public static function deploy() {
		if ( ! self::is_configured() ) {
			return new WP_Error( 'aaw_cf', 'ابتدا Account ID و API Token کلادفلر را ذخیره کنید.' );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore
		}
		$acc    = rawurlencode( self::account() );
		$script = rawurlencode( self::script() );

		$kv = self::ensure_kv();
		if ( is_wp_error( $kv ) ) {
			return $kv;
		}

		$site     = home_url();
		$bindings = array(
			array( 'type' => 'kv_namespace', 'name' => 'AAW_KV', 'namespace_id' => $kv ),
			array( 'type' => 'plain_text', 'name' => 'WP_API', 'text' => self::wp_api() ),
			array( 'type' => 'plain_text', 'name' => 'ALLOWED_ORIGIN', 'text' => self::origin( admin_url() ) ),
			array( 'type' => 'plain_text', 'name' => 'SITE_URL', 'text' => $site ),
			array( 'type' => 'plain_text', 'name' => 'AAW_VERSION', 'text' => AAW_VERSION ),
		);
		if ( AAW_Settings::get( 'bind_workers_ai' ) ) {
			$bindings[] = array( 'type' => 'ai', 'name' => 'AI' );
		}
		if ( AAW_Settings::get( 'claude_pro_enabled' ) ) {
			$bindings[] = array( 'type' => 'service', 'name' => 'CLAUDE_PRO', 'service' => AAW_Settings::get( 'runner_name', 'aria-claude-pro' ) );
		}
		$base_meta = array(
			'main_module'        => 'worker.js',
			'compatibility_date' => '2024-11-01',
			'keep_bindings'      => array( 'secret_text', 'secret_key' ),
			'observability'      => array( 'enabled' => true ),
		);
		$do_binding = array( 'type' => 'durable_object_namespace', 'name' => 'AAW_JOBS', 'class_name' => 'AawJobs' );
		// Background jobs need a Durable Object (free plan supports SQLite-backed DOs).
		// Try: with migration → binding only (already migrated) → without background jobs.
		$variants = array();
		if ( AAW_Settings::get( 'bg_migrated' ) !== 'aaw-v1' ) {
			$variants[] = array( 'bg' => true, 'meta' => $base_meta + array( 'bindings' => array_merge( $bindings, array( $do_binding ) ), 'migrations' => array( 'new_tag' => 'aaw-v1', 'new_sqlite_classes' => array( 'AawJobs' ) ) ) );
		}
		$variants[] = array( 'bg' => true, 'meta' => $base_meta + array( 'bindings' => array_merge( $bindings, array( $do_binding ) ) ) );
		$variants[] = array( 'bg' => false, 'meta' => $base_meta + array( 'bindings' => $bindings ) );

		// Optional Cloudflare Images binding: shrinks big PNGs to WebP before the host downloads them.
		$images = 'no' !== get_option( 'aaw_cf_images' );
		$up     = null;
		$bg_ok  = false;
		$errs   = array();
		foreach ( $variants as $v ) {
			$meta = $v['meta'];
			if ( $images ) {
				$meta['bindings'][] = array( 'type' => 'images', 'name' => 'IMAGES' );
			}
			$up = self::upload_script( $acc, $script, $meta );
			if ( is_wp_error( $up ) && $images && 'aaw_cf' === $up->get_error_code() && preg_match( '/image|binding/i', $up->get_error_message() ) && ! preg_match( '/durable/i', $up->get_error_message() ) ) {
				$images = false; // Account without the Images binding → same variant without it.
				update_option( 'aaw_cf_images', 'no', false );
				$up = self::upload_script( $acc, $script, $v['meta'] );
			}
			if ( ! is_wp_error( $up ) ) {
				$bg_ok = $v['bg'];
				update_option( 'aaw_cf_images', $images ? 'yes' : 'no', false );
				break;
			}
			$errs[] = $up->get_error_message();
		}
		if ( is_wp_error( $up ) ) {
			return $up;
		}
		AAW_Settings::update( array( 'worker_bg' => $bg_ok, 'bg_migrated' => $bg_ok ? 'aaw-v1' : AAW_Settings::get( 'bg_migrated' ), 'deployed_version' => AAW_VERSION ) );
		delete_transient( 'aaw_worker_caps' );
		if ( ! $bg_ok ) {
			AAW_Logs::add( 'warning', 'deploy', 'کارهای پس‌زمینه (Durable Object) روی حساب کلادفلر فعال نشد؛ کارهای طولانی با اتصال زنده انجام می‌شوند. ' . implode( ' | ', array_slice( $errs, 0, 2 ) ) );
		}

		// Shared signing secret.
		$sec = self::put_secret( 'AAW_SHARED_SECRET', AAW_Settings::shared_secret() );
		if ( is_wp_error( $sec ) ) {
			return $sec;
		}

		// workers.dev route.
		$url = self::ensure_workers_dev();
		if ( is_wp_error( $url ) ) {
			return $url;
		}

		$cron = self::apply_schedule();
		AAW_Settings::update(
			array(
				'worker_url'       => $url,
				'deployed_at'      => time(),
				'deployed_version' => AAW_VERSION,
			)
		);
		AAW_Logs::add( 'success', 'deploy', 'ورکر با موفقیت روی کلادفلر مستقر شد: ' . $url );
		if ( is_wp_error( $cron ) ) {
			return $cron;
		}
		self::sync_kv();
		return array(
			'url'  => $url,
			'kv'   => $kv,
			'cron' => $cron,
		);
	}

	private static function upload_script( $acc, $script, array $metadata ) {
		$boundary = 'aaw' . wp_generate_password( 24, false, false );
		$eol      = "\r\n";
		$body     = '--' . $boundary . $eol
			. 'Content-Disposition: form-data; name="metadata"; filename="metadata.json"' . $eol
			. 'Content-Type: application/json' . $eol . $eol
			. wp_json_encode( $metadata ) . $eol
			. '--' . $boundary . $eol
			. 'Content-Disposition: form-data; name="worker.js"; filename="worker.js"' . $eol
			. 'Content-Type: application/javascript+module' . $eol . $eol
			. self::worker_source( true ) . $eol
			. '--' . $boundary . '--' . $eol;
		return self::request( 'PUT', "/accounts/{$acc}/workers/scripts/{$script}", $body, 'multipart/form-data; boundary=' . $boundary );
	}

	private static function origin( $url ) {
		$p = wp_parse_url( $url );
		return ( $p['scheme'] ?? 'https' ) . '://' . ( $p['host'] ?? '' ) . ( isset( $p['port'] ) ? ':' . $p['port'] : '' );
	}

	public static function ensure_workers_dev() {
		$acc    = rawurlencode( self::account() );
		$script = rawurlencode( self::script() );
		$sub    = self::request( 'GET', "/accounts/{$acc}/workers/subdomain" );
		if ( is_wp_error( $sub ) || empty( $sub['subdomain'] ) ) {
			$name = 'aaw-' . strtolower( wp_generate_password( 8, false, false ) );
			$sub  = self::request( 'PUT', "/accounts/{$acc}/workers/subdomain", array( 'subdomain' => $name ) );
			if ( is_wp_error( $sub ) ) {
				return new WP_Error( 'aaw_cf', 'زیردامنه workers.dev فعال نیست و ساخت خودکار آن هم ممکن نشد. یک‌بار از داشبورد کلادفلر بخش Workers را باز کنید. ' . $sub->get_error_message() );
			}
		}
		$en = self::request( 'POST', "/accounts/{$acc}/workers/scripts/{$script}/subdomain", array( 'enabled' => true, 'previews_enabled' => false ) );
		if ( is_wp_error( $en ) ) {
			return $en;
		}
		return 'https://' . self::script() . '.' . $sub['subdomain'] . '.workers.dev';
	}

	public static function delete_worker() {
		$acc    = rawurlencode( self::account() );
		$script = rawurlencode( self::script() );
		$r      = self::request( 'DELETE', "/accounts/{$acc}/workers/scripts/{$script}?force=true" );
		if ( ! is_wp_error( $r ) ) {
			AAW_Settings::update( array( 'deployed_at' => 0, 'worker_url' => '', 'deployed_version' => '', 'worker_bg' => false, 'bg_migrated' => '' ) );
			AAW_Logs::add( 'warning', 'deploy', 'ورکر از کلادفلر حذف شد.' );
		}
		return $r;
	}

	/* ------------------------------ Secrets ------------------------------ */

	public static function put_secret( $name, $value, $script_name = null ) {
		$acc    = rawurlencode( self::account() );
		$script = rawurlencode( $script_name ? $script_name : self::script() );
		return self::request(
			'PUT',
			"/accounts/{$acc}/workers/scripts/{$script}/secrets",
			array(
				'name' => $name,
				'text' => (string) $value,
				'type' => 'secret_text',
			)
		);
	}

	public static function delete_secret( $name, $script_name = null ) {
		$acc    = rawurlencode( self::account() );
		$script = rawurlencode( $script_name ? $script_name : self::script() );
		return self::request( 'DELETE', "/accounts/{$acc}/workers/scripts/{$script}/secrets/" . rawurlencode( $name ) );
	}

	/** Does a Worker script with this name exist on the account? */
	public static function script_exists( $name ) {
		$acc  = rawurlencode( self::account() );
		$list = self::request( 'GET', "/accounts/{$acc}/workers/scripts" );
		if ( is_wp_error( $list ) ) {
			return $list;
		}
		foreach ( (array) $list as $s ) {
			if ( isset( $s['id'] ) && $s['id'] === $name ) {
				return true;
			}
		}
		return false;
	}

	public static function list_secrets() {
		$acc    = rawurlencode( self::account() );
		$script = rawurlencode( self::script() );
		return self::request( 'GET', "/accounts/{$acc}/workers/scripts/{$script}/secrets" );
	}

	/* ------------------------------ Cron ------------------------------ */

	/**
	 * Translate settings to Cloudflare cron expressions (UTC).
	 * Intervals that do not divide 24h fire hourly and are gated by WordPress.
	 */
	public static function cron_expressions() {
		// In local/pull mode Cloudflare cannot reach WordPress: WP-Cron schedules instead.
		if ( class_exists( 'AAW_Pull' ) && AAW_Pull::active() ) {
			return array();
		}
		return self::schedule_expressions();
	}

	/** The user's schedule as cron expressions (UTC), independent of who executes it. */
	public static function schedule_expressions() {
		if ( AAW_Settings::get( 'paused' ) || ! AAW_Settings::get( 'enabled' ) ) {
			return array();
		}
		$m = (int) AAW_Settings::get( 'run_minute', 0 );
		if ( 'custom' === AAW_Settings::get( 'cron_mode' ) ) {
			$exprs = array();
			foreach ( preg_split( '/[\r\n;]+/', (string) AAW_Settings::get( 'custom_cron' ) ) as $c ) {
				$c = trim( preg_replace( '/\s+/', ' ', $c ) );
				if ( self::valid_cron( $c ) ) {
					$exprs[] = $c;
				}
			}
			return array_slice( $exprs, 0, 3 );
		}
		$n = (int) AAW_Settings::get( 'interval_hours', 12 );
		if ( $n < 24 && 0 === 24 % $n ) {
			return array( 1 === $n ? "{$m} * * * *" : "{$m} */{$n} * * *" );
		}
		if ( 24 === $n ) {
			return array( "{$m} 5 * * *" );
		}
		if ( 0 === $n % 24 ) {
			return array( "{$m} 5 * * *" ); // Daily tick, gated by interval.
		}
		return array( "{$m} * * * *" ); // Hourly tick, gated by interval.
	}

	public static function needs_gating() {
		if ( 'custom' === AAW_Settings::get( 'cron_mode' ) ) {
			return false;
		}
		$n = (int) AAW_Settings::get( 'interval_hours', 12 );
		return ! ( $n <= 24 && 0 === 24 % $n );
	}

	public static function valid_cron( $c ) {
		$parts = explode( ' ', trim( $c ) );
		if ( 5 !== count( $parts ) ) {
			return false;
		}
		foreach ( $parts as $p ) {
			if ( ! preg_match( '/^[0-9A-Za-z\*\/\-,#LW\?]+$/', $p ) ) {
				return false;
			}
		}
		return true;
	}

	public static function apply_schedule() {
		if ( ! self::is_configured() ) {
			return new WP_Error( 'aaw_cf', 'کلادفلر متصل نیست.' );
		}
		$acc    = rawurlencode( self::account() );
		$script = rawurlencode( self::script() );
		$body   = array();
		foreach ( self::cron_expressions() as $c ) {
			$body[] = array( 'cron' => $c );
		}
		$r = self::request( 'PUT', "/accounts/{$acc}/workers/scripts/{$script}/schedules", $body );
		if ( ! is_wp_error( $r ) ) {
			AAW_Logs::add( 'info', 'schedule', $body ? 'زمان‌بندی کلادفلر به‌روز شد: ' . implode( ' , ', wp_list_pluck( $body, 'cron' ) ) : 'زمان‌بندی متوقف شد (بدون Cron فعال).' );
		}
		return is_wp_error( $r ) ? $r : wp_list_pluck( $body, 'cron' );
	}

	public static function get_schedule() {
		$acc    = rawurlencode( self::account() );
		$script = rawurlencode( self::script() );
		return self::request( 'GET', "/accounts/{$acc}/workers/scripts/{$script}/schedules" );
	}

	/** Next run timestamp (approximate, computed locally from expressions). */
	public static function next_run_ts() {
		$exprs = self::schedule_expressions();
		if ( empty( $exprs ) ) {
			return 0;
		}
		$now  = time();
		$best = 0;
		foreach ( $exprs as $e ) {
			$t = self::next_from_expr( $e, $now );
			if ( $t && ( ! $best || $t < $best ) ) {
				$best = $t;
			}
		}
		if ( $best && self::needs_gating() ) {
			$last = AAW_Logs::last( 'draft', 'success' );
			$n    = (int) AAW_Settings::get( 'interval_hours', 12 ) * HOUR_IN_SECONDS;
			if ( $last ) {
				$due = strtotime( $last['created_at'] . ' UTC' ) + $n - 600;
				while ( $best < $due ) {
					$best += ( 0 === ( $n % DAY_IN_SECONDS ) ) ? DAY_IN_SECONDS : HOUR_IN_SECONDS;
				}
			}
		}
		return $best;
	}

	/** Minimal cron evaluator (minute/hour/dom/month/dow with *, lists, ranges, steps). */
	public static function next_from_expr( $expr, $from ) {
		$f = explode( ' ', $expr );
		if ( 5 !== count( $f ) ) {
			return 0;
		}
		$t = $from - ( $from % 60 ) + 60;
		for ( $i = 0; $i < 60 * 24 * 8; $i++ ) {
			$min  = (int) gmdate( 'i', $t );
			$hour = (int) gmdate( 'G', $t );
			$dom  = (int) gmdate( 'j', $t );
			$mon  = (int) gmdate( 'n', $t );
			$dow  = (int) gmdate( 'w', $t );
			if ( self::field_match( $f[0], $min, 0, 59 ) && self::field_match( $f[1], $hour, 0, 23 ) && self::field_match( $f[2], $dom, 1, 31 ) && self::field_match( $f[3], $mon, 1, 12 ) && self::field_match( $f[4], $dow, 0, 7, true ) ) {
				return $t;
			}
			$t += 60;
		}
		return 0;
	}

	private static function field_match( $field, $val, $lo, $hi, $is_dow = false ) {
		if ( '*' === $field || '?' === $field ) {
			return true;
		}
		foreach ( explode( ',', $field ) as $part ) {
			$step     = 1;
			$has_step = false !== strpos( $part, '/' );
			if ( $has_step ) {
				list( $part, $step ) = explode( '/', $part, 2 );
				$step = max( 1, (int) $step );
			}
			if ( '*' === $part ) {
				$a = $lo;
				$b = $hi;
			} elseif ( false !== strpos( $part, '-' ) ) {
				list( $a, $b ) = array_map( 'intval', explode( '-', $part, 2 ) );
			} else {
				$a = (int) $part;
				$b = $has_step ? $hi : $a;
			}
			for ( $x = $a; $x <= $b; $x += $step ) {
				if ( $x === $val || ( $is_dow && 7 === $x && 0 === $val ) ) {
					return true;
				}
			}
		}
		return false;
	}

	/* ------------------------------ Backup to KV ------------------------------ */

	public static function sync_kv() {
		if ( ! AAW_Settings::get( 'kv_sync' ) || ! AAW_Settings::get( 'kv_namespace_id' ) || ! self::is_configured() ) {
			return false;
		}
		$topics = AAW_Topics::query( array( 'per_page' => 1000 ) );
		$r1     = self::kv_put( 'settings', AAW_Settings::export() );
		$r2     = self::kv_put( 'topics', array( 'saved_at' => time(), 'items' => $topics['items'] ) );
		update_option( 'aaw_last_kv_sync', time(), false );
		return ! is_wp_error( $r1 ) && ! is_wp_error( $r2 );
	}

	public static function restore_from_kv() {
		$raw = self::kv_get( 'settings' );
		if ( is_wp_error( $raw ) ) {
			return $raw;
		}
		$data = json_decode( $raw, true );
		$r    = AAW_Settings::import( $data );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$count = 0;
		$traw  = self::kv_get( 'topics' );
		if ( ! is_wp_error( $traw ) ) {
			$t = json_decode( $traw, true );
			if ( ! empty( $t['items'] ) && AAW_Topics::counts()['total'] === 0 ) {
				foreach ( $t['items'] as $item ) {
					unset( $item['id'] );
					if ( ! is_wp_error( AAW_Topics::add( $item ) ) ) {
						++$count;
					}
				}
			}
		}
		return array( 'topics' => $count );
	}

	/* ------------------------------ Server-to-worker calls ------------------------------ */

	/**
	 * Live capabilities of the deployed worker (GET /health, cached 20 min).
	 *
	 * @return array{version:string,bg:bool,gzip:bool,parts:bool,ok:bool}
	 */
	public static function caps( $force = false ) {
		$c = $force ? false : get_transient( 'aaw_worker_caps' );
		if ( is_array( $c ) ) {
			return $c;
		}
		$c   = array( 'ok' => false, 'version' => '', 'code' => '', 'bg' => false, 'gzip' => false, 'parts' => false, 'chunks' => false, 'relay' => false, 'shrink' => false );
		$url = self::endpoint();
		if ( $url ) {
			$r = wp_remote_get( trailingslashit( $url ) . 'health', array( 'timeout' => 10 ) );
			$j = is_wp_error( $r ) ? null : json_decode( (string) wp_remote_retrieve_body( $r ), true );
			if ( is_array( $j ) && ! empty( $j['ok'] ) ) {
				$c = array(
					'ok'      => true,
					'version' => (string) ( $j['version'] ?? '' ),
					'code'    => (string) ( $j['code'] ?? '' ),
					'bg'      => ! empty( $j['bg'] ),
					'gzip'    => ! empty( $j['gzip'] ),
					'parts'   => ! empty( $j['parts'] ),
					'chunks'  => ! empty( $j['chunks'] ),
					'relay'   => ! empty( $j['relay'] ),
					'shrink'  => ! empty( $j['shrink'] ),
				);
			}
		}
		set_transient( 'aaw_worker_caps', $c, $c['ok'] ? 20 * MINUTE_IN_SECONDS : 2 * MINUTE_IN_SECONDS );
		return $c;
	}

	/**
	 * Big uploads to GitHub / Cloudflare API through the worker: the host sends a small,
	 * gzip'd, chunked request and Cloudflare makes the real call at full speed.
	 *
	 * @return array|WP_Error WP-style response array.
	 */
	public static function relay( $method, $url, array $headers, $body ) {
		if ( ! self::is_deployed() ) {
			return new WP_Error( 'aaw_relay', 'no worker' );
		}
		$caps = self::caps();
		if ( empty( $caps['relay'] ) ) {
			return new WP_Error( 'aaw_relay', 'worker without relay' );
		}
		$r = self::call_worker( 'relay', array( 'method' => $method, 'url' => $url, 'headers' => $headers, 'body' => $body ), 150 );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$code = (int) ( $r['status'] ?? 0 );
		return array( 'code' => $code, 'response' => array( 'code' => $code, 'message' => '' ), 'body' => (string) ( $r['body'] ?? '' ), 'headers' => array() );
	}

	/** Should this outgoing request go through the worker relay? (big body + slow host) */
	public static function use_relay( $body ) {
		return is_string( $body ) && strlen( $body ) > 8000 && 'direct' !== AAW_Settings::get( 'net_relay', 'auto' ) && self::is_deployed();
	}

	public static function call_worker( $route, $payload = array(), $timeout = 60 ) {
		$url = self::endpoint();
		if ( ! $url ) {
			return new WP_Error( 'aaw_worker', AAW_Errors::format( 'ورکر هنوز مستقر نشده است', 'آدرس ورکر کلادفلر در تنظیمات وجود ندارد.', 'در تب کلادفلر توکن را ذخیره و «استقرار ورکر» را بزنید.' ) );
		}
		$body    = wp_json_encode( $payload );
		$headers = AAW_Security::sign( $route, $body );
		// Long AI routes stream keep-alive bytes so proxies never cut an idle connection.
		$headers['X-AAW-Stream'] = '1';
		if ( $timeout > 60 && function_exists( 'set_time_limit' ) ) {
			@set_time_limit( $timeout + 30 ); // phpcs:ignore
		}
		$target = trailingslashit( $url ) . ltrim( $route, '/' );
		$send   = $body;
		// Small uploads only: gzip anything non-trivial, and split big bodies into signed
		// parts so no single request runs long on slow / time-limited outbound links.
		$caps = strlen( $body ) > 4096 && 'part' !== $route ? self::caps() : array();
		if ( ! empty( $caps['gzip'] ) && function_exists( 'gzencode' ) ) {
			$gz = gzencode( $body, 9 );
			if ( false !== $gz ) {
				$send                      = $gz;
				$headers['X-AAW-Encoding'] = 'gzip';
				$limit                     = AAW_Transfer::up_chunk();
				if ( strlen( $gz ) > $limit && ! empty( $caps['parts'] ) ) {
					$token = strtolower( wp_generate_password( 16, false, false ) );
					$off   = 0;
					$n     = 0;
					$tries = 0;
					// Adaptive pieces: each one ~5 s; a failed piece is re-sent smaller.
					while ( $off < strlen( $gz ) ) {
						$size  = AAW_Transfer::up_chunk();
						$chunk = substr( $gz, $off, $size );
						$t0    = microtime( true );
						$pr    = self::call_worker( 'part', array( 't' => $token, 'n' => $n, 'data' => base64_encode( $chunk ) ), AAW_Transfer::PIECE_TO ); // phpcs:ignore
						if ( is_wp_error( $pr ) ) {
							AAW_Transfer::record( 'up', 0, microtime( true ) - $t0, false, strlen( $chunk ) );
							if ( ++$tries >= 6 ) {
								return $pr;
							}
							continue;
						}
						AAW_Transfer::record( 'up', (int) ( strlen( $chunk ) * 1.37 ), microtime( true ) - $t0, true );
						$off  += strlen( $chunk );
						$n++;
						$tries = 0;
						if ( $n > 390 ) {
							return new WP_Error( 'aaw_worker', 'حجم درخواست برای ارسال تکه‌ای بیش از حد بزرگ است.' );
						}
					}
					$headers['X-AAW-Parts'] = $token . ':' . $n;
					$send                   = '';
				}
			}
		}
		$headers['Content-Type'] = isset( $headers['X-AAW-Encoding'] ) ? 'application/octet-stream' : 'application/json';
		$t0  = microtime( true );
		$res = wp_remote_post(
			$target,
			array(
				'timeout' => $timeout,
				'headers' => $headers,
				'body'    => $send,
			)
		);
		if ( is_wp_error( $res ) ) {
			return AAW_Errors::network( $res, $target, microtime( true ) - $t0, 'ورکر کلادفلر', strlen( $send ) );
		}
		return self::parse_worker_response( $res );
	}

	/** Decode a worker response (plain or keep-alive streamed) with exact error reasons. */
	public static function parse_worker_response( $res ) {
		$text = (string) wp_remote_retrieve_body( $res );
		$code = (int) wp_remote_retrieve_response_code( $res );
		$json = json_decode( trim( $text ), true );
		if ( is_array( $json ) && isset( $json['ok'] ) && false === $json['ok'] ) {
			return new WP_Error( 'aaw_worker', AAW_Errors::explain( ( $json['error'] ?? 'خطای ورکر' ) . ( $code >= 400 ? ' (HTTP ' . $code . ')' : '' ), 'ورکر کلادفلر' ) );
		}
		if ( $code >= 300 || ! is_array( $json ) ) {
			if ( '' === trim( $text ) ) {
				return new WP_Error( 'aaw_worker', AAW_Errors::format( 'ورکر پاسخ خالی برگرداند (HTTP ' . $code . ')', 'اتصال برقرار شد ولی بدنه پاسخ خالی بود؛ معمولاً ورکر حین پردازش متوقف شده یا یک پراکسی پاسخ را حذف کرده است.', 'در تب کلادفلر «استقرار مجدد» را بزنید و دوباره تلاش کنید.' ) );
			}
			if ( preg_match( '/error code:\s*(\d{4})/i', $text, $m ) ) {
				return new WP_Error( 'aaw_worker', AAW_Errors::explain( 'error code: ' . $m[1], 'کلادفلر' ) );
			}
			if ( false !== stripos( $text, '<html' ) ) {
				$title = preg_match( '#<title>(.*?)</title>#is', $text, $t ) ? trim( wp_strip_all_tags( $t[1] ) ) : '';
				return new WP_Error( 'aaw_worker', AAW_Errors::format( 'به‌جای پاسخ ورکر یک صفحه HTML برگشت (HTTP ' . $code . ')', 'درخواست به ورکر نرسید و یک واسط (صفحه خطای کلادفلر، فیلترینگ یا پراکسی هاست) صفحه دیگری برگرداند' . ( $title ? ': «' . $title . '»' : '' ) . '.', 'آدرس ورکر را در تب کلادفلر بررسی و «استقرار مجدد» کنید؛ اگر صفحه فیلترینگ است، دامنه اختصاصی ورکر بسازید.' ) );
			}
			return new WP_Error( 'aaw_worker', AAW_Errors::explain( 'پاسخ نامعتبر از ورکر (HTTP ' . $code . '): ' . substr( wp_strip_all_tags( $text ), 0, 200 ), 'ورکر کلادفلر' ) );
		}
		return $json;
	}
}
