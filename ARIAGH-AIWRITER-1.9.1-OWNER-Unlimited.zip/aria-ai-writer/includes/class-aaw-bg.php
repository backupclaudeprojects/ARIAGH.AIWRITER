<?php
/**
 * Background jobs on the Cloudflare worker (Durable Object alarm, up to 15 minutes).
 *
 * WordPress and the browser only make short requests: one to start the job and
 * short polls to read its status. Hosting / national network limits on the length
 * of outbound connections (e.g. Iranian hosts cutting foreign connections after
 * ~15 s) therefore never break long AI work.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_BG {

	/** Worker deployed with the AawJobs Durable Object and matching version. */
	public static function available() {
		if ( ! AAW_Cloudflare::is_deployed() ) {
			return false;
		}
		// Ask the worker itself (cached) instead of trusting saved flags.
		$caps = AAW_Cloudflare::caps();
		if ( $caps['ok'] ) {
			return (bool) $caps['bg'];
		}
		return AAW_Settings::get( 'worker_bg' ) && AAW_Settings::get( 'deployed_version' ) === AAW_VERSION;
	}

	public static function new_id( $prefix = 'b' ) {
		return $prefix . time() . strtolower( wp_generate_password( 6, false, false ) );
	}

	/**
	 * Start a job.
	 *
	 * @param string $kind    analyze|generate|run|suggest|image|seo_learn|style_learn.
	 * @param array  $payload Job payload.
	 * @param bool   $mailbox Deliver the result to the KV mailbox read by AAW_Pull::poll().
	 * @param array  $topics  Topic ids to track (marked failed if the job is lost).
	 * @return string|WP_Error Job id.
	 */
	public static function start( $kind, array $payload, $mailbox = false, array $topics = array(), $label = '' ) {
		$id = self::new_id( substr( $kind, 0, 1 ) );
		$r  = AAW_Cloudflare::call_worker(
			'bg_start',
			array(
				'id'      => $id,
				'kind'    => $kind,
				'payload' => $payload,
				'mailbox' => (bool) $mailbox,
			),
			40
		);
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		AAW_Activity::start( $kind, $label ? $label : self::kind_label( $kind, $payload ), array( 'bg' => $id, 'post_id' => (int) ( $payload['post_id'] ?? 0 ) ) );
		if ( $mailbox ) {
			$pending        = get_option( AAW_Pull::PENDING, array() );
			$pending        = is_array( $pending ) ? $pending : array();
			$pending[ $id ] = array( 'time' => time(), 'topics' => array_map( 'absint', $topics ), 'kind' => $kind );
			update_option( AAW_Pull::PENDING, $pending, false );
			AAW_Pull::schedule_bg_poll();
		}
		$jobs        = get_option( 'aaw_bg_jobs', array() );
		$jobs        = is_array( $jobs ) ? array_slice( $jobs, -19, null, true ) : array();
		$jobs[ $id ] = array( 'kind' => $kind, 'time' => time() );
		update_option( 'aaw_bg_jobs', $jobs, false );
		return $id;
	}

	/** @return array|WP_Error Job record: status queued|running|done|error, step, result, error. */
	public static function get( $id ) {
		$id = preg_replace( '/[^a-z0-9]/i', '', (string) $id );
		$r  = AAW_Cloudflare::call_worker( 'bg_get', array( 'id' => $id ), 25 );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return isset( $r['job'] ) && is_array( $r['job'] ) ? $r['job'] : array( 'status' => 'unknown' );
	}

	/**
	 * Wait for a job from PHP with short polls (each request a few hundred ms).
	 *
	 * @return array|WP_Error Result payload.
	 */
	public static function wait( $id, $max_seconds = 600, $every = 4 ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( $max_seconds + 60 ); // phpcs:ignore
		}
		$until = time() + $max_seconds;
		$fails = 0;
		do {
			sleep( $every );
			$j = self::get( $id );
			if ( is_wp_error( $j ) ) {
				if ( ++$fails >= 4 ) {
					return $j;
				}
				continue;
			}
			$fails = 0;
			if ( 'done' === ( $j['status'] ?? '' ) ) {
				return isset( $j['result'] ) && is_array( $j['result'] ) ? $j['result'] : array();
			}
			if ( 'error' === ( $j['status'] ?? '' ) ) {
				return new WP_Error( 'aaw_bg', AAW_Errors::explain( (string) ( $j['error'] ?? 'خطای نامشخص در کار پس‌زمینه' ), 'ورکر کلادفلر' ) );
			}
		} while ( time() < $until );
		return new WP_Error( 'aaw_bg', AAW_Errors::format( 'کار پس‌زمینه در زمان انتظار تمام نشد', 'کار روی کلادفلر هنوز در حال اجراست یا متوقف شده است (حداکثر ۱۵ دقیقه).', 'چند دقیقه بعد «گزارش‌ها» را ببینید؛ نتیجه در صورت آماده شدن خودکار دریافت می‌شود.' ) );
	}

	public static function kind_label( $kind, array $payload = array() ) {
		$map = array(
			'analyze'     => 'تحلیل هوشمند سایت',
			'generate'    => 'نوشتن مقاله',
			'run'         => 'تولید فوری مقاله',
			'suggest'     => 'ایده‌پردازی موضوعات جدید',
			'image'       => 'تست ساخت تصویر',
			'seo_learn'   => 'یادگیری دانش به‌روز سئو',
			'style_learn' => 'یادگیری تم تصویری سایت',
			'revise'      => 'اصلاح مقاله با دستور شما',
			'post_image'  => 'ساخت تصویر جدید برای مقاله',
		);
		$l = $map[ $kind ] ?? $kind;
		if ( 'generate' === $kind && ! empty( $payload['jobs'] ) ) {
			$l .= ': ' . implode( '، ', array_map( function ( $j ) { return $j['topic']['title'] ?? ''; }, array_slice( $payload['jobs'], 0, 3 ) ) );
		}
		if ( ! empty( $payload['post_id'] ) ) {
			$l .= ': ' . get_the_title( (int) $payload['post_id'] );
		}
		return $l;
	}

	/** Human label for a running step. */
	public static function step_label( $step ) {
		$step = (string) $step;
		if ( 0 === strpos( $step, 'write:' ) ) {
			return 'هوش مصنوعی در حال نوشتن مقاله است…';
		}
		if ( 0 === strpos( $step, 'image:' ) ) {
			return 'در حال ساخت تصاویر مقاله…';
		}
		$map = array(
			'start'  => 'کار روی کلادفلر شروع شد…',
			'ai'     => 'هوش مصنوعی در حال تحلیل است…',
			'fetch'  => 'در حال خواندن منابع سئو…',
			'revise' => 'هوش مصنوعی در حال اعمال اصلاحات شما روی مقاله است…',
		);
		return $map[ $step ] ?? 'در حال انجام…';
	}
}
