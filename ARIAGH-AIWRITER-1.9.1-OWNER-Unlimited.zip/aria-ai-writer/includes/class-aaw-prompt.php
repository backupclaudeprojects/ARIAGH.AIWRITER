<?php
/**
 * Prompt engineering: master prompt, presets, variables and SEO rule compilation.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Prompt {

	public static function tones() {
		return array(
			'professional'   => 'حرفه‌ای و معتبر',
			'friendly'       => 'دوستانه و صمیمی',
			'formal'         => 'رسمی',
			'conversational' => 'محاوره‌ای و روان',
			'educational'    => 'آموزشی و گام‌به‌گام',
			'persuasive'     => 'متقاعدکننده و فروش‌محور',
			'journalistic'   => 'خبری و ژورنالیستی',
			'storytelling'   => 'داستان‌گو و روایی',
			'technical'      => 'فنی و تخصصی',
			'inspirational'  => 'الهام‌بخش و انگیزشی',
		);
	}

	public static function languages() {
		return array(
			'fa' => 'فارسی',
			'en' => 'English',
			'ar' => 'العربية',
			'tr' => 'Türkçe',
			'de' => 'Deutsch',
			'fr' => 'Français',
			'es' => 'Español',
			'ru' => 'Русский',
			'ur' => 'اردو',
			'ps' => 'پښتو',
		);
	}

	public static function levels() {
		return array(
			'simple'       => 'ساده و قابل‌فهم برای عموم',
			'intermediate' => 'متوسط؛ دقیق ولی روان',
			'expert'       => 'تخصصی برای مخاطب حرفه‌ای',
		);
	}

	public static function povs() {
		return array(
			'we'      => 'اول‌شخص جمع (ما)',
			'you'     => 'دوم‌شخص (شما) با خطاب مستقیم',
			'neutral' => 'سوم‌شخص و بی‌طرف',
		);
	}

	public static function default_prompt() {
		return <<<'PROMPT'
تو یک کپی‌رایتر فروش و متخصص ارشد سئو با بیش از ۱۰ سال تجربه در حوزه «{niche}» هستی و برای فروشگاه/وب‌سایت «{site_name}» می‌نویسی.

هدف اصلی: مقاله‌ای درباره «{topic}» بنویس که هم در گوگل رتبه بگیرد و هم خواننده را قدم‌به‌قدم به خرید محصولات {brand} برساند؛ یعنی یک مقاله «فروش‌محور» که اول مشکل خواننده را واقعاً حل می‌کند و بعد محصول مناسب را به‌عنوان بهترین راه‌حل معرفی می‌کند.

مخاطب: {audience}
لحن: {tone} (صمیمی، قابل‌اعتماد و متقاعدکننده؛ نه تبلیغاتی و اغراق‌آمیز)
زبان نگارش: {language}
سال جاری: {year}

ساختار و اصول فروش‌محور:
۱. نیت جستجو را تشخیص بده؛ حتی در موضوعات اطلاعاتی، مسیر «آگاهی ← علاقه ← تصمیم ← خرید» (AIDA) را دنبال کن.
۲. مقدمه با درد یا خواسته واقعی مخاطب شروع شود (مسئله ← پیامد ← وعده راه‌حل). کلمه کلیدی اصلی در ۱۰۰ کلمه اول بیاید.
۳. اطلاعات مفید و دقیق بده تا اعتماد ساخته شود (E-E-A-T)؛ آمار یا منبع ساختگی ممنوع است.
۴. در بخش‌های مرتبط، محصولات واقعی فروشگاه را با فایده‌ها (نه فقط ویژگی‌ها) معرفی کن: چه مشکلی را حل می‌کند، برای چه کسی مناسب است، چرا بهتر از گزینه‌های معمول است. به صفحه هر محصول با انکر تکست طبیعی لینک بده.
۵. حداقل یک دعوت به اقدام میانی (بعد از بخش راه‌حل) و یک دعوت به اقدام قوی در پایان بنویس که خواننده را به صفحه محصول یا خرید هدایت کند (مثل «همین حالا … را از {brand} تهیه کنید»).
۶. به اعتراض‌ها و تردیدهای رایج خرید (قیمت، کیفیت، اصالت، ارسال، نگهداری، نحوه مصرف) صادقانه پاسخ بده و نشانه‌های اعتماد واقعی برند را برجسته کن.
۷. یک جدول مقایسه یا راهنمای انتخاب بیاور تا تصمیم خرید آسان شود.
۸. جمله‌ها کوتاه و روان، پاراگراف‌ها کوتاه و متن اسکن‌پذیر باشد (زیرعنوان، فهرست، نکته برجسته).
۹. کلمات کلیدی فرعی و تجاری (خرید، قیمت، بهترین، مقایسه) را طبیعی و بدون کیورد استافینگ به کار ببر.
۱۰. فقط ادعاهای درست و قابل دفاع درباره محصول بنویس؛ هرگز خواص پزشکی، تخفیف یا قیمتی که داده نشده را از خودت نساز.
۱۱. متن کاملاً انسانی باشد؛ عبارت‌های کلیشه‌ای هوش مصنوعی مثل «در دنیای امروز» و «در این مقاله قصد داریم» ممنوع است. نگارش فارسی معیار با نیم‌فاصله درست.
PROMPT;
	}

	/** Previous (pre-1.7) default prompt – treated as "default" so users get the new sales version. */
	public static function is_legacy_default( $text ) {
		return false !== strpos( (string) $text, 'تو یک نویسنده ارشد محتوا و متخصص سئو با بیش از ۱۰ سال تجربه' ) && false === strpos( (string) $text, 'فروش‌محور' );
	}

	public static function presets() {
		return array(
			'pro'      => array(
				'label'  => 'مقاله فروش‌محور سئو (پیش‌فرض)',
				'prompt' => self::default_prompt(),
			),
			'guide'    => array(
				'label'  => 'راهنمای جامع (Pillar Content)',
				'prompt' => "تو یک نویسنده محتوای Pillar برای سایت «{site_name}» در حوزه «{niche}» هستی.\nیک راهنمای جامع و مرجع درباره «{topic}» بنویس که همه زیرموضوعات مهم را پوشش دهد و کاربر نیازی به مراجعه به منبع دیگری نداشته باشد.\nمخاطب: {audience} | لحن: {tone} | زبان: {language}\n\nهر بخش را با تعریف، اهمیت، روش اجرا، نکات حرفه‌ای و اشتباهات رایج پوشش بده. از جدول مقایسه و چک‌لیست استفاده کن. مثال‌های عملی و مرحله‌به‌مرحله بیاور. کلمه کلیدی اصلی در مقدمه، یکی از H2ها و جمع‌بندی بیاید. هیچ آمار ساختگی ننویس.",
			),
			'commerce' => array(
				'label'  => 'محتوای فروشگاهی و راهنمای خرید',
				'prompt' => "تو کپی‌رایتر و متخصص سئوی فروشگاه اینترنتی «{site_name}» ({niche}) هستی.\nیک مقاله راهنمای خرید درباره «{topic}» بنویس که کاربر را از مرحله آگاهی به تصمیم خرید برساند.\nمخاطب: {audience} | لحن: {tone} | زبان: {language}\n\nمعیارهای انتخاب، مقایسه انواع، مزایا و معایب، نکات قیمت و کیفیت، اشتباهات رایج خرید و پاسخ به سؤالات متداول را پوشش بده. بدون اغراق و ادعای غیرواقعی بنویس و در انتها به‌صورت طبیعی {brand} را به‌عنوان انتخاب مطمئن معرفی کن.",
			),
			'news'     => array(
				'label'  => 'تحلیلی و خبری',
				'prompt' => "تو یک روزنامه‌نگار تحلیلگر در حوزه «{niche}» برای «{site_name}» هستی.\nیک مقاله تحلیلی درباره «{topic}» بنویس: ابتدا خلاصه مهم‌ترین نکته (هرم وارونه)، سپس زمینه، تحلیل ابعاد، پیامدها برای {audience} و چشم‌انداز آینده.\nلحن: {tone} | زبان: {language}\nفقط اطلاعات قابل‌اتکا بنویس؛ اگر مطمئن نیستی، ادعا نکن و آمار نساز.",
			),
			'howto'    => array(
				'label'  => 'آموزش گام‌به‌گام (How-to)',
				'prompt' => "تو مدرس و نویسنده آموزشی در حوزه «{niche}» برای «{site_name}» هستی.\nیک آموزش کامل و گام‌به‌گام درباره «{topic}» بنویس که یک مبتدی بتواند فقط با خواندن آن کار را انجام دهد.\nمخاطب: {audience} | لحن: {tone} | زبان: {language}\nپیش‌نیازها، ابزار لازم، مراحل شماره‌دار با توضیح دقیق هر مرحله، نکات طلایی، خطاهای رایج و راه‌حل آن‌ها، و سؤالات متداول را پوشش بده.",
			),
			'listicle' => array(
				'label'  => 'لیستی (بهترین‌ها / ترفندها)',
				'prompt' => "تو نویسنده محتوای لیستی جذاب برای «{site_name}» در حوزه «{niche}» هستی.\nیک مقاله لیستی درباره «{topic}» بنویس. هر آیتم یک H2 یا H3 مستقل با توضیح کاربردی، مزیت اصلی، و نکته اجرایی داشته باشد.\nمخاطب: {audience} | لحن: {tone} | زبان: {language}\nدر ابتدا جدول خلاصه آیتم‌ها و در انتها جمع‌بندی و پیشنهاد نهایی بیاور.",
			),
		);
	}

	public static function variables() {
		return array(
			'{site_name}'         => 'نام سایت',
			'{niche}'             => 'موضوع و حوزه سایت',
			'{audience}'          => 'مخاطب هدف',
			'{brand}'             => 'نام برند',
			'{brand_description}' => 'معرفی برند',
			'{topic}'             => 'موضوع مقاله جاری',
			'{keywords}'          => 'کلمات کلیدی موضوع',
			'{tone}'              => 'لحن',
			'{language}'          => 'زبان',
			'{word_min}'          => 'حداقل کلمات',
			'{word_max}'          => 'حداکثر کلمات',
			'{category}'          => 'دسته‌بندی',
			'{year}'              => 'سال جاری (شمسی و میلادی)',
			'{date}'              => 'تاریخ امروز',
			'{cta}'               => 'متن دعوت به اقدام',
		);
	}

	public static function jalali_year() {
		$gy = (int) gmdate( 'Y' );
		$gm = (int) gmdate( 'n' );
		$gd = (int) gmdate( 'j' );
		// Persian new year is around March 21.
		return ( $gm > 3 || ( 3 === $gm && $gd >= 21 ) ) ? $gy - 621 : $gy - 622;
	}

	public static function replace_vars( $text, $topic = array() ) {
		$s      = AAW_Settings::all();
		$tones  = self::tones();
		$langs  = self::languages();
		$tone   = ! empty( $topic['tone'] ) && isset( $tones[ $topic['tone'] ] ) ? $topic['tone'] : $s['tone'];
		$words  = ! empty( $topic['word_count'] ) ? (int) $topic['word_count'] : 0;
		$brand  = $s['brand_name'] ? $s['brand_name'] : $s['site_name'];
		$cat    = ! empty( $topic['category_id'] ) ? get_cat_name( (int) $topic['category_id'] ) : '';
		$map    = array(
			'{site_name}'         => $s['site_name'],
			'{niche}'             => $s['niche'] ? $s['niche'] : get_bloginfo( 'description' ),
			'{audience}'          => $s['audience'],
			'{brand}'             => $brand,
			'{brand_description}' => $s['brand_description'],
			'{topic}'             => isset( $topic['title'] ) ? $topic['title'] : '',
			'{keywords}'          => isset( $topic['keywords'] ) ? $topic['keywords'] : '',
			'{tone}'              => $tones[ $tone ],
			'{language}'          => $langs[ $s['language'] ] ?? 'فارسی',
			'{word_min}'          => $words ? $words : $s['word_count_min'],
			'{word_max}'          => $words ? (int) round( $words * 1.25 ) : $s['word_count_max'],
			'{category}'          => $cat,
			'{year}'              => self::jalali_year() . ' (' . gmdate( 'Y' ) . ')',
			'{date}'              => wp_date( 'Y-m-d' ),
			'{cta}'               => $s['cta_text'],
		);
		return strtr( (string) $text, $map );
	}

	/**
	 * Structural and SEO rules compiled from settings.
	 */
	public static function rules( $topic = array() ) {
		$s     = AAW_Settings::all();
		$words = ! empty( $topic['word_count'] ) ? (int) $topic['word_count'] : 0;
		$min   = $words ? $words : (int) $s['word_count_min'];
		$max   = $words ? (int) round( $words * 1.25 ) : (int) $s['word_count_max'];
		$r     = array();
		$r[]   = "طول متن اصلی بین {$min} تا {$max} کلمه باشد.";
		$r[]   = 'سطح نگارش: ' . self::levels()[ $s['reading_level'] ] . '.';
		$r[]   = 'زاویه دید: ' . self::povs()[ $s['pov'] ] . '.';
		$r[]   = "حدود {$s['h2_count']} زیرعنوان H2 داشته باشد" . ( $s['use_h3'] ? ' و در صورت نیاز زیرعنوان‌های H3 زیر آن‌ها.' : ' و از H3 استفاده نشود.' );
		$r[]   = "هر پاراگراف حداکثر {$s['paragraph_max_sentences']} جمله باشد.";
		$r[]   = 'از تگ H1 در content_html استفاده نکن (عنوان جداگانه است). فقط از h2, h3, p, ul, ol, li, table, thead, tbody, tr, th, td, strong, em, blockquote, a استفاده کن.';
		$r[]   = "تراکم کلمه کلیدی اصلی حدود {$s['keyword_density']} درصد باشد و در اولین پاراگراف، حداقل یک H2 و جمع‌بندی بیاید.";
		if ( $s['lsi_count'] > 0 ) {
			$r[] = "حداقل {$s['lsi_count']} کلمه کلیدی مرتبط (LSI) را طبیعی در متن به کار ببر و آن‌ها را در secondary_keywords برگردان.";
		}
		if ( $s['bold_keywords'] ) {
			$r[] = 'کلمه کلیدی اصلی و چند عبارت مهم را با strong برجسته کن (نه بیش از حد).';
		}
		if ( $s['include_intro_hook'] ) {
			$r[] = 'مقدمه با یک قلاب جذاب (مسئله، سؤال یا واقعیت جالب) شروع شود.';
		}
		if ( $s['include_key_takeaways'] ) {
			$r[] = 'بلافاصله بعد از مقدمه یک باکس «نکات کلیدی» به شکل <div class="aaw-takeaways"><h3>نکات کلیدی</h3><ul>...</ul></div> با ۳ تا ۵ مورد بیاور.';
		}
		if ( $s['include_table'] ) {
			$r[] = 'حداقل یک جدول HTML مقایسه‌ای یا خلاصه اطلاعات مفید داشته باش.';
		}
		if ( $s['include_lists'] ) {
			$r[] = 'از فهرست‌های گلوله‌ای یا شماره‌دار برای خوانایی بیشتر استفاده کن.';
		}
		if ( $s['include_examples'] ) {
			$r[] = 'مثال‌های واقعی و کاربردی بیاور.';
		}
		if ( $s['include_stats'] ) {
			$r[] = 'در صورت اطمینان، از عدد و آمار معتبر استفاده کن؛ آمار ساختگی ممنوع است.';
		}
		if ( $s['include_pros_cons'] ) {
			$r[] = 'یک بخش «مزایا و معایب» داشته باش.';
		}
		if ( $s['include_howto_steps'] ) {
			$r[] = 'یک بخش مراحل گام‌به‌گام با فهرست شماره‌دار داشته باش.';
		}
		if ( $s['include_mistakes'] ) {
			$r[] = 'یک بخش «اشتباهات رایج» و راه اجتناب از آن‌ها داشته باش.';
		}
		if ( $s['include_checklist'] ) {
			$r[] = 'یک چک‌لیست عملی نهایی ارائه بده.';
		}
		if ( $s['include_glossary'] ) {
			$r[] = 'یک بخش کوتاه «واژه‌نامه» برای اصطلاحات تخصصی بیاور.';
		}
		if ( $s['include_quote'] ) {
			$r[] = 'یک نقل‌قول یا نکته برجسته در قالب blockquote بیاور (بدون نسبت دادن سخن ساختگی به افراد واقعی).';
		}
		if ( $s['include_faq'] ) {
			$r[] = "{$s['faq_count']} سؤال متداول واقعی کاربران (به سبک People Also Ask) با پاسخ کوتاه و دقیق در آرایه faq برگردان؛ سؤالات متداول را داخل content_html تکرار نکن.";
		}
		if ( $s['include_conclusion'] ) {
			$r[] = 'یک بخش جمع‌بندی کاربردی با H2 در انتها داشته باش.';
		}
		if ( $s['include_cta'] ) {
			$cta = $s['cta_text'] ? $s['cta_text'] : 'دعوت طبیعی به تماس، خرید یا مطالعه بیشتر';
			$r[] = 'در انتهای متن یک دعوت به اقدام (CTA) بنویس با این مضمون: ' . $cta;
		}
		if ( $s['brand_mention'] && ( $s['brand_name'] || $s['site_name'] ) ) {
			$r[] = 'نام برند «' . ( $s['brand_name'] ? $s['brand_name'] : $s['site_name'] ) . '» را ۱ تا ۲ بار به‌صورت طبیعی ذکر کن.' . ( $s['brand_description'] ? ' معرفی برند: ' . $s['brand_description'] : '' );
		}
		if ( $s['avoid_cliches'] ) {
			$r[] = 'عبارات کلیشه‌ای و ماشینی ممنوع: «در دنیای امروز»، «در این مقاله»، «همان‌طور که می‌دانید»، «در پایان می‌توان گفت»، «بیایید»، «سفر».';
		}
		if ( $s['no_emoji'] ) {
			$r[] = 'از هیچ ایموجی استفاده نکن.';
		}
		if ( ! empty( $s['forbidden_words'] ) ) {
			$r[] = 'این کلمات/عبارات ممنوع هستند: ' . implode( '، ', $s['forbidden_words'] ) . '.';
		}
		$r[] = "seo_title حداکثر {$s['seo_title_max']} کاراکتر، جذاب و شامل کلمه کلیدی اصلی ترجیحاً در ابتدا.";
		$r[] = "meta_description بین 120 تا {$s['meta_desc_max']} کاراکتر، ترغیب‌کننده و شامل کلمه کلیدی.";
		if ( 'ai_english' === $s['slug_mode'] ) {
			$r[] = "slug انگلیسی، با حروف کوچک و خط تیره، حداکثر {$s['slug_max_words']} کلمه و بیانگر کلمه کلیدی.";
		} else {
			$r[] = "slug کوتاه (حداکثر {$s['slug_max_words']} کلمه) با خط تیره.";
		}
		if ( $s['tags_max'] > 0 ) {
			$r[] = "حداکثر {$s['tags_max']} برچسب مرتبط در tags.";
		}
		if ( $s['excerpt_enabled'] ) {
			$r[] = 'excerpt خلاصه ۲ جمله‌ای جذاب مقاله باشد.';
		}
		if ( ! empty( $s['custom_instructions'] ) ) {
			$r[] = 'دستورالعمل اختصاصی: ' . $s['custom_instructions'];
		}
		if ( ! empty( $topic['notes'] ) ) {
			$r[] = 'توضیحات اختصاصی این موضوع: ' . $topic['notes'];
		}
		return $r;
	}

	public static function output_schema() {
		return <<<'SCHEMA'
خروجی را فقط و فقط به‌صورت یک شیء JSON معتبر (بدون متن اضافه، بدون ```) با این کلیدها برگردان:
{
  "title": "عنوان H1 جذاب مقاله",
  "seo_title": "عنوان سئو",
  "meta_description": "توضیحات متا",
  "slug": "url-slug",
  "focus_keyword": "کلمه کلیدی اصلی",
  "secondary_keywords": ["..."],
  "tags": ["..."],
  "category": "نام یکی از دسته‌های موجود یا خالی",
  "excerpt": "خلاصه",
  "content_html": "<p>...</p><h2>...</h2>...",
  "faq": [{"question": "...", "answer": "..."}],
  "image_prompt": "a detailed English prompt for a featured image, no text",
  "image_alt": "متن جایگزین تصویر شامل کلمه کلیدی"
}
SCHEMA;
	}

	/**
	 * Build full job prompts for a topic.
	 */
	public static function build( array $topic, array $context = array() ) {
		$s      = AAW_Settings::all();
		$master = ( trim( $s['system_prompt'] ) && ! self::is_legacy_default( $s['system_prompt'] ) ) ? $s['system_prompt'] : self::default_prompt();
		// Stable prefix first (learned SEO playbook) so providers can cache it between articles.
		$system = AAW_Knowledge::prompt_block() . self::replace_vars( $master, $topic );
		$system .= "\n\n## قوانین ساختاری و سئو\n- " . implode( "\n- ", self::rules( $topic ) );

		if ( ! empty( $context['categories'] ) && 'ai_pick' === $s['category_mode'] && empty( $topic['category_id'] ) ) {
			$system .= "\n\n## دسته‌بندی‌های موجود سایت\nمناسب‌ترین را در category برگردان: " . implode( '، ', $context['categories'] );
		}
		if ( ! empty( $context['links'] ) && in_array( $s['internal_links_mode'], array( 'ai', 'both' ), true ) && $s['internal_links_count'] > 0 ) {
			$system .= "\n\n## لینک‌سازی داخلی\nدر صورت ارتباط معنایی، {$s['internal_links_count']} لینک داخلی با انکر تکست طبیعی به این صفحات موجود بساز (فقط از همین آدرس‌ها استفاده کن و آدرس جعلی نساز):\n";
			foreach ( $context['links'] as $l ) {
				$system .= '- ' . $l['title'] . ' => ' . $l['url'] . "\n";
			}
		}
		if ( ! empty( $topic['title'] ) ) {
			$system .= AAW_Products::prompt_block( $topic['title'], (string) ( $topic['keywords'] ?? '' ) );
		}
		if ( $s['duplicate_check'] && ! empty( $topic['title'] ) ) {
			$dup_block = AAW_Dedupe::prompt_block( $topic['title'], (string) ( $topic['keywords'] ?? '' ) );
			if ( $dup_block ) {
				$system .= "\n\n" . $dup_block;
			}
		}
		$system .= "\n\n## فرمت خروجی\n" . self::output_schema();

		$kw   = ! empty( $topic['keywords'] ) ? "\nکلمات کلیدی هدف: " . $topic['keywords'] : "\nکلمه کلیدی اصلی را خودت بر اساس بیشترین حجم جستجوی محتمل انتخاب کن.";
		$user = 'موضوع مقاله: ' . $topic['title'] . $kw . "\n\nمقاله کامل را طبق همه قوانین بنویس و فقط JSON برگردان.";

		$outline = '';
		if ( $s['two_pass'] ) {
			$outline = 'برای موضوع «' . $topic['title'] . '»' . $kw . "\nابتدا نیت جستجو و رقبا را تحلیل کن و یک طرح کلی (Outline) بسیار دقیق و سئو‌شده بساز. فقط JSON برگردان با کلیدهای: {\"focus_keyword\":\"\",\"search_intent\":\"\",\"title\":\"\",\"outline\":[{\"h2\":\"\",\"h3\":[\"\"],\"points\":[\"\"]}],\"faq_questions\":[\"\"],\"lsi\":[\"\"]}";
		}

		return array(
			'system'  => $system,
			'user'    => $user,
			'outline' => $outline,
		);
	}

	/** Prompt to generate new topic ideas when the queue is empty. */
	public static function topic_ideas_prompt( $count, array $existing_titles ) {
		$s   = AAW_Settings::all();
		$txt = "تو استراتژیست محتوای سئو برای سایت «{$s['site_name']}» در حوزه «" . ( $s['niche'] ? $s['niche'] : get_bloginfo( 'description' ) ) . "» هستی. مخاطب: {$s['audience']}.\n";
		$txt .= "{$count} موضوع مقاله جدید، پرجستجو و با پتانسیل رتبه‌گیری پیشنهاد بده که با مقالات موجود تکراری نباشد. زبان: " . ( self::languages()[ $s['language'] ] ?? 'فارسی' ) . ".\n";
		if ( $existing_titles ) {
			$txt .= "مقالات موجود سایت با کلمه کلیدی آن‌ها (هیچ موضوعی که همین نیت جستجو یا همین کلمه کلیدی اصلی را هدف بگیرد پیشنهاد نده؛ فقط شکاف‌های واقعی):\n- " . implode( "\n- ", array_slice( $existing_titles, 0, 150 ) ) . "\n";
		}
		global $wpdb;
		$queued = $wpdb->get_col( 'SELECT title FROM ' . AAW_Topics::table() . " WHERE status IN ('pending','processing','paused') ORDER BY id DESC LIMIT 60" ); // phpcs:ignore
		if ( $queued ) {
			$txt .= "موضوعات در صف تولید (این‌ها هم تکرار نشوند):\n- " . implode( "\n- ", $queued ) . "\n";
		}
		$txt .= 'فقط JSON برگردان: {"topics":[{"title":"","keywords":["",""]}]}';
		return $txt;
	}
}
