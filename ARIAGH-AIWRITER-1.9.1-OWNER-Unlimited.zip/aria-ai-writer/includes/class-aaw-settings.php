<?php
/**
 * Settings store with schema-driven sanitization.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Settings {

	const OPTION        = 'aaw_settings';
	const SECURE_OPTION = 'aaw_secure';

	private static $cache = null;

	/**
	 * Schema: key => array( type, default, [choices] ).
	 */
	public static function schema() {
		return array(
			// General.
			'enabled'                 => array( 'bool', true ),
			'site_name'               => array( 'text', '' ),
			'niche'                   => array( 'textarea', '' ),
			'audience'                => array( 'text', 'کاربران علاقه‌مند و خریداران احتمالی' ),
			'brand_name'              => array( 'text', '' ),
			'brand_description'       => array( 'textarea', '' ),
			'brand_mention'           => array( 'bool', true ),
			'language'                => array( 'select', 'fa', array( 'fa', 'en', 'ar', 'tr', 'de', 'fr', 'es', 'ru', 'ur', 'ps' ) ),

			// Content.
			'tone'                    => array( 'select', 'professional', array( 'professional', 'friendly', 'formal', 'conversational', 'educational', 'persuasive', 'journalistic', 'storytelling', 'technical', 'inspirational' ) ),
			'reading_level'           => array( 'select', 'intermediate', array( 'simple', 'intermediate', 'expert' ) ),
			'pov'                     => array( 'select', 'we', array( 'we', 'you', 'neutral' ) ),
			'word_count_min'          => array( 'int', 1500, array( 300, 10000 ) ),
			'word_count_max'          => array( 'int', 2200, array( 400, 12000 ) ),
			'h2_count'                => array( 'int', 6, array( 2, 20 ) ),
			'use_h3'                  => array( 'bool', true ),
			'paragraph_max_sentences' => array( 'int', 4, array( 2, 10 ) ),
			'include_intro_hook'      => array( 'bool', true ),
			'include_toc'             => array( 'bool', true ),
			'include_key_takeaways'   => array( 'bool', true ),
			'include_table'           => array( 'bool', true ),
			'include_faq'             => array( 'bool', true ),
			'faq_count'               => array( 'int', 5, array( 2, 12 ) ),
			'include_conclusion'      => array( 'bool', true ),
			'include_cta'             => array( 'bool', true ),
			'cta_text'                => array( 'textarea', '' ),
			'include_stats'           => array( 'bool', true ),
			'include_examples'        => array( 'bool', true ),
			'include_lists'           => array( 'bool', true ),
			'include_pros_cons'       => array( 'bool', false ),
			'include_glossary'        => array( 'bool', false ),
			'include_quote'           => array( 'bool', false ),
			'include_howto_steps'     => array( 'bool', false ),
			'include_mistakes'        => array( 'bool', true ),
			'include_checklist'       => array( 'bool', false ),
			'bold_keywords'           => array( 'bool', true ),
			'keyword_density'         => array( 'float', 1.2, array( 0.3, 3 ) ),
			'lsi_count'               => array( 'int', 8, array( 0, 30 ) ),
			'forbidden_words'         => array( 'list', array() ),
			'avoid_cliches'           => array( 'bool', true ),
			'no_emoji'                => array( 'bool', true ),
			'custom_instructions'     => array( 'textarea', '' ),
			'fix_persian_typography'  => array( 'bool', true ),
			'persian_digits'          => array( 'bool', false ),
			'convert_arabic_chars'    => array( 'bool', true ),
			'remove_h1'               => array( 'bool', true ),
			'min_quality_words'       => array( 'int', 500, array( 0, 5000 ) ),

			// SEO.
			'seo_plugin'              => array( 'select', 'auto', array( 'auto', 'yoast', 'rankmath', 'aioseo', 'seopress', 'none' ) ),
			'seo_title_max'           => array( 'int', 60, array( 30, 90 ) ),
			'meta_desc_max'           => array( 'int', 155, array( 80, 320 ) ),
			'slug_mode'               => array( 'select', 'ai_english', array( 'ai_english', 'persian', 'title' ) ),
			'slug_max_words'          => array( 'int', 6, array( 2, 15 ) ),
			'faq_schema'              => array( 'bool', true ),
			'article_schema'          => array( 'bool', false ),
			'internal_links_count'    => array( 'int', 3, array( 0, 15 ) ),
			'internal_links_pool'     => array( 'int', 150, array( 10, 1000 ) ),
			'internal_links_mode'     => array( 'select', 'ai', array( 'ai', 'auto', 'both', 'off' ) ),
			'external_links_nofollow' => array( 'bool', true ),
			'external_links_blank'    => array( 'bool', true ),
			'tags_max'                => array( 'int', 6, array( 0, 20 ) ),
			'create_tags'             => array( 'bool', true ),
			'category_mode'           => array( 'select', 'ai_pick', array( 'fixed', 'ai_pick', 'topic' ) ),
			'default_category'        => array( 'int', 0, array( 0, PHP_INT_MAX ) ),
			'image_alt_keyword'       => array( 'bool', true ),
			'toc_title'               => array( 'text', 'فهرست مطالب' ),
			'toc_min_headings'        => array( 'int', 3, array( 1, 20 ) ),
			'toc_collapsible'         => array( 'bool', true ),
			'toc_numbered'            => array( 'bool', true ),
			'duplicate_check'         => array( 'bool', true ),
			'duplicate_threshold'     => array( 'int', 75, array( 50, 100 ) ),

			// Publishing.
			'post_type'               => array( 'text', 'post' ),
			'post_status'             => array( 'select', 'draft', array( 'draft', 'pending', 'future', 'publish' ) ),
			'future_days'             => array( 'int', 1, array( 0, 60 ) ),
			'author_id'               => array( 'int', 0, array( 0, PHP_INT_MAX ) ),
			'comment_status'          => array( 'select', 'open', array( 'open', 'closed' ) ),
			'post_format'             => array( 'select', 'standard', array( 'standard', 'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat' ) ),
			'excerpt_enabled'         => array( 'bool', true ),

			// Images.
			'featured_image'          => array( 'bool', true ),
			'image_provider'          => array( 'select', 'workers_ai', array( 'workers_ai', 'openai' ) ),
			'image_model'             => array( 'text', '@cf/black-forest-labs/flux-1-schnell' ),
			'image_openai_model'      => array( 'text', 'gpt-image-1' ),
			'image_size'              => array( 'select', '1536x1024', array( '1024x1024', '1536x1024', '1024x1536' ) ),
			'image_style'             => array( 'text', 'photorealistic editorial photo, soft natural light, clean modern composition, no text, no watermark' ),
			'image_engine'            => array( 'select', 'workers_ai', array( 'workers_ai', 'openai', 'gemini', 'higgsfield', 'fal', 'custom', 'sub_codex' ) ),
			'image_engine_model'      => array( 'text', '' ),
			'image_custom_url'        => array( 'text', '' ),
			'image_inline_count'      => array( 'int', 0, array( 0, 4 ) ),
			'image_product_refs'      => array( 'int', 3, array( 0, 8 ) ),
			'image_style_refs'        => array( 'int', 2, array( 0, 4 ) ),
			'image_max_refs'          => array( 'int', 6, array( 0, 16 ) ),
			'image_style_ids'         => array( 'text', '' ),
			'image_use_theme'         => array( 'bool', true ),
			'image_brand_colors'      => array( 'text', '' ),
			'image_ref_transport'     => array( 'select', 'auto', array( 'auto', 'url', 'inline' ) ),
			'product_links'           => array( 'bool', true ),
			'product_links_count'     => array( 'int', 3, array( 1, 8 ) ),
			'product_box'             => array( 'bool', true ),
			'product_box_title'       => array( 'text', 'محصولات پیشنهادی ما' ),
			'site_source'             => array( 'select', 'auto', array( 'auto', 'local' ) ),
			'gsc_site'                => array( 'text', '' ),
			'gsc_client_id'           => array( 'text', '' ),
			'local_route_claude'      => array( 'select', 'github', array( 'github', 'local' ) ),
			'local_route_codex'       => array( 'select', 'github', array( 'github', 'local' ) ),
			'local_node_path'         => array( 'text', '' ),
			'local_bin_claude'        => array( 'text', '' ),
			'local_bin_codex'         => array( 'text', '' ),
			'local_timeout'           => array( 'int', 20, array( 5, 60 ) ),
			'image_product_ids'       => array( 'text', '' ),
			'image_chat_prompt'       => array( 'textarea', '' ),
			'seo_learn'               => array( 'bool', true ),
			'seo_learn_days'          => array( 'int', 30, array( 7, 180 ) ),
			'seo_sources'             => array( 'textarea', "https://developers.google.com/search/docs/fundamentals/creating-helpful-content\nhttps://developers.google.com/search/docs/fundamentals/seo-starter-guide\nhttps://developers.google.com/search/docs/essentials/spam-policies\nhttps://developers.google.com/search/docs/appearance/ai-features\nhttps://developers.google.com/search/updates/ranking\nhttps://developers.google.com/search/docs/appearance/structured-data/search-gallery\nhttps://moz.com/learn/seo/on-page-factors\nhttps://backlinko.com/hub/seo\nhttps://websima.academy/seo-tutorials/\nhttps://seoedu.ir/seo-learning/\nhttps://safine.net/whatis-seo/google-algorithms/\nhttps://tabaneshahr.com/%D8%A7%D9%84%DA%AF%D9%88%D8%B1%DB%8C%D8%AA%D9%85-%D9%87%D8%A7%DB%8C-%DA%AF%D9%88%DA%AF%D9%84/" ),

			// AI.
			'provider'                => array( 'text', 'openai' ),
			'model'                   => array( 'text', '' ),
			'fallbacks'               => array( 'list', array() ),
			'image_fallbacks'         => array( 'list', array() ),
			'image_free_fallback'     => array( 'bool', true ),
			'image_models'            => array( 'map', array() ),
			'temperature'             => array( 'float', 0.7, array( 0, 2 ) ),
			'max_tokens'              => array( 'int', 8000, array( 500, 64000 ) ),
			'top_p'                   => array( 'float', 1, array( 0, 1 ) ),
			'two_pass'                => array( 'bool', true ),
			'json_mode'               => array( 'bool', true ),
			'request_timeout'         => array( 'int', 180, array( 20, 600 ) ),
			'retries'                 => array( 'int', 2, array( 0, 5 ) ),
			'system_prompt'           => array( 'textarea_raw', '' ),
			'prompt_preset'           => array( 'text', 'pro' ),
			'provider_models'         => array( 'map', array() ),

			// Schedule.
			'cron_mode'               => array( 'select', 'interval', array( 'interval', 'custom' ) ),
			'interval_hours'          => array( 'int', 12, array( 1, 168 ) ),
			'run_minute'              => array( 'int', 0, array( 0, 59 ) ),
			'custom_cron'             => array( 'textarea', '' ),
			'posts_per_run'           => array( 'int', 1, array( 1, 5 ) ),
			'auto_topics'             => array( 'bool', true ),
			'auto_topics_count'       => array( 'int', 5, array( 1, 30 ) ),
			'retry_failed'            => array( 'bool', true ),
			'max_attempts'            => array( 'int', 3, array( 1, 10 ) ),
			'paused'                  => array( 'bool', false ),
			'daily_limit'             => array( 'int', 0, array( 0, 100 ) ),

			// Cloudflare (non-secret).
			'cf_account_id'           => array( 'text', '' ),
			'worker_name'             => array( 'slug', 'aria-ai-writer' ),
			'kv_namespace_id'         => array( 'text', '' ),
			'worker_url'              => array( 'text', '' ),
			'worker_custom_url'       => array( 'text', '' ),
			'wp_api_override'         => array( 'text', '' ),
			'connection_mode'         => array( 'select', 'push', array( 'auto', 'push', 'pull' ) ),
			'runner_name'             => array( 'slug', 'aria-claude-pro' ),
			'gh_owner'                => array( 'text', '' ),
			'gh_repo'                 => array( 'slug', 'aria-ai-runner' ),
			'gh_branch'               => array( 'text', '' ),
			'gh_connected_at'         => array( 'int', 0, array( 0, PHP_INT_MAX ) ),
			'gh_files_version'        => array( 'text', '' ),
			'claude_pro_enabled'      => array( 'bool', false ),
			'claude_pro_fallback'     => array( 'select', 'haiku', array( '', 'sonnet', 'haiku', 'opus' ) ),
			'deployed_at'             => array( 'int', 0, array( 0, PHP_INT_MAX ) ),
			'deployed_version'        => array( 'text', '' ),
			'worker_bg'               => array( 'bool', false ),
			'net_part_kb'             => array( 'int', 32, array( 8, 512 ) ),
			'net_relay'               => array( 'select', 'auto', array( 'auto', 'direct' ) ),
			'bg_migrated'             => array( 'text', '' ),
			'bind_workers_ai'         => array( 'bool', true ),
			'kv_sync'                 => array( 'bool', true ),

			// Notifications.
			'notify_email'            => array( 'bool', false ),
			'notify_email_to'         => array( 'text', '' ),
			'notify_on_fail'          => array( 'bool', true ),
			'telegram_enabled'        => array( 'bool', false ),
			'telegram_chat'           => array( 'text', '' ),
			'webhook_url'             => array( 'text', '' ),
			'dashboard_widget'        => array( 'bool', true ),
			'admin_bar'               => array( 'bool', true ),
			'posts_column'            => array( 'bool', true ),

			// Advanced.
			'debug'                   => array( 'bool', false ),
			'log_retention_days'      => array( 'int', 60, array( 1, 3650 ) ),
			'delete_on_uninstall'     => array( 'bool', false ),
			'allow_editors'           => array( 'bool', false ),
			'allow_shop_managers'     => array( 'bool', true ),
			'load_font'               => array( 'bool', true ),
			'frontend_css'            => array( 'bool', true ),
			'toc_accent'              => array( 'text', '#4f46e5' ),
			'rest_ip_allow'           => array( 'list', array() ),
		);
	}

	public static function defaults() {
		$out = array();
		foreach ( self::schema() as $key => $def ) {
			$out[ $key ] = $def[1];
		}
		$out['site_name']     = get_bloginfo( 'name' );
		$out['system_prompt'] = AAW_Prompt::default_prompt();
		return $out;
	}

	public static function all() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION, array() );
			self::$cache = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		}
		return self::$cache;
	}

	public static function get( $key, $fallback = null ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}

	/** Override a value for the current request only (e.g. previews). */
	public static function set_runtime( $key, $value ) {
		self::all();
		self::$cache[ $key ] = $value;
	}

	public static function sanitize_value( $key, $value ) {
		$schema = self::schema();
		if ( ! isset( $schema[ $key ] ) ) {
			return null;
		}
		$def  = $schema[ $key ];
		$type = $def[0];
		switch ( $type ) {
			case 'bool':
				return ( true === $value || 1 === $value || '1' === $value || 'true' === $value || 'on' === $value || 'yes' === $value );
			case 'int':
				$v = (int) $value;
				if ( isset( $def[2] ) ) {
					$v = max( $def[2][0], min( $def[2][1], $v ) );
				}
				return $v;
			case 'float':
				$v = (float) $value;
				if ( isset( $def[2] ) ) {
					$v = max( $def[2][0], min( $def[2][1], $v ) );
				}
				return round( $v, 3 );
			case 'select':
				$value = (string) $value;
				return in_array( $value, $def[2], true ) ? $value : $def[1];
			case 'slug':
				$v = sanitize_title( (string) $value );
				return '' === $v ? $def[1] : substr( $v, 0, 60 );
			case 'textarea':
				return sanitize_textarea_field( (string) $value );
			case 'textarea_raw':
				// Prompts may contain < > characters; strip tags-only scripting but keep text.
				return trim( wp_check_invalid_utf8( (string) wp_unslash( $value ) ) );
			case 'list':
				if ( is_string( $value ) ) {
					$value = preg_split( '/[\r\n,،]+/u', $value );
				}
				$value = is_array( $value ) ? $value : array();
				$value = array_map( 'sanitize_text_field', array_map( 'strval', $value ) );
				return array_values( array_filter( array_unique( array_map( 'trim', $value ) ), 'strlen' ) );
			case 'map':
				$out = array();
				if ( is_array( $value ) ) {
					foreach ( $value as $k => $v ) {
						$out[ sanitize_key( $k ) ] = sanitize_text_field( (string) $v );
					}
				}
				return $out;
			case 'text':
			default:
				return sanitize_text_field( (string) $value );
		}
	}

	/**
	 * Update a subset of settings. Unknown keys are ignored.
	 */
	public static function update( array $values ) {
		$current = self::all();
		foreach ( $values as $key => $value ) {
			$clean = self::sanitize_value( $key, $value );
			if ( null !== $clean ) {
				$current[ $key ] = $clean;
			}
		}
		if ( $current['word_count_max'] < $current['word_count_min'] ) {
			$current['word_count_max'] = $current['word_count_min'] + 300;
		}
		update_option( self::OPTION, $current, false );
		self::$cache = $current;
		do_action( 'aaw_settings_updated', $current );
		return $current;
	}

	public static function reset() {
		delete_option( self::OPTION );
		self::$cache = null;
		return self::all();
	}

	/* ---------------- Secure values (encrypted, never exported) ---------------- */

	public static function secure_get( $key ) {
		$all = get_option( self::SECURE_OPTION, array() );
		return isset( $all[ $key ] ) ? AAW_Crypto::decrypt( $all[ $key ] ) : '';
	}

	public static function secure_set( $key, $value ) {
		$all = get_option( self::SECURE_OPTION, array() );
		if ( ! is_array( $all ) ) {
			$all = array();
		}
		if ( '' === (string) $value ) {
			unset( $all[ $key ] );
		} else {
			$all[ $key ] = AAW_Crypto::encrypt( $value );
		}
		update_option( self::SECURE_OPTION, $all, false );
	}

	/** Shared HMAC secret between WordPress and the Worker. */
	public static function shared_secret() {
		$s = self::secure_get( 'shared_secret' );
		if ( '' === $s ) {
			$s = AAW_Crypto::random_secret( 32 );
			self::secure_set( 'shared_secret', $s );
		}
		return $s;
	}

	/* ---------------- Custom providers & key metadata ---------------- */

	public static function custom_providers() {
		$list = get_option( 'aaw_custom_providers', array() );
		return is_array( $list ) ? $list : array();
	}

	public static function save_custom_providers( array $list ) {
		update_option( 'aaw_custom_providers', array_values( $list ), false );
	}

	/** Metadata about secrets stored in Cloudflare (mask + time), never the value. */
	public static function key_meta() {
		$m = get_option( 'aaw_key_meta', array() );
		return is_array( $m ) ? $m : array();
	}

	public static function set_key_meta( $provider_id, $mask ) {
		$m = self::key_meta();
		if ( null === $mask ) {
			unset( $m[ $provider_id ] );
		} else {
			$m[ $provider_id ] = array(
				'mask' => $mask,
				'time' => time(),
			);
		}
		update_option( 'aaw_key_meta', $m, false );
	}

	/** Export settings (safe – no secrets). */
	public static function export() {
		return array(
			'plugin'           => 'aria-ai-writer',
			'version'          => AAW_VERSION,
			'exported_at'      => gmdate( 'c' ),
			'settings'         => self::all(),
			'custom_providers' => self::custom_providers(),
		);
	}

	public static function import( $data ) {
		if ( ! is_array( $data ) || empty( $data['settings'] ) || ! is_array( $data['settings'] ) ) {
			return new WP_Error( 'aaw_import', 'فایل تنظیمات نامعتبر است.' );
		}
		$settings = $data['settings'];
		// Never import deployment-specific identifiers blindly.
		unset( $settings['deployed_at'], $settings['deployed_version'], $settings['worker_bg'], $settings['bg_migrated'] );
		self::update( $settings );
		if ( ! empty( $data['custom_providers'] ) && is_array( $data['custom_providers'] ) ) {
			$clean = array();
			foreach ( $data['custom_providers'] as $cp ) {
				$c = AAW_Providers::sanitize_custom( $cp );
				if ( $c ) {
					$clean[] = $c;
				}
			}
			self::save_custom_providers( $clean );
		}
		return true;
	}
}
