<?php
/**
 * Priority lists for the two main engines:
 *  - text  : provider + fallbacks (any API provider, subscription accounts, Workers AI)
 *  - image : image_engine + image_fallbacks (Workers AI, image APIs, ChatGPT subscription)
 *
 * The same subscription account can be switched on in one list and off in the other,
 * e.g. Claude for articles only and ChatGPT for images only.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Priority {

	const SUBS = array( 'sub_claude', 'sub_codex' );

	/* --------------------------------------------------------------- text */

	public static function text_chain() {
		$s   = AAW_Settings::all();
		$ids = array_values( array_unique( array_merge( array( (string) $s['provider'] ), (array) $s['fallbacks'] ) ) );
		return array_values( array_filter( $ids, function ( $id ) {
			return '' !== $id && null !== AAW_Providers::get( $id );
		} ) );
	}

	/** @return array{0:bool,1:string} ready + human note */
	public static function text_ready( $id ) {
		$p = AAW_Providers::get( $id );
		if ( ! $p ) {
			return array( false, 'نامعتبر' );
		}
		$meta = AAW_Settings::key_meta();
		if ( 'github_runner' === $p['format'] && class_exists( 'AAW_Local' ) && AAW_Local::is_local( $id ) ) {
			$e = AAW_Local::engine_of( $id );
			if ( '' === AAW_Local::binary( $e ) ) {
				return array( false, 'روی سرور نصب نشده (تب موتور هوش مصنوعی روی سرور)' );
			}
			return AAW_Local::has_login( $e ) ? array( true, 'مستقیم روی همین سرور' ) : array( false, 'ورود روی سرور انجام نشده' );
		}
		if ( 'github_runner' === $p['format'] ) {
			if ( ! AAW_GitHub::is_connected() ) {
				return array( false, 'GitHub وصل نیست (تب اکانت اشتراکی)' );
			}
			return isset( $meta[ $id ] ) ? array( true, 'اکانت وصل است' ) : array( false, 'اکانت وصل نشده (تب اکانت اشتراکی)' );
		}
		if ( empty( $p['requires_key'] ) ) {
			return array( true, 'بدون کلید' );
		}
		return isset( $meta[ $id ] ) ? array( true, 'کلید ثبت شده' ) : array( false, 'کلید ثبت نشده' );
	}

	public static function text_kind( $id ) {
		$p = AAW_Providers::get( $id );
		if ( ! $p ) {
			return 'api';
		}
		if ( in_array( $p['format'], array( 'github_runner', 'claude_code' ), true ) ) {
			return 'sub';
		}
		if ( 'workers_ai' === $id ) {
			return 'free';
		}
		return ! empty( $p['custom'] ) ? 'custom' : 'api';
	}

	public static function text_items() {
		$chain = self::text_chain();
		$items = array();
		foreach ( AAW_Providers::all() as $id => $p ) {
			list( $ready, $note ) = self::text_ready( $id );
			$rank                = array_search( $id, $chain, true );
			$items[]             = array(
				'id'     => $id,
				'name'   => $p['name'],
				'kind'   => self::text_kind( $id ),
				'color'  => $p['color'] ?? '#475569',
				'ready'  => $ready,
				'note'   => $note,
				'on'     => false !== $rank,
				'rank'   => false === $rank ? 999 : (int) $rank,
				'model'  => AAW_Providers::model_for( $id ),
				'models' => array_values( (array) $p['models'] ),
				'link'   => 'github_runner' === $p['format'] || 'claude_code' === $p['format'] ? admin_url( 'admin.php?page=aaw&tab=subscription' ) : '',
			);
		}
		return self::sort_items( $items );
	}

	public static function save_text( array $order, array $models = array() ) {
		$ids = array();
		foreach ( $order as $id ) {
			$id = sanitize_key( (string) $id );
			if ( '' === $id || in_array( $id, $ids, true ) ) {
				continue;
			}
			if ( ! AAW_Providers::get( $id ) ) {
				return new WP_Error( 'aaw', 'هوش مصنوعی نامعتبر: ' . $id );
			}
			list( $ready, $note ) = self::text_ready( $id );
			if ( ! $ready ) {
				$p = AAW_Providers::get( $id );
				return new WP_Error( 'aaw', '«' . $p['name'] . '» آماده نیست: ' . $note . '. ابتدا آن را وصل کنید یا خاموش بگذارید.' );
			}
			$ids[] = $id;
		}
		if ( ! $ids ) {
			return new WP_Error( 'aaw', 'حداقل یک هوش مصنوعی برای تولید محتوا روشن بگذارید.' );
		}
		$map = (array) AAW_Settings::get( 'provider_models', array() );
		foreach ( $models as $id => $m ) {
			$id = sanitize_key( (string) $id );
			if ( AAW_Providers::get( $id ) ) {
				$map[ $id ] = sanitize_text_field( (string) $m );
			}
		}
		$primary = array_shift( $ids );
		AAW_Settings::update(
			array(
				'provider'        => $primary,
				'fallbacks'       => $ids,
				'provider_models' => $map,
				'model'           => ! empty( $map[ $primary ] ) ? $map[ $primary ] : AAW_Providers::model_for( $primary ),
			)
		);
		return array_merge( array( $primary ), $ids );
	}

	/* -------------------------------------------------------------- image */

	public static function image_chain() {
		$engines = AAW_Images::engines();
		$ids     = array_merge( array( AAW_Images::engine() ), (array) AAW_Settings::get( 'image_fallbacks', array() ) );
		$ids     = array_values( array_unique( $ids ) );
		return array_values( array_filter( $ids, function ( $id ) use ( $engines ) {
			return isset( $engines[ $id ] );
		} ) );
	}

	public static function image_ready( $id ) {
		$engines = AAW_Images::engines();
		if ( ! isset( $engines[ $id ] ) ) {
			return array( false, 'نامعتبر' );
		}
		$e    = $engines[ $id ];
		$meta = AAW_Settings::key_meta();
		if ( 'sub_codex' === $id && class_exists( 'AAW_Local' ) && AAW_Local::is_local( 'codex' ) ) {
			if ( '' === AAW_Local::binary( 'codex' ) ) {
				return array( false, 'Codex روی سرور نصب نشده' );
			}
			return AAW_Local::has_login( 'codex' ) ? array( true, 'مستقیم روی همین سرور' ) : array( false, 'ورود ChatGPT روی سرور انجام نشده' );
		}
		if ( 'sub_codex' === $id ) {
			if ( ! AAW_GitHub::is_connected() ) {
				return array( false, 'GitHub وصل نیست (تب اکانت اشتراکی)' );
			}
			return isset( $meta['sub_codex'] ) ? array( true, 'ChatGPT وصل است' ) : array( false, 'ChatGPT وصل نشده (تب اکانت اشتراکی)' );
		}
		if ( '' === $e['secret'] ) {
			return array( true, 'بدون کلید' );
		}
		if ( 'custom' === $id && '' === trim( (string) AAW_Settings::get( 'image_custom_url' ) ) ) {
			return array( false, 'Base URL وارد نشده' );
		}
		$meta_id = in_array( $id, array( 'openai', 'gemini' ), true ) ? $id : 'img_' . $id;
		return isset( $meta[ $meta_id ] ) ? array( true, 'کلید ثبت شده' ) : array( false, 'کلید ثبت نشده' );
	}

	public static function image_items() {
		$chain = self::image_chain();
		$items = array();
		foreach ( AAW_Images::engines() as $id => $e ) {
			list( $ready, $note ) = self::image_ready( $id );
			$rank                = array_search( $id, $chain, true );
			$items[]             = array(
				'id'     => $id,
				'name'   => $e['name'],
				'kind'   => 'sub_codex' === $id ? 'sub' : ( 'workers_ai' === $id ? 'free' : ( 'custom' === $id ? 'custom' : 'api' ) ),
				'color'  => array( 'workers_ai' => '#f38020', 'openai' => '#10a37f', 'gemini' => '#4285f4', 'higgsfield' => '#111827', 'fal' => '#7c3aed', 'sub_codex' => '#10a37f', 'custom' => '#475569' )[ $id ] ?? '#475569',
				'ready'  => $ready,
				'note'   => $note,
				'on'     => false !== $rank,
				'rank'   => false === $rank ? 999 : (int) $rank,
				'model'  => 'sub_codex' === $id ? '' : AAW_Images::model( $id ),
				'models' => array_keys( (array) $e['models'] ),
				'refs'   => (int) $e['refs'],
				'link'   => 'sub_codex' === $id ? admin_url( 'admin.php?page=aaw&tab=subscription' ) : '',
			);
		}
		return self::sort_items( $items );
	}

	public static function save_image( array $order, array $models = array() ) {
		$engines = AAW_Images::engines();
		$ids     = array();
		foreach ( $order as $id ) {
			$id = sanitize_key( (string) $id );
			if ( '' === $id || in_array( $id, $ids, true ) ) {
				continue;
			}
			if ( ! isset( $engines[ $id ] ) ) {
				return new WP_Error( 'aaw', 'موتور تصویر نامعتبر: ' . $id );
			}
			list( $ready, $note ) = self::image_ready( $id );
			if ( ! $ready ) {
				return new WP_Error( 'aaw', '«' . $engines[ $id ]['name'] . '» آماده نیست: ' . $note . '. ابتدا آن را وصل کنید یا خاموش بگذارید.' );
			}
			$ids[] = $id;
		}
		if ( ! $ids ) {
			return new WP_Error( 'aaw', 'حداقل یک موتور تصویر روشن بگذارید (یا «تولید تصویر برای مقالات» را خاموش کنید).' );
		}
		$map = (array) AAW_Settings::get( 'image_models', array() );
		$upd = array();
		foreach ( $models as $id => $m ) {
			$id = sanitize_key( (string) $id );
			if ( ! isset( $engines[ $id ] ) || 'sub_codex' === $id ) {
				continue;
			}
			$m          = sanitize_text_field( (string) $m );
			$map[ $id ] = $m;
			if ( 'workers_ai' === $id && $m && isset( $engines['workers_ai']['models'][ $m ] ) ) {
				$upd['image_model'] = $m;
			}
			if ( 'openai' === $id && $m ) {
				$upd['image_openai_model'] = $m;
			}
		}
		$primary = array_shift( $ids );
		AAW_Settings::update(
			$upd + array(
				'image_engine'       => $primary,
				'image_fallbacks'    => $ids,
				'image_models'       => $map,
				'image_engine_model' => isset( $map[ $primary ] ) ? $map[ $primary ] : '',
			)
		);
		return array_merge( array( $primary ), $ids );
	}

	/* --------------------------------------------------------- shortcuts */

	/** Move an engine to the top of a list (switching it on). */
	public static function promote( $kind, $id ) {
		if ( 'image' === $kind ) {
			$chain = array_values( array_diff( self::image_chain(), array( $id ) ) );
			array_unshift( $chain, $id );
			return self::save_image( $chain );
		}
		$chain = array_values( array_diff( self::text_chain(), array( $id ) ) );
		array_unshift( $chain, $id );
		return self::save_text( $chain );
	}

	/** Where a subscription account is used: rank (1-based) in each list, 0 = off. */
	public static function roles( $id ) {
		$t = array_search( $id, self::text_chain(), true );
		$i = 'sub_codex' === $id ? array_search( 'sub_codex', self::image_chain(), true ) : false;
		return array(
			'text'  => false === $t ? 0 : $t + 1,
			'image' => false === $i ? 0 : $i + 1,
		);
	}

	/**
	 * Set the role of a subscription account from the subscription tab.
	 * Switching on keeps its current place, or adds it first.
	 */
	public static function set_role( $id, $text_on, $image_on ) {
		if ( ! in_array( $id, self::SUBS, true ) ) {
			return new WP_Error( 'aaw', 'اکانت نامعتبر' );
		}
		$text = self::text_chain();
		if ( $text_on && ! in_array( $id, $text, true ) ) {
			array_unshift( $text, $id );
		} elseif ( ! $text_on ) {
			$text = array_values( array_diff( $text, array( $id ) ) );
			if ( ! $text ) {
				$text = array( 'workers_ai' );
			}
		}
		$r = self::save_text( $text );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		if ( 'sub_codex' === $id ) {
			$img = self::image_chain();
			if ( $image_on && ! in_array( $id, $img, true ) ) {
				array_unshift( $img, $id );
			} elseif ( ! $image_on ) {
				$img = array_values( array_diff( $img, array( $id ) ) );
				if ( ! $img ) {
					$img = array( 'workers_ai' );
				}
			}
			$r = self::save_image( $img );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		return true;
	}

	/** Remove subscription accounts from both lists (GitHub disconnected). */
	public static function drop_subs() {
		$s    = AAW_Settings::all();
		$text = array_values( array_diff( self::text_chain(), self::SUBS ) );
		if ( ! $text ) {
			$text = array( 'workers_ai' );
		}
		$primary = array_shift( $text );
		$img     = array_values( array_diff( self::image_chain(), array( 'sub_codex' ) ) );
		if ( ! $img ) {
			$img = array( 'workers_ai' );
		}
		$ip = array_shift( $img );
		AAW_Settings::update(
			array(
				'provider'        => $primary,
				'fallbacks'       => $text,
				'model'           => AAW_Providers::model_for( $primary ),
				'image_engine'    => $ip,
				'image_fallbacks' => $img,
			)
		);
		unset( $s );
	}

	/* ------------------------------------------------------- failover */

	/**
	 * An article failed on Cloudflare (API providers). If a subscription account comes
	 * later in the content priority list, hand the topic to it once.
	 */
	public static function text_failover( $topic_id, array $meta ) {
		$topic_id = absint( $topic_id );
		if ( ! $topic_id || 'github' === ( $meta['runner'] ?? '' ) || 0 === strpos( (string) ( $meta['provider'] ?? '' ), 'sub_' ) ) {
			return false;
		}
		$chain = self::text_chain();
		$first = AAW_Providers::get( $chain[0] ?? '' );
		if ( $first && 'github_runner' === $first['format'] ) {
			return false; // The runner already walks the list itself.
		}
		$sub = '';
		foreach ( array_slice( $chain, 1 ) as $id ) {
			$p = AAW_Providers::get( $id );
			if ( $p && 'github_runner' === $p['format'] && self::text_ready( $id )[0] ) {
				$sub = $id;
				break;
			}
		}
		if ( ! $sub || get_transient( 'aaw_failover_' . $topic_id ) ) {
			return false;
		}
		set_transient( 'aaw_failover_' . $topic_id, 1, HOUR_IN_SECONDS );
		AAW_Topics::update( $topic_id, array( 'status' => 'pending' ) );
		$engine = AAW_Providers::get( $sub )['engine'];
		if ( AAW_Local::is_local( $engine ) ) {
			$d = AAW_Local::start_generate( 'manual', $topic_id, $engine );
		} elseif ( AAW_Pull::active() ) {
			$d = AAW_Pull::dispatch_subscription( 'manual', $topic_id, '', $engine );
			$d = 'dispatched' === ( $d['status'] ?? '' ) ? $d : new WP_Error( 'aaw', (string) ( $d['reason'] ?? 'dispatch failed' ) );
		} else {
			$d = AAW_GitHub::dispatch( 'manual', $topic_id, $engine );
		}
		if ( is_wp_error( $d ) ) {
			AAW_Logs::add( 'error', 'run', 'جایگزینی با اکانت اشتراکی شروع نشد: ' . $d->get_error_message(), array( 'topic_id' => $topic_id ) );
			return false;
		}
		AAW_Logs::add( 'info', 'run', 'هوش مصنوعی‌های API موفق نشدند؛ طبق اولویت، مقاله به اکانت اشتراکی ' . AAW_Providers::get( $sub )['name'] . ' سپرده شد.', array( 'topic_id' => $topic_id ) );
		return true;
	}

	/** API image engines failed: use the ChatGPT subscription if it is later in the image list. */
	public static function image_failover( $post_id, $prompt = '', $inline = false ) {
		$chain = self::image_chain();
		if ( ! $post_id || 'sub_codex' === ( $chain[0] ?? '' ) || ! in_array( 'sub_codex', $chain, true ) || ! self::image_ready( 'sub_codex' )[0] ) {
			return false;
		}
		if ( get_transient( 'aaw_imgfo_' . $post_id ) ) {
			return false;
		}
		set_transient( 'aaw_imgfo_' . $post_id, 1, 30 * MINUTE_IN_SECONDS );
		$r = AAW_Revise::request_image( $post_id, $prompt, $inline, 'sub_codex' );
		if ( is_wp_error( $r ) ) {
			AAW_Logs::add( 'error', 'image', 'جایگزینی تصویر با اکانت ChatGPT شروع نشد: ' . $r->get_error_message(), array( 'post_id' => $post_id ) );
			return false;
		}
		AAW_Logs::add( 'info', 'image', 'موتورهای تصویر API موفق نشدند؛ طبق اولویت، تصویر با اکانت ChatGPT ساخته می‌شود.', array( 'post_id' => $post_id ) );
		return true;
	}

	/* ------------------------------------------------------------ util */

	private static function sort_items( array $items ) {
		usort(
			$items,
			function ( $a, $b ) {
				if ( $a['on'] !== $b['on'] ) {
					return $a['on'] ? -1 : 1;
				}
				if ( $a['on'] ) {
					return $a['rank'] <=> $b['rank'];
				}
				if ( $a['ready'] !== $b['ready'] ) {
					return $a['ready'] ? -1 : 1;
				}
				$order = array( 'sub' => 0, 'free' => 1, 'api' => 2, 'custom' => 3 );
				return ( $order[ $a['kind'] ] ?? 9 ) <=> ( $order[ $b['kind'] ] ?? 9 );
			}
		);
		return $items;
	}

	/** Short label of the first engine of a list (for the navigation tiles). */
	public static function first_label( $kind ) {
		if ( 'image' === $kind ) {
			if ( ! AAW_Settings::get( 'featured_image' ) ) {
				return 'خاموش';
			}
			$c = self::image_chain();
			$e = AAW_Images::engines();
			$n = isset( $e[ $c[0] ?? '' ] ) ? $e[ $c[0] ]['name'] : '—';
		} else {
			$c = self::text_chain();
			$p = AAW_Providers::get( $c[0] ?? '' );
			$n = $p ? $p['name'] : '—';
		}
		$n = trim( preg_replace( '/\s*\(.*$/u', '', $n ) );
		return $n . ( count( $c ) > 1 ? ' +' . number_format_i18n( count( $c ) - 1 ) : '' );
	}
}
