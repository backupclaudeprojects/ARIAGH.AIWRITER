<?php
/**
 * Turns the AI JSON article into a fully optimized WordPress draft.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Post_Builder {

	/**
	 * Create the post.
	 *
	 * @param array $a     Article data from the worker.
	 * @param array $topic Topic row (may be empty for auto topics).
	 * @param array $meta  Run metadata (provider, model, tokens...).
	 * @return int|WP_Error
	 */
	public static function create( array $a, array $topic = array(), array $meta = array() ) {
		$s = AAW_Settings::all();

		$title = isset( $a['title'] ) ? sanitize_text_field( $a['title'] ) : '';
		$html  = isset( $a['content_html'] ) ? (string) $a['content_html'] : '';
		if ( '' === $title && ! empty( $topic['title'] ) ) {
			$title = $topic['title'];
		}
		if ( '' === trim( wp_strip_all_tags( $html ) ) ) {
			return new WP_Error( 'aaw_empty', 'هوش مصنوعی محتوای خالی برگرداند.' );
		}

		$html = self::process_html( $html, $a );
		$html = AAW_Products::ensure_links( $html, $title, (string) ( $a['focus_keyword'] ?? ( $topic['keywords'] ?? '' ) ) );
		$wc   = self::word_count( $html );
		if ( $s['min_quality_words'] > 0 && $wc < $s['min_quality_words'] ) {
			return new WP_Error( 'aaw_short', sprintf( 'مقاله تولیدشده کوتاه‌تر از حد مجاز است (%d کلمه).', $wc ) );
		}

		// FAQ block.
		$faq = array();
		if ( $s['include_faq'] && ! empty( $a['faq'] ) && is_array( $a['faq'] ) ) {
			foreach ( $a['faq'] as $f ) {
				$q = isset( $f['question'] ) ? sanitize_text_field( $f['question'] ) : ( isset( $f['q'] ) ? sanitize_text_field( $f['q'] ) : '' );
				$ans = isset( $f['answer'] ) ? wp_kses_post( $f['answer'] ) : ( isset( $f['a'] ) ? wp_kses_post( $f['a'] ) : '' );
				if ( $q && $ans ) {
					$faq[] = array( 'q' => self::typography( $q ), 'a' => self::typography( $ans ) );
				}
			}
			if ( $faq ) {
				$html .= self::faq_html( $faq );
			}
		}

		$status = $s['post_status'];
		$date   = null;
		if ( 'future' === $status ) {
			$date = gmdate( 'Y-m-d H:i:s', time() + max( 0, (int) $s['future_days'] ) * DAY_IN_SECONDS + HOUR_IN_SECONDS );
		}

		$author = (int) $s['author_id'];
		if ( ! $author || ! get_userdata( $author ) ) {
			$admins = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ID' ) );
			$author = $admins ? (int) $admins[0] : 1;
		}

		$post_type = post_type_exists( $s['post_type'] ) ? $s['post_type'] : 'post';

		$postarr = array(
			'post_title'     => self::typography( $title ),
			'post_content'   => $html,
			'post_status'    => $status,
			'post_type'      => $post_type,
			'post_author'    => $author,
			'post_name'      => self::slug( $a, $title ),
			'comment_status' => $s['comment_status'],
			'meta_input'     => array(
				'_aaw_generated'     => 1,
				'_aaw_topic_id'      => isset( $topic['id'] ) ? (int) $topic['id'] : 0,
				'_aaw_provider'      => isset( $meta['provider'] ) ? sanitize_text_field( $meta['provider'] ) : '',
				'_aaw_model'         => isset( $meta['model'] ) ? sanitize_text_field( $meta['model'] ) : '',
				'_aaw_focus_keyword' => isset( $a['focus_keyword'] ) ? sanitize_text_field( $a['focus_keyword'] ) : '',
				'_aaw_secondary'     => isset( $a['secondary_keywords'] ) ? implode( '، ', array_map( 'sanitize_text_field', (array) $a['secondary_keywords'] ) ) : '',
				'_aaw_tokens'        => (int) ( $meta['tokens_in'] ?? 0 ) + (int) ( $meta['tokens_out'] ?? 0 ),
				'_aaw_word_count'    => $wc,
				'_aaw_generated_at'  => time(),
			),
		);
		if ( $s['excerpt_enabled'] && ! empty( $a['excerpt'] ) ) {
			$postarr['post_excerpt'] = self::typography( sanitize_textarea_field( $a['excerpt'] ) );
		}
		if ( $date ) {
			$postarr['post_date_gmt'] = $date;
			$postarr['post_date']     = get_date_from_gmt( $date );
		}

		// Prevent kses from stripping the TOC/details markup for users without unfiltered_html (cron context).
		kses_remove_filters();
		$post_id = wp_insert_post( wp_slash( $postarr ), true );
		kses_init_filters();
		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		if ( 'post' === $post_type && 'standard' !== $s['post_format'] ) {
			set_post_format( $post_id, $s['post_format'] );
		}

		self::assign_terms( $post_id, $a, $topic, $post_type );
		self::seo_meta( $post_id, $a );
		self::schema_meta( $post_id, $a, $faq );

		if ( ! empty( $a['image'] ) && is_array( $a['image'] ) ) {
			$img = self::attach_image( $post_id, $a['image'], $a, $title );
			if ( is_wp_error( $img ) ) {
				AAW_Logs::add( 'warning', 'image', 'ذخیره تصویر شاخص ناموفق بود: ' . $img->get_error_message(), array( 'post_id' => $post_id ) );
			}
		}
		if ( ! empty( $meta['image_error'] ) ) {
			AAW_Logs::add( 'error', 'image', 'ساخت تصویر: ' . $meta['image_error'], array( 'post_id' => $post_id ) );
		}

		// Inline images inside the article (placed after the paragraph following an H2).
		if ( ! empty( $a['inline_images'] ) && is_array( $a['inline_images'] ) ) {
			$figs = array();
			foreach ( array_slice( $a['inline_images'], 0, 4 ) as $im ) {
				if ( empty( $im['base64'] ) ) {
					continue;
				}
				$alt    = sanitize_text_field( $im['alt'] ?? $title );
				$att_id = self::attach_image( $post_id, $im, array( 'image_alt' => $alt, 'focus_keyword' => $a['focus_keyword'] ?? '' ), $alt, false );
				if ( is_wp_error( $att_id ) ) {
					continue;
				}
				$figs[ (int) ( $im['after_h2'] ?? 0 ) ] = "\n" . '<figure class="wp-block-image size-large aaw-inline-image">' . wp_get_attachment_image( $att_id, 'large', false, array( 'loading' => 'lazy', 'decoding' => 'async' ) ) . '</figure>' . "\n";
			}
			if ( $figs ) {
				$content = get_post_field( 'post_content', $post_id );
				wp_update_post( array( 'ID' => $post_id, 'post_content' => AAW_Images::insert_inline( $content, $figs ) ) );
			}
		}

		do_action( 'aaw_post_created', $post_id, $a, $topic, $meta );
		return (int) $post_id;
	}

	/**
	 * Rewrite an existing post from a (revised) article; keeps status, author, date,
	 * images and terms. Returns true or WP_Error.
	 */
	public static function update_from_article( $post_id, array $a ) {
		$s    = AAW_Settings::all();
		$html = isset( $a['content_html'] ) ? (string) $a['content_html'] : '';
		if ( '' === trim( wp_strip_all_tags( $html ) ) ) {
			return new WP_Error( 'aaw_empty', 'هوش مصنوعی محتوای خالی برگرداند.' );
		}
		// Keep inline images that were already in the post (the AI only sees text).
		$old  = (string) get_post_field( 'post_content', $post_id );
		$figs = array();
		if ( preg_match_all( '#<figure class="wp-block-image size-large aaw-inline-image">.*?</figure>#is', $old, $m ) && false === strpos( $html, 'aaw-inline-image' ) ) {
			$figs = $m[0];
		}
		$html = self::process_html( $html, $a );
		$faq  = array();
		if ( $s['include_faq'] && ! empty( $a['faq'] ) && is_array( $a['faq'] ) ) {
			foreach ( $a['faq'] as $f ) {
				$q   = sanitize_text_field( $f['question'] ?? ( $f['q'] ?? '' ) );
				$ans = wp_kses_post( $f['answer'] ?? ( $f['a'] ?? '' ) );
				if ( $q && $ans ) {
					$faq[] = array( 'q' => self::typography( $q ), 'a' => self::typography( $ans ) );
				}
			}
			if ( $faq ) {
				$html .= self::faq_html( $faq );
			}
		}
		if ( $figs ) {
			$map = array();
			foreach ( array_values( $figs ) as $i => $f ) {
				$map[ $i ] = "\n" . $f . "\n";
			}
			$html = AAW_Images::insert_inline( $html, $map );
		}
		$postarr = array( 'ID' => $post_id, 'post_content' => $html );
		if ( ! empty( $a['title'] ) ) {
			$postarr['post_title'] = self::typography( sanitize_text_field( $a['title'] ) );
		}
		if ( $s['excerpt_enabled'] && ! empty( $a['excerpt'] ) ) {
			$postarr['post_excerpt'] = self::typography( sanitize_textarea_field( $a['excerpt'] ) );
		}
		kses_remove_filters();
		$r = wp_update_post( wp_slash( $postarr ), true );
		kses_init_filters();
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		if ( ! empty( $a['focus_keyword'] ) ) {
			update_post_meta( $post_id, '_aaw_focus_keyword', sanitize_text_field( $a['focus_keyword'] ) );
		}
		update_post_meta( $post_id, '_aaw_word_count', self::word_count( $html ) );
		self::seo_meta( $post_id, $a );
		self::schema_meta( $post_id, $a, $faq );
		return true;
	}

	/* ------------------------------------------------------------------ */

	public static function word_count( $html ) {
		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $html ) ) );
		return $text ? count( preg_split( '/\s+/u', $text ) ) : 0;
	}

	public static function slug( $a, $title ) {
		$s    = AAW_Settings::all();
		$max  = (int) $s['slug_max_words'];
		$base = $title;
		if ( 'ai_english' === $s['slug_mode'] && ! empty( $a['slug'] ) ) {
			$base = $a['slug'];
		} elseif ( 'persian' === $s['slug_mode'] && ! empty( $a['focus_keyword'] ) ) {
			$base = $a['focus_keyword'];
		}
		$slug  = sanitize_title( $base );
		$parts = array_slice( array_filter( explode( '-', $slug ) ), 0, $max );
		return implode( '-', $parts );
	}

	/**
	 * DOM-based HTML post-processing.
	 */
	public static function process_html( $html, $a = array() ) {
		$s    = AAW_Settings::all();
		$html = preg_replace( '/^```(?:html)?|```$/m', '', trim( $html ) );

		// Normalize headings.
		if ( $s['remove_h1'] ) {
			$html = preg_replace( '#<h1([^>]*)>(.*?)</h1>#is', '<h2$1>$2</h2>', $html );
		}

		$allowed                      = wp_kses_allowed_html( 'post' );
		$allowed['div']['class']      = true;
		$allowed['nav']               = array( 'class' => true, 'aria-label' => true );
		$allowed['details']           = array( 'class' => true, 'open' => true );
		$allowed['summary']           = array( 'class' => true );
		$allowed['h2']['id']          = true;
		$allowed['h3']['id']          = true;
		$html                         = wp_kses( $html, $allowed );

		if ( ! class_exists( 'DOMDocument' ) ) {
			return self::typography( $html );
		}

		$dom  = new DOMDocument( '1.0', 'UTF-8' );
		$prev = libxml_use_internal_errors( true );
		$dom->loadHTML( '<!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body><div id="aaw-root">' . $html . '</div></body></html>' );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );
		$xp   = new DOMXPath( $dom );
		$root = $dom->getElementById( 'aaw-root' );
		if ( ! $root ) {
			return self::typography( $html );
		}

		// Typography / digits / emoji on text nodes only.
		foreach ( $xp->query( '//div[@id="aaw-root"]//text()' ) as $node ) {
			$node->nodeValue = self::typography( $node->nodeValue );
		}

		// Heading anchors.
		$used     = array();
		$headings = array();
		foreach ( $xp->query( '//div[@id="aaw-root"]//h2 | //div[@id="aaw-root"]//h3' ) as $h ) {
			$text = trim( $h->textContent );
			$id   = self::anchor_id( $text, $used );
			$h->setAttribute( 'id', $id );
			if ( $xp->query( 'ancestor::div[contains(concat(" ", normalize-space(@class), " "), " aaw-takeaways ")]', $h )->length ) {
				continue;
			}
			$headings[] = array(
				'level' => strtolower( $h->nodeName ),
				'text'  => $text,
				'id'    => $id,
			);
		}

		// Links.
		$home_host = wp_parse_url( home_url(), PHP_URL_HOST );
		foreach ( $xp->query( '//div[@id="aaw-root"]//a[@href]' ) as $link ) {
			$href = $link->getAttribute( 'href' );
			$host = wp_parse_url( $href, PHP_URL_HOST );
			if ( $host && $host !== $home_host ) {
				$rel = array( 'noopener' );
				if ( $s['external_links_nofollow'] ) {
					$rel[] = 'nofollow';
				}
				$link->setAttribute( 'rel', implode( ' ', $rel ) );
				if ( $s['external_links_blank'] ) {
					$link->setAttribute( 'target', '_blank' );
				}
			}
		}

		// Automatic internal links.
		if ( in_array( $s['internal_links_mode'], array( 'auto', 'both' ), true ) && $s['internal_links_count'] > 0 ) {
			self::auto_internal_links( $dom, $xp, (int) $s['internal_links_count'] );
		}

		$out = '';
		foreach ( $root->childNodes as $child ) {
			$out .= $dom->saveHTML( $child );
		}

		// Table of contents.
		if ( $s['include_toc'] ) {
			$toc = self::toc_html( $headings );
			if ( $toc ) {
				if ( preg_match( '#</div>#', $out ) && false !== strpos( $out, 'aaw-takeaways' ) ) {
					$pos = strpos( $out, '</div>', strpos( $out, 'aaw-takeaways' ) );
					$out = substr_replace( $out, '</div>' . $toc, $pos, 6 );
				} elseif ( false !== ( $pos = strpos( $out, '</p>' ) ) ) {
					$out = substr_replace( $out, '</p>' . $toc, $pos, 4 );
				} else {
					$out = $toc . $out;
				}
			}
		}
		return $out;
	}

	public static function anchor_id( $text, array &$used ) {
		$base = sanitize_title( $text );
		$base = $base ? urldecode( $base ) : 'section';
		$base = preg_replace( '/[^\p{L}\p{N}\-]/u', '', $base );
		$base = mb_substr( $base ? $base : 'section', 0, 60 );
		$id   = $base;
		$i    = 2;
		while ( isset( $used[ $id ] ) ) {
			$id = $base . '-' . $i++;
		}
		$used[ $id ] = true;
		return $id;
	}

	public static function toc_html( array $headings ) {
		$s   = AAW_Settings::all();
		$h2s = array_filter( $headings, function ( $h ) {
			return 'h2' === $h['level'];
		} );
		if ( count( $h2s ) < (int) $s['toc_min_headings'] ) {
			return '';
		}
		$tag  = $s['toc_numbered'] ? 'ol' : 'ul';
		$list = '<' . $tag . '>';
		$open = false;
		foreach ( $headings as $h ) {
			if ( 'h2' === $h['level'] ) {
				if ( $open ) {
					$list .= '</li>';
				}
				$list .= '<li><a href="#' . esc_attr( $h['id'] ) . '">' . esc_html( $h['text'] ) . '</a>';
				$open  = true;
			} elseif ( $open && $s['use_h3'] ) {
				$list .= '<ul class="aaw-toc-sub"><li><a href="#' . esc_attr( $h['id'] ) . '">' . esc_html( $h['text'] ) . '</a></li></ul>';
			}
		}
		if ( $open ) {
			$list .= '</li>';
		}
		$list .= '</' . $tag . '>';
		$list  = str_replace( '</ul><ul class="aaw-toc-sub">', '', $list );
		$title = esc_html( $s['toc_title'] );
		if ( $s['toc_collapsible'] ) {
			return '<details class="aaw-toc" open><summary>' . $title . '</summary><nav aria-label="' . $title . '">' . $list . '</nav></details>';
		}
		return '<nav class="aaw-toc" aria-label="' . $title . '"><p><strong>' . $title . '</strong></p>' . $list . '</nav>';
	}

	public static function faq_html( array $faq ) {
		$out = '<h2 id="faq">سؤالات متداول</h2><div class="aaw-faq">';
		foreach ( $faq as $f ) {
			$out .= '<details class="aaw-faq-item"><summary>' . esc_html( $f['q'] ) . '</summary><div class="aaw-faq-answer"><p>' . $f['a'] . '</p></div></details>';
		}
		return $out . '</div>';
	}

	/** Persian typography corrections, digit conversion and emoji stripping. */
	public static function typography( $text ) {
		$s = AAW_Settings::all();
		if ( $s['no_emoji'] ) {
			$text = preg_replace( '/[\x{1F000}-\x{1FAFF}\x{2600}-\x{27BF}\x{FE0F}\x{200D}\x{1F1E6}-\x{1F1FF}]/u', '', $text );
		}
		if ( 'fa' === $s['language'] ) {
			if ( $s['convert_arabic_chars'] ) {
				$text = str_replace( array( 'ي', 'ك', 'ى' ), array( 'ی', 'ک', 'ی' ), $text );
			}
			if ( $s['fix_persian_typography'] ) {
				$zwnj = "\u{200C}";
				$text = preg_replace( '/(^|[\s(«])(ن?می)\s+(?=[\x{0600}-\x{06FF}])/u', '$1$2' . $zwnj, $text );
				$text = preg_replace( '/([\x{0600}-\x{06FF}])\s+(ها|های|هایی|هایم|هایت|هایش|هایمان|هایتان|هایشان|تر|ترین|ترها)(?=[\s\.,،؛:!؟)»]|$)/u', '$1' . $zwnj . '$2', $text );
				$text = preg_replace( '/\s+([،؛:!؟\.])/u', '$1', $text );
				$text = preg_replace( '/ {2,}/', ' ', $text );
			}
			if ( $s['persian_digits'] ) {
				$text = strtr( $text, array( '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹' ) );
			}
		}
		return $text;
	}

	/** Link first occurrence of existing post titles/keywords inside paragraphs. */
	private static function auto_internal_links( DOMDocument $dom, DOMXPath $xp, $limit ) {
		$pool = self::link_pool( (int) AAW_Settings::get( 'internal_links_pool', 150 ) );
		if ( empty( $pool ) ) {
			return;
		}
		// Count existing internal links.
		$home  = wp_parse_url( home_url(), PHP_URL_HOST );
		$count = 0;
		$linked = array();
		foreach ( $xp->query( '//div[@id="aaw-root"]//a[@href]' ) as $a ) {
			$h = wp_parse_url( $a->getAttribute( 'href' ), PHP_URL_HOST );
			if ( ! $h || $h === $home ) {
				++$count;
				$linked[ untrailingslashit( $a->getAttribute( 'href' ) ) ] = true;
			}
		}
		if ( $count >= $limit ) {
			return;
		}
		foreach ( $pool as $item ) {
			if ( $count >= $limit ) {
				break;
			}
			if ( isset( $linked[ untrailingslashit( $item['url'] ) ] ) ) {
				continue;
			}
			$phrase = $item['keyword'];
			if ( mb_strlen( $phrase ) < 4 ) {
				continue;
			}
			foreach ( $xp->query( '//div[@id="aaw-root"]//p//text()[not(ancestor::a)] | //div[@id="aaw-root"]//li//text()[not(ancestor::a)]' ) as $textnode ) {
				$val = $textnode->nodeValue;
				$pos = mb_strpos( $val, $phrase );
				if ( false === $pos ) {
					continue;
				}
				$before = mb_substr( $val, 0, $pos );
				$after  = mb_substr( $val, $pos + mb_strlen( $phrase ) );
				$link   = $dom->createElement( 'a' );
				$link->setAttribute( 'href', $item['url'] );
				$link->appendChild( $dom->createTextNode( $phrase ) );
				$parent = $textnode->parentNode;
				$parent->insertBefore( $dom->createTextNode( $before ), $textnode );
				$parent->insertBefore( $link, $textnode );
				$parent->insertBefore( $dom->createTextNode( $after ), $textnode );
				$parent->removeChild( $textnode );
				++$count;
				$linked[ untrailingslashit( $item['url'] ) ] = true;
				break;
			}
		}
	}

	/**
	 * Existing published posts usable for internal linking.
	 */
	public static function link_pool( $limit = 150, $query_text = '' ) {
		$posts = get_posts(
			array(
				'post_type'      => array( 'post', 'page', 'product' ),
				'post_status'    => 'publish',
				'posts_per_page' => $limit,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'no_found_rows'  => true,
			)
		);
		$out = array();
		foreach ( $posts as $p ) {
			$kw = get_post_meta( $p->ID, '_yoast_wpseo_focuskw', true );
			if ( ! $kw ) {
				$rm = get_post_meta( $p->ID, 'rank_math_focus_keyword', true );
				$kw = $rm ? trim( explode( ',', $rm )[0] ) : '';
			}
			if ( ! $kw ) {
				$kw = get_post_meta( $p->ID, '_aaw_focus_keyword', true );
			}
			$out[] = array(
				'id'      => $p->ID,
				'title'   => $p->post_title,
				'url'     => get_permalink( $p ),
				'keyword' => $kw ? $kw : $p->post_title,
			);
		}
		if ( $query_text ) {
			$words = array_filter( preg_split( '/\s+/u', AAW_Topics::normalize( $query_text ) ), function ( $w ) {
				return mb_strlen( $w ) > 2;
			} );
			foreach ( $out as &$o ) {
				$score = 0;
				$t     = AAW_Topics::normalize( $o['title'] . ' ' . $o['keyword'] );
				foreach ( $words as $w ) {
					if ( false !== mb_strpos( $t, $w ) ) {
						++$score;
					}
				}
				$o['score'] = $score;
			}
			unset( $o );
			usort( $out, function ( $x, $y ) {
				return $y['score'] <=> $x['score'];
			} );
		}
		return $out;
	}

	private static function assign_terms( $post_id, $a, $topic, $post_type ) {
		$s = AAW_Settings::all();
		if ( 'post' !== $post_type ) {
			return;
		}
		$cat = 0;
		if ( ! empty( $topic['category_id'] ) ) {
			$cat = (int) $topic['category_id'];
		} elseif ( 'fixed' === $s['category_mode'] ) {
			$cat = (int) $s['default_category'];
		} elseif ( 'ai_pick' === $s['category_mode'] && ! empty( $a['category'] ) ) {
			$term = get_term_by( 'name', sanitize_text_field( $a['category'] ), 'category' );
			if ( ! $term ) {
				$best = 0;
				foreach ( get_categories( array( 'hide_empty' => false ) ) as $c ) {
					similar_text( AAW_Topics::normalize( $c->name ), AAW_Topics::normalize( $a['category'] ), $pct );
					if ( $pct > 70 && $pct > $best ) {
						$best = $pct;
						$term = $c;
					}
				}
			}
			$cat = $term ? (int) $term->term_id : (int) $s['default_category'];
		}
		if ( ! $cat && $s['default_category'] ) {
			$cat = (int) $s['default_category'];
		}
		if ( $cat ) {
			wp_set_post_categories( $post_id, array( $cat ) );
		}
		if ( $s['create_tags'] && $s['tags_max'] > 0 && ! empty( $a['tags'] ) ) {
			$tags = array_slice( array_filter( array_map( 'sanitize_text_field', (array) $a['tags'] ) ), 0, (int) $s['tags_max'] );
			wp_set_post_tags( $post_id, array_map( array( __CLASS__, 'typography' ), $tags ), false );
		}
	}

	public static function detect_seo_plugin() {
		$pref = AAW_Settings::get( 'seo_plugin', 'auto' );
		if ( 'auto' !== $pref ) {
			return $pref;
		}
		if ( defined( 'WPSEO_VERSION' ) ) {
			return 'yoast';
		}
		if ( defined( 'RANK_MATH_VERSION' ) ) {
			return 'rankmath';
		}
		if ( defined( 'AIOSEO_VERSION' ) ) {
			return 'aioseo';
		}
		if ( defined( 'SEOPRESS_VERSION' ) ) {
			return 'seopress';
		}
		return 'none';
	}

	private static function seo_meta( $post_id, $a ) {
		$s     = AAW_Settings::all();
		$title = isset( $a['seo_title'] ) ? self::typography( mb_substr( sanitize_text_field( $a['seo_title'] ), 0, (int) $s['seo_title_max'] + 10 ) ) : '';
		$desc  = isset( $a['meta_description'] ) ? self::typography( mb_substr( sanitize_text_field( $a['meta_description'] ), 0, (int) $s['meta_desc_max'] ) ) : '';
		$kw    = isset( $a['focus_keyword'] ) ? sanitize_text_field( $a['focus_keyword'] ) : '';
		$sec   = isset( $a['secondary_keywords'] ) ? array_slice( array_map( 'sanitize_text_field', (array) $a['secondary_keywords'] ), 0, 4 ) : array();

		update_post_meta( $post_id, '_aaw_seo_title', $title );
		update_post_meta( $post_id, '_aaw_meta_description', $desc );

		switch ( self::detect_seo_plugin() ) {
			case 'yoast':
				update_post_meta( $post_id, '_yoast_wpseo_title', $title );
				update_post_meta( $post_id, '_yoast_wpseo_metadesc', $desc );
				update_post_meta( $post_id, '_yoast_wpseo_focuskw', $kw );
				break;
			case 'rankmath':
				update_post_meta( $post_id, 'rank_math_title', $title );
				update_post_meta( $post_id, 'rank_math_description', $desc );
				update_post_meta( $post_id, 'rank_math_focus_keyword', implode( ',', array_filter( array_merge( array( $kw ), $sec ) ) ) );
				break;
			case 'aioseo':
				update_post_meta( $post_id, '_aioseo_title', $title );
				update_post_meta( $post_id, '_aioseo_description', $desc );
				update_post_meta( $post_id, '_aioseo_keywords', $kw );
				if ( class_exists( '\AIOSEO\Plugin\Common\Models\Post' ) ) {
					try {
						$p              = \AIOSEO\Plugin\Common\Models\Post::getPost( $post_id );
						$p->post_id     = $post_id;
						$p->title       = $title;
						$p->description = $desc;
						$p->keyphrases  = wp_json_encode( array( 'focus' => array( 'keyphrase' => $kw ) ) );
						$p->save();
					} catch ( \Throwable $e ) { // phpcs:ignore
						unset( $e );
					}
				}
				break;
			case 'seopress':
				update_post_meta( $post_id, '_seopress_titles_title', $title );
				update_post_meta( $post_id, '_seopress_titles_desc', $desc );
				update_post_meta( $post_id, '_seopress_analysis_target_kw', $kw );
				break;
		}
	}

	private static function schema_meta( $post_id, $a, $faq ) {
		$s      = AAW_Settings::all();
		$graphs = array();
		if ( $s['faq_schema'] && $faq ) {
			$items = array();
			foreach ( $faq as $f ) {
				$items[] = array(
					'@type'          => 'Question',
					'name'           => $f['q'],
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => wp_strip_all_tags( $f['a'] ),
					),
				);
			}
			$graphs[] = array(
				'@type'      => 'FAQPage',
				'mainEntity' => $items,
			);
		}
		if ( $s['article_schema'] ) {
			$graphs[] = array(
				'@type'       => 'Article',
				'headline'    => isset( $a['title'] ) ? sanitize_text_field( $a['title'] ) : '',
				'description' => isset( $a['meta_description'] ) ? sanitize_text_field( $a['meta_description'] ) : '',
				'keywords'    => isset( $a['focus_keyword'] ) ? sanitize_text_field( $a['focus_keyword'] ) : '',
				'inLanguage'  => $s['language'],
			);
		}
		if ( $graphs ) {
			update_post_meta( $post_id, '_aaw_schema', wp_slash( wp_json_encode( $graphs, JSON_UNESCAPED_UNICODE ) ) );
		}
	}

	/**
	 * Save a base64 image as the featured image.
	 */
	public static function attach_image( $post_id, array $image, array $a, $title, $featured = true ) {
		if ( empty( $image['base64'] ) ) {
			if ( ! empty( $image['url'] ) ) {
				require_once ABSPATH . 'wp-admin/includes/media.php';
				require_once ABSPATH . 'wp-admin/includes/file.php';
				require_once ABSPATH . 'wp-admin/includes/image.php';
				$id = media_sideload_image( esc_url_raw( $image['url'] ), $post_id, $title, 'id' );
				if ( is_wp_error( $id ) ) {
					return $id;
				}
				if ( $featured ) {
					set_post_thumbnail( $post_id, $id );
				}
				self::image_meta( $id, $a, $title );
				return $id;
			}
			return new WP_Error( 'aaw_img', 'داده تصویر خالی است.' );
		}
		$bin = base64_decode( preg_replace( '#^data:image/\w+;base64,#', '', $image['base64'] ), true );
		if ( false === $bin || strlen( $bin ) < 100 ) {
			return new WP_Error( 'aaw_img', 'تصویر نامعتبر است.' );
		}
		$finfo = function_exists( 'finfo_open' ) ? finfo_open( FILEINFO_MIME_TYPE ) : null;
		$mime  = $finfo ? finfo_buffer( $finfo, $bin ) : ( $image['mime'] ?? 'image/png' );
		$ext   = array(
			'image/png'  => 'png',
			'image/jpeg' => 'jpg',
			'image/webp' => 'webp',
		);
		if ( ! isset( $ext[ $mime ] ) ) {
			return new WP_Error( 'aaw_img', 'فرمت تصویر پشتیبانی نمی‌شود: ' . $mime );
		}
		$slug = get_post_field( 'post_name', $post_id );
		$name = ( $slug ? urldecode( $slug ) : 'aaw-image' ) . '-' . $post_id . ( $featured ? '' : '-' . wp_generate_password( 4, false, false ) ) . '.' . $ext[ $mime ];
		$up   = wp_upload_bits( sanitize_file_name( $name ), null, $bin );
		if ( ! empty( $up['error'] ) ) {
			return new WP_Error( 'aaw_img', $up['error'] );
		}
		$att_id = wp_insert_attachment(
			array(
				'post_mime_type' => $mime,
				'post_title'     => sanitize_text_field( $title ),
				'post_status'    => 'inherit',
			),
			$up['file'],
			$post_id
		);
		if ( is_wp_error( $att_id ) ) {
			return $att_id;
		}
		require_once ABSPATH . 'wp-admin/includes/image.php';
		wp_update_attachment_metadata( $att_id, wp_generate_attachment_metadata( $att_id, $up['file'] ) );
		if ( $featured ) {
			set_post_thumbnail( $post_id, $att_id );
		}
		self::image_meta( $att_id, $a, $title );
		return $att_id;
	}

	private static function image_meta( $att_id, $a, $title ) {
		$alt = ! empty( $a['image_alt'] ) ? sanitize_text_field( $a['image_alt'] ) : $title;
		if ( AAW_Settings::get( 'image_alt_keyword' ) && ! empty( $a['focus_keyword'] ) && false === mb_strpos( $alt, $a['focus_keyword'] ) ) {
			$alt = sanitize_text_field( $a['focus_keyword'] ) . ' - ' . $alt;
		}
		update_post_meta( $att_id, '_wp_attachment_image_alt', self::typography( $alt ) );
		wp_update_post(
			array(
				'ID'           => $att_id,
				'post_excerpt' => self::typography( $alt ),
			)
		);
	}
}
