<?php
/**
 * Up-to-date SEO knowledge, learned once and reused.
 *
 * A background job on the worker reads official Google Search documentation and
 * top international + Iranian SEO articles (and, with a web-capable engine, live
 * search), then distils a compact, dated "SEO playbook". The playbook is placed at
 * the very start of every article prompt (a stable prefix → provider prompt caching)
 * and refreshed automatically every N days, so the expensive learning happens once
 * instead of on every article.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Knowledge {

	const OPTION = 'aaw_seo_playbook';

	public static function get() {
		$k = get_option( self::OPTION, array() );
		return is_array( $k ) ? $k : array();
	}

	public static function sources() {
		$list = preg_split( '/[\r\n]+/', (string) AAW_Settings::get( 'seo_sources' ) );
		return array_values( array_filter( array_map( 'esc_url_raw', array_map( 'trim', $list ) ) ) );
	}

	public static function is_stale() {
		$k = self::get();
		return empty( $k['playbook'] ) || ( time() - (int) ( $k['at'] ?? 0 ) ) > (int) AAW_Settings::get( 'seo_learn_days', 30 ) * DAY_IN_SECONDS;
	}

	public static function payload() {
		$s = AAW_Settings::all();
		return array(
			'runtime'  => AAW_REST::runtime(),
			'sources'  => self::sources(),
			'web'      => AAW_Analyzer::web_capable(),
			'site'     => $s['site_name'],
			'niche'    => $s['niche'] ? $s['niche'] : get_bloginfo( 'description' ),
			'language' => $s['language'],
		);
	}

	/** Start learning as a background job; result is saved by poll()/bg_status. */
	public static function start( $mailbox = true ) {
		if ( AAW_SiteData::available() || AAW_SiteData::local_engine() ) {
			// One tiny request; GitHub fetches the sources, builds the playbook and stores the SEO database.
			$r = AAW_SiteData::start_seo();
			return is_wp_error( $r ) ? $r : $r['id'];
		}
		if ( ! AAW_BG::available() ) {
			return new WP_Error( 'aaw', AAW_Errors::format( 'یادگیری سئو نیاز به ورکر به‌روز دارد', 'کارهای پس‌زمینه کلادفلر روی ورکر فعال نیست.', 'در تب کلادفلر «استقرار مجدد» را بزنید.' ) );
		}
		$id = AAW_BG::start( 'seo_learn', self::payload(), $mailbox );
		if ( ! is_wp_error( $id ) ) {
			update_option( 'aaw_seo_learning', array( 'id' => $id, 't' => time() ), false );
		}
		return $id;
	}

	public static function save( array $r ) {
		if ( empty( $r['playbook'] ) ) {
			return false;
		}
		update_option(
			self::OPTION,
			array(
				'playbook'   => wp_kses_post( $r['playbook'] ),
				'highlights' => array_map( 'sanitize_text_field', (array) ( $r['highlights'] ?? array() ) ),
				'sources'    => array_map( 'esc_url_raw', (array) ( $r['sources'] ?? array() ) ),
				'engine'     => sanitize_text_field( (string) ( $r['engine'] ?? '' ) ),
				'model'      => sanitize_text_field( (string) ( $r['model'] ?? '' ) ),
				'version'    => sanitize_text_field( (string) ( $r['version'] ?? '' ) ),
				'store'      => 'github' === ( $r['store'] ?? '' ) ? 'github' : 'local',
				'at'         => time(),
			),
			false
		);
		delete_option( 'aaw_seo_learning' );
		AAW_Logs::add( 'success', 'seo', 'دانش به‌روز سئو یاد گرفته شد (' . count( (array) ( $r['sources'] ?? array() ) ) . ' منبع). این دستورالعمل در همه مقالات بعدی استفاده می‌شود.' );
		return true;
	}

	/** Prompt prefix (stable between articles → provider-side prompt caching). */
	public static function prompt_block() {
		if ( ! AAW_Settings::get( 'seo_learn' ) ) {
			return '';
		}
		$k = self::get();
		if ( empty( $k['playbook'] ) ) {
			return '';
		}
		return '## دانش به‌روز سئو (آموخته‌شده از منابع رسمی گوگل و مقالات برتر ایرانی و بین‌المللی، نسخه ' . ( $k['version'] ? $k['version'] : wp_date( 'Y-m-d', (int) $k['at'] ) ) . ")\nاین دستورالعمل را دقیق رعایت کن:\n" . wp_strip_all_tags( $k['playbook'] ) . "\n";
	}

	/** Daily: refresh when stale (one background job, results land via poll). */
	public static function maybe_refresh() {
		$busy = get_option( 'aaw_seo_learning' );
		$busy = is_array( $busy ) && ( time() - (int) ( $busy['t'] ?? 0 ) ) < 6 * HOUR_IN_SECONDS;
		if ( AAW_Settings::get( 'seo_learn' ) && self::is_stale() && ( AAW_SiteData::available() || AAW_SiteData::local_engine() || AAW_BG::available() ) && ! $busy ) {
			self::start( true );
		}
	}
}
