<?php
/**
 * Activation / deactivation / upgrade routines.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Installer {

	public static function activate() {
		AAW_Topics::create_table();
		AAW_Logs::create_table();
		update_option( 'aaw_db_version', AAW_DB_VERSION, false );

		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->add_cap( AAW_CAP );
		}
		self::sync_editor_cap();
		if ( false === get_option( AAW_Settings::OPTION, false ) ) {
			add_option( AAW_Settings::OPTION, AAW_Settings::defaults(), '', false );
		}
		AAW_Settings::shared_secret();

		if ( ! wp_next_scheduled( 'aaw_daily' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'aaw_daily' );
		}
		AAW_License::trial();
		add_option( 'aaw_activated_redirect', 1, '', false );
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'aaw_daily' );
		wp_clear_scheduled_hook( 'aaw_kv_sync' );
		wp_clear_scheduled_hook( 'aaw_pull_tick' );
		wp_clear_scheduled_hook( 'aaw_license_check' );
		wp_clear_scheduled_hook( 'aaw_bg_poll' );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'aaw_caps_version' ) !== AAW_VERSION ) {
			self::sync_editor_cap(); // e.g. WooCommerce «مدیر فروشگاه» gets access after an update.
		}
		if ( get_option( 'aaw_db_version' ) !== AAW_DB_VERSION ) {
			AAW_Topics::create_table();
			AAW_Logs::create_table();
			update_option( 'aaw_db_version', AAW_DB_VERSION, false );
		}
	}

	/** Who may open the plugin: administrators always; shop managers / editors by setting. */
	public static function sync_editor_cap() {
		$map = array(
			'administrator' => true,
			'shop_manager'  => (bool) AAW_Settings::get( 'allow_shop_managers' ),
			'editor'        => (bool) AAW_Settings::get( 'allow_editors' ),
		);
		foreach ( $map as $role_name => $allow ) {
			$role = get_role( $role_name );
			if ( ! $role ) {
				continue;
			}
			if ( $allow && ! $role->has_cap( AAW_CAP ) ) {
				$role->add_cap( AAW_CAP );
			} elseif ( ! $allow && $role->has_cap( AAW_CAP ) ) {
				$role->remove_cap( AAW_CAP );
			}
		}
		update_option( 'aaw_caps_version', AAW_VERSION, false );
	}
}
