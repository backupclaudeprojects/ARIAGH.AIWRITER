<?php
/**
 * Live activity feed: every operation the plugin runs (tests, article writing,
 * images, analysis, revisions, learning) with its current step, so the "Live"
 * tab can show exactly what the AI is doing right now.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Activity {

	const OPTION = 'aaw_activity';
	const MAX    = 40;

	private static function all() {
		$a = get_option( self::OPTION, array() );
		return is_array( $a ) ? $a : array();
	}

	private static function save( array $a ) {
		if ( count( $a ) > self::MAX ) {
			$a = array_slice( $a, -self::MAX, null, true );
		}
		update_option( self::OPTION, $a, false );
	}

	/**
	 * @param string $kind  test|generate|run|analyze|image|revise|seo_learn|style_learn|suggest|github
	 * @param array  $extra bg (job id), github (task id), url, post_id
	 */
	public static function start( $kind, $label, array $extra = array() ) {
		$a        = self::all();
		$id       = 'op' . time() . strtolower( wp_generate_password( 4, false, false ) );
		$a[ $id ] = array_merge(
			array(
				'id'      => $id,
				'kind'    => $kind,
				'label'   => $label,
				'status'  => 'running',
				'step'    => 'شروع شد…',
				'started' => time(),
				'ended'   => 0,
				'detail'  => '',
				'user'    => get_current_user_id(),
			),
			$extra
		);
		self::save( $a );
		return $id;
	}

	public static function step( $id, $text ) {
		$a = self::all();
		if ( isset( $a[ $id ] ) && 'running' === $a[ $id ]['status'] ) {
			$a[ $id ]['step'] = $text;
			self::save( $a );
		}
	}

	public static function finish( $id, $ok = true, $detail = '' ) {
		$a = self::all();
		if ( isset( $a[ $id ] ) ) {
			$a[ $id ]['status'] = $ok ? 'done' : 'error';
			$a[ $id ]['ended']  = time();
			$a[ $id ]['detail'] = (string) $detail;
			$a[ $id ]['step']   = $ok ? 'انجام شد' : 'ناموفق';
			self::save( $a );
		}
	}

	/** Finish the operation linked to a background/GitHub job id. */
	public static function finish_job( $job_id, $ok = true, $detail = '' ) {
		foreach ( self::all() as $id => $op ) {
			if ( ( ( $op['bg'] ?? '' ) === $job_id || ( $op['github'] ?? '' ) === $job_id || ( $op['local'] ?? '' ) === $job_id ) && 'running' === $op['status'] ) {
				self::finish( $id, $ok, $detail );
			}
		}
	}

	public static function running_count() {
		$n = 0;
		foreach ( self::all() as $op ) {
			if ( 'running' === $op['status'] && time() - (int) $op['started'] < 40 * MINUTE_IN_SECONDS ) {
				++$n;
			}
		}
		return $n;
	}

	/** Feed for the Live tab: refreshes running background jobs from the worker (max 4 calls). */
	public static function feed() {
		if ( class_exists( 'AAW_Local' ) ) {
			AAW_Local::tick( 12 ); // Advance jobs running directly on this server.
		}
		$a     = self::all();
		$calls = 0;
		$dirty = false;
		foreach ( $a as $id => &$op ) {
			if ( 'running' !== $op['status'] ) {
				continue;
			}
			if ( time() - (int) $op['started'] > 40 * MINUTE_IN_SECONDS ) {
				$op['status'] = 'error';
				$op['step']   = 'بدون پاسخ (بیش از ۴۰ دقیقه)';
				$op['ended']  = time();
				$dirty        = true;
				continue;
			}
			if ( ! empty( $op['bg'] ) && $calls < 4 ) {
				++$calls;
				$j = AAW_BG::get( $op['bg'] );
				if ( is_wp_error( $j ) ) {
					continue;
				}
				$st = (string) ( $j['status'] ?? '' );
				if ( 'done' === $st ) {
					$op['status'] = 'done';
					$op['step']   = 'انجام شد';
					$op['ended']  = time();
					if ( ! empty( $j['result']['delivered'] ) ) {
						AAW_Pull::poll(); // Turn the result into drafts / images right away.
					}
				} elseif ( 'error' === $st ) {
					$op['status'] = 'error';
					$op['step']   = 'ناموفق';
					$op['detail'] = AAW_Errors::explain( (string) ( $j['error'] ?? '' ) );
					$op['ended']  = time();
				} else {
					$op['step'] = 'queued' === $st ? 'در صف کلادفلر…' : AAW_BG::step_label( $j['step'] ?? '' );
				}
				$dirty = true;
			} elseif ( ! empty( $op['github'] ) ) {
				$op['step'] = 'در حال اجرا در GitHub Actions با اکانت اشتراکی… (نتیجه خودکار دریافت می‌شود)';
			}
		}
		unset( $op );
		if ( $dirty ) {
			self::save( $a );
		}
		$ops = array_reverse( array_values( $a ) );
		foreach ( $ops as &$o ) {
			$o['elapsed'] = ( $o['ended'] ? $o['ended'] : time() ) - (int) $o['started'];
			$o['time']    = wp_date( 'H:i:s', (int) $o['started'] );
		}
		unset( $o );
		return $ops;
	}

	public static function clear_finished() {
		self::save(
			array_filter(
				self::all(),
				function ( $op ) {
					return 'running' === $op['status'];
				}
			)
		);
	}
}
