<?php
/**
 * Programs on THIS server (the official Claude Code / OpenAI Codex CLIs, npm, node).
 *
 * - Fixed argument lists only (proc_open with an array → no shell parsing of user input).
 * - Long runs are started DETACHED (setsid / nohup): they keep running after the PHP request
 *   ends, so the host's 30–60 s PHP time limit never cuts an article in half. Every run gets its
 *   own private folder with in.txt / out.txt / err.txt / code.txt / pid; WordPress checks it
 *   later (cron or the open admin page) and continues the job.
 * - Private files live outside the web root when possible (else behind deny rules), mode 0700/0600.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Proc {

	/** Functions this class needs that hosts often disable. */
	const NEEDED = array( 'proc_open', 'proc_close', 'proc_get_status', 'proc_terminate' );

	public static function blocked() {
		$off = array_map( 'trim', explode( ',', strtolower( (string) ini_get( 'disable_functions' ) ) ) );
		$out = array();
		foreach ( self::NEEDED as $f ) {
			if ( ! function_exists( $f ) || in_array( $f, $off, true ) ) {
				$out[] = $f;
			}
		}
		return $out;
	}

	public static function can_exec() {
		return ! self::blocked() && version_compare( PHP_VERSION, '7.4', '>=' );
	}

	public static function user_home() {
		$h = (string) getenv( 'HOME' );
		if ( '' === $h && function_exists( 'posix_getpwuid' ) && function_exists( 'posix_geteuid' ) ) {
			$pw = @posix_getpwuid( posix_geteuid() ); // phpcs:ignore
			$h  = is_array( $pw ) ? (string) $pw['dir'] : '';
		}
		if ( '' === $h && preg_match( '#^(/home\d*/[^/]+)/#', ABSPATH, $m ) ) {
			$h = $m[1]; // cPanel: /home/<user>/public_html/
		}
		return untrailingslashit( $h );
	}

	/** Base private folder: outside the web root when writable, else uploads/ with deny rules. */
	public static function base_dir() {
		$saved = (string) get_option( 'aaw_private_dir', '' );
		if ( '' !== $saved && @is_dir( $saved ) && @is_writable( $saved ) ) { // phpcs:ignore
			return $saved;
		}
		$cands = array();
		$home  = self::user_home();
		if ( $home && 0 !== strpos( untrailingslashit( ABSPATH ), $home . '/.aaw' ) ) {
			$cands[] = $home . '/.aaw-ai-writer';
		}
		$cands[] = dirname( untrailingslashit( ABSPATH ) ) . '/.aaw-ai-writer';
		$up      = wp_upload_dir( null, false );
		$cands[] = trailingslashit( $up['basedir'] ) . 'aaw-private';
		foreach ( $cands as $d ) {
			if ( ( @is_dir( $d ) || @wp_mkdir_p( $d ) ) && @is_writable( $d ) ) { // phpcs:ignore
				@chmod( $d, 0700 ); // phpcs:ignore
				if ( false !== strpos( $d, $up['basedir'] ) ) {
					@file_put_contents( $d . '/.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore
					@file_put_contents( $d . '/index.php', "<?php // Silence.\n" ); // phpcs:ignore
				}
				update_option( 'aaw_private_dir', $d, false );
				return $d;
			}
		}
		return '';
	}

	public static function private_dir( $sub ) {
		$base = self::base_dir();
		if ( '' === $base ) {
			return '';
		}
		$d = $base . '/' . preg_replace( '/[^a-z0-9_\-]/i', '', $sub );
		if ( ! is_dir( $d ) ) {
			wp_mkdir_p( $d );
		}
		@chmod( $d, 0700 ); // phpcs:ignore
		return $d;
	}

	public static function write_secret( $file, $content ) {
		$ok = false !== @file_put_contents( $file, (string) $content, LOCK_EX ); // phpcs:ignore
		@chmod( $file, 0600 ); // phpcs:ignore
		return $ok;
	}

	public static function rrmdir( $dir ) {
		if ( ! $dir || ! is_dir( $dir ) || strlen( $dir ) < 12 ) {
			return;
		}
		foreach ( (array) scandir( $dir ) as $f ) {
			if ( '.' === $f || '..' === $f ) {
				continue;
			}
			$p = $dir . '/' . $f;
			if ( is_dir( $p ) && ! is_link( $p ) ) {
				self::rrmdir( $p );
			} else {
				@unlink( $p ); // phpcs:ignore
			}
		}
		@rmdir( $dir ); // phpcs:ignore
	}

	/** First existing executable among names in the given folders (+ PATH). */
	public static function which( $name, array $dirs = array() ) {
		$all = array_merge( $dirs, explode( PATH_SEPARATOR, (string) getenv( 'PATH' ) ), array( '/usr/local/bin', '/usr/bin', '/bin', '/usr/sbin' ) );
		foreach ( array_unique( array_filter( $all ) ) as $d ) {
			$f = rtrim( $d, '/' ) . '/' . $name;
			if ( @is_file( $f ) && @is_executable( $f ) ) { // phpcs:ignore
				return $f;
			}
		}
		return '';
	}

	/** Environment for a run: PATH with the folders of the given programs; nothing inherited. */
	public static function env( array $bins, array $extra = array() ) {
		$dirs = array();
		foreach ( $bins as $b ) {
			if ( $b ) {
				$dirs[] = dirname( $b );
			}
		}
		$dirs = array_merge( $dirs, array( '/usr/local/bin', '/usr/bin', '/bin' ) );
		$env  = array(
			'PATH'               => implode( ':', array_unique( $dirs ) ),
			'HOME'               => self::user_home() ? self::user_home() : sys_get_temp_dir(),
			'LANG'               => 'C.UTF-8',
			'LC_ALL'             => 'C.UTF-8',
			'TMPDIR'             => sys_get_temp_dir(),
			'NO_COLOR'           => '1',
			'CI'                 => '1',
			'DISABLE_AUTOUPDATER' => '1',
			'NODE_OPTIONS'       => '--max-old-space-size=512',
		);
		foreach ( $extra as $k => $v ) {
			if ( null === $v ) {
				unset( $env[ $k ] );
			} else {
				$env[ $k ] = (string) $v;
			}
		}
		return $env;
	}

	/**
	 * Run a short program and wait (version checks, `--help`). Never through a shell.
	 *
	 * @return array|WP_Error { code, out, err, ms, killed }
	 */
	public static function run( array $cmd, $input, array $env, $cwd, $timeout = 30 ) {
		if ( ! self::can_exec() ) {
			return new WP_Error( 'aaw_proc', 'PROC_DISABLED' );
		}
		$t0    = microtime( true );
		$pipes = array();
		$p     = @proc_open( $cmd, array( 0 => array( 'pipe', 'r' ), 1 => array( 'pipe', 'w' ), 2 => array( 'pipe', 'w' ) ), $pipes, $cwd ? $cwd : null, $env ); // phpcs:ignore
		if ( ! is_resource( $p ) ) {
			return new WP_Error( 'aaw_proc', 'START_FAILED' );
		}
		if ( '' !== (string) $input ) {
			@fwrite( $pipes[0], (string) $input ); // phpcs:ignore
		}
		fclose( $pipes[0] ); // phpcs:ignore
		stream_set_blocking( $pipes[1], false );
		stream_set_blocking( $pipes[2], false );
		$out    = '';
		$err    = '';
		$killed = false;
		while ( true ) {
			$st   = proc_get_status( $p );
			$out .= (string) stream_get_contents( $pipes[1] );
			$err .= (string) stream_get_contents( $pipes[2] );
			if ( ! $st['running'] ) {
				$code = (int) $st['exitcode'];
				break;
			}
			if ( microtime( true ) - $t0 > $timeout ) {
				proc_terminate( $p, 9 );
				$killed = true;
				$code   = -1;
				break;
			}
			usleep( 50000 );
		}
		$out .= (string) stream_get_contents( $pipes[1] );
		$err .= (string) stream_get_contents( $pipes[2] );
		fclose( $pipes[1] ); // phpcs:ignore
		fclose( $pipes[2] ); // phpcs:ignore
		proc_close( $p );
		return array( 'code' => $code, 'out' => $out, 'err' => $err, 'ms' => (int) ( ( microtime( true ) - $t0 ) * 1000 ), 'killed' => $killed );
	}

	/**
	 * Start a long program DETACHED in $dir. Reads $dir/in.txt (if any), writes out.txt, err.txt,
	 * and code.txt (exit code) when it ends; pid holds the process id. Returns immediately.
	 */
	public static function spawn( array $cmd, $dir, array $env, $timeout = 1200 ) {
		if ( ! self::can_exec() ) {
			return new WP_Error( 'aaw_proc', 'PROC_DISABLED' );
		}
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		foreach ( array( 'code.txt', 'out.txt', 'err.txt', 'pid' ) as $f ) {
			@unlink( $dir . '/' . $f ); // phpcs:ignore
		}
		if ( ! file_exists( $dir . '/in.txt' ) ) {
			self::write_secret( $dir . '/in.txt', '' );
		}
		$sh = self::which( 'sh', array( '/bin' ) );
		if ( '' === $sh ) {
			return new WP_Error( 'aaw_proc', 'NO_SHELL' );
		}
		$to = self::which( 'timeout' );
		if ( $to ) {
			$cmd = array_merge( array( $to, '-k', '30', (string) max( 30, (int) $timeout ) ), $cmd );
		}
		// The wrapper only redirects files and records the exit code; the program and its
		// arguments are passed as "$@" (never interpolated into the script).
		// Raise the soft memory limits PHP/LiteSpeed handed down to the hard maximum (allowed for any
		// user), record the real limits for diagnosis, then run the program.
		$script = 'echo $$ > pid; '
			. 'ulimit -S -v unlimited 2>/dev/null || ulimit -S -v "$(ulimit -H -v)" 2>/dev/null; '
			. 'ulimit -S -d unlimited 2>/dev/null || ulimit -S -d "$(ulimit -H -d)" 2>/dev/null; '
			. 'echo "v=$(ulimit -S -v) vh=$(ulimit -H -v) d=$(ulimit -S -d) u=$(ulimit -S -u 2>/dev/null)" > limits.txt; '
			. '"$@" < in.txt > out.txt 2> err.txt; echo $? > code.tmp; mv code.tmp code.txt';
		$sid    = self::which( 'setsid' );
		if ( $sid ) {
			$argv = array_merge( array( $sid, '-f', $sh, '-c', $script, 'aaw' ), $cmd );
		} else {
			$quoted = implode( ' ', array_map( 'escapeshellarg', $cmd ) );
			$argv   = array( $sh, '-c', 'nohup ' . escapeshellarg( $sh ) . ' -c ' . escapeshellarg( $script ) . ' aaw ' . $quoted . ' >/dev/null 2>&1 &' );
		}
		$pipes = array();
		$null  = '/dev/null';
		$p     = @proc_open( $argv, array( 0 => array( 'file', $null, 'r' ), 1 => array( 'file', $null, 'w' ), 2 => array( 'file', $null, 'w' ) ), $pipes, $dir, $env ); // phpcs:ignore
		if ( ! is_resource( $p ) ) {
			return new WP_Error( 'aaw_proc', 'START_FAILED' );
		}
		proc_close( $p ); // setsid -f / nohup … & return at once.
		self::write_secret( $dir . '/started', (string) time() );
		return true;
	}

	/** @return array { state: running|done|lost, code, out, err, age } */
	public static function status( $dir ) {
		$started = (int) @file_get_contents( $dir . '/started' ); // phpcs:ignore
		$age     = $started ? time() - $started : 0;
		if ( file_exists( $dir . '/code.txt' ) ) {
			return array( 'state' => 'done', 'code' => (int) trim( (string) file_get_contents( $dir . '/code.txt' ) ), 'age' => $age ); // phpcs:ignore
		}
		$pid = (int) @file_get_contents( $dir . '/pid' ); // phpcs:ignore
		if ( $pid && self::alive( $pid ) ) {
			return array( 'state' => 'running', 'code' => null, 'age' => $age );
		}
		// No pid yet right after start, or the process was killed (host limit) without an exit code.
		return array( 'state' => ( $age < 20 ) ? 'running' : 'lost', 'code' => null, 'age' => $age );
	}

	public static function alive( $pid ) {
		if ( function_exists( 'posix_kill' ) ) {
			return @posix_kill( (int) $pid, 0 ); // phpcs:ignore
		}
		return @is_dir( '/proc/' . (int) $pid ); // phpcs:ignore
	}

	public static function kill( $dir ) {
		$pid = (int) @file_get_contents( $dir . '/pid' ); // phpcs:ignore
		if ( ! $pid ) {
			return;
		}
		if ( function_exists( 'posix_kill' ) ) {
			@posix_kill( -$pid, 9 ); // phpcs:ignore — the whole process group (setsid).
			@posix_kill( $pid, 9 ); // phpcs:ignore
		} elseif ( self::which( 'kill' ) ) {
			self::run( array( self::which( 'kill' ), '-9', (string) $pid ), '', self::env( array() ), null, 5 );
		}
	}

	public static function read( $dir, $file, $max = 0 ) {
		$f = $dir . '/' . $file;
		if ( ! file_exists( $f ) ) {
			return '';
		}
		$s = (string) file_get_contents( $f ); // phpcs:ignore
		return $max > 0 && strlen( $s ) > $max ? substr( $s, -$max ) : $s;
	}

	/** Virtual-memory limit (KB) the host gives to programs (0 = unlimited/unknown). */
	public static function vmem_kb() {
		$l = self::limits();
		return $l['hard'] ? $l['hard'] : $l['soft'];
	}

	/** Soft / hard virtual-memory limits in KB (0 = unlimited). */
	public static function limits() {
		$sh = self::which( 'sh', array( '/bin' ) );
		if ( ! $sh || ! self::can_exec() ) {
			return array( 'soft' => 0, 'hard' => 0 );
		}
		$r = self::run( array( $sh, '-c', 'echo "$(ulimit -S -v) $(ulimit -H -v)"' ), '', self::env( array() ), null, 5 );
		$p = is_wp_error( $r ) ? array() : preg_split( '/\s+/', trim( $r['out'] ) );
		$n = function ( $v ) { return ctype_digit( (string) $v ) ? (int) $v : 0; };
		return array( 'soft' => $n( $p[0] ?? '' ), 'hard' => $n( $p[1] ?? '' ) );
	}

	/** "v=1048576 vh=2097152 …" written by spawn() → readable text in MB. */
	public static function limits_text( $dir ) {
		$t = trim( self::read( $dir, 'limits.txt' ) );
		if ( ! preg_match( '/v=(\S+) vh=(\S+)/', $t, $m ) ) {
			return '';
		}
		$mb = function ( $v ) { return ctype_digit( $v ) ? round( (int) $v / 1024 ) . ' MB' : 'نامحدود'; };
		return 'سقف حافظه مجازی برنامه روی هاست: ' . $mb( $m[1] ) . ' (حداکثر مجاز حساب: ' . $mb( $m[2] ) . ')';
	}
}
