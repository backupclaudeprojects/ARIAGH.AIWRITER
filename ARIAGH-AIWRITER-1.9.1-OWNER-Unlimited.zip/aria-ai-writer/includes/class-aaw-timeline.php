<?php
/**
 * Timeline: what the AI did (past), is doing (now) and will do (future, with times and topics).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Timeline {

	/** Upcoming run times (UTC timestamps) honouring schedule, interval gating and daily limit. */
	public static function future_times( $count = 12 ) {
		$s     = AAW_Settings::all();
		$exprs = AAW_Cloudflare::schedule_expressions();
		if ( empty( $exprs ) ) {
			return array();
		}
		$gate = AAW_Cloudflare::needs_gating() ? (int) $s['interval_hours'] * HOUR_IN_SECONDS - 600 : 0;
		$last = AAW_Logs::last( 'draft', 'success' );
		$prev = $last ? strtotime( $last['created_at'] . ' UTC' ) : 0;
		$from = time();
		$out  = array();
		$per_day = array();
		for ( $i = 0; $i < 500 && count( $out ) < $count; $i++ ) {
			$best = 0;
			foreach ( $exprs as $e ) {
				$t = AAW_Cloudflare::next_from_expr( $e, $from );
				if ( $t && ( ! $best || $t < $best ) ) {
					$best = $t;
				}
			}
			if ( ! $best ) {
				break;
			}
			$from = $best;
			if ( $gate && $prev && $best - $prev < $gate ) {
				continue;
			}
			$day = gmdate( 'Y-m-d', $best );
			if ( $s['daily_limit'] > 0 && ( $per_day[ $day ] ?? 0 ) >= $s['daily_limit'] ) {
				continue;
			}
			$per_day[ $day ] = ( $per_day[ $day ] ?? 0 ) + (int) $s['posts_per_run'];
			$out[]           = $best;
			$prev            = $best;
		}
		return $out;
	}

	/** Topics in the exact order the generator will claim them. */
	public static function upcoming_topics( $limit = 200 ) {
		global $wpdb;
		$s        = AAW_Settings::all();
		$t        = AAW_Topics::table();
		$statuses = $s['retry_failed'] ? "'pending','failed'" : "'pending'";
		return $wpdb->get_results( $wpdb->prepare( "SELECT id, title, keywords, priority, status, source, category_id, word_count FROM {$t} WHERE status IN ({$statuses}) AND attempts < %d ORDER BY (status = 'failed') ASC, priority DESC, position ASC, id ASC LIMIT %d", (int) $s['max_attempts'], (int) $limit ), ARRAY_A ); // phpcs:ignore
	}

	public static function future( $runs = 12 ) {
		$s      = AAW_Settings::all();
		$times  = self::future_times( $runs );
		$topics = self::upcoming_topics();
		$per    = max( 1, (int) $s['posts_per_run'] );
		$out    = array();
		$i      = 0;
		foreach ( $times as $ts ) {
			$items = array();
			for ( $k = 0; $k < $per; $k++ ) {
				if ( isset( $topics[ $i ] ) ) {
					$tp      = $topics[ $i ];
					$items[] = array(
						'id'       => (int) $tp['id'],
						'title'    => $tp['title'],
						'keywords' => $tp['keywords'],
						'priority' => (int) $tp['priority'],
						'retry'    => 'failed' === $tp['status'],
						'ai'       => 'ai' === $tp['source'],
						'category' => $tp['category_id'] ? get_cat_name( (int) $tp['category_id'] ) : '',
					);
					++$i;
				} elseif ( $s['auto_topics'] ) {
					$items[] = array( 'id' => 0, 'title' => 'موضوع جدید با ایده‌پردازی خودکار هوش مصنوعی', 'idea' => true );
				}
			}
			if ( ! $items ) {
				break;
			}
			$out[] = array( 'ts' => $ts, 'items' => $items );
		}
		return array(
			'runs'      => $out,
			'remaining' => max( 0, count( $topics ) - $i ),
			'paused'    => (bool) $s['paused'] || ! $s['enabled'],
			'empty'     => empty( $topics ) && ! $s['auto_topics'],
		);
	}

	public static function past( $limit = 60 ) {
		$posts = get_posts(
			array(
				'post_type'      => 'any',
				'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
				'meta_key'       => '_aaw_generated',
				'posts_per_page' => $limit,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'no_found_rows'  => true,
			)
		);
		$out = array();
		foreach ( $posts as $p ) {
			$gen   = (int) get_post_meta( $p->ID, '_aaw_generated_at', true );
			$out[] = array(
				'ts'       => $gen ? $gen : get_post_timestamp( $p ),
				'id'       => $p->ID,
				'title'    => $p->post_title,
				'status'   => $p->post_status,
				'words'    => (int) get_post_meta( $p->ID, '_aaw_word_count', true ),
				'keyword'  => get_post_meta( $p->ID, '_aaw_focus_keyword', true ),
				'model'    => get_post_meta( $p->ID, '_aaw_model', true ),
				'edit'     => get_edit_post_link( $p->ID, 'raw' ),
				'view'     => 'publish' === $p->post_status ? get_permalink( $p ) : get_preview_post_link( $p ),
				'thumb'    => get_the_post_thumbnail_url( $p, 'thumbnail' ),
			);
		}
		// Recent failures (from the log) so the history is honest.
		$fails = AAW_Logs::query( array( 'level' => 'error', 'event' => 'run', 'per_page' => 15 ) );
		foreach ( $fails['items'] as $f ) {
			$out[] = array(
				'ts'     => strtotime( $f['created_at'] . ' UTC' ),
				'id'     => 0,
				'title'  => $f['message'],
				'status' => 'failed',
			);
		}
		usort(
			$out,
			function ( $a, $b ) {
				return $b['ts'] <=> $a['ts'];
			}
		);
		return array_slice( $out, 0, $limit );
	}

	/** What is happening right now, in plain words. */
	public static function now() {
		global $wpdb;
		$t          = AAW_Topics::table();
		$processing = $wpdb->get_col( "SELECT title FROM {$t} WHERE status = 'processing' ORDER BY locked_at DESC LIMIT 5" ); // phpcs:ignore
		$pending    = get_option( AAW_Pull::PENDING, array() );
		$analysis   = get_option( 'aaw_analysis_pending' );
		$last       = AAW_Logs::query( array( 'per_page' => 1 ) );
		$s          = AAW_Settings::all();
		$state      = 'idle';
		$text       = 'آماده؛ منتظر نوبت بعدی.';
		if ( ! $s['enabled'] ) {
			$state = 'off';
			$text  = 'تولید خودکار خاموش است.';
		} elseif ( $s['paused'] ) {
			$state = 'paused';
			$text  = 'زمان‌بندی متوقف است؛ فقط تولید دستی انجام می‌شود.';
		}
		if ( $processing ) {
			$state = 'working';
			$text  = 'هوش مصنوعی در حال نوشتن: «' . $processing[0] . '»' . ( count( $processing ) > 1 ? ' و ' . ( count( $processing ) - 1 ) . ' مورد دیگر' : '' );
		} elseif ( $analysis ) {
			$state = 'working';
			$text  = 'در حال تحلیل هوشمند سایت و رقبا…';
		} elseif ( ! empty( $pending ) ) {
			$state = 'working';
			$text  = 'اجرا در GitHub در جریان است؛ نتیجه به‌زودی دریافت می‌شود.';
		}
		$future = self::future( 1 );
		$next   = $future['runs'][0] ?? null;
		return array(
			'state'   => $state,
			'text'    => $text,
			'next'    => $next,
			'last'    => $last['items'][0] ?? null,
			'engine'  => ( AAW_Providers::get( $s['provider'] )['name'] ?? $s['provider'] ),
			'mode'    => AAW_Pull::active() ? 'local' : 'public',
		);
	}
}
