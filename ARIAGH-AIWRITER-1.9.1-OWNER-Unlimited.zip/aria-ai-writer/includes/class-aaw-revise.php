<?php
/**
 * Editor ↔ AI loop on generated posts:
 *  - "comment for the AI": revision instructions applied to the existing article,
 *    result saved back to the same post as a draft ready to publish again;
 *  - "new image only": regenerate the featured image (text untouched) from the
 *    editor's own image description.
 * Runs as a Cloudflare background job (API engines) or a GitHub Actions run
 * (subscription engines); results arrive through the KV mailbox (AAW_Pull::poll).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Revise {

	const META_HISTORY = '_aaw_revisions';
	const META_STATE   = '_aaw_ai_state';

	/* ---------------------------------------------------------------- */

	/** Article view of a post that the AI can edit (TOC/FAQ markup removed, FAQ as data). */
	public static function article_from_post( $post_id ) {
		$p    = get_post( $post_id );
		$html = (string) $p->post_content;
		$faq  = array();
		if ( preg_match_all( '#<details class="aaw-faq-item"[^>]*>\s*<summary>(.*?)</summary>\s*<div class="aaw-faq-answer">(.*?)</div>\s*</details>#is', $html, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $f ) {
				$faq[] = array( 'question' => wp_strip_all_tags( $f[1] ), 'answer' => trim( $f[2] ) );
			}
		}
		$html = preg_replace( '#<details class="aaw-toc"[^>]*>.*?</details>|<nav class="aaw-toc"[^>]*>.*?</nav>#is', '', $html );
		$html = preg_replace( '#<h2 id="faq">.*?</h2>\s*<div class="aaw-faq">.*$#is', '', $html );
		$html = trim( $html );
		return array(
			'title'            => get_the_title( $post_id ),
			'seo_title'        => (string) get_post_meta( $post_id, '_aaw_seo_title', true ),
			'meta_description' => (string) get_post_meta( $post_id, '_aaw_meta_description', true ),
			'focus_keyword'    => (string) get_post_meta( $post_id, '_aaw_focus_keyword', true ),
			'excerpt'          => (string) $p->post_excerpt,
			'content_html'     => $html,
			'faq'              => $faq,
		);
	}

	public static function prompts( $post_id, $instructions ) {
		$article = self::article_from_post( $post_id );
		$system  = AAW_Knowledge::prompt_block()
			. "تو ویراستار ارشد سئو و فروش این سایت هستی. فقط اصلاحاتی را که مدیر خواسته دقیق و کامل اعمال کن؛ بقیه مقاله (ساختار، لینک‌ها به‌خصوص لینک محصولات، کلمه کلیدی، لحن و طول) را حفظ کن مگر اینکه خلافش خواسته شده باشد. فارسی معیار با نیم‌فاصله درست. بدون ادعای نادرست.\n"
			. AAW_Products::prompt_block( $article['title'], $article['focus_keyword'] )
			. "\n## فرمت خروجی\n" . AAW_Prompt::output_schema();
		$user    = "دستور اصلاح مدیر:\n" . $instructions . "\n\nمقاله فعلی (JSON):\n" . wp_json_encode( $article, JSON_UNESCAPED_UNICODE ) . "\n\nمقاله کامل اصلاح‌شده را فقط به شکل JSON برگردان.";
		return array( 'system' => $system, 'prompt' => $user );
	}

	/** Runtime chain without subscription runners (the worker can't call those). */
	private static function api_runtime() {
		$rt = AAW_REST::runtime();
		$rt['providers'] = array_values(
			array_filter(
				(array) $rt['providers'],
				function ( $p ) {
					return 'github_runner' !== ( $p['format'] ?? '' );
				}
			)
		);
		return $rt;
	}

	private static function uses_subscription_text() {
		$p = AAW_Providers::get( AAW_Settings::get( 'provider' ) );
		return $p && 'github_runner' === $p['format'];
	}

	private static function set_state( $post_id, $state, $note = '' ) {
		update_post_meta( $post_id, self::META_STATE, array( 'state' => $state, 'note' => $note, 't' => time() ) );
	}

	/** Queue a GitHub Actions task (subscription engines): payload in KV, result via mailbox. */
	private static function github_task( $trigger, array $payload, $engine, $post_id ) {
		if ( AAW_Local::is_local( $engine ) ) {
			return AAW_Local::start( $trigger, $engine, $payload, array( 'post_id' => (int) $post_id, 'kind' => $trigger ) );
		}
		if ( ! AAW_GitHub::is_connected() ) {
			return new WP_Error( 'aaw', AAW_Errors::format( 'GitHub متصل نیست', 'این کار با اکانت اشتراکی از طریق GitHub Actions انجام می‌شود.', 'در تب «اکانت اشتراکی» GitHub را وصل کنید.' ) );
		}
		$id = AAW_BG::new_id( substr( $trigger, 0, 1 ) );
		$q  = AAW_Cloudflare::call_worker( 'queue_put', array( 'id' => $id, 'payload' => $payload ), 40 );
		if ( is_wp_error( $q ) ) {
			return $q;
		}
		$d = AAW_GitHub::dispatch( $trigger, 0, $engine, $id );
		if ( is_wp_error( $d ) ) {
			return $d;
		}
		$pending        = get_option( AAW_Pull::PENDING, array() );
		$pending        = is_array( $pending ) ? $pending : array();
		$pending[ $id ] = array( 'time' => time(), 'topics' => array(), 'kind' => $trigger, 'post_id' => (int) $post_id );
		update_option( AAW_Pull::PENDING, $pending, false );
		AAW_Pull::schedule_bg_poll();
		AAW_Activity::start( $trigger, ( 'image' === $trigger ? 'ساخت تصویر با اکانت اشتراکی ChatGPT: ' : 'اصلاح مقاله با اکانت اشتراکی: ' ) . get_the_title( $post_id ), array( 'github' => $id, 'url' => AAW_GitHub::repo_url() . '/actions' ) );
		return $id;
	}

	/* ------------------------------- revise ------------------------------- */

	/** @return string|WP_Error job id */
	public static function request_revision( $post_id, $instructions ) {
		$post_id      = absint( $post_id );
		$instructions = trim( sanitize_textarea_field( $instructions ) );
		if ( ! $post_id || ! get_post( $post_id ) ) {
			return new WP_Error( 'aaw', 'نوشته پیدا نشد.' );
		}
		if ( mb_strlen( $instructions ) < 3 ) {
			return new WP_Error( 'aaw', 'دستور اصلاح را بنویسید (مثلاً: «پاراگراف دوم کوتاه‌تر شود و یک جدول مقایسه قیمت اضافه کن»).' );
		}
		$p          = self::prompts( $post_id, $instructions );
		$request_id = wp_generate_password( 8, false, false );
		$id         = self::dispatch_rewrite( $post_id, $p, $request_id );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$hist   = (array) get_post_meta( $post_id, self::META_HISTORY, true );
		$hist   = array_filter( $hist );
		$hist[] = array( 'id' => $request_id, 'job' => $id, 'text' => $instructions, 'user' => get_current_user_id(), 't' => time(), 'status' => 'pending' );
		update_post_meta( $post_id, self::META_HISTORY, array_slice( $hist, -20 ) );
		self::set_state( $post_id, 'revising', $instructions );
		AAW_Logs::add( 'info', 'revise', 'درخواست اصلاح برای «' . get_the_title( $post_id ) . '» ثبت شد: ' . mb_substr( $instructions, 0, 160 ), array( 'post_id' => $post_id ) );
		return $id;
	}

	/**
	 * Send a full-article rewrite (revise / merge) to the content engine: subscription
	 * account on GitHub, or the API engines as a Cloudflare background job.
	 */
	public static function dispatch_rewrite( $post_id, array $p, $request_id, $label = '' ) {
		$payload = array( 'post_id' => (int) $post_id, 'system' => $p['system'], 'prompt' => $p['prompt'], 'request_id' => (string) $request_id );
		if ( self::uses_subscription_text() ) {
			$prov = AAW_Providers::get( AAW_Settings::get( 'provider' ) );
			return self::github_task( 'revise', $payload, $prov['engine'] ?? 'claude', $post_id );
		}
		if ( ! AAW_BG::available() ) {
			return new WP_Error( 'aaw', AAW_Errors::format( 'این کار نیاز به ورکر به‌روز دارد', 'کارهای پس‌زمینه روی ورکر فعال نیست.', 'در تب کلادفلر «استقرار مجدد» را بزنید.' ) );
		}
		$payload['runtime'] = self::api_runtime();
		return AAW_BG::start( 'revise', $payload, true, array(), $label );
	}

	/** Apply a revision result (from the mailbox). */
	public static function apply_revision( $post_id, array $article, $request_id = '' ) {
		$post_id = absint( $post_id );
		if ( ! $post_id || ! get_post( $post_id ) ) {
			return new WP_Error( 'aaw', 'نوشته برای اعمال اصلاح پیدا نشد.' );
		}
		$meta = isset( $article['_meta'] ) ? (array) $article['_meta'] : array();
		unset( $article['_meta'] );
		if ( AAW_Merge::is_merge_request( $request_id ) ) {
			return AAW_Merge::apply( $post_id, $article, $request_id ); // Merge was explicitly confirmed by the editor.
		}
		if ( 'publish' === get_post_status( $post_id ) ) {
			// Live post: never change it silently – keep the revision until the editor publishes it.
			update_post_meta( $post_id, '_aaw_revision_pending', wp_slash( wp_json_encode( $article, JSON_UNESCAPED_UNICODE ) ) );
			self::set_state( $post_id, 'revision_ready' );
			self::mark_history( $post_id, $request_id, $meta );
			AAW_Logs::add( 'success', 'revise', 'نسخه اصلاح‌شده «' . get_the_title( $post_id ) . '» آماده است؛ با «انتشار اصلاحات» روی نوشته منتشرشده اعمال می‌شود.', array( 'post_id' => $post_id ) );
			return true;
		}
		$r = AAW_Post_Builder::update_from_article( $post_id, $article );
		if ( is_wp_error( $r ) ) {
			self::set_state( $post_id, 'error', $r->get_error_message() );
			return $r;
		}
		self::mark_history( $post_id, $request_id, $meta );
		self::set_state( $post_id, 'revised' );
		delete_transient( 'aaw_pending_review' );
		AAW_Logs::add( 'success', 'revise', 'اصلاحات روی «' . get_the_title( $post_id ) . '» اعمال شد و آماده بازبینی/انتشار است.', array( 'post_id' => $post_id, 'provider' => $meta['provider'] ?? '' ) );
		return true;
	}

	private static function mark_history( $post_id, $request_id, array $meta ) {
		$hist = (array) get_post_meta( $post_id, self::META_HISTORY, true );
		foreach ( $hist as &$h ) {
			if ( is_array( $h ) && ( '' === $request_id || ( $h['id'] ?? '' ) === $request_id ) && 'pending' === ( $h['status'] ?? '' ) ) {
				$h['status'] = 'done';
				$h['done']   = time();
				$h['engine'] = $meta['provider'] ?? '';
			}
		}
		unset( $h );
		update_post_meta( $post_id, self::META_HISTORY, array_filter( $hist ) );
	}

	/** Publish a pending revision onto a live post. */
	public static function publish_pending( $post_id ) {
		$raw = get_post_meta( $post_id, '_aaw_revision_pending', true );
		$a   = $raw ? json_decode( $raw, true ) : null;
		if ( ! is_array( $a ) ) {
			return new WP_Error( 'aaw', 'نسخه اصلاح‌شده‌ای برای این نوشته وجود ندارد.' );
		}
		$r = AAW_Post_Builder::update_from_article( $post_id, $a );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		delete_post_meta( $post_id, '_aaw_revision_pending' );
		self::set_state( $post_id, 'revised' );
		AAW_Logs::add( 'success', 'revise', 'اصلاحات روی نوشته منتشرشده «' . get_the_title( $post_id ) . '» اعمال شد.', array( 'post_id' => $post_id ) );
		return true;
	}

	/* ------------------------------- image only ------------------------------- */

	/** Regenerate the image(s) of an existing post; text stays as it is. */
	public static function request_image( $post_id, $prompt = '', $inline = false, $engine = '' ) {
		$post_id = absint( $post_id );
		$post    = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error( 'aaw', 'نوشته پیدا نشد.' );
		}
		$prompt  = trim( sanitize_textarea_field( $prompt ) );
		$title   = get_the_title( $post_id );
		$kw      = (string) get_post_meta( $post_id, '_aaw_focus_keyword', true );
		preg_match_all( '#<h2[^>]*>.*?</h2>#is', (string) $post->post_content, $h2s );
		// Only the H2 headings are needed (inline image placement) → tiny request from the host.
		$heads   = array_map( function ( $h ) { return '<h2>' . wp_strip_all_tags( $h ) . '</h2>'; }, $h2s[0] );
		$article = array( 'title' => $title, 'image_prompt' => $prompt ? $prompt : $title, 'content_html' => implode( "\n", $heads ) );
		$refs    = AAW_Images::references_for( array( 'title' => $title, 'keywords' => $kw ) );
		$engine  = $engine ? $engine : AAW_Images::engine();
		$cfg     = $engine === AAW_Images::engine() ? AAW_Images::runtime() : AAW_Images::runtime( $engine );
		$cfg['inline_count'] = $inline ? (int) AAW_Settings::get( 'image_inline_count' ) : 0;
		update_post_meta( $post_id, '_aaw_image_prompt', $prompt );

		if ( 'sub_codex' === $engine ) {
			$inl = array();
			if ( $cfg['inline_count'] ) {
				preg_match_all( '#<h2[^>]*>(.*?)</h2>#is', $article['content_html'], $hs );
				$n = min( (int) $cfg['inline_count'], count( $hs[1] ) );
				for ( $i = 0; $i < $n; $i++ ) {
					$h     = wp_strip_all_tags( $hs[1][ $i ] );
					$inl[] = array( 'prompt' => $article['image_prompt'] . '. Scene for the section: ' . $h, 'alt' => $h, 'after_h2' => $i );
				}
			}
			$payload         = array( 'post_id' => $post_id, 'prompt' => self::full_image_prompt( $article['image_prompt'], $refs ), 'refs' => AAW_Images::refs_for_remote( $refs ), 'inline' => $inl, 'replace_inline' => (bool) $inline );
			$payload['chat'] = AAW_Local::image_message( $payload, $payload['prompt'], count( $payload['refs']['products'] ) + count( $payload['refs']['styles'] ) ); // The editable message, for the GitHub runner too.
			$id      = self::github_task( 'image', $payload, 'codex', $post_id );
		} else {
			if ( ! AAW_BG::available() ) {
				return new WP_Error( 'aaw', AAW_Errors::format( 'ساخت تصویر نیاز به ورکر به‌روز دارد', 'کارهای پس‌زمینه روی ورکر فعال نیست.', 'در تب کلادفلر «استقرار مجدد» را بزنید.' ) );
			}
			$id = AAW_BG::start( 'post_image', array( 'post_id' => $post_id, 'cfg' => $cfg, 'article' => $article, 'refs' => $refs, 'replace_inline' => (bool) $inline ), true );
		}
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		self::set_state( $post_id, 'imaging', $prompt );
		AAW_Logs::add( 'info', 'image', 'ساخت تصویر جدید برای «' . $title . '» شروع شد' . ( $prompt ? ': ' . mb_substr( $prompt, 0, 140 ) : '.' ), array( 'post_id' => $post_id ) );
		return $id;
	}

	/** Prompt text for engines that only get one string (subscription image engine). */
	public static function full_image_prompt( $base, array $refs ) {
		$parts = array( $base );
		$theme = AAW_Images::runtime()['theme'];
		if ( ! empty( $refs['product_names'] ) ) {
			$parts[] = 'Products to show exactly as in the reference photos: ' . implode( ', ', $refs['product_names'] ) . '.';
		}
		if ( $theme ) {
			$parts[] = 'Site visual theme: ' . $theme;
		}
		$style = (string) AAW_Settings::get( 'image_style' );
		if ( $style ) {
			$parts[] = $style;
		}
		return implode( ' ', $parts );
	}

	/** Apply an image result (featured, optional inline set). */
	public static function apply_image( $post_id, $image, array $inline = array(), $replace_inline = false ) {
		$post_id = absint( $post_id );
		if ( ! $post_id || ! get_post( $post_id ) || empty( $image ) ) {
			return new WP_Error( 'aaw', 'تصویر یا نوشته معتبر نیست.' );
		}
		$a     = array( 'focus_keyword' => (string) get_post_meta( $post_id, '_aaw_focus_keyword', true ), 'image_alt' => get_the_title( $post_id ) );
		$att   = AAW_Post_Builder::attach_image( $post_id, (array) $image, $a, get_the_title( $post_id ), true );
		if ( is_wp_error( $att ) ) {
			self::set_state( $post_id, 'error', $att->get_error_message() );
			return $att;
		}
		if ( $inline ) {
			$content = (string) get_post_field( 'post_content', $post_id );
			if ( $replace_inline ) {
				$content = preg_replace( '#\s*<figure class="wp-block-image size-large aaw-inline-image">.*?</figure>\s*#is', "\n", $content );
			}
			$figs = array();
			foreach ( array_slice( $inline, 0, 4 ) as $im ) {
				if ( empty( $im['base64'] ) ) {
					continue;
				}
				$alt = sanitize_text_field( $im['alt'] ?? '' );
				$id  = AAW_Post_Builder::attach_image( $post_id, $im, array( 'image_alt' => $alt, 'focus_keyword' => $a['focus_keyword'] ), $alt, false );
				if ( ! is_wp_error( $id ) ) {
					$figs[ (int) ( $im['after_h2'] ?? 0 ) ] = "\n" . '<figure class="wp-block-image size-large aaw-inline-image">' . wp_get_attachment_image( $id, 'large', false, array( 'loading' => 'lazy', 'decoding' => 'async' ) ) . '</figure>' . "\n";
				}
			}
			if ( $figs || $replace_inline ) {
				kses_remove_filters();
				wp_update_post( array( 'ID' => $post_id, 'post_content' => AAW_Images::insert_inline( $content, $figs ) ) );
				kses_init_filters();
			}
		}
		self::set_state( $post_id, 'image_ready' );
		AAW_Logs::add( 'success', 'image', 'تصویر جدید برای «' . get_the_title( $post_id ) . '» ثبت شد (متن بدون تغییر).', array( 'post_id' => $post_id ) );
		return $att;
	}

	/**
	 * After a new draft: subscription image engine runs as its own GitHub task; if the API
	 * image engines all failed and ChatGPT is later in the image priority list, it takes over.
	 */
	public static function after_draft( $post_id, $article, array $meta = array() ) {
		if ( ! AAW_Settings::get( 'featured_image' ) || has_post_thumbnail( $post_id ) ) {
			return;
		}
		if ( 'sub_codex' !== AAW_Images::engine() ) {
			if ( ! empty( $meta['image_error'] ) && empty( $article['image'] ) ) {
				self::image_retry( $post_id, (string) ( $article['image_prompt'] ?? '' ), (string) $meta['image_error'] );
			}
			return;
		}
		$r = self::request_image( $post_id, (string) ( $article['image_prompt'] ?? '' ), (int) AAW_Settings::get( 'image_inline_count' ) > 0 );
		if ( is_wp_error( $r ) ) {
			AAW_Logs::add( 'error', 'image', 'ساخت تصویر با اکانت اشتراکی شروع نشد: ' . $r->get_error_message(), array( 'post_id' => $post_id ) );
		}
	}

	/**
	 * The article arrived without its image: show why, and make the image again once
	 * (separately, so a slow or failed image never blocks the article).
	 */
	public static function image_retry( $post_id, $prompt, $error ) {
		$fatal = (bool) preg_match( '/Secrets|یافت نشد|not found in|invalid[_ ]api[_ ]key|incorrect api key|401|403|billing|quota|insufficient|credit|balance|not_enough|payment|402|Base URL/i', $error );
		if ( $fatal || get_transient( 'aaw_imgretry_' . $post_id ) ) {
			self::set_state( $post_id, 'image_error', AAW_Errors::explain( $error ) );
			if ( ! $fatal ) {
				return;
			}
			// Key / billing problem: next engine of the priority list, if any.
			if ( AAW_Priority::image_failover( $post_id, $prompt, (int) AAW_Settings::get( 'image_inline_count' ) > 0 ) ) {
				return;
			}
			$chain = array_slice( AAW_Priority::image_chain(), 1 );
			$next  = array_values( array_diff( $chain, array( 'sub_codex' ) ) );
			if ( ! $next && AAW_Settings::get( 'image_free_fallback' ) && AAW_Settings::get( 'bind_workers_ai' ) && 'workers_ai' !== AAW_Images::engine() ) {
				$next = array( 'workers_ai' ); // Free last resort.
			}
			if ( ! $next || get_transient( 'aaw_imgretry_' . $post_id ) ) {
				return;
			}
			set_transient( 'aaw_imgretry_' . $post_id, 1, HOUR_IN_SECONDS );
			$r = self::request_image( $post_id, $prompt, false, $next[0] );
			if ( ! is_wp_error( $r ) ) {
				self::set_state( $post_id, 'imaging', 'موتور اول خطا داد: ' . mb_substr( AAW_Errors::explain( $error ), 0, 300 ) . ' — با موتور بعدی ساخته می‌شود.' );
				AAW_Logs::add( 'info', 'image', 'موتور اول تصویر نتوانست (' . mb_substr( $error, 0, 120 ) . ')؛ تصویر با موتور بعدی لیست ساخته می‌شود.', array( 'post_id' => $post_id ) );
			}
			return;
		}
		set_transient( 'aaw_imgretry_' . $post_id, 1, HOUR_IN_SECONDS );
		if ( AAW_Priority::image_failover( $post_id, $prompt, false ) ) {
			return;
		}
		$r = self::request_image( $post_id, $prompt, false );
		if ( is_wp_error( $r ) ) {
			// Starting the retry failed (e.g. the host cut the connection): show the real image
			// reason, and try again a bit later in a fresh request.
			self::set_state( $post_id, 'image_error', AAW_Errors::explain( $error ) );
			wp_schedule_single_event( time() + 90, 'aaw_image_retry', array( (int) $post_id, (string) $prompt ) );
			AAW_Logs::add( 'warning', 'image', 'شروع ساخت دوباره تصویر فعلاً ممکن نشد؛ ۹۰ ثانیه دیگر خودکار دوباره تلاش می‌شود: ' . $r->get_error_message(), array( 'post_id' => $post_id ) );
			return;
		}
		AAW_Logs::add( 'info', 'image', 'مقاله بدون تصویر رسید (' . mb_substr( $error, 0, 120 ) . ')؛ تصویر جداگانه دوباره ساخته می‌شود و چند دقیقه دیگر به همین مقاله اضافه می‌شود.', array( 'post_id' => $post_id ) );
	}

	/** Cron: delayed image retry (fresh PHP request). */
	public static function cron_image_retry( $post_id, $prompt = '' ) {
		$post_id = absint( $post_id );
		if ( ! $post_id || has_post_thumbnail( $post_id ) || (int) get_transient( 'aaw_imgcron_' . $post_id ) >= 3 ) {
			return;
		}
		set_transient( 'aaw_imgcron_' . $post_id, (int) get_transient( 'aaw_imgcron_' . $post_id ) + 1, DAY_IN_SECONDS );
		$r = self::request_image( $post_id, $prompt, false );
		if ( is_wp_error( $r ) ) {
			wp_schedule_single_event( time() + 300, 'aaw_image_retry', array( $post_id, (string) $prompt ) );
		}
	}

	public static function state( $post_id ) {
		$s = get_post_meta( $post_id, self::META_STATE, true );
		return is_array( $s ) ? $s : array();
	}
}
