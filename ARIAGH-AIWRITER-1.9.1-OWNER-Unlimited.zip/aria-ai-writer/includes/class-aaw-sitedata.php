<?php
/**
 * Site database on GitHub.
 *
 * "Site analysis" and "SEO knowledge" no longer make the host upload anything: the host
 * sends ONE tiny request (queue + GitHub dispatch), then GitHub Actions reads the public
 * site itself (WordPress REST API / WooCommerce Store API, sitemap fallback), keeps a
 * complete text backup on the private branch "aaw-data" (replaced on every run), and
 * sends a compact index to Cloudflare. Every AI engine then sees the real product,
 * category and article links from there – for internal links and to avoid duplicates.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_SiteData {

	const OPTION = 'aaw_site_data';
	const BRANCH = 'aaw-data';

	/** GitHub mode is used when GitHub + the worker are connected (setting "site_source"). */
	/** A subscription account set to "direct from this server" handles site analysis & SEO learning. */
	public static function local_engine() {
		$e = self::engine();
		return ( 'none' !== $e && AAW_Local::is_local( $e ) ) ? $e : '';
	}

	public static function available() {
		$src = (string) AAW_Settings::get( 'site_source', 'auto' );
		return 'local' !== $src && AAW_GitHub::is_connected() && AAW_Cloudflare::is_deployed();
	}

	public static function get() {
		$d = get_option( self::OPTION, array() );
		return is_array( $d ) ? $d : array();
	}

	/** Subscription engine for jobs on GitHub: first subscription account in the content list, else none. */
	public static function engine() {
		foreach ( AAW_Priority::text_chain() as $id ) {
			$p = AAW_Providers::get( $id );
			if ( $p && 'github_runner' === $p['format'] && AAW_Priority::text_ready( $id )[0] ) {
				return ! empty( $p['engine'] ) ? $p['engine'] : 'claude';
			}
		}
		return 'none';
	}

	public static function branch_url( $path = '' ) {
		return AAW_GitHub::repo_url() . '/tree/' . self::BRANCH . ( $path ? '/' . ltrim( $path, '/' ) : '' );
	}

	/** Queue a job in Cloudflare KV and start the GitHub workflow (both tiny requests). */
	private static function task( $trigger, array $payload, $label ) {
		if ( ! AAW_GitHub::is_connected() ) {
			return new WP_Error( 'aaw', AAW_Errors::format( 'GitHub متصل نیست', 'خواندن سایت و ساخت دیتابیس روی GitHub انجام می‌شود.', 'در تب «اکانت اشتراکی» مرحله اتصال GitHub را انجام دهید.' ) );
		}
		$engine = self::engine();
		$id     = AAW_BG::new_id( 'c' === substr( $trigger, 0, 1 ) ? 'g' : 's' );
		$payload['runtime'] = AAW_REST::runtime();
		$q = AAW_Cloudflare::call_worker( 'queue_put', array( 'id' => $id, 'payload' => $payload ), 40 );
		if ( is_wp_error( $q ) ) {
			return $q;
		}
		$d = AAW_GitHub::dispatch( $trigger, 0, $engine, $id );
		if ( is_wp_error( $d ) ) {
			return $d;
		}
		$pending        = get_option( AAW_Pull::PENDING, array() );
		$pending        = is_array( $pending ) ? $pending : array();
		$pending[ $id ] = array( 'time' => time(), 'topics' => array(), 'kind' => $trigger );
		update_option( AAW_Pull::PENDING, $pending, false );
		AAW_Pull::schedule_bg_poll();
		AAW_Activity::start( 'crawl' === $trigger ? 'analyze' : 'seo', $label, array( 'github' => $id, 'url' => AAW_GitHub::repo_url() . '/actions' ) );
		AAW_Logs::add( 'info', 'crawl' === $trigger ? 'analysis' : 'seo', $label . ' (GitHub' . ( 'none' === $engine ? ' + هوش مصنوعی‌های API کلادفلر' : ' + اکانت اشتراکی ' . ( 'codex' === $engine ? 'ChatGPT' : 'Claude' ) ) . ')' );
		return array( 'id' => $id, 'engine' => $engine );
	}

	/**
	 * Back up the whole site on GitHub and (optionally) run the strategy analysis there.
	 *
	 * @param array|null $analyze { system, prompt, competitors, web, stats } – prompt WITHOUT site data.
	 */
	public static function start_crawl( $analyze = null ) {
		$payload = array( 'site' => untrailingslashit( home_url() ), 'analyze' => $analyze );
		$r       = self::task( 'crawl', $payload, $analyze ? 'تحلیل سایت: GitHub کل سایت را می‌خواند، نسخه پشتیبان می‌سازد و تحلیل می‌کند' : 'به‌روزرسانی نسخه پشتیبان سایت در GitHub' );
		if ( ! is_wp_error( $r ) ) {
			update_option( 'aaw_site_crawl', array( 'id' => $r['id'], 't' => time() ), false );
			delete_option( 'aaw_site_data_error' );
		}
		return $r;
	}

	public static function start_seo() {
		$p      = AAW_Knowledge::payload();
		$engine = self::engine();
		if ( 'none' !== $engine && AAW_Local::is_local( $engine ) ) {
			unset( $p['runtime'] );
			$id = AAW_Local::start( 'seo_learn', $engine, $p, array( 'kind' => 'seo_learn' ) );
			if ( ! is_wp_error( $id ) ) {
				update_option( 'aaw_seo_learning', array( 'id' => $id, 't' => time(), 'local' => true ), false );
				return array( 'id' => $id, 'engine' => $engine, 'local' => true );
			}
			return $id;
		}
		unset( $p['runtime'] );
		$r = self::task( 'seo_learn', $p, 'ساخت دیتابیس دانش سئو در GitHub' );
		if ( ! is_wp_error( $r ) ) {
			update_option( 'aaw_seo_learning', array( 'id' => $r['id'], 't' => time(), 'github' => true ), false );
		}
		return $r;
	}

	/** Result of a crawl (from the mailbox). */
	public static function save( array $r ) {
		$counts = array_map( 'absint', (array) ( $r['counts'] ?? array() ) );
		update_option(
			self::OPTION,
			array(
				'crawled_at' => sanitize_text_field( (string) ( $r['crawled_at'] ?? '' ) ),
				'at'         => time(),
				'source'     => 'sitemap' === ( $r['source'] ?? '' ) ? 'sitemap' : 'rest',
				'counts'     => $counts,
				'notes'      => array_map( 'sanitize_text_field', array_slice( (array) ( $r['notes'] ?? array() ), 0, 8 ) ),
				'files'      => absint( $r['files'] ?? 0 ),
				'kv'         => ! empty( $r['kv'] ),
			),
			false
		);
		delete_option( 'aaw_site_crawl' );
		AAW_Logs::add( 'success', 'analysis', sprintf( 'نسخه پشتیبان سایت در GitHub به‌روز شد: %d مقاله، %d محصول، %d برگه، %d دسته. هوش مصنوعی از این پس لینک‌ها و مقالات قبلی را از آنجا می‌بیند.', $counts['posts'] ?? 0, $counts['products'] ?? 0, $counts['pages'] ?? 0, $counts['categories'] ?? 0 ) );
		return true;
	}

	public static function crawling() {
		$c = get_option( 'aaw_site_crawl' );
		return is_array( $c ) && ( time() - (int) ( $c['t'] ?? 0 ) ) < 2 * HOUR_IN_SECONDS;
	}

	/** Short status for the UI. */
	public static function status() {
		$d = self::get();
		return array(
			'available' => self::available(),
			'crawling'  => self::crawling(),
			'data'      => $d,
			'ago'       => ! empty( $d['at'] ) ? human_time_diff( (int) $d['at'] ) : '',
			'error'     => (string) get_option( 'aaw_site_data_error', '' ),
			'url'       => AAW_GitHub::is_connected() ? self::branch_url( 'site' ) : '',
			'engine'    => self::available() ? self::engine() : '',
		);
	}
}
