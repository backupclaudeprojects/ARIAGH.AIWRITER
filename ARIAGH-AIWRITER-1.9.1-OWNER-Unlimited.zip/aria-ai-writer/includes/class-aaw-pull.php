<?php
/**
 * Local / Pull mode.
 *
 * For sites that the internet cannot reach (localhost, LAN, behind a firewall).
 * WordPress itself calls the Cloudflare worker (outbound only) and the worker
 * never calls WordPress. Scheduling is done by WP-Cron.
 *
 * - API providers: WordPress → worker /generate (+ /image) → draft created locally.
 * - Subscription (GitHub) mode: WordPress stores the job in Cloudflare KV, dispatches
 *   the GitHub workflow, the runner writes the result back to KV and WordPress
 *   collects it (poll).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Pull {

	const PENDING = 'aaw_pull_pending';

	public static function site_is_local() {
		$host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		if ( '' === $host || false === strpos( $host, '.' ) ) {
			return true; // localhost, machine names.
		}
		if ( preg_match( '/\.(local|localhost|test|lan|internal|home|invalid|example)$/', $host ) ) {
			return true;
		}
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return ! filter_var( $host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
		}
		return false;
	}

	public static function active() {
		$mode = AAW_Settings::get( 'connection_mode', 'push' );
		if ( 'pull' === $mode ) {
			return true;
		}
		if ( 'push' === $mode ) {
			return false;
		}
		return self::site_is_local();
	}

	private static function long_request() {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore
		}
		ignore_user_abort( true );
	}

	/**
	 * Generate articles now (API providers) or dispatch the subscription runner.
	 *
	 * @return array Summary compatible with the worker's run summary.
	 */
	public static function run_cycle( $trigger = 'manual', $topic_id = 0 ) {
		self::long_request();
		$t0      = microtime( true );
		$summary = array( 'trigger' => $trigger, 'status' => 'ok', 'drafts' => array(), 'errors' => array(), 'mode' => 'pull' );
		if ( ! AAW_Cloudflare::is_deployed() ) {
			return array( 'status' => 'skip', 'reason' => 'ورکر کلادفلر مستقر نشده است (تب کلادفلر).' ) + $summary;
		}

		$job = AAW_REST::job_data( array( 'trigger' => $trigger, 'topic_id' => (int) $topic_id ) );

		if ( isset( $job['status'] ) && 'need_topics' === $job['status'] && AAW_BG::available() ) {
			$id = AAW_BG::start( 'suggest', array( 'runtime' => $job['runtime'], 'prompt' => $job['ideas']['prompt'] ), true );
			if ( is_wp_error( $id ) ) {
				$summary['errors'][] = array( 'topic' => 'ایده‌پردازی خودکار', 'error' => $id->get_error_message() );
				$summary['status']   = 'error';
				return $summary;
			}
			return array( 'status' => 'dispatched', 'bg' => $id, 'reason' => 'صف موضوعات خالی بود؛ ایده‌پردازی خودکار روی کلادفلر شروع شد. موضوعات جدید چند دقیقه دیگر اضافه می‌شوند.' ) + $summary;
		}

		if ( isset( $job['status'] ) && 'need_topics' === $job['status'] ) {
			$r = AAW_Cloudflare::call_worker( 'suggest', array( 'runtime' => $job['runtime'], 'prompt' => $job['ideas']['prompt'] ), 300 );
			if ( is_wp_error( $r ) ) {
				$summary['errors'][] = array( 'topic' => 'ایده‌پردازی خودکار', 'error' => $r->get_error_message() );
				$summary['status']   = 'error';
				return $summary;
			}
			$added          = AAW_REST::apply_topics( array( 'topics' => $r['topics'] ) );
			$summary['ideas'] = (int) $added['added'];
			$job            = AAW_REST::job_data( array( 'trigger' => $trigger, 'no_ideas' => true ) );
		}

		if ( ! isset( $job['status'] ) || 'ok' !== $job['status'] ) {
			$summary['status'] = $job['status'] ?? 'skip';
			$summary['reason'] = $job['reason'] ?? '';
			if ( ! empty( $job['url'] ) ) {
				$summary['url'] = $job['url'];
			}
			$summary['ms'] = (int) ( ( microtime( true ) - $t0 ) * 1000 );
			return $summary;
		}

		// Preferred: one background job on Cloudflare writes all articles (and images);
		// results arrive in the KV mailbox and are turned into drafts by poll().
		if ( AAW_BG::available() ) {
			$topics = array();
			foreach ( $job['jobs'] as $j ) {
				$topics[] = (int) $j['topic']['id'];
			}
			$id = AAW_BG::start( 'generate', array( 'runtime' => $job['runtime'], 'jobs' => $job['jobs'] ), true, $topics );
			if ( is_wp_error( $id ) ) {
				foreach ( $job['jobs'] as $j ) {
					AAW_REST::apply_fail( array( 'topic_id' => $j['topic']['id'], 'error' => $id->get_error_message(), 'meta' => array( 'runner' => 'pull' ) ) );
					$summary['errors'][] = array( 'topic' => $j['topic']['title'], 'error' => $id->get_error_message() );
				}
				$summary['status'] = 'error';
				return $summary;
			}
			AAW_Logs::add( 'info', 'run', 'نوشتن ' . count( $topics ) . ' مقاله به‌صورت کار پس‌زمینه روی کلادفلر شروع شد.' );
			$summary['status'] = 'dispatched';
			$summary['bg']     = $id;
			$summary['reason'] = 'نوشتن مقاله روی کلادفلر شروع شد؛ نتیجه چند دقیقه دیگر خودکار در صف بازبینی قرار می‌گیرد.';
			$summary['ms']     = (int) ( ( microtime( true ) - $t0 ) * 1000 );
			return $summary;
		}

		foreach ( $job['jobs'] as $j ) {
			$start = microtime( true );
			$g     = AAW_Cloudflare::call_worker( 'generate', array( 'runtime' => $job['runtime'], 'job' => $j ), 900 );
			if ( is_wp_error( $g ) ) {
				AAW_REST::apply_fail( array( 'topic_id' => $j['topic']['id'], 'error' => $g->get_error_message(), 'meta' => array( 'runner' => 'pull' ) ) );
				$summary['errors'][] = array( 'topic' => $j['topic']['title'], 'error' => $g->get_error_message() );
				continue;
			}
			$article = (array) $g['article'];
			$meta    = isset( $g['meta'] ) ? (array) $g['meta'] : array();
			if ( ! empty( $job['runtime']['image']['enabled'] ) ) {
				$img = AAW_Cloudflare::call_worker( 'image', array( 'cfg' => $job['runtime']['image'], 'article' => $article, 'refs' => $j['images'] ?? array() ), 240 );
				if ( is_wp_error( $img ) ) {
					$meta['image_error'] = $img->get_error_message();
				} elseif ( ! empty( $img['image'] ) ) {
					if ( ! empty( $img['image']['inline'] ) ) {
						$article['inline_images'] = $img['image']['inline'];
						unset( $img['image']['inline'] );
					}
					$article['image'] = $img['image'];
				}
			}
			$meta['duration_ms'] = (int) ( ( microtime( true ) - $start ) * 1000 );
			$meta['runner']      = 'pull';
			$res                 = AAW_REST::apply_draft( array( 'topic_id' => $j['topic']['id'], 'article' => $article, 'meta' => $meta ) );
			if ( is_wp_error( $res ) ) {
				$summary['errors'][] = array( 'topic' => $j['topic']['title'], 'error' => $res->get_error_message() );
			} else {
				$summary['drafts'][] = array( 'topic' => $j['topic']['title'], 'post_id' => $res['post_id'], 'title' => $res['title'], 'edit_url' => $res['edit_url'] );
			}
		}
		$summary['status'] = $summary['errors'] && ! $summary['drafts'] ? 'error' : 'ok';
		$summary['ms']     = (int) ( ( microtime( true ) - $t0 ) * 1000 );
		return $summary;
	}

	/**
	 * Subscription mode on a local site: queue the job in KV and dispatch GitHub.
	 */
	public static function dispatch_subscription( $trigger, $topic_id = 0, $test_engine = '', $engine = '' ) {
		$eng = $test_engine ? $test_engine : ( $engine ? $engine : AAW_Local::default_engine() );
		if ( AAW_Local::is_local( $eng ) ) {
			// "Direct from this server": never GitHub, never Cloudflare.
			if ( $test_engine ) {
				$id = AAW_Local::start( 'test', $eng, array( 'status' => 'test' ) );
				return is_wp_error( $id ) ? array( 'status' => 'skip', 'reason' => $id->get_error_message() ) : array( 'status' => 'dispatched', 'local' => true, 'id' => $id, 'reason' => 'تست مستقیم روی همین سرور شروع شد.' );
			}
			$r = AAW_Local::start_generate( $trigger, (int) $topic_id, $eng );
			return is_wp_error( $r ) ? array( 'status' => 'skip', 'reason' => $r->get_error_message() ) : $r;
		}
		if ( ! AAW_GitHub::is_connected() ) {
			return array( 'status' => 'skip', 'reason' => 'حالت اکانت اشتراکی فعال است ولی GitHub متصل نیست.' );
		}
		if ( ! AAW_Cloudflare::is_deployed() ) {
			return array( 'status' => 'skip', 'reason' => 'در اتصال معکوس، ورکر کلادفلر برای انتقال نتیجه لازم است (تب کلادفلر).' );
		}
		if ( $test_engine ) {
			$payload = array( 'status' => 'test' );
		} else {
			$payload = AAW_REST::job_data( array( 'trigger' => 'runner', 'origin' => $trigger, 'topic_id' => (int) $topic_id ) );
			if ( ! in_array( $payload['status'] ?? '', array( 'ok', 'need_topics' ), true ) ) {
				return $payload;
			}
		}
		$id     = 'p' . time() . strtolower( wp_generate_password( 6, false, false ) );
		$topics = array();
		foreach ( (array) ( $payload['jobs'] ?? array() ) as $j ) {
			$topics[] = (int) $j['topic']['id'];
		}
		$q = AAW_Cloudflare::call_worker( 'queue_put', array( 'id' => $id, 'payload' => $payload ), 45 );
		if ( is_wp_error( $q ) ) {
			if ( $topics ) {
				AAW_Topics::bulk_status( $topics, 'pending' );
			}
			return array( 'status' => 'skip', 'reason' => 'ارسال کار به کلادفلر ناموفق بود: ' . $q->get_error_message() );
		}
		$d = AAW_GitHub::dispatch( $test_engine ? 'test' : $trigger, (int) $topic_id, $test_engine ? $test_engine : $engine, $id );
		if ( is_wp_error( $d ) ) {
			if ( $topics ) {
				AAW_Topics::bulk_status( $topics, 'pending' );
			}
			AAW_Logs::add( 'error', 'run', 'اجرای GitHub شروع نشد: ' . $d->get_error_message() );
			return array( 'status' => 'skip', 'reason' => 'اجرای GitHub شروع نشد: ' . $d->get_error_message() );
		}
		$pending        = get_option( self::PENDING, array() );
		$pending        = is_array( $pending ) ? $pending : array();
		$pending[ $id ] = array( 'time' => time(), 'topics' => $topics );
		update_option( self::PENDING, $pending, false );
		AAW_Logs::add( 'info', 'run', 'اتصال معکوس: کار در KV کلادفلر قرار گرفت و اجرای GitHub (' . $d['inputs']['engine'] . ') شروع شد.' );
		return array(
			'status' => 'dispatched',
			'reason' => 'نوشتن با اکانت اشتراکی در GitHub شروع شد. در اتصال معکوس، نتیجه را افزونه خودش از کلادفلر برمی‌دارد (هنگام باز بودن پیشخوان یا با دکمه «دریافت نتایج»).',
			'url'    => AAW_GitHub::repo_url() . '/actions',
		);
	}

	/** Collect finished results from Cloudflare KV. */
	public static function poll() {
		if ( ! AAW_Cloudflare::is_deployed() ) {
			return array( 'drafts' => 0, 'errors' => 0, 'pending' => 0 );
		}
		// Compact list: big results are only announced and then fetched in small resumable pieces.
		$r = AAW_Cloudflare::call_worker( 'result_list', array( 'compact' => true, 'inline_max' => max( 8000, min( 60000, AAW_Transfer::down_chunk() ) ) ), AAW_Transfer::PIECE_TO );
		if ( is_wp_error( $r ) ) {
			AAW_Transfer::record( 'down', 0, AAW_Transfer::PIECE_TO, false );
			return $r;
		}
		self::long_request();
		$waiting = 0;
		$pending = get_option( self::PENDING, array() );
		$pending = is_array( $pending ) ? $pending : array();
		$done    = array();
		$drafts  = 0;
		$errors  = 0;
		foreach ( (array) ( $r['items'] ?? array() ) as $item ) {
			$id   = sanitize_key( $item['id'] ?? '' );
			$data = isset( $item['data'] ) && is_array( $item['data'] ) ? $item['data'] : array();
			if ( '' === $id ) {
				continue;
			}
			if ( ! empty( $item['big'] ) ) {
				$raw = AAW_Transfer::download( 'result_get', 'id', $id );
				if ( null === $raw ) {
					$waiting++;
					self::download_note( $id, AAW_Transfer::progress( 'result_get', $id ), (int) ( $item['size'] ?? 0 ) );
					continue; // Continues on the next tick from where it stopped.
				}
				if ( is_wp_error( $raw ) ) {
					if ( ! get_transient( 'aaw_dlerr_' . $id ) ) {
						set_transient( 'aaw_dlerr_' . $id, 1, HOUR_IN_SECONDS );
						AAW_Logs::add( 'warning', 'run', $raw->get_error_message() );
					}
					$waiting++;
					continue;
				}
				$data = json_decode( $raw, true );
				if ( ! is_array( $data ) ) {
					AAW_Transfer::release( 'result_get', $id );
					$waiting++;
					continue;
				}
			}
			$blob_keys = self::blob_keys( $data );
			$ready     = true;
			foreach ( $blob_keys as $bk ) {
				$b = AAW_Transfer::download( 'blob_get', 'key', $bk );
				if ( null === $b ) {
					$ready = false;
					break;
				}
			}
			if ( ! $ready ) {
				$waiting++;
				$pg = 0;
				foreach ( $blob_keys as $bk ) {
					$pg += AAW_Transfer::progress( 'blob_get', $bk );
				}
				self::download_note( $id, (int) round( $pg / max( 1, count( $blob_keys ) ) ), 0, true );
				continue; // Images still arriving in small pieces.
			}
			self::download_note( $id, 100, 0, false, true );
			$n       = self::ingest( $id, $data, $pending[ $id ] ?? array() );
			$drafts += $n['drafts'];
			$errors += $n['errors'];
			$done[] = $id;
			unset( $pending[ $id ] );
			AAW_Transfer::release( 'result_get', $id );
			foreach ( $blob_keys as $bk ) {
				AAW_Transfer::release( 'blob_get', $bk );
			}
		}
		if ( $done ) {
			AAW_Cloudflare::call_worker( 'result_ack', array( 'ids' => $done ), 30 );
		}
		// Forget very old pending entries (runner never reported back).
		foreach ( $pending as $pid => $p ) {
			if ( time() - (int) $p['time'] > 3 * HOUR_IN_SECONDS ) {
				unset( $pending[ $pid ] );
			}
		}
		update_option( self::PENDING, $pending, false );
		update_option( 'aaw_last_poll', time(), false );
		update_option( 'aaw_poll_waiting', $waiting, false );
		if ( $waiting ) {
			self::schedule_bg_poll( 45 ); // Keep collecting soon.
		}
		return array( 'drafts' => $drafts, 'errors' => $errors, 'pending' => count( $pending ), 'waiting' => $waiting );
	}

	/**
	 * Apply one finished result (GitHub mailbox, or a job that ran directly on this server).
	 *
	 * @param array $pend The pending entry: kind, post_id, topics.
	 * @return array { drafts, errors }
	 */
	public static function ingest( $id, array $data, array $pend = array() ) {
		$drafts = 0;
		$errors = 0;
		foreach ( (array) ( $data['results'] ?? array() ) as $res ) {
			if ( ! empty( $res['article'] ) ) {
				$had_img        = ! empty( $res['article']['image'] );
				$res['article'] = self::resolve_blobs( (array) $res['article'] );
				$rmeta          = (array) ( $res['meta'] ?? array() );
				if ( $had_img && empty( $res['article']['image'] ) && empty( $rmeta['image_error'] ) ) {
					$rmeta['image_error'] = 'تصویر ساخته شد ولی دریافت آن از کلادفلر کامل نشد.';
					$rmeta['image_lost']  = true;
				}
				$x = AAW_REST::apply_draft( array( 'topic_id' => (int) ( $res['topic_id'] ?? 0 ), 'article' => (array) $res['article'], 'meta' => $rmeta ) );
				is_wp_error( $x ) ? $errors++ : $drafts++;
			} else {
				AAW_REST::apply_fail( array( 'topic_id' => (int) ( $res['topic_id'] ?? 0 ), 'error' => (string) ( $res['error'] ?? 'خطای نامشخص' ), 'meta' => (array) ( $res['meta'] ?? array() ) ) );
				$errors++;
			}
		}
		if ( ! empty( $data['analysis']['result'] ) ) {
			$saved = AAW_Analyzer::save( $data['analysis']['result'], (array) ( $data['analysis']['meta'] ?? array() ) );
			if ( is_wp_error( $saved ) ) {
				AAW_Logs::add( 'error', 'analysis', $saved->get_error_message() );
				AAW_Analyzer::fail( $saved->get_error_message() );
			} else {
				AAW_Analyzer::done();
			}
		}
		if ( ! empty( $data['fatal'] ) && AAW_Analyzer::pending_id() === $id ) {
			AAW_Analyzer::fail( AAW_Errors::explain( (string) $data['fatal'] ) );
		}
		foreach ( (array) ( $data['revisions'] ?? array() ) as $rv ) {
			$x = AAW_Revise::apply_revision( (int) ( $rv['post_id'] ?? 0 ), (array) ( $rv['article'] ?? array() ), (string) ( $rv['request_id'] ?? '' ) );
			if ( is_wp_error( $x ) ) {
				AAW_Logs::add( 'error', 'revise', $x->get_error_message() );
			}
		}
		foreach ( (array) ( $data['images'] ?? array() ) as $im ) {
			$res_im = self::resolve_blobs( array( 'image' => $im['image'] ?? null, 'inline_images' => $im['inline'] ?? array() ) );
			if ( empty( $res_im['image'] ) ) {
				continue;
			}
			$pid = (int) ( $im['post_id'] ?? 0 );
			$x   = AAW_Revise::apply_image( $pid, $res_im['image'], (array) ( $res_im['inline_images'] ?? array() ), ! empty( $im['replace_inline'] ) );
			if ( is_wp_error( $x ) ) {
				AAW_Logs::add( 'error', 'image', $x->get_error_message(), array( 'post_id' => $pid ) );
			}
		}
		if ( ! empty( $data['fatal'] ) && ! empty( $pend['post_id'] ) ) {
			$fpid = (int) $pend['post_id'];
			update_post_meta( $fpid, AAW_Revise::META_STATE, array( 'state' => 'error', 'note' => AAW_Errors::explain( (string) $data['fatal'] ), 't' => time() ) );
			AAW_Logs::add( 'error', $pend['kind'] ?? 'run', (string) $data['fatal'], array( 'post_id' => $fpid ) );
			// ChatGPT image failed (e.g. quota): next engine of the image priority list takes over once.
			if ( 'image' === ( $pend['kind'] ?? '' ) && ! get_transient( 'aaw_imgfo2_' . $fpid ) ) {
				$next = array_values( array_diff( AAW_Priority::image_chain(), array( 'sub_codex' ) ) );
				if ( $next && AAW_Settings::get( 'featured_image' ) ) {
					set_transient( 'aaw_imgfo2_' . $fpid, 1, HOUR_IN_SECONDS );
					$x = AAW_Revise::request_image( $fpid, (string) get_post_meta( $fpid, '_aaw_image_prompt', true ), false, $next[0] );
					if ( ! is_wp_error( $x ) ) {
						AAW_Logs::add( 'info', 'image', 'تصویر با اکانت ChatGPT ساخته نشد؛ طبق اولویت با ' . AAW_Images::engines()[ $next[0] ]['name'] . ' ساخته می‌شود.', array( 'post_id' => $fpid ) );
					}
				}
			}
		}
		AAW_Activity::finish_job( $id, empty( $data['fatal'] ), ! empty( $data['fatal'] ) ? AAW_Errors::explain( (string) $data['fatal'] ) : '' );
		if ( ! empty( $data['site_data']['counts'] ) ) {
			AAW_SiteData::save( (array) $data['site_data'] );
		}
		if ( ! empty( $data['fatal'] ) && 'crawl' === ( $pend['kind'] ?? '' ) ) {
			update_option( 'aaw_site_data_error', AAW_Errors::explain( (string) $data['fatal'] ), false );
			delete_option( 'aaw_site_crawl' );
			AAW_Logs::add( 'error', 'analysis', 'خواندن سایت در GitHub: ' . (string) $data['fatal'] );
		}
		if ( ! empty( $data['seo_playbook']['playbook'] ) ) {
			AAW_Knowledge::save( $data['seo_playbook'] );
		}
		if ( ! empty( $data['style_theme']['theme'] ) ) {
			AAW_Images::save_theme( $data['style_theme'] );
		}
		if ( ! empty( $data['fatal'] ) && ! empty( $pend['kind'] ) && in_array( $pend['kind'], array( 'seo_learn', 'style_learn' ), true ) ) {
			AAW_Logs::add( 'error', 'seo_learn' === $pend['kind'] ? 'seo' : 'image', (string) $data['fatal'] );
			if ( 'seo_learn' === $pend['kind'] ) {
				delete_option( 'aaw_seo_learning' );
			}
		}
		if ( ! empty( $data['ideas'] ) ) {
			AAW_REST::apply_topics( array( 'topics' => $data['ideas'] ) );
		}
		foreach ( (array) ( $data['logs'] ?? array() ) as $l ) {
			AAW_Logs::add( $l['level'] ?? 'info', $l['event'] ?? 'runner', $l['message'] ?? '' );
		}
		if ( ! empty( $data['fatal'] ) && ! empty( $pend['topics'] ) ) {
			foreach ( $pend['topics'] as $tid ) {
				AAW_Topics::mark_failed( $tid, (string) $data['fatal'] );
			}
			$errors++;
		}
		return array( 'drafts' => $drafts, 'errors' => $errors );
	}

	/** Live activity line while a result/image arrives in small pieces on a slow host. */
	private static function download_note( $id, $pct, $size = 0, $images = false, $done = false ) {
		$ops = get_option( 'aaw_dl_ops', array() );
		$ops = is_array( $ops ) ? $ops : array();
		if ( $done ) {
			if ( isset( $ops[ $id ] ) ) {
				AAW_Activity::finish( $ops[ $id ], true, 'دریافت کامل شد.' );
				unset( $ops[ $id ] );
				update_option( 'aaw_dl_ops', $ops, false );
			}
			return;
		}
		if ( empty( $ops[ $id ] ) ) {
			$ops[ $id ] = AAW_Activity::start( 'fetch', $images ? 'دریافت تصویر مقاله از کلادفلر (تکه‌تکه، به‌خاطر محدودیت اینترنت هاست)' : 'دریافت نتیجه از کلادفلر (تکه‌تکه، به‌خاطر محدودیت اینترنت هاست)', array( 'dl' => $id ) );
			update_option( 'aaw_dl_ops', $ops, false );
		}
		$sp = AAW_Transfer::speeds();
		AAW_Activity::step( $ops[ $id ], ( $images ? 'تصویر: ' : 'نتیجه: ' ) . $pct . '٪ دریافت شد · سرعت هاست ' . round( $sp['down'] / 1024, 1 ) . ' KB/s · ادامه خودکار' . ( $size ? ' (' . round( $size / 1024 ) . ' KB)' : '' ) );
	}

	/** Blob keys (stashed images) referenced by a mailbox. */
	public static function blob_keys( array $data ) {
		$keys = array();
		$add  = function ( $img ) use ( &$keys ) {
			if ( is_array( $img ) && ! empty( $img['blob'] ) ) {
				$keys[] = preg_replace( '/[^a-z0-9]/i', '', (string) $img['blob'] );
			}
		};
		foreach ( (array) ( $data['results'] ?? array() ) as $r ) {
			$add( $r['article']['image'] ?? null );
			foreach ( (array) ( $r['article']['inline_images'] ?? array() ) as $x ) {
				$add( $x );
			}
		}
		foreach ( (array) ( $data['images'] ?? array() ) as $im ) {
			$add( $im['image'] ?? null );
			foreach ( (array) ( $im['inline'] ?? array() ) as $x ) {
				$add( $x );
			}
		}
		return array_values( array_unique( array_filter( $keys ) ) );
	}

	/** Download stashed images in short ranged requests. */
	public static function resolve_blobs( array $article ) {
		$get = function ( $img ) {
			if ( ! is_array( $img ) || empty( $img['blob'] ) ) {
				return $img;
			}
			// Already fetched in small resumable pieces (cached in uploads/aaw-tmp).
			$data = AAW_Transfer::download( 'blob_get', 'key', preg_replace( '/[^a-z0-9]/i', '', (string) $img['blob'] ) );
			if ( ! is_string( $data ) || '' === $data ) {
				AAW_Logs::add( 'warning', 'image', 'دریافت تصویر از کلادفلر کامل نشد' . ( is_wp_error( $data ) ? ': ' . $data->get_error_message() : '؛ در دریافت بعدی ادامه پیدا می‌کند.' ) );
				return null;
			}
			unset( $img['blob'], $img['size'] );
			$img['base64'] = $data;
			return $img;
		};
		if ( ! empty( $article['image'] ) ) {
			$article['image'] = $get( $article['image'] );
		}
		if ( ! empty( $article['inline_images'] ) && is_array( $article['inline_images'] ) ) {
			$article['inline_images'] = array_values( array_filter( array_map( $get, $article['inline_images'] ) ) );
		}
		return $article;
	}

	/** Short follow-up polls while background jobs are pending (every 2 min, max 40 min). */
	public static function bg_poll() {
		$r       = self::poll();
		$pending = get_option( self::PENDING, array() );
		$young   = false;
		foreach ( (array) $pending as $p ) {
			if ( time() - (int) ( $p['time'] ?? 0 ) < 40 * MINUTE_IN_SECONDS ) {
				$young = true;
			}
		}
		if ( $young && ! wp_next_scheduled( 'aaw_bg_poll' ) ) {
			wp_schedule_single_event( time() + 120, 'aaw_bg_poll' );
		}
		return $r;
	}

	public static function schedule_bg_poll( $delay = 120 ) {
		if ( ! wp_next_scheduled( 'aaw_bg_poll' ) ) {
			wp_schedule_single_event( time() + $delay, 'aaw_bg_poll' );
		}
	}

	/** WP-Cron tick (hourly): run when the schedule says so, then collect results. */
	public static function tick() {
		AAW_Analyzer::check_stale();
		if ( ! self::active() ) {
			return;
		}
		$s    = AAW_Settings::all();
		$now  = time();
		$last = (int) get_option( 'aaw_pull_last_tick', $now - HOUR_IN_SECONDS );
		update_option( 'aaw_pull_last_tick', $now, false );
		$due = false;
		if ( $s['enabled'] && ! $s['paused'] ) {
			foreach ( AAW_Cloudflare::schedule_expressions() as $expr ) {
				$t = AAW_Cloudflare::next_from_expr( $expr, $last );
				if ( $t && $t <= $now ) {
					$due = true;
				}
			}
		}
		if ( $due ) {
			self::run_cycle( 'cron' );
		}
		// Only contact Cloudflare when something is actually expected (or as a 6-hourly safety net).
		$pending = get_option( self::PENDING, array() );
		if ( $pending || ( time() - (int) get_option( 'aaw_last_poll', 0 ) ) > 6 * HOUR_IN_SECONDS ) {
			self::poll();
		}
	}

	public static function ensure_schedule() {
		$next = wp_next_scheduled( 'aaw_pull_tick' );
		if ( self::active() && ! $next ) {
			wp_schedule_event( time() + 60, 'hourly', 'aaw_pull_tick' );
		} elseif ( ! self::active() && $next ) {
			wp_clear_scheduled_hook( 'aaw_pull_tick' );
		}
	}
}
