<?php
/**
 * AI provider registry: 20 built-in providers + unlimited custom (Base URL) providers.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Providers {

	public static function builtin() {
		$p = array(
			array( 'sub_claude', 'Claude Pro/Max (اکانت چت)', '', 'github_runner', 'sonnet', array( 'sonnet', 'opus', 'haiku' ), 'https://code.claude.com/docs/en/github-actions', '#c96442', false, 'رایگان · از سهمیه اشتراک · GitHub Actions' ),
			array( 'sub_codex', 'ChatGPT Plus/Pro (اکانت چت)', '', 'github_runner', '', array( 'gpt-5', 'gpt-5-codex', 'gpt-5-mini' ), 'https://learn.chatgpt.com/docs/auth/ci-cd-auth', '#10a37f', false, 'رایگان · از سهمیه اشتراک · GitHub Actions' ),
			array( 'claude_pro', 'Claude Pro (اشتراک شخصی)', '', 'claude_code', 'sonnet', array( 'sonnet', 'opus', 'haiku' ), 'https://code.claude.com/docs/en/authentication#generate-a-long-lived-token', '#c96442', false, 'از سهمیه اشتراک Pro/Max · Cloudflare Containers' ),
			array( 'openai', 'OpenAI', 'https://api.openai.com/v1', 'openai', 'gpt-4.1-mini', array( 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4o', 'gpt-4o-mini', 'o4-mini' ), 'https://platform.openai.com/api-keys', '#10a37f', true, 'بین‌المللی' ),
			array( 'anthropic', 'Anthropic Claude', 'https://api.anthropic.com/v1', 'anthropic', 'claude-sonnet-4-5', array( 'claude-sonnet-4-5', 'claude-opus-4-1', 'claude-haiku-4-5' ), 'https://console.anthropic.com/settings/keys', '#d97757', false, 'بین‌المللی' ),
			array( 'gemini', 'Google Gemini', 'https://generativelanguage.googleapis.com/v1beta/openai', 'openai', 'gemini-2.5-flash', array( 'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-2.0-flash' ), 'https://aistudio.google.com/app/apikey', '#4285f4', true, 'بین‌المللی' ),
			array( 'openrouter', 'OpenRouter', 'https://openrouter.ai/api/v1', 'openai', 'openai/gpt-4.1-mini', array( 'openai/gpt-4.1-mini', 'anthropic/claude-sonnet-4.5', 'google/gemini-2.5-flash', 'deepseek/deepseek-chat' ), 'https://openrouter.ai/keys', '#6467f2', false, 'واسط چندمدلی' ),
			array( 'groq', 'Groq', 'https://api.groq.com/openai/v1', 'openai', 'llama-3.3-70b-versatile', array( 'llama-3.3-70b-versatile', 'openai/gpt-oss-120b', 'qwen/qwen3-32b' ), 'https://console.groq.com/keys', '#f55036', true, 'سرعت بالا' ),
			array( 'mistral', 'Mistral AI', 'https://api.mistral.ai/v1', 'openai', 'mistral-large-latest', array( 'mistral-large-latest', 'mistral-medium-latest', 'mistral-small-latest' ), 'https://console.mistral.ai/api-keys', '#fa520f', true, 'اروپا' ),
			array( 'deepseek', 'DeepSeek', 'https://api.deepseek.com/v1', 'openai', 'deepseek-chat', array( 'deepseek-chat', 'deepseek-reasoner' ), 'https://platform.deepseek.com/api_keys', '#4d6bfe', true, 'اقتصادی' ),
			array( 'xai', 'xAI Grok', 'https://api.x.ai/v1', 'openai', 'grok-3-mini', array( 'grok-4', 'grok-3', 'grok-3-mini' ), 'https://console.x.ai', '#111111', true, 'بین‌المللی' ),
			array( 'together', 'Together AI', 'https://api.together.xyz/v1', 'openai', 'meta-llama/Llama-3.3-70B-Instruct-Turbo', array( 'meta-llama/Llama-3.3-70B-Instruct-Turbo', 'Qwen/Qwen2.5-72B-Instruct-Turbo', 'deepseek-ai/DeepSeek-V3' ), 'https://api.together.xyz/settings/api-keys', '#0f6fff', true, 'متن‌باز' ),
			array( 'fireworks', 'Fireworks AI', 'https://api.fireworks.ai/inference/v1', 'openai', 'accounts/fireworks/models/llama-v3p3-70b-instruct', array( 'accounts/fireworks/models/llama-v3p3-70b-instruct', 'accounts/fireworks/models/deepseek-v3' ), 'https://fireworks.ai/account/api-keys', '#6720ff', true, 'متن‌باز' ),
			array( 'perplexity', 'Perplexity', 'https://api.perplexity.ai', 'openai', 'sonar-pro', array( 'sonar-pro', 'sonar', 'sonar-reasoning' ), 'https://www.perplexity.ai/settings/api', '#20808d', false, 'جستجوی آنلاین' ),
			array( 'cohere', 'Cohere', 'https://api.cohere.ai/compatibility/v1', 'openai', 'command-a-03-2025', array( 'command-a-03-2025', 'command-r-plus' ), 'https://dashboard.cohere.com/api-keys', '#39594d', false, 'سازمانی' ),
			array( 'cerebras', 'Cerebras', 'https://api.cerebras.ai/v1', 'openai', 'llama-3.3-70b', array( 'llama-3.3-70b', 'qwen-3-32b', 'gpt-oss-120b' ), 'https://cloud.cerebras.ai', '#f15a29', false, 'سرعت بالا' ),
			array( 'deepinfra', 'DeepInfra', 'https://api.deepinfra.com/v1/openai', 'openai', 'meta-llama/Llama-3.3-70B-Instruct', array( 'meta-llama/Llama-3.3-70B-Instruct', 'deepseek-ai/DeepSeek-V3', 'Qwen/Qwen2.5-72B-Instruct' ), 'https://deepinfra.com/dash/api_keys', '#2f3b52', true, 'اقتصادی' ),
			array( 'moonshot', 'Moonshot Kimi', 'https://api.moonshot.ai/v1', 'openai', 'kimi-k2-0711-preview', array( 'kimi-k2-0711-preview', 'moonshot-v1-32k', 'moonshot-v1-128k' ), 'https://platform.moonshot.ai/console/api-keys', '#16191e', true, 'آسیا' ),
			array( 'qwen', 'Alibaba Qwen', 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1', 'openai', 'qwen-plus', array( 'qwen-max', 'qwen-plus', 'qwen-turbo' ), 'https://dashscope.console.aliyun.com/apiKey', '#615ced', true, 'آسیا' ),
			array( 'zhipu', 'Zhipu GLM', 'https://open.bigmodel.cn/api/paas/v4', 'openai', 'glm-4-plus', array( 'glm-4-plus', 'glm-4-air', 'glm-4-flash' ), 'https://open.bigmodel.cn/usercenter/apikeys', '#3859ff', false, 'آسیا' ),
			array( 'avalai', 'AvalAI (اول‌ای‌آی)', 'https://api.avalai.ir/v1', 'openai', 'gpt-4.1-mini', array( 'gpt-4.1-mini', 'gpt-4o', 'claude-sonnet-4-5', 'gemini-2.5-flash' ), 'https://chat.avalai.ir/platform/api-keys', '#0ea5a4', true, 'ایرانی · پرداخت ریالی' ),
			array( 'gapgpt', 'GapGPT (گپ‌جی‌پی‌تی)', 'https://api.gapgpt.app/v1', 'openai', 'gpt-4.1-mini', array( 'gpt-4.1-mini', 'gpt-4o', 'claude-sonnet-4-5', 'gemini-2.5-flash' ), 'https://gapgpt.app/platform', '#7c3aed', true, 'ایرانی · پرداخت ریالی' ),
			array( 'workers_ai', 'Cloudflare Workers AI', '', 'workers_ai', '@cf/meta/llama-3.3-70b-instruct-fp8-fast', array( '@cf/meta/llama-3.3-70b-instruct-fp8-fast', '@cf/meta/llama-4-scout-17b-16e-instruct', '@cf/qwen/qwq-32b', '@cf/mistralai/mistral-small-3.1-24b-instruct' ), 'https://dash.cloudflare.com/?to=/:account/ai/workers-ai', '#f38020', false, 'بدون کلید · روی خود کلادفلر' ),
		);

		$out = array();
		foreach ( $p as $row ) {
			$out[ $row[0] ] = array(
				'id'            => $row[0],
				'name'          => $row[1],
				'base_url'      => $row[2],
				'format'        => $row[3],
				'default_model' => $row[4],
				'models'        => $row[5],
				'key_url'       => $row[6],
				'color'         => $row[7],
				'json_mode'     => (bool) $row[8],
				'badge'         => $row[9],
				'requires_key'  => 'workers_ai' !== $row[0],
				'custom'        => false,
				'auth_header'   => 'anthropic' === $row[3] ? 'x-api-key' : ( in_array( $row[3], array( 'claude_code', 'github_runner' ), true ) ? 'none' : 'authorization' ),
				'path'          => 'anthropic' === $row[3] ? '/messages' : '/chat/completions',
				'query'         => '',
				'headers'       => array(),
				'engine'        => 'sub_codex' === $row[0] ? 'codex' : ( 'sub_claude' === $row[0] ? 'claude' : '' ),
			);
		}
		return $out;
	}

	public static function all() {
		$all = self::builtin();
		foreach ( AAW_Settings::custom_providers() as $cp ) {
			if ( ! empty( $cp['id'] ) ) {
				$all[ $cp['id'] ] = $cp;
			}
		}
		return $all;
	}

	public static function get( $id ) {
		$all = self::all();
		return isset( $all[ $id ] ) ? $all[ $id ] : null;
	}

	/** Cloudflare secret name holding the API key of a provider. */
	public static function secret_name( $id ) {
		if ( 'claude_pro' === $id ) {
			return 'CLAUDE_CODE_OAUTH_TOKEN';
		}
		return 'AAW_KEY_' . strtoupper( preg_replace( '/[^a-zA-Z0-9]/', '_', $id ) );
	}

	public static function model_for( $id ) {
		$models = AAW_Settings::get( 'provider_models', array() );
		if ( ! empty( $models[ $id ] ) ) {
			return $models[ $id ];
		}
		$p = self::get( $id );
		return $p ? $p['default_model'] : '';
	}

	/**
	 * Non-secret runtime descriptor sent to the worker.
	 */
	public static function runtime( $id, $model = '' ) {
		$p = self::get( $id );
		if ( ! $p ) {
			return null;
		}
		return array(
			'id'          => $p['id'],
			'name'        => $p['name'],
			'format'      => $p['format'],
			'base_url'    => untrailingslashit( $p['base_url'] ),
			'path'        => $p['path'],
			'query'       => $p['query'],
			'model'       => $model ? $model : self::model_for( $id ),
			'auth_header' => $p['auth_header'],
			'headers'     => (object) ( isset( $p['headers'] ) ? $p['headers'] : array() ),
			'json_mode'   => ! empty( $p['json_mode'] ),
			'secret'      => self::secret_name( $p['id'] ),
			'needs_key'   => ! empty( $p['requires_key'] ) && ! in_array( $p['format'], array( 'claude_code', 'github_runner' ), true ),
			'engine'      => isset( $p['engine'] ) ? $p['engine'] : '',
			'fallback_model' => 'claude_code' === $p['format'] ? (string) AAW_Settings::get( 'claude_pro_fallback', '' ) : '',
		);
	}

	public static function sanitize_custom( $cp ) {
		if ( ! is_array( $cp ) ) {
			return null;
		}
		$name = isset( $cp['name'] ) ? sanitize_text_field( $cp['name'] ) : '';
		$base = isset( $cp['base_url'] ) ? esc_url_raw( trim( $cp['base_url'] ), array( 'http', 'https' ) ) : '';
		if ( '' === $name || '' === $base ) {
			return null;
		}
		$slug = ! empty( $cp['id'] ) ? sanitize_key( $cp['id'] ) : 'custom_' . sanitize_key( substr( sanitize_title( $name ), 0, 20 ) ) . '_' . substr( md5( $base . microtime() ), 0, 4 );
		if ( 0 !== strpos( $slug, 'custom_' ) ) {
			$slug = 'custom_' . $slug;
		}
		$format = isset( $cp['format'] ) && in_array( $cp['format'], array( 'openai', 'anthropic' ), true ) ? $cp['format'] : 'openai';
		$auth   = isset( $cp['auth_header'] ) && in_array( $cp['auth_header'], array( 'authorization', 'x-api-key', 'api-key', 'none' ), true ) ? $cp['auth_header'] : ( 'anthropic' === $format ? 'x-api-key' : 'authorization' );

		$headers = array();
		if ( ! empty( $cp['headers'] ) ) {
			$raw = is_array( $cp['headers'] ) ? $cp['headers'] : preg_split( '/\r\n|\n/', (string) $cp['headers'] );
			foreach ( $raw as $k => $line ) {
				if ( is_string( $k ) ) {
					$hk = $k;
					$hv = $line;
				} else {
					if ( false === strpos( $line, ':' ) ) {
						continue;
					}
					list( $hk, $hv ) = array_map( 'trim', explode( ':', $line, 2 ) );
				}
				$hk = preg_replace( '/[^A-Za-z0-9\-]/', '', $hk );
				if ( '' !== $hk && ! in_array( strtolower( $hk ), array( 'authorization', 'x-api-key', 'api-key' ), true ) ) {
					$headers[ $hk ] = sanitize_text_field( $hv );
				}
			}
		}
		$path = isset( $cp['path'] ) && '' !== trim( $cp['path'] ) ? '/' . ltrim( sanitize_text_field( $cp['path'] ), '/' ) : ( 'anthropic' === $format ? '/messages' : '/chat/completions' );
		$model = isset( $cp['default_model'] ) ? sanitize_text_field( $cp['default_model'] ) : '';

		return array(
			'id'            => $slug,
			'name'          => $name,
			'base_url'      => untrailingslashit( $base ),
			'format'        => $format,
			'default_model' => $model,
			'models'        => $model ? array( $model ) : array(),
			'key_url'       => '',
			'color'         => isset( $cp['color'] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $cp['color'] ) ? $cp['color'] : '#475569',
			'json_mode'     => ! empty( $cp['json_mode'] ),
			'badge'         => 'پرووایدر شخصی',
			'requires_key'  => 'none' !== $auth,
			'custom'        => true,
			'auth_header'   => $auth,
			'path'          => $path,
			'query'         => isset( $cp['query'] ) ? ltrim( sanitize_text_field( $cp['query'] ), '?' ) : '',
			'headers'       => $headers,
		);
	}
}
