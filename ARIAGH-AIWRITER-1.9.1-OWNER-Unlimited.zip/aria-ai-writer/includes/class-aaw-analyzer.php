<?php
/**
 * Smart site analysis: reads the whole site (posts, pages, categories, tags,
 * WooCommerce products), competitors and trends, and asks the AI for a complete
 * SEO content strategy with ready-to-queue topics.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Analyzer {

	const OPTION = 'aaw_analysis';
	const JOB    = 'aaw_analysis_job';

	/* ---------------- the running analysis: never "in progress" forever ---------------- */

	/** Remember a started analysis (id, where it runs, when). */
	public static function track( $id, $mode, $url = '' ) {
		update_option( 'aaw_analysis_pending', (string) $id, false );
		update_option( self::JOB, array( 'id' => (string) $id, 'mode' => (string) $mode, 't' => time(), 'url' => (string) $url, 'checked' => 0, 'done_at' => 0 ), false );
		delete_option( 'aaw_analysis_error' );
	}

	public static function pending_id() {
		return (string) get_option( 'aaw_analysis_pending', '' );
	}

	/** End a running analysis with a clear message (shown in the analysis tab). */
	public static function fail( $message ) {
		update_option( 'aaw_analysis_error', (string) $message, false );
		delete_option( 'aaw_analysis_pending' );
		delete_option( self::JOB );
		AAW_Logs::add( 'error', 'analysis', 'تحلیل هوشمند سایت: ' . wp_strip_all_tags( (string) $message ) );
	}

	public static function done() {
		delete_option( 'aaw_analysis_pending' );
		delete_option( self::JOB );
	}

	public static function cancel() {
		$id  = self::pending_id();
		$job = get_option( self::JOB );
		if ( $id && is_array( $job ) && 'local' === ( $job['mode'] ?? '' ) && class_exists( 'AAW_Local' ) ) {
			AAW_Local::cancel( $id );
		}
		delete_option( 'aaw_analysis_pending' );
		delete_option( self::JOB );
		delete_option( 'aaw_analysis_error' );
		if ( $id ) {
			AAW_Logs::add( 'info', 'analysis', 'تحلیل هوشمند در حال انجام توسط کاربر لغو شد.' );
		}
		return array( 'message' => 'تحلیل لغو شد؛ می‌توانید دوباره شروع کنید.' );
	}

	/**
	 * Decide what happened to a running analysis: finished on GitHub with an error, finished but
	 * the result never arrived, still running, or simply too old. Called from the status checks,
	 * the analysis tab and the cron tick (GitHub is asked at most every 2 minutes).
	 */
	public static function check_stale() {
		$id = self::pending_id();
		if ( '' === $id ) {
			return;
		}
		$job = get_option( self::JOB );
		if ( ! is_array( $job ) || ( $job['id'] ?? '' ) !== $id ) {
			$job = array( 'id' => $id, 'mode' => 'legacy', 't' => 0, 'url' => '', 'checked' => 0, 'done_at' => 0 ); // Started by an older version.
		}
		$age  = $job['t'] ? time() - (int) $job['t'] : PHP_INT_MAX;
		$mode = (string) $job['mode'];
		if ( 'local' === $mode ) {
			$st = null;
			foreach ( (array) get_option( 'aaw_local_jobs', array() ) as $j ) {
				if ( $j['id'] === $id ) {
					$st = $j;
				}
			}
			if ( ! $st ) {
				self::fail( 'کار تحلیل روی سرور پیدا نشد (احتمالاً پاک شده است). دوباره «شروع تحلیل هوشمند» را بزنید.' );
			} elseif ( 'error' === $st['status'] ) {
				self::fail( (string) $st['error'] );
			} elseif ( 'done' === $st['status'] ) {
				self::fail( 'اجرای روی سرور تمام شد ولی نتیجه‌ای ثبت نشد. دوباره امتحان کنید.' );
			}
			return;
		}
		if ( 'async' === $mode ) {
			if ( $age > 25 * MINUTE_IN_SECONDS ) {
				self::fail( 'تحلیل روی کلادفلر در ۲۵ دقیقه نتیجه نداد و متوقف شد. دوباره «شروع تحلیل هوشمند» را بزنید؛ اگر تکرار شد تعداد موضوع را کمتر کنید یا موتور دیگری انتخاب کنید.' );
			}
			return;
		}
		// GitHub (or started by an older version).
		if ( $age > 70 * MINUTE_IN_SECONDS && 'legacy' !== $mode ) {
			self::fail( 'تحلیل در GitHub بیش از ۷۰ دقیقه نتیجه نداد و متوقف شد. اجرای GitHub را در تب Actions مخزن ببینید و دوباره «شروع تحلیل هوشمند» را بزنید.' . ( $job['url'] ? "
" . $job['url'] : '' ) );
			return;
		}
		if ( $age < 3 * MINUTE_IN_SECONDS || time() - (int) $job['checked'] < 2 * MINUTE_IN_SECONDS || ! AAW_GitHub::is_connected() ) {
			return;
		}
		$job['checked'] = time();
		$runs           = AAW_GitHub::runs( 15 );
		if ( is_wp_error( $runs ) ) {
			update_option( self::JOB, $job, false );
			return;
		}
		$run = null;
		foreach ( $runs as $r ) {
			if ( false !== strpos( (string) $r['title'], $id ) ) {
				$run = $r;
				break;
			}
		}
		if ( ! $run && 'legacy' === $mode ) {
			foreach ( $runs as $r ) {
				if ( in_array( $r['status'], array( 'queued', 'in_progress', 'waiting', 'pending' ), true ) ) {
					$job['mode'] = 'github';
					$job['t']    = time(); // Something is still running: give it time.
					update_option( self::JOB, $job, false );
					return;
				}
			}
			self::fail( 'تحلیل قبلی هیچ‌وقت نتیجه‌ای به سایت نرساند (اجرایی در GitHub در جریان نیست) و متوقف شد. دوباره «شروع تحلیل هوشمند» را بزنید.' );
			return;
		}
		if ( ! $run ) {
			if ( $age > 15 * MINUTE_IN_SECONDS ) {
				self::fail( 'اجرای GitHub برای این تحلیل پیدا نشد (شروع نشد یا حذف شد). دوباره «شروع تحلیل هوشمند» را بزنید و اگر تکرار شد در تب «اکانت اشتراکی» دکمه «همگام‌سازی فایل‌ها» را بزنید.' );
			}
			update_option( self::JOB, $job, false );
			return;
		}
		if ( 'completed' !== $run['status'] ) {
			update_option( self::JOB, $job, false );
			return;
		}
		if ( 'success' !== $run['conclusion'] ) {
			// The runner normally reports its own error; collect it first, else explain.
			AAW_Pull::poll();
			if ( self::pending_id() === $id ) {
				self::fail( 'اجرای GitHub با خطا تمام شد (' . ( $run['conclusion'] ? $run['conclusion'] : 'failed' ) . ') و نتیجه‌ای نفرستاد. علت دقیق را در صفحه اجرا ببینید، مشکل را رفع و دوباره تحلیل را شروع کنید.' . "
" . $run['url'] );
			}
			return;
		}
		if ( ! $job['done_at'] ) {
			$job['done_at'] = time();
		}
		update_option( self::JOB, $job, false );
		AAW_Pull::poll(); // Finished on GitHub: collect the result now.
		if ( self::pending_id() === $id && time() - (int) $job['done_at'] > 10 * MINUTE_IN_SECONDS ) {
			self::fail( 'GitHub تحلیل را تمام کرد ولی نتیجه به سایت نرسید (دریافت از کلادفلر ناموفق ماند). در تب کلادفلر «بررسی وضعیت» را بزنید و دوباره تحلیل را شروع کنید.' . "
" . $run['url'] );
		}
	}

	/** Collect everything the AI needs to understand the site. */
	public static function inventory() {
		$s   = AAW_Settings::all();
		$inv = array(
			'site'       => array(
				'name'     => $s['site_name'] ? $s['site_name'] : get_bloginfo( 'name' ),
				'tagline'  => get_bloginfo( 'description' ),
				'url'      => home_url(),
				'language' => $s['language'],
				'niche'    => $s['niche'],
				'audience' => $s['audience'],
				'brand'    => trim( $s['brand_name'] . ' ' . $s['brand_description'] ),
			),
			'categories' => array(),
			'tags'       => array(),
			'posts'      => array(),
			'pages'      => array(),
			'products'   => array(),
			'product_categories' => array(),
			'queue'      => array(),
		);

		foreach ( get_categories( array( 'hide_empty' => false, 'number' => 80, 'orderby' => 'count', 'order' => 'DESC' ) ) as $c ) {
			$inv['categories'][] = array( 'name' => $c->name, 'count' => (int) $c->count );
		}
		foreach ( (array) get_tags( array( 'number' => 40, 'orderby' => 'count', 'order' => 'DESC' ) ) as $t ) {
			if ( is_object( $t ) ) {
				$inv['tags'][] = $t->name;
			}
		}
		$posts = get_posts( array( 'post_type' => 'post', 'post_status' => array( 'publish', 'draft', 'pending', 'future' ), 'posts_per_page' => 300, 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true ) );
		foreach ( $posts as $p ) {
			$kw = get_post_meta( $p->ID, '_aaw_focus_keyword', true );
			if ( ! $kw ) {
				$kw = get_post_meta( $p->ID, '_yoast_wpseo_focuskw', true );
			}
			if ( ! $kw ) {
				$rm = get_post_meta( $p->ID, 'rank_math_focus_keyword', true );
				$kw = $rm ? trim( explode( ',', $rm )[0] ) : '';
			}
			$cats = wp_list_pluck( (array) get_the_category( $p->ID ), 'name' );
			$inv['posts'][] = array(
				't' => $p->post_title,
				'k' => $kw,
				'c' => implode( '، ', array_slice( $cats, 0, 2 ) ),
				's' => $p->post_status,
			);
		}
		foreach ( get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 50, 'no_found_rows' => true ) ) as $p ) {
			$inv['pages'][] = $p->post_title;
		}
		if ( post_type_exists( 'product' ) ) {
			foreach ( get_posts( array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 200, 'no_found_rows' => true ) ) as $p ) {
				$terms = get_the_terms( $p->ID, 'product_cat' );
				$inv['products'][] = array(
					't' => $p->post_title,
					'c' => ( $terms && ! is_wp_error( $terms ) ) ? implode( '، ', array_slice( wp_list_pluck( $terms, 'name' ), 0, 2 ) ) : '',
					'p' => (string) get_post_meta( $p->ID, '_price', true ),
				);
			}
			if ( taxonomy_exists( 'product_cat' ) ) {
				$pc = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'number' => 60 ) );
				if ( ! is_wp_error( $pc ) ) {
					foreach ( $pc as $t ) {
						$inv['product_categories'][] = array( 'name' => $t->name, 'count' => (int) $t->count );
					}
				}
			}
		}
		$q = AAW_Topics::query( array( 'per_page' => 200 ) );
		foreach ( $q['items'] as $t ) {
			if ( 'done' !== $t['status'] ) {
				$inv['queue'][] = $t['title'];
			}
		}
		return $inv;
	}

	/**
	 * Only what is NOT public (drafts, scheduled posts, the topic queue) + site settings.
	 * The published posts, products, pages and categories are read by GitHub from the site itself.
	 */
	public static function inventory_light() {
		$inv = self::inventory();
		$inv['posts'] = array_values( array_filter( $inv['posts'], function ( $p ) { return 'publish' !== $p['s']; } ) );
		$inv['categories'] = array();
		$inv['tags'] = array();
		$inv['pages'] = array();
		$inv['products'] = array();
		$inv['product_categories'] = array();
		return $inv;
	}

	public static function stats( array $inv ) {
		return array(
			'posts'              => count( $inv['posts'] ),
			'pages'              => count( $inv['pages'] ),
			'products'           => count( $inv['products'] ),
			'categories'         => count( $inv['categories'] ),
			'product_categories' => count( $inv['product_categories'] ),
			'tags'               => count( $inv['tags'] ),
			'queue'              => count( $inv['queue'] ),
		);
	}

	/** Compact, token-friendly text version of the inventory. */
	public static function inventory_text( array $inv ) {
		$o   = array();
		$o[] = '## اطلاعات سایت';
		foreach ( $inv['site'] as $k => $v ) {
			if ( '' !== (string) $v ) {
				$o[] = "- {$k}: {$v}";
			}
		}
		if ( $inv['categories'] ) {
			$o[] = "\n## دسته‌بندی‌های وبلاگ (نام: تعداد مطلب)";
			$o[] = implode( ' | ', array_map( function ( $c ) { return $c['name'] . ': ' . $c['count']; }, $inv['categories'] ) );
		}
		if ( $inv['product_categories'] ) {
			$o[] = "\n## دسته‌بندی‌های محصولات";
			$o[] = implode( ' | ', array_map( function ( $c ) { return $c['name'] . ': ' . $c['count']; }, $inv['product_categories'] ) );
		}
		if ( $inv['products'] ) {
			$o[] = "\n## محصولات (" . count( $inv['products'] ) . ')';
			foreach ( $inv['products'] as $p ) {
				$o[] = '- ' . $p['t'] . ( $p['c'] ? ' [' . $p['c'] . ']' : '' ) . ( $p['p'] ? ' — قیمت: ' . $p['p'] : '' );
			}
		}
		if ( $inv['tags'] ) {
			$o[] = "\n## برچسب‌های پرکاربرد\n" . implode( '، ', $inv['tags'] );
		}
		if ( $inv['pages'] ) {
			$o[] = "\n## برگه‌ها\n" . implode( '، ', $inv['pages'] );
		}
		$o[] = "\n## مقالات موجود (" . count( $inv['posts'] ) . ') — این موضوعات را تکرار نکن';
		foreach ( $inv['posts'] as $p ) {
			$o[] = '- ' . $p['t'] . ( $p['k'] ? ' (کیورد: ' . $p['k'] . ')' : '' ) . ( $p['c'] ? ' [' . $p['c'] . ']' : '' ) . ( 'publish' !== $p['s'] ? ' {' . $p['s'] . '}' : '' );
		}
		if ( $inv['queue'] ) {
			$o[] = "\n## موضوعاتی که در صف تولید هستند — تکرار نکن\n- " . implode( "\n- ", $inv['queue'] );
		}
		$text = implode( "\n", $o );
		return mb_substr( $text, 0, 60000 );
	}

	public static function build_prompt( array $inv, $count = 20, $hint = '', $web = false, $competitors = array() ) {
		$langs  = AAW_Prompt::languages();
		$lang   = $langs[ AAW_Settings::get( 'language' ) ] ?? 'فارسی';
		$today  = wp_date( 'Y-m-d' ) . ' (سال شمسی ' . AAW_Prompt::jalali_year() . ')';
		$system = "تو یک استراتژیست ارشد سئو و بازاریابی محتوا با ۱۵ سال تجربه هستی که برای بازار «{$lang}» و موتور جستجوی گوگل کار می‌کنی. تحلیل‌هایت دقیق، داده‌محور و قابل اجراست.\n"
			. "امروز: {$today}.\n"
			. ( $web ? "ابزار جستجوی وب در اختیار داری: حتماً روندهای روز، سؤالات پرتکرار کاربران و صفحات رتبه‌های اول گوگل برای کلمات اصلی این حوزه و وبلاگ رقبا را جستجو و بررسی کن و نتیجه را در تحلیل لحاظ کن.\n" : "به اینترنت دسترسی نداری؛ بر اساس دانش خودت از این بازار، رفتار جستجوی کاربران و رقبای شناخته‌شده تحلیل کن و ادعای آماری ساختگی نکن.\n" )
			. 'خروجی را فقط به‌صورت یک شیء JSON معتبر بده.';

		$task  = "داده‌های کامل سایت در ادامه آمده است. کارهای زیر را انجام بده:\n";
		$task .= "۱. از روی محصولات، دسته‌ها و مقالات بفهم کسب‌وکار دقیقاً چیست، مخاطب کیست و مدل درآمدی چیست.\n";
		$task .= "۲. ستون‌های محتوایی (Pillar) و خوشه‌های موضوعی (Cluster) مناسب را تعریف کن.\n";
		$task .= "۳. شکاف‌های محتوایی را پیدا کن: موضوعات پرجستجو و مرتبط با محصولات/دسته‌ها که هنوز مقاله‌ای برایشان نوشته نشده.\n";
		$task .= "۴. رقبای اصلی این حوزه را معرفی و نقاط قوت/ضعف محتوایی‌شان را بگو" . ( $competitors ? ' (داده‌های واقعی جمع‌آوری‌شده از سایت رقبا در انتها آمده است)' : '' ) . ".\n";
		$task .= "۵. روندهای روز و فصلی (با توجه به تاریخ امروز و مناسبت‌های پیش‌رو) را در نظر بگیر.\n";
		$task .= "۶. دقیقاً {$count} موضوع مقاله جدید، غیرتکراری و با بیشترین پتانسیل ترافیک و فروش پیشنهاد بده؛ ترکیبی از محتوای آموزشی (بالای قیف)، مقایسه‌ای/راهنمای خرید (وسط قیف) و محصول‌محور (پایین قیف). کلمات کلیدی را همان‌طور که کاربران واقعاً جستجو می‌کنند بنویس.\n";
		$task .= "۷. برای هر موضوع بگو چرا مهم است، با چه زاویه‌ای می‌شود از رقبا بهتر نوشت و به کدام مقالات/محصولات موجود لینک داخلی بدهد.\n";
		$task .= "۸. موضوعات را به ترتیب اولویت اجرا مرتب کن.\n";
		if ( $hint ) {
			$task .= "\nتمرکز ویژه مدیر سایت: {$hint}\n";
		}
		$task .= "\nقالب خروجی (فقط JSON):\n" . '{"summary":"خلاصه کسب‌وکار","audience":"مخاطب هدف","business_type":"","pillars":[{"name":"","description":""}],"gaps":[""],"competitors":[{"name":"","url":"","strengths":"","weaknesses":""}],"trends":[""],"seo_notes":[""],"topics":[{"title":"","focus_keyword":"","keywords":["",""],"intent":"informational|commercial|transactional","priority":"high|medium|low","pillar":"","category":"یکی از دسته‌های موجود یا پیشنهاد جدید","word_count":1800,"reason":"","angle":"","internal_links":[""]}]}';
		$task .= "\n\n# داده‌های سایت\n" . self::inventory_text( $inv );

		return array( 'system' => $system, 'prompt' => $task );
	}

	public static function sanitize_result( $a ) {
		if ( ! is_array( $a ) ) {
			return null;
		}
		$clean_list = function ( $v ) {
			return array_values( array_filter( array_map( function ( $x ) {
				return is_scalar( $x ) ? sanitize_text_field( (string) $x ) : '';
			}, (array) $v ) ) );
		};
		$out = array(
			'summary'       => sanitize_textarea_field( (string) ( $a['summary'] ?? '' ) ),
			'audience'      => sanitize_textarea_field( (string) ( $a['audience'] ?? '' ) ),
			'business_type' => sanitize_text_field( (string) ( $a['business_type'] ?? '' ) ),
			'gaps'          => $clean_list( $a['gaps'] ?? array() ),
			'trends'        => $clean_list( $a['trends'] ?? array() ),
			'seo_notes'     => $clean_list( $a['seo_notes'] ?? array() ),
			'pillars'       => array(),
			'competitors'   => array(),
			'topics'        => array(),
		);
		foreach ( (array) ( $a['pillars'] ?? array() ) as $p ) {
			if ( is_array( $p ) && ! empty( $p['name'] ) ) {
				$out['pillars'][] = array( 'name' => sanitize_text_field( $p['name'] ), 'description' => sanitize_text_field( $p['description'] ?? '' ) );
			}
		}
		foreach ( (array) ( $a['competitors'] ?? array() ) as $c ) {
			if ( is_array( $c ) && ! empty( $c['name'] ) ) {
				$out['competitors'][] = array(
					'name'       => sanitize_text_field( $c['name'] ),
					'url'        => esc_url_raw( (string) ( $c['url'] ?? '' ) ),
					'strengths'  => sanitize_text_field( $c['strengths'] ?? '' ),
					'weaknesses' => sanitize_text_field( $c['weaknesses'] ?? ( $c['weakness'] ?? '' ) ),
				);
			}
		}
		foreach ( (array) ( $a['topics'] ?? array() ) as $t ) {
			if ( ! is_array( $t ) || empty( $t['title'] ) ) {
				continue;
			}
			$prio            = in_array( $t['priority'] ?? '', array( 'high', 'medium', 'low' ), true ) ? $t['priority'] : 'medium';
			$out['topics'][] = array(
				'title'          => sanitize_text_field( $t['title'] ),
				'focus_keyword'  => sanitize_text_field( $t['focus_keyword'] ?? '' ),
				'keywords'       => array_slice( $clean_list( $t['keywords'] ?? array() ), 0, 10 ),
				'intent'         => sanitize_key( $t['intent'] ?? '' ),
				'priority'       => $prio,
				'pillar'         => sanitize_text_field( $t['pillar'] ?? '' ),
				'category'       => sanitize_text_field( $t['category'] ?? '' ),
				'word_count'     => min( 6000, absint( $t['word_count'] ?? 0 ) ),
				'reason'         => sanitize_text_field( $t['reason'] ?? '' ),
				'angle'          => sanitize_text_field( $t['angle'] ?? '' ),
				'internal_links' => array_slice( $clean_list( $t['internal_links'] ?? array() ), 0, 6 ),
			);
		}
		return $out['topics'] || $out['summary'] ? $out : null;
	}

	public static function save( $result, array $meta = array() ) {
		$clean = self::sanitize_result( $result );
		if ( ! $clean ) {
			return new WP_Error( 'aaw', 'خروجی تحلیل معتبر نبود؛ دوباره تلاش کنید یا مدل قوی‌تری انتخاب کنید.' );
		}
		$record = array(
			'time'   => time(),
			'result' => $clean,
			'meta'   => array(
				'provider'    => sanitize_text_field( $meta['provider'] ?? '' ),
				'model'       => sanitize_text_field( $meta['model'] ?? '' ),
				'web'         => ! empty( $meta['web'] ),
				'competitors' => (int) ( $meta['competitors_fetched'] ?? 0 ),
				'stats'       => isset( $meta['stats'] ) && is_array( $meta['stats'] ) ? array_map( 'intval', $meta['stats'] ) : array(),
				'runner'      => sanitize_key( $meta['runner'] ?? '' ),
			),
		);
		update_option( self::OPTION, $record, false );
		AAW_Logs::add( 'success', 'analysis', sprintf( 'تحلیل هوشمند سایت انجام شد: %d موضوع پیشنهادی، %d رقیب بررسی شد.', count( $clean['topics'] ), count( $clean['competitors'] ) ), array( 'provider' => $record['meta']['provider'], 'model' => $record['meta']['model'] ) );
		return $record;
	}

	public static function get() {
		$r = get_option( self::OPTION, array() );
		return is_array( $r ) && ! empty( $r['result'] ) ? $r : null;
	}

	/** Queue selected topics with all the strategic context the writer needs. */
	public static function add_topics( array $topics, $create_categories = false ) {
		$added    = 0;
		$skipped  = 0;
		$existing = AAW_Topics::all_titles_normalized();
		foreach ( $topics as $t ) {
			$t = is_array( $t ) ? $t : array();
			if ( empty( $t['title'] ) ) {
				continue;
			}
			$norm = AAW_Topics::normalize( $t['title'] );
			if ( isset( $existing[ $norm ] ) ) {
				++$skipped;
				continue;
			}
			$cat = 0;
			if ( ! empty( $t['category'] ) ) {
				$term = get_term_by( 'name', $t['category'], 'category' );
				if ( $term ) {
					$cat = (int) $term->term_id;
				} elseif ( $create_categories ) {
					$cat = AAW_Topics::resolve_category( $t['category'] );
				}
			}
			$notes = array();
			if ( ! empty( $t['angle'] ) ) {
				$notes[] = 'زاویه برتری نسبت به رقبا: ' . $t['angle'];
			}
			if ( ! empty( $t['reason'] ) ) {
				$notes[] = 'چرا این موضوع: ' . $t['reason'];
			}
			if ( ! empty( $t['intent'] ) ) {
				$notes[] = 'نیت جستجو: ' . $t['intent'];
			}
			if ( ! empty( $t['internal_links'] ) ) {
				$notes[] = 'حتماً به این مطالب/محصولات لینک داخلی بده: ' . implode( '، ', (array) $t['internal_links'] );
			}
			$kw = array_filter( array_merge( array( $t['focus_keyword'] ?? '' ), (array) ( $t['keywords'] ?? array() ) ) );
			$r  = AAW_Topics::add(
				array(
					'title'       => $t['title'],
					'keywords'    => array_values( array_unique( $kw ) ),
					'category_id' => $cat,
					'word_count'  => (int) ( $t['word_count'] ?? 0 ),
					'priority'    => 'high' === ( $t['priority'] ?? '' ) ? 1 : 0,
					'notes'       => implode( "\n", $notes ),
					'source'      => 'ai',
				)
			);
			if ( ! is_wp_error( $r ) ) {
				++$added;
				$existing[ $norm ] = true;
			}
		}
		AAW_Logs::add( 'info', 'topics', sprintf( '%d موضوع از تحلیل هوشمند به صف اضافه شد.', $added ) );
		return array( 'added' => $added, 'skipped' => $skipped );
	}

	/** Can the chosen engine search the live web? */
	public static function web_capable() {
		$p = AAW_Providers::get( AAW_Settings::get( 'provider' ) );
		if ( ! $p ) {
			return false;
		}
		return 'sub_claude' === $p['id'] || 'perplexity' === $p['id'] || 'openrouter' === $p['id'];
	}
}
