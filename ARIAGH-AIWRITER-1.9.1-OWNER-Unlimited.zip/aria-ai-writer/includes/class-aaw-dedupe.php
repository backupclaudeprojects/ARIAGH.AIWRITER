<?php
/**
 * Duplicate-content guard.
 *
 * Builds a compact, cached "content memory" of everything the site already has
 * (posts, drafts, products, queued topics) with titles + focus keywords, and
 * scores new topics against it with a Persian-aware token similarity. Used to:
 *  - skip topics that are effectively the same as an existing article,
 *  - reject near-duplicate topics when they are added to the queue,
 *  - tell the AI exactly which existing articles are closest, so it writes a
 *    distinct angle and links to them instead of repeating them.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Dedupe {

	const CACHE = 'aaw_dedupe_corpus';

	private static $corpus = null;

	private static function stopwords() {
		static $sw = null;
		if ( null === $sw ) {
			$sw = array_flip(
				array(
					'و', 'در', 'به', 'از', 'که', 'با', 'این', 'آن', 'را', 'برای', 'تا', 'یا', 'هم', 'چه', 'چی', 'چیست', 'چیه', 'چگونه', 'چطور', 'چرا', 'کدام',
					'است', 'هست', 'شود', 'کنیم', 'کنید', 'کرد', 'کردن', 'های', 'ها', 'ی', 'یک', 'هر', 'بر', 'می', 'نمی', 'شد', 'باید', 'بهترین', 'کامل', 'راهنما',
					'راهنمای', 'معرفی', 'نکته', 'نکات', 'روش', 'روشهای', 'روش‌های', 'انواع', 'همه', 'چیز', 'درباره', 'مورد', 'خانه', 'خانگی', 'جدید', 'سال',
					'the', 'a', 'an', 'of', 'to', 'in', 'for', 'and', 'or', 'how', 'what', 'why', 'best', 'guide', 'complete', 'top', 'vs', 'with', 'on', 'is',
				)
			);
		}
		return $sw;
	}

	/** Persian/Arabic normalisation + light stemming. */
	public static function tokens( $text ) {
		$t = str_replace( array( 'ي', 'ك', 'ۀ', 'ة', 'أ', 'إ', 'آ', '‌', '‏', 'ـ' ), array( 'ی', 'ک', 'ه', 'ه', 'ا', 'ا', 'ا', ' ', ' ', '' ), (string) $text );
		$t = strtr( $t, array( '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9' ) );
		$t = mb_strtolower( preg_replace( '/[^\p{L}\p{N}\s]/u', ' ', $t ) );
		$out = array();
		$sw  = self::stopwords();
		foreach ( preg_split( '/\s+/u', $t, -1, PREG_SPLIT_NO_EMPTY ) as $w ) {
			if ( isset( $sw[ $w ] ) || mb_strlen( $w ) < 2 || preg_match( '/^\d{4}$/', $w ) ) {
				continue;
			}
			// Light suffix stripping: plurals / ezafe / comparatives.
			$w = preg_replace( '/(هایی|های|ها|ات|ترین|تر|ی|ان)$/u', '', $w );
			if ( mb_strlen( $w ) < 2 || isset( $sw[ $w ] ) ) {
				continue;
			}
			$out[ $w ] = true;
		}
		return array_keys( $out );
	}

	/** Weighted overlap score 0..1 (title tokens + keyword tokens). */
	public static function score( array $a, array $b ) {
		if ( ! $a || ! $b ) {
			return 0.0;
		}
		$inter = count( array_intersect( $a, $b ) );
		if ( ! $inter ) {
			return 0.0;
		}
		$jac   = $inter / count( array_unique( array_merge( $a, $b ) ) );
		$cover = $inter / min( count( $a ), count( $b ) ); // Containment: short title fully inside a longer one.
		return round( 0.55 * $jac + 0.45 * $cover, 3 );
	}

	/** Compact cached corpus of existing content. */
	public static function corpus() {
		if ( null !== self::$corpus ) {
			return self::$corpus;
		}
		$c = get_transient( self::CACHE );
		if ( is_array( $c ) ) {
			self::$corpus = $c;
			return $c;
		}
		global $wpdb;
		$rows = $wpdb->get_results(
			"SELECT p.ID, p.post_title, p.post_type, p.post_status,
				(SELECT meta_value FROM {$wpdb->postmeta} m WHERE m.post_id = p.ID AND m.meta_key IN ('rank_math_focus_keyword','_yoast_wpseo_focuskw','_aaw_focus_keyword') LIMIT 1) AS kw
			FROM {$wpdb->posts} p
			WHERE p.post_type IN ('post','product','page') AND p.post_status IN ('publish','draft','pending','future')
			ORDER BY p.ID DESC LIMIT 3000",
			ARRAY_A
		); // phpcs:ignore
		$c = array();
		foreach ( (array) $rows as $r ) {
			$kw  = (string) $r['kw'];
			$c[] = array(
				'id'   => (int) $r['ID'],
				'type' => $r['post_type'],
				'st'   => $r['post_status'],
				't'    => $r['post_title'],
				'kw'   => $kw,
				'tok'  => self::tokens( $r['post_title'] . ' ' . str_replace( ',', ' ', $kw ) ),
			);
		}
		set_transient( self::CACHE, $c, 12 * HOUR_IN_SECONDS );
		self::$corpus = $c;
		return $c;
	}

	public static function flush( $post_id = 0 ) {
		if ( $post_id && wp_is_post_revision( $post_id ) ) {
			return;
		}
		delete_transient( self::CACHE );
		self::$corpus = null;
	}

	/**
	 * Closest existing items.
	 *
	 * @return array<int,array{id:int,title:string,keyword:string,score:float,type:string,url:string}>
	 */
	public static function nearest( $title, $keywords = '', $n = 8, $types = array( 'post' ), $exclude = 0 ) {
		$q   = self::tokens( $title . ' ' . str_replace( array( ',', '،' ), ' ', (string) $keywords ) );
		$out = array();
		foreach ( self::corpus() as $item ) {
			if ( ( $exclude && $item['id'] === (int) $exclude ) || ! in_array( $item['type'], $types, true ) ) {
				continue;
			}
			$sc = self::score( $q, $item['tok'] );
			if ( $sc > 0.15 ) {
				$out[] = array( 'id' => $item['id'], 'title' => $item['t'], 'keyword' => $item['kw'], 'score' => $sc, 'type' => $item['type'], 'status' => $item['st'] );
			}
		}
		usort(
			$out,
			function ( $a, $b ) {
				return $b['score'] <=> $a['score'];
			}
		);
		$out = array_slice( $out, 0, $n );
		foreach ( $out as &$o ) {
			$o['url'] = 'publish' === $o['status'] ? get_permalink( $o['id'] ) : '';
		}
		return $out;
	}

	/** Threshold 50..100 from settings → 0.5..1.0. */
	public static function threshold() {
		return max( 0.5, min( 1.0, (int) AAW_Settings::get( 'duplicate_threshold', 75 ) / 100 ) );
	}

	/** @return array|null Matching existing post if the topic duplicates it. */
	public static function duplicate_of( $title, $keywords = '' ) {
		$n = self::nearest( $title, $keywords, 1 );
		return ( $n && $n[0]['score'] >= self::threshold() ) ? $n[0] : null;
	}

	/** Similarity to topics already waiting in the queue. */
	public static function queued_duplicate( $title, $keywords = '', $exclude_id = 0 ) {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT id, title, keywords FROM ' . AAW_Topics::table() . " WHERE status IN ('pending','processing','paused','failed') ORDER BY id DESC LIMIT 1000", ARRAY_A ); // phpcs:ignore
		$q    = self::tokens( $title . ' ' . $keywords );
		foreach ( (array) $rows as $r ) {
			if ( (int) $r['id'] === (int) $exclude_id ) {
				continue;
			}
			if ( self::score( $q, self::tokens( $r['title'] . ' ' . $r['keywords'] ) ) >= self::threshold() ) {
				return $r;
			}
		}
		return null;
	}

	/** Prompt block: closest existing articles the AI must not repeat. */
	public static function prompt_block( $title, $keywords = '' ) {
		$near = self::nearest( $title, $keywords, 8 );
		if ( ! $near ) {
			return '';
		}
		$lines = array();
		foreach ( $near as $n ) {
			$lines[] = '- «' . $n['title'] . '»' . ( $n['keyword'] ? ' (کلمه کلیدی: ' . $n['keyword'] . ')' : '' ) . ( $n['url'] ? ' => ' . $n['url'] : '' ) . ' — شباهت ' . round( $n['score'] * 100 ) . '٪';
		}
		return "## جلوگیری از محتوای تکراری (بسیار مهم)\nاین مقالات نزدیک قبلاً در سایت وجود دارند. مقاله جدید نباید همان محتوا، همان زاویه، همان ساختار سرفصل‌ها یا همان کلمه کلیدی اصلی را تکرار کند. یک زاویه، نیت جستجو یا بخش کاملاً تازه انتخاب کن، اطلاعات تکمیلی و جدید بده و در صورت ارتباط به این مقالات با انکر طبیعی لینک بده (همپوشانی کلمه کلیدی = آسیب به سئو):\n" . implode( "\n", $lines );
	}

	/** Compact list of existing titles (+keywords) for idea generation prompts. */
	public static function existing_index( $limit = 150 ) {
		$out = array();
		foreach ( self::corpus() as $i ) {
			if ( 'post' !== $i['type'] ) {
				continue;
			}
			$out[] = $i['t'] . ( $i['kw'] ? ' [' . $i['kw'] . ']' : '' );
			if ( count( $out ) >= $limit ) {
				break;
			}
		}
		return $out;
	}
}
