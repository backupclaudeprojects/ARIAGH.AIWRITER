<?php
/**
 * Google Search Console (read-only) through the Cloudflare worker.
 *
 * Connection: a Google Cloud *service account* (JSON key) that the site owner adds as a
 * user of the Search Console property. The key is stored only as a Cloudflare secret;
 * every Google call runs on Cloudflare (Google APIs are not reached from the host).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_GSC {

	const REPORT = 'aaw_gsc_report';

	public static function connected() {
		return '' !== (string) AAW_Settings::get( 'gsc_site' ) && isset( AAW_Settings::key_meta()['gsc'] ) && AAW_Cloudflare::is_deployed();
	}

	public static function site() {
		return (string) AAW_Settings::get( 'gsc_site' );
	}

	/** Validate + store the service-account JSON as a worker secret, then list its properties. */
	public static function save_key( $json ) {
		$j = json_decode( trim( (string) $json ), true );
		if ( ! is_array( $j ) || empty( $j['client_email'] ) || empty( $j['private_key'] ) ) {
			return new WP_Error( 'aaw', AAW_Errors::format( 'فایل JSON معتبر نیست', 'محتوای فایل کلید Service Account باید شامل client_email و private_key باشد.', 'در Google Cloud → IAM → Service Accounts → Keys → Add key → JSON، فایل را بسازید و کل محتوایش (از { تا }) را جای‌گذاری کنید.' ) );
		}
		if ( ( $j['type'] ?? '' ) !== 'service_account' ) {
			return new WP_Error( 'aaw', 'این فایل کلید Service Account نیست (type باید service_account باشد).' );
		}
		$j['private_key'] = str_replace( array( '\\n', "\r\n" ), "\n", (string) $j['private_key'] );
		if ( false === strpos( $j['private_key'], 'PRIVATE KEY-----' ) || ( function_exists( 'openssl_pkey_get_private' ) && ! @openssl_pkey_get_private( $j['private_key'] ) ) ) { // phpcs:ignore
			return new WP_Error( 'aaw', AAW_Errors::format( 'کلید خصوصی داخل فایل JSON سالم نیست', 'مقدار private_key ناقص یا تغییر کرده است (مثلاً هنگام کپی بخشی از آن جا مانده).', 'فایل JSON را با Notepad باز کنید، کل محتوا را (Ctrl+A) کپی و دوباره جای‌گذاری کنید؛ یا از روش «Client ID و Client Secret» استفاده کنید.' ) );
		}
		if ( ! AAW_Cloudflare::is_deployed() ) {
			return new WP_Error( 'aaw', 'ابتدا ورکر کلادفلر را مستقر کنید؛ کلید فقط در Secrets کلادفلر ذخیره می‌شود.' );
		}
		$r = AAW_Cloudflare::put_secret( 'AAW_GSC_KEY', wp_json_encode( $j ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		AAW_Settings::set_key_meta( 'gsc', sanitize_email( $j['client_email'] ) );
		sleep( 2 ); // Secret propagation.
		return self::sites();
	}

	/* ---------------- Sign in with a Google account (OAuth Client ID / Secret) ---------------- */

	/** Exact address to paste in Google Cloud → Clients → Authorized redirect URIs. */
	public static function redirect_uri() {
		return admin_url( 'admin-post.php?action=aaw_gsc_oauth' );
	}

	public static function save_client( $id, $secret ) {
		$id     = trim( (string) $id );
		$secret = trim( (string) $secret );
		if ( ! preg_match( '/^[0-9]+-[a-z0-9_]+\.apps\.googleusercontent\.com$/i', $id ) ) {
			return new WP_Error( 'aaw', AAW_Errors::format( 'Client ID نامعتبر است', 'Client ID گوگل شبیه 1234567890-abc123.apps.googleusercontent.com است.', 'در Google Auth Platform → Clients روی کلاینت بزنید و Client ID را کامل کپی کنید.' ) );
		}
		if ( strlen( $secret ) < 10 || preg_match( '/\s/', $secret ) ) {
			return new WP_Error( 'aaw', 'Client Secret نامعتبر است (معمولاً با GOCSPX- شروع می‌شود).' );
		}
		if ( ! AAW_Cloudflare::is_deployed() ) {
			return new WP_Error( 'aaw', 'ابتدا ورکر کلادفلر را مستقر کنید؛ Client Secret فقط در Secrets کلادفلر ذخیره می‌شود.' );
		}
		foreach ( array( 'AAW_GSC_CLIENT_ID' => $id, 'AAW_GSC_CLIENT_SECRET' => $secret ) as $name => $val ) {
			$r = AAW_Cloudflare::put_secret( $name, $val );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		AAW_Settings::update( array( 'gsc_client_id' => $id ) );
		AAW_Settings::set_key_meta( 'gsc_client', substr( $id, 0, 12 ) . '…' );
		sleep( 2 ); // Secret propagation.
		return array( 'message' => 'Client ID و Client Secret ذخیره شد. حالا «ورود با حساب گوگل» را بزنید.' ) + self::auth_url();
	}

	public static function auth_url() {
		$id = (string) AAW_Settings::get( 'gsc_client_id' );
		if ( '' === $id ) {
			return new WP_Error( 'aaw', 'ابتدا Client ID و Client Secret را ذخیره کنید.' );
		}
		$state = strtolower( wp_generate_password( 32, false, false ) );
		set_transient( 'aaw_gsc_state_' . get_current_user_id(), $state, 30 * MINUTE_IN_SECONDS );
		$q = array(
			'client_id'              => $id,
			'redirect_uri'           => self::redirect_uri(),
			'response_type'          => 'code',
			'scope'                  => 'openid email https://www.googleapis.com/auth/webmasters.readonly',
			'access_type'            => 'offline',
			'prompt'                 => 'consent',
			'include_granted_scopes' => 'true',
			'state'                  => $state,
		);
		return array( 'url' => 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query( $q, '', '&', PHP_QUERY_RFC3986 ), 'redirect_uri' => self::redirect_uri() );
	}

	/** admin-post.php?action=aaw_gsc_oauth – Google sends the browser back here with ?code=…&state=… */
	public static function oauth_callback() {
		$back = admin_url( 'admin.php?page=aaw&tab=gsc' );
		if ( ! current_user_can( AAW_CAP ) && ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی غیرمجاز' );
		}
		$uid   = get_current_user_id();
		$state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : ''; // phpcs:ignore
		$saved = get_transient( 'aaw_gsc_state_' . $uid );
		$r     = null;
		if ( ! empty( $_GET['error'] ) ) { // phpcs:ignore
			$e = sanitize_text_field( wp_unslash( $_GET['error'] ) ); // phpcs:ignore
			$r = new WP_Error( 'aaw', 'access_denied' === $e ? 'ورود به گوگل لغو شد یا اجازه داده نشد. اگر پیام «Access blocked / has not completed the Google verification» دیدید، در Google Auth Platform → Audience ایمیل خود را در Test users اضافه یا برنامه را Publish کنید.' : 'گوگل خطا داد: ' . $e );
		} elseif ( ! $saved || ! hash_equals( (string) $saved, $state ) ) {
			$r = new WP_Error( 'aaw', 'درخواست ورود منقضی شده یا معتبر نیست؛ دوباره «ورود با حساب گوگل» را بزنید.' );
		} else {
			delete_transient( 'aaw_gsc_state_' . $uid );
			$code = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : ''; // phpcs:ignore
			$r    = AAW_Cloudflare::call_worker( 'gsc_oauth', array( 'action' => 'exchange', 'code' => $code, 'redirect_uri' => self::redirect_uri() ), AAW_Transfer::PIECE_TO );
		}
		if ( is_wp_error( $r ) ) {
			set_transient( 'aaw_gsc_notice_' . $uid, array( 'error', AAW_Errors::explain( $r ) ), 300 );
			AAW_Logs::add( 'error', 'seo', 'اتصال سرچ کنسول با حساب گوگل ناموفق بود: ' . $r->get_error_message() );
		} else {
			$email = sanitize_email( (string) ( $r['email'] ?? '' ) );
			AAW_Settings::set_key_meta( 'gsc', $email ? $email : 'حساب گوگل' );
			$s = self::sites();
			$n = is_wp_error( $s ) ? 0 : count( $s['sites'] );
			set_transient( 'aaw_gsc_notice_' . $uid, array( 'success', 'سرچ کنسول با حساب ' . ( $email ? $email : 'گوگل' ) . ' وصل شد' . ( $n ? '؛ ' . $n . ' property پیدا شد.' : ( is_wp_error( $s ) ? '؛ ولی خواندن propertyها خطا داد: ' . $s->get_error_message() : '؛ ولی این حساب به هیچ property سرچ کنسول دسترسی ندارد.' ) ) ), 300 );
			AAW_Logs::add( 'success', 'seo', 'سرچ کنسول با حساب گوگل وصل شد' . ( $email ? ' (' . $email . ')' : '' ) . '.' );
		}
		wp_safe_redirect( $back );
		exit;
	}

	public static function notice() {
		$k = 'aaw_gsc_notice_' . get_current_user_id();
		$n = get_transient( $k );
		if ( $n ) {
			delete_transient( $k );
		}
		return is_array( $n ) ? $n : null;
	}

	public static function disconnect() {
		if ( AAW_Cloudflare::is_deployed() ) {
			AAW_Cloudflare::call_worker( 'gsc_oauth', array( 'action' => 'disconnect' ), AAW_Transfer::PIECE_TO );
			AAW_Cloudflare::delete_secret( 'AAW_GSC_KEY' );
		}
		AAW_Settings::set_key_meta( 'gsc', null );
		return array( 'message' => 'اتصال سرچ کنسول قطع شد.' );
	}

	/** Properties the service account can read; auto-select the one matching this site. */
	public static function sites() {
		$r = AAW_Cloudflare::call_worker( 'gsc', array( 'action' => 'sites' ), AAW_Transfer::PIECE_TO );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$sites = array_values( array_filter( (array) ( $r['sites'] ?? array() ), function ( $s ) { return 'siteUnverifiedUser' !== ( $s['level'] ?? '' ); } ) );
		$host  = preg_replace( '/^www\./', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$best  = '';
		foreach ( $sites as $s ) {
			$u = (string) $s['url'];
			if ( 'sc-domain:' . $host === $u ) {
				$best = $u;
				break;
			}
			if ( preg_replace( '/^www\./', '', (string) wp_parse_url( $u, PHP_URL_HOST ) ) === $host ) {
				$best = $best ? $best : $u;
			}
		}
		if ( $best && ! AAW_Settings::get( 'gsc_site' ) ) {
			AAW_Settings::update( array( 'gsc_site' => $best ) );
		}
		return array( 'sites' => $sites, 'selected' => AAW_Settings::get( 'gsc_site' ), 'email' => (string) ( $r['email'] ?? '' ) );
	}

	/** Fresh report from Google (stored on Cloudflare, fetched here in small resumable pieces). */
	public static function refresh( $days = 90 ) {
		if ( ! self::site() ) {
			return new WP_Error( 'aaw', 'ابتدا property سرچ کنسول را انتخاب کنید.' );
		}
		$r = AAW_Cloudflare::call_worker( 'gsc', array( 'action' => 'report', 'site' => self::site(), 'days' => (int) $days ), AAW_Transfer::PIECE_TO );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		AAW_Transfer::release( 'gsc_get', 'report' );
		return self::collect();
	}

	/** @return array|null|WP_Error report, null = still downloading (call again). */
	public static function collect() {
		$raw = AAW_Transfer::download( 'gsc_get', 'key', 'report' );
		if ( null === $raw || is_wp_error( $raw ) ) {
			return $raw;
		}
		$rep = json_decode( $raw, true );
		AAW_Transfer::release( 'gsc_get', 'report' );
		if ( ! is_array( $rep ) || ! isset( $rep['top'] ) ) {
			return new WP_Error( 'aaw', 'گزارش سرچ کنسول خوانا نبود.' );
		}
		update_option( self::REPORT, $rep, false );
		delete_transient( 'aaw_merge_candidates' );
		AAW_Logs::add( 'success', 'seo', sprintf( 'داده‌های سرچ کنسول دریافت شد: %d جستجو، %d فرصت نزدیک صفحه اول، %d همپوشانی.', count( $rep['top'] ), count( $rep['striking'] ), count( $rep['cannibal'] ) ) );
		return $rep;
	}

	public static function report() {
		$r = get_option( self::REPORT, array() );
		return is_array( $r ) ? $r : array();
	}

	/** Clicks / impressions of one URL from the stored report. */
	public static function page_stats( $url ) {
		$rep = self::report();
		$n   = self::norm_url( $url );
		foreach ( (array) ( $rep['pages'] ?? array() ) as $p ) {
			if ( self::norm_url( $p['u'] ) === $n ) {
				return $p;
			}
		}
		return array( 'c' => 0, 'i' => 0, 'p' => 0 );
	}

	public static function norm_url( $u ) {
		$u = strtolower( rawurldecode( (string) $u ) );
		$u = preg_replace( '#^https?://(www\.)?#', '', $u );
		return rtrim( preg_replace( '/[#?].*$/', '', $u ), '/' );
	}
}
