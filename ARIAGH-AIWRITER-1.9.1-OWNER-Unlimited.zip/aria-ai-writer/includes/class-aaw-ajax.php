<?php
/**
 * Admin AJAX controller.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Ajax {

	public static function register() {
		$actions = array(
			'save_settings', 'cf_save', 'cf_accounts', 'cf_deploy', 'cf_delete', 'cf_status', 'cf_sync', 'cf_restore', 'cf_rotate', 'cf_schedule',
			'key_save', 'key_delete', 'provider_test', 'provider_models', 'custom_save', 'custom_delete',
			'topics_list', 'topic_add', 'topics_bulk', 'topic_update', 'topics_delete', 'topics_reorder', 'topic_move', 'topics_status', 'topic_duplicate',
			'topics_export', 'topics_import', 'suggest_ticket', 'suggest_add',
			'run_ticket', 'generate_ticket', 'save_generated',
			'review_list', 'review_action',
			'logs_list', 'logs_clear', 'logs_export',
			'settings_export', 'settings_import', 'settings_reset', 'prompt_preview', 'dashboard', 'worker_unlock', 'test_notify', 'reveal_secret', 'manual_worker', 'proxy', 'claude_pro_connect', 'claude_pro_disconnect', 'gh_connect', 'gh_sub_save', 'gh_test', 'gh_runs', 'gh_sync', 'gh_disconnect', 'gh_activate', 'diagnose', 'pull_run', 'pull_poll', 'analysis_start', 'analysis_save', 'analysis_status', 'analysis_add', 'analysis_cancel', 'local_doctor', 'local_install', 'local_install_status', 'local_login_save', 'local_login_start', 'local_login_status', 'local_login_import', 'local_signout', 'local_test', 'local_jobs', 'local_cancel', 'local_route', 'local_settings', 'timeline', 'now', 'license_activate', 'license_check', 'license_deactivate', 'explain', 'run_bg', 'bg_status', 'image_key_save', 'image_test', 'style_learn', 'seo_learn', 'knowledge', 'act_start', 'act_end', 'activity', 'activity_clear', 'revise', 'post_image', 'revision_publish', 'priority', 'priority_save', 'sub_role', 'site_crawl', 'site_status', 'codex_login_start', 'codex_login_status', 'gsc_key_save', 'gsc_client_save', 'gsc_auth_url', 'gsc_disconnect', 'gsc_report', 'gsc_sites', 'gsc_site_save', 'gsc_refresh', 'gsc_add_topics', 'merge_list', 'merge_start', 'merge_undo',
		);
		foreach ( $actions as $a ) {
			add_action( 'wp_ajax_aaw_' . $a, array( __CLASS__, 'dispatch' ) );
		}
	}

	public static function dispatch() {
		$action = isset( $_REQUEST['action'] ) ? substr( sanitize_key( wp_unslash( $_REQUEST['action'] ) ), 4 ) : '';
		if ( ! check_ajax_referer( 'aaw_admin', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'نشست منقضی شده است؛ صفحه را تازه کنید.' ), 403 );
		}
		if ( ! current_user_can( AAW_CAP ) && ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
		}
		// Security-sensitive actions stay with the site administrator (not shop managers / editors).
		$admin_only = array( 'reveal_secret', 'cf_delete', 'cf_rotate', 'settings_reset', 'settings_import', 'license_deactivate', 'gh_disconnect', 'local_install', 'local_login_save', 'local_login_start', 'local_login_import', 'local_signout', 'local_settings', 'local_route' );
		if ( in_array( $action, $admin_only, true ) && ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'این کار فقط با حساب مدیر کل سایت ممکن است.' ), 403 );
		}

		$method = 'a_' . $action;
		if ( ! method_exists( __CLASS__, $method ) ) {
			wp_send_json_error( array( 'message' => 'عملیات ناشناخته' ), 400 );
		}
		try {
			$result = call_user_func( array( __CLASS__, $method ), self::data() );
		} catch ( \Throwable $e ) {
			wp_send_json_error( array( 'message' => AAW_Errors::explain( $e->getMessage() . ' (' . basename( $e->getFile() ) . ':' . $e->getLine() . ')' ) ), 500 );
		}
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => AAW_Errors::explain( $result->get_error_message() ) ) );
		}
		wp_send_json_success( $result );
	}

	private static function data() {
		$raw = isset( $_POST['data'] ) ? wp_unslash( $_POST['data'] ) : '{}'; // phpcs:ignore
		$d   = json_decode( $raw, true );
		return is_array( $d ) ? $d : array();
	}

	/* ============================ Settings ============================ */

	private static function a_save_settings( $d ) {
		$values   = isset( $d['settings'] ) && is_array( $d['settings'] ) ? $d['settings'] : array();
		if ( ! current_user_can( 'manage_options' ) ) {
			unset( $values['allow_shop_managers'], $values['allow_editors'] ); // Role access: administrators only.
		}
		$before   = AAW_Cloudflare::cron_expressions();
		$secure   = array( 'telegram_token' );
		foreach ( $secure as $sk ) {
			if ( isset( $values[ $sk ] ) ) {
				if ( '' !== $values[ $sk ] && false === strpos( $values[ $sk ], '•' ) ) {
					AAW_Settings::secure_set( $sk, sanitize_text_field( $values[ $sk ] ) );
				}
				unset( $values[ $sk ] );
			}
		}
		if ( isset( $values['model'] ) && isset( $values['provider'] ) ) {
			$map                       = AAW_Settings::get( 'provider_models', array() );
			$map[ $values['provider'] ] = $values['model'];
			$values['provider_models'] = $map;
		}
		if ( isset( $values['provider'] ) && ! AAW_Providers::get( $values['provider'] ) ) {
			return new WP_Error( 'aaw', 'پرووایدر انتخاب‌شده معتبر نیست.' );
		}
		if ( isset( $values['custom_cron'] ) && '' !== trim( $values['custom_cron'] ) ) {
			foreach ( preg_split( '/[\r\n;]+/', $values['custom_cron'] ) as $c ) {
				$c = trim( preg_replace( '/\s+/', ' ', $c ) );
				if ( '' !== $c && ! AAW_Cloudflare::valid_cron( $c ) ) {
					return new WP_Error( 'aaw', 'عبارت Cron نامعتبر است: ' . $c );
				}
			}
		}
		AAW_Settings::update( $values );
		$msg   = 'تنظیمات ذخیره شد.';
		$after = AAW_Cloudflare::cron_expressions();
		if ( $before !== $after && AAW_Cloudflare::is_deployed() ) {
			$r    = AAW_Cloudflare::apply_schedule();
			$msg .= is_wp_error( $r ) ? ' (به‌روزرسانی زمان‌بندی کلادفلر ناموفق: ' . $r->get_error_message() . ')' : ' زمان‌بندی کلادفلر هم به‌روز شد.';
		}
		return array(
			'message'  => $msg,
			'next_run' => self::next_run_label(),
			'cron'     => $after,
		);
	}

	private static function next_run_label() {
		$t = AAW_Cloudflare::next_run_ts();
		return $t ? array( 'ts' => $t, 'label' => wp_date( 'l Y/m/d ساعت H:i', $t ) ) : null;
	}

	private static function a_settings_export( $d ) {
		return array(
			'filename' => 'aria-ai-writer-settings-' . gmdate( 'Ymd-His' ) . '.json',
			'content'  => wp_json_encode( AAW_Settings::export(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ),
		);
	}

	private static function a_settings_import( $d ) {
		$data = isset( $d['content'] ) ? json_decode( $d['content'], true ) : null;
		$r    = AAW_Settings::import( $data );
		return is_wp_error( $r ) ? $r : array( 'message' => 'تنظیمات با موفقیت وارد شد.' );
	}

	private static function a_settings_reset( $d ) {
		$keep = array();
		foreach ( array( 'cf_account_id', 'worker_name', 'kv_namespace_id', 'worker_url', 'deployed_at', 'deployed_version' ) as $k ) {
			$keep[ $k ] = AAW_Settings::get( $k );
		}
		AAW_Settings::reset();
		AAW_Settings::update( $keep );
		return array( 'message' => 'تنظیمات به حالت پیش‌فرض بازگشت (اتصال کلادفلر حفظ شد).' );
	}

	private static function a_prompt_preview( $d ) {
		$topic = array(
			'id'          => 0,
			'title'       => ! empty( $d['topic'] ) ? sanitize_text_field( $d['topic'] ) : 'نمونه موضوع مقاله',
			'keywords'    => ! empty( $d['keywords'] ) ? sanitize_text_field( $d['keywords'] ) : '',
			'category_id' => 0,
			'word_count'  => 0,
			'tone'        => '',
			'notes'       => '',
		);
		if ( isset( $d['system_prompt'] ) ) {
			// Preview unsaved prompt without persisting it.
			AAW_Settings::set_runtime( 'system_prompt', (string) $d['system_prompt'] );
		}
		$p = AAW_Prompt::build( $topic, array() );
		return array(
			'system'  => $p['system'],
			'user'    => $p['user'],
			'outline' => $p['outline'],
			'chars'   => mb_strlen( $p['system'] . $p['user'] ),
		);
	}

	private static function a_dashboard( $d ) {
		return array(
			'counts'   => AAW_Topics::counts(),
			'stats'    => AAW_Logs::stats( 30 ),
			'review'   => AAW_Plugin::pending_review_count(),
			'next_run' => self::next_run_label(),
		);
	}

	/* ============================ Cloudflare ============================ */

	private static function a_cf_save( $d ) {
		$acc   = isset( $d['account_id'] ) ? preg_replace( '/[^a-f0-9]/i', '', $d['account_id'] ) : '';
		$token = isset( $d['token'] ) ? trim( sanitize_text_field( $d['token'] ) ) : '';
		$name  = isset( $d['worker_name'] ) ? $d['worker_name'] : AAW_Settings::get( 'worker_name' );
		AAW_Settings::update( array( 'cf_account_id' => $acc, 'worker_name' => $name ) );
		if ( '' !== $token && false === strpos( $token, '•' ) ) {
			AAW_Settings::secure_set( 'cf_api_token', $token );
		}
		$v = AAW_Cloudflare::verify_token();
		if ( is_wp_error( $v ) ) {
			return $v;
		}
		AAW_Logs::add( 'success', 'cloudflare', 'اتصال به کلادفلر تایید شد.' );
		return array(
			'message' => 'توکن معتبر است (وضعیت: ' . ( $v['status'] ?? 'active' ) . '). اکنون ورکر را مستقر کنید.',
			'mask'    => AAW_Crypto::mask( AAW_Cloudflare::token() ),
		);
	}

	private static function a_cf_accounts( $d ) {
		if ( ! empty( $d['token'] ) && false === strpos( $d['token'], '•' ) ) {
			AAW_Settings::secure_set( 'cf_api_token', trim( sanitize_text_field( $d['token'] ) ) );
		}
		$r = AAW_Cloudflare::list_accounts();
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$out = array();
		foreach ( (array) $r as $acc ) {
			$out[] = array( 'id' => $acc['id'], 'name' => $acc['name'] );
		}
		return array( 'accounts' => $out );
	}

	private static function a_cf_deploy( $d ) {
		$r = AAW_Cloudflare::deploy();
		if ( is_wp_error( $r ) ) {
			AAW_Logs::add( 'error', 'deploy', $r->get_error_message() );
			return $r;
		}
		if ( AAW_GitHub::is_connected() ) {
			AAW_GitHub::sync_base_secrets();
		}
		return array(
			'message' => 'ورکر مستقر شد و Cron فعال است.',
			'url'     => $r['url'],
			'cron'    => $r['cron'],
		);
	}

	private static function a_cf_delete( $d ) {
		$r = AAW_Cloudflare::delete_worker();
		return is_wp_error( $r ) ? $r : array( 'message' => 'ورکر حذف شد.' );
	}

	private static function a_cf_schedule( $d ) {
		$r = AAW_Cloudflare::apply_schedule();
		return is_wp_error( $r ) ? $r : array( 'message' => $r ? 'زمان‌بندی اعمال شد: ' . implode( ' , ', $r ) : 'زمان‌بندی متوقف شد.', 'next_run' => self::next_run_label() );
	}

	private static function a_cf_status( $d ) {
		$out = array( 'configured' => AAW_Cloudflare::is_configured(), 'deployed' => AAW_Cloudflare::is_deployed() );
		if ( ! $out['configured'] ) {
			return $out;
		}
		$sec = AAW_Cloudflare::list_secrets();
		$out['secrets'] = is_wp_error( $sec ) ? array() : wp_list_pluck( (array) $sec, 'name' );
		$sch = AAW_Cloudflare::get_schedule();
		$out['schedules'] = is_wp_error( $sch ) ? array() : wp_list_pluck( (array) ( $sch['schedules'] ?? array() ), 'cron' );
		if ( $out['deployed'] ) {
			$w = AAW_Cloudflare::call_worker( 'status', array(), 20 );
			$out['worker'] = is_wp_error( $w ) ? array( 'error' => $w->get_error_message() ) : $w;
		}
		$out['outdated'] = $out['deployed'] && AAW_Settings::get( 'deployed_version' ) !== AAW_VERSION;
		$out['caps']     = $out['deployed'] ? AAW_Cloudflare::caps( true ) : array();
		return $out;
	}

	private static function a_cf_sync( $d ) {
		return AAW_Cloudflare::sync_kv() ? array( 'message' => 'تنظیمات و موضوعات در KV کلادفلر پشتیبان‌گیری شد.' ) : new WP_Error( 'aaw', 'همگام‌سازی KV انجام نشد (اتصال یا KV را بررسی کنید).' );
	}

	private static function a_cf_restore( $d ) {
		$r = AAW_Cloudflare::restore_from_kv();
		return is_wp_error( $r ) ? $r : array( 'message' => 'بازیابی از کلادفلر انجام شد. موضوعات بازیابی‌شده: ' . $r['topics'] );
	}

	private static function a_cf_rotate( $d ) {
		$old = AAW_Settings::shared_secret();
		$new = AAW_Crypto::random_secret( 32 );
		if ( AAW_Cloudflare::is_deployed() ) {
			$r = AAW_Cloudflare::put_secret( 'AAW_SHARED_SECRET', $new );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		AAW_Settings::secure_set( 'shared_secret', $new );
		unset( $old );
		if ( AAW_GitHub::is_connected() ) {
			AAW_GitHub::put_secret( 'AAW_SHARED_SECRET', $new );
		}
		if ( AAW_Settings::get( 'claude_pro_enabled' ) ) {
			AAW_Cloudflare::put_secret( 'AAW_SHARED_SECRET', $new, AAW_Settings::get( 'runner_name' ) );
		}
		AAW_Logs::add( 'warning', 'security', 'کلید امضای مشترک تعویض شد.' );
		return array( 'message' => 'کلید امضای مشترک با موفقیت تعویض شد.' );
	}

	private static function a_reveal_secret( $d ) {
		return array( 'secret' => AAW_Settings::shared_secret() );
	}

	private static function a_manual_worker( $d ) {
		$url = isset( $d['worker_url'] ) ? esc_url_raw( trim( $d['worker_url'] ), array( 'https' ) ) : '';
		if ( ! $url ) {
			return new WP_Error( 'aaw', 'آدرس ورکر نامعتبر است (باید با https شروع شود).' );
		}
		AAW_Settings::update( array( 'worker_url' => untrailingslashit( $url ), 'deployed_at' => time(), 'deployed_version' => AAW_VERSION ) );
		$r = AAW_Cloudflare::call_worker( 'status', array(), 20 );
		if ( is_wp_error( $r ) ) {
			return new WP_Error( 'aaw', 'آدرس ذخیره شد اما ورکر پاسخ معتبر نداد: ' . $r->get_error_message() );
		}
		return array( 'message' => 'ورکر دستی متصل شد و امضا تایید شد.' );
	}

	/** End-to-end connectivity diagnosis between the Cloudflare worker and WordPress. */
	private static function a_diagnose( $d ) {
		$out = array(
			'home'     => home_url(),
			'rest'     => rest_url( 'aaw/v1' ),
			'wp_api'   => AAW_Cloudflare::wp_api(),
			'worker'   => AAW_Cloudflare::endpoint(),
			'deployed' => AAW_Cloudflare::is_deployed(),
			'checks'   => array(),
		);
		$add = function ( $ok, $title, $detail = '' ) use ( &$out ) {
			$out['checks'][] = array( 'ok' => $ok, 'title' => $title, 'detail' => $detail );
		};
		$host = wp_parse_url( $out['wp_api'], PHP_URL_HOST );
		$add( $host && ! preg_match( '/^(localhost|127\.|10\.|192\.168\.)/', $host ) && false !== strpos( $host, '.' ), 'آدرس REST عمومی است', $out['wp_api'] );
		$add( 0 === strpos( $out['wp_api'], 'https://' ), 'آدرس REST با https است', 0 === strpos( $out['wp_api'], 'https://' ) ? '' : 'استفاده از http ممکن است با ریدایرکت به https مشکل ایجاد کند.' );
		if ( ! $out['deployed'] ) {
			$add( false, 'ورکر مستقر شده است', 'ابتدا ورکر را مستقر کنید.' );
			return $out;
		}
		if ( AAW_Pull::active() ) {
			$st = AAW_Cloudflare::call_worker( 'status', array(), 30 );
			$add( true, 'اتصال معکوس فعال است', 'در این حالت کلادفلر به سایت شما وصل نمی‌شود؛ پس DNS و در دسترس بودن سایت اهمیتی ندارد.' );
			$add( ! is_wp_error( $st ), 'اتصال وردپرس به ورکر کلادفلر', is_wp_error( $st ) ? $st->get_error_message() : 'برقرار است (نسخه ورکر ' . ( $st['version'] ?? '?' ) . ')' );
			if ( ! is_wp_error( $st ) && ( $st['version'] ?? '' ) !== AAW_VERSION ) {
				$add( false, 'نسخه ورکر به‌روز است', 'ورکر نسخه ' . ( $st['version'] ?? '?' ) . ' است؛ «استقرار مجدد» را بزنید.' );
			}
			return $out;
		}
		$r = AAW_Cloudflare::call_worker( 'diag', array(), 45 );
		if ( is_wp_error( $r ) ) {
			$msg = $r->get_error_message();
			if ( false !== stripos( $msg, 'Unknown route' ) ) {
				$msg = 'نسخه ورکر قدیمی است؛ در همین تب «استقرار مجدد» را بزنید و دوباره عیب‌یابی کنید.';
			}
			$add( false, 'ارتباط وردپرس با ورکر', $msg );
			return $out;
		}
		$g            = $r['diag'];
		$out['diag']  = $g;
		$add( $g['wp_api'] === $out['wp_api'], 'آدرس REST داخل ورکر با تنظیمات فعلی یکی است', $g['wp_api'] === $out['wp_api'] ? $g['wp_api'] : 'ورکر از «' . $g['wp_api'] . '» استفاده می‌کند؛ «استقرار مجدد» را بزنید.' );
		$a     = isset( $g['dns']['A']['answers'] ) ? $g['dns']['A']['answers'] : array();
		$aaaa  = isset( $g['dns']['AAAA']['answers'] ) ? $g['dns']['AAAA']['answers'] : array();
		$add( ! empty( $a ) || ! empty( $aaaa ), 'DNS دامنه از داخل شبکه کلادفلر پیدا می‌شود', $a || $aaaa ? implode( '، ', array_merge( $a, $aaaa ) ) : 'هیچ رکورد A/AAAA برای «' . ( $g['host'] ?? '' ) . '» از دید 1.1.1.1 پیدا نشد (علت اصلی خطای 1016). DNS دامنه/زیردامنه www را بررسی کنید.' );
		if ( ! empty( $g['private_ip'] ) ) {
			$add( false, 'IP دامنه عمومی است', 'دامنه به IP داخلی/خصوصی اشاره می‌کند و از اینترنت قابل دسترسی نیست.' );
		}
		$http = $g['http'] ?? array();
		if ( isset( $http['error'] ) ) {
			$add( false, 'اتصال HTTP ورکر به سایت', $http['error'] );
		} else {
			$body = (string) ( $http['body'] ?? '' );
			$code = (int) ( $http['status'] ?? 0 );
			if ( preg_match( '/error code: (\d+)/', $body, $m ) ) {
				$map = array(
					'1016' => 'Origin DNS error: کلادفلرِ سایت شما رکورد مبدأ (Origin) را پیدا نمی‌کند. در DNS کلادفلر دامنه، رکورد A را با IP سرور بررسی کنید؛ اگر رکورد CNAME به سرویس دیگری (مثلاً CDN ایرانی) اشاره می‌کند، آن مقصد از خارج ایران resolve نمی‌شود — به رکورد A مستقیم تغییر دهید.',
					'1020' => 'فایروال (WAF) سایت درخواست را بست؛ یک قانون Skip برای مسیر /wp-json/aaw/v1/ بسازید.',
				);
				$add( false, 'اتصال HTTP ورکر به سایت (کد ' . $m[1] . ')', $map[ $m[1] ] ?? $body );
			} elseif ( in_array( $code, array( 301, 302, 307, 308 ), true ) ) {
				$add( false, 'اتصال HTTP ورکر به سایت', 'ریدایرکت به «' . ( $http['location'] ?? '' ) . '». آدرس REST را در «آدرس REST برای ورکر» دقیقاً همان آدرس نهایی (مثلاً با/بدون www) قرار دهید و استقرار مجدد کنید.' );
			} elseif ( 401 === $code && false !== strpos( $body, 'aaw_auth' ) ) {
				$add( true, 'اتصال HTTP ورکر به سایت', 'ورکر به REST افزونه رسید (' . $code . ' مورد انتظار برای درخواست بدون امضا) · ' . (int) $http['ms'] . 'ms' );
			} elseif ( $code >= 200 && $code < 300 ) {
				$add( true, 'اتصال HTTP ورکر به سایت', 'HTTP ' . $code );
			} elseif ( 404 === $code ) {
				$add( false, 'اتصال HTTP ورکر به سایت', 'مسیر REST پیدا نشد (404). پیوندهای یکتا را یک‌بار ذخیره کنید یا آدرس REST را به شکل ?rest_route=/aaw/v1 تنظیم کنید.' );
			} elseif ( 403 === $code || 503 === $code ) {
				$add( false, 'اتصال HTTP ورکر به سایت', 'HTTP ' . $code . ' — احتمالاً فایروال هاست، افزونه امنیتی یا Bot Fight Mode کلادفلر. سرور: ' . ( $http['server'] ?? '' ) );
			} else {
				$add( false, 'اتصال HTTP ورکر به سایت', 'HTTP ' . $code . ' · ' . mb_substr( $body, 0, 160 ) );
			}
		}
		return $out;
	}

	private static function a_pull_run( $d ) {
		$lic = AAW_License::can_generate();
		if ( is_wp_error( $lic ) ) {
			return $lic;
		}
		return AAW_Pull::run_cycle( 'manual', absint( $d['topic_id'] ?? 0 ) );
	}

	private static function a_pull_poll( $d ) {
		$r = AAW_Pull::poll();
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$r['message'] = $r['drafts'] || $r['errors'] ? sprintf( '%d پیش‌نویس جدید دریافت شد%s.', $r['drafts'], $r['errors'] ? ' و ' . $r['errors'] . ' خطا ثبت شد' : '' ) : ( $r['pending'] ? 'هنوز نتیجه‌ای آماده نیست (' . $r['pending'] . ' اجرا در جریان).' : 'نتیجه جدیدی وجود ندارد.' );
		return $r;
	}

	/* ============================ Smart analysis & timeline ============================ */

	private static function analysis_payload( $d, $light = false ) {
		$inv   = $light ? AAW_Analyzer::inventory_light() : AAW_Analyzer::inventory();
		$comp  = array_slice( array_filter( array_map( 'trim', preg_split( '/[\s,،]+/u', (string) ( $d['competitors'] ?? '' ) ) ) ), 0, 5 );
		$comp  = array_values( array_filter( array_map( function ( $u ) { return esc_url_raw( preg_match( '#^https?://#', $u ) ? $u : 'https://' . $u ); }, $comp ) ) );
		$count = max( 5, min( 50, absint( $d['count'] ?? 20 ) ) );
		$web   = AAW_Analyzer::web_capable();
		$p     = AAW_Analyzer::build_prompt( $inv, $count, sanitize_text_field( $d['hint'] ?? '' ), $web, $comp );
		return array(
			'payload' => array(
				'runtime'     => AAW_REST::runtime(),
				'system'      => $p['system'],
				'prompt'      => $p['prompt'],
				'competitors' => $comp,
				'web'         => $web,
				'gsc'         => AAW_GSC::connected() ? AAW_GSC::site() : '',
				'stats'       => AAW_Analyzer::stats( $inv ),
			),
			'stats'   => AAW_Analyzer::stats( $inv ),
			'web'     => $web,
		);
	}

	private static function a_analysis_ticket( $d ) {
		$x = self::analysis_payload( $d );
		return self::ticket( 'analyze', $x['payload'] );
	}

	private static function a_analysis_start( $d ) {
		$lic = AAW_License::can_generate();
		if ( is_wp_error( $lic ) ) {
			return $lic;
		}
		delete_option( 'aaw_analysis_error' );
		AAW_Analyzer::check_stale();
		if ( AAW_Analyzer::pending_id() ) {
			return new WP_Error( 'aaw', 'یک تحلیل هنوز در حال انجام است. صبر کنید یا آن را «لغو» کنید.' );
		}

		// A subscription account set to "direct from this server": everything runs here (no GitHub, no Cloudflare).
		$local = AAW_SiteData::local_engine();
		$prim  = AAW_Providers::get( AAW_Settings::get( 'provider' ) );
		if ( ! $local && $prim && 'github_runner' === $prim['format'] && AAW_Local::is_local( $prim['engine'] ?? 'claude' ) ) {
			$local = $prim['engine'] ?? 'claude';
		}
		if ( $local ) {
			$x  = self::analysis_payload( $d );
			$p  = $x['payload'];
			unset( $p['runtime'] );
			$id = AAW_Local::start( 'analyze', $local, $p, array( 'kind' => 'analyze' ) );
			if ( is_wp_error( $id ) ) {
				return $id;
			}
			AAW_Analyzer::track( $id, 'local' );
			return array( 'mode' => 'local', 'id' => $id, 'stats' => $x['stats'], 'web' => 'claude' === $local, 'started' => time(), 'engine' => $local );
		}

		if ( ! AAW_Cloudflare::is_deployed() ) {
			return new WP_Error( 'aaw', 'برای تحلیل، ابتدا ورکر کلادفلر را مستقر کنید (تب کلادفلر).' );
		}

		// GitHub reads the whole site, stores the backup on the private branch and runs the analysis there.
		if ( AAW_SiteData::available() ) {
			$x  = self::analysis_payload( $d, true );
			$st = $x['payload']['stats'];
			$st['drafts'] = $st['posts'];
			$r  = AAW_SiteData::start_crawl(
				array(
					'system'      => $x['payload']['system'],
					'prompt'      => $x['payload']['prompt'] . "\n\n(بالا فقط پیش‌نویس‌ها و صف تولید است؛ مقالات منتشرشده، محصولات، برگه‌ها و دسته‌ها در ادامه از نسخه پشتیبان کامل سایت آمده‌اند.)",
					'competitors' => $x['payload']['competitors'],
					'web'         => $x['payload']['web'],
					'gsc'         => $x['payload']['gsc'],
					'stats'       => $st,
				)
			);
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			AAW_Analyzer::track( $r['id'], 'github', AAW_GitHub::repo_url() . '/actions' );
			return array( 'mode' => 'github', 'crawl' => true, 'stats' => $st, 'web' => $x['web'], 'started' => time(), 'url' => AAW_GitHub::repo_url() . '/actions', 'engine' => $r['engine'] );
		}

		$x       = self::analysis_payload( $d );
		$primary = AAW_Providers::get( AAW_Settings::get( 'provider' ) );

		if ( $primary && 'github_runner' === $primary['format'] ) {
			if ( ! AAW_GitHub::is_connected() ) {
				return new WP_Error( 'aaw', 'موتور اصلی اکانت اشتراکی است ولی GitHub متصل نیست.' );
			}
			$id      = 'a' . time() . strtolower( wp_generate_password( 6, false, false ) );
			$payload = array( 'status' => 'analyze' ) + $x['payload'];
			unset( $payload['runtime'] );
			$q = AAW_Cloudflare::call_worker( 'queue_put', array( 'id' => $id, 'payload' => $payload ), 45 );
			if ( is_wp_error( $q ) ) {
				return $q;
			}
			$dsp = AAW_GitHub::dispatch( 'analyze', 0, '', $id );
			if ( is_wp_error( $dsp ) ) {
				return $dsp;
			}
			AAW_Analyzer::track( $id, 'github', AAW_GitHub::repo_url() . '/actions' );
			$pending        = get_option( AAW_Pull::PENDING, array() );
			$pending        = is_array( $pending ) ? $pending : array();
			$pending[ $id ] = array( 'time' => time(), 'topics' => array() );
			update_option( AAW_Pull::PENDING, $pending, false );
			AAW_Logs::add( 'info', 'analysis', 'تحلیل هوشمند سایت با اکانت اشتراکی در GitHub شروع شد' . ( $x['web'] ? ' (با جستجوی زنده وب).' : '.' ) );
			return array( 'mode' => 'github', 'stats' => $x['stats'], 'web' => $x['web'], 'started' => time(), 'url' => AAW_GitHub::repo_url() . '/actions' );
		}

		// Preferred: background job on Cloudflare — only short requests, immune to connection-length limits.
		if ( AAW_BG::available() ) {
			$id = AAW_BG::start( 'analyze', $x['payload'], true );
			if ( is_wp_error( $id ) ) {
				return $id;
			}
			AAW_Analyzer::track( $id, 'async' );
			AAW_Logs::add( 'info', 'analysis', 'تحلیل هوشمند سایت به‌صورت کار پس‌زمینه روی کلادفلر شروع شد' . ( $x['web'] ? ' (با جستجوی زنده وب).' : '.' ) );
			return array( 'mode' => 'async', 'id' => $id, 'stats' => $x['stats'], 'web' => $x['web'], 'started' => time() );
		}

		if ( AAW_Pull::active() ) {
			if ( function_exists( 'set_time_limit' ) ) {
				@set_time_limit( 0 ); // phpcs:ignore
			}
			$r = AAW_Cloudflare::call_worker( 'analyze', $x['payload'], 900 );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			$rec = AAW_Analyzer::save( $r['analysis'], array_merge( (array) $r['meta'], array( 'stats' => $x['stats'] ) ) );
			return is_wp_error( $rec ) ? $rec : array( 'mode' => 'done', 'stats' => $x['stats'], 'web' => $x['web'], 'record' => $rec );
		}

		return array( 'mode' => 'ticket', 'stats' => $x['stats'], 'web' => $x['web'], 'ticket' => self::ticket( 'analyze', $x['payload'] ) );
	}

	private static function a_analysis_save( $d ) {
		$meta          = isset( $d['meta'] ) && is_array( $d['meta'] ) ? $d['meta'] : array();
		$meta['stats'] = isset( $d['stats'] ) && is_array( $d['stats'] ) ? $d['stats'] : array();
		$rec           = AAW_Analyzer::save( $d['analysis'] ?? null, $meta );
		return is_wp_error( $rec ) ? $rec : array( 'record' => $rec );
	}

	private static function a_analysis_status( $d ) {
		$pending = get_option( 'aaw_analysis_pending' );
		if ( $pending ) {
			if ( class_exists( 'AAW_Local' ) ) {
				AAW_Local::tick( 15 );
			}
			$job = get_option( AAW_Analyzer::JOB );
			if ( ! is_array( $job ) || 'local' !== ( $job['mode'] ?? '' ) ) {
				AAW_Pull::poll(); // Collect the GitHub result if it's ready (works for local and public sites).
			}
			AAW_Analyzer::check_stale();
			$pending = get_option( 'aaw_analysis_pending' );
		}
		$rec  = AAW_Analyzer::get();
		$step = '';
		if ( $pending && AAW_BG::available() && 'a' === substr( (string) $pending, 0, 1 ) ) {
			$j = AAW_BG::get( $pending );
			if ( ! is_wp_error( $j ) ) {
				$step = AAW_BG::step_label( $j['step'] ?? '' );
				if ( 'error' === ( $j['status'] ?? '' ) ) {
					AAW_Analyzer::fail( AAW_Errors::explain( (string) $j['error'] ) );
					$pending = false;
				}
			}
		}
		$job = get_option( AAW_Analyzer::JOB );
		if ( $pending && is_array( $job ) && 'local' === ( $job['mode'] ?? '' ) ) {
			foreach ( AAW_Local::jobs_summary() as $lj ) {
				if ( $lj['id'] === $pending ) {
					$step = $lj['step'];
				}
			}
		}
		return array(
			'step'    => $step,
			'started' => is_array( $job ) ? (int) $job['t'] : 0,
			'mode'    => is_array( $job ) ? (string) $job['mode'] : '',
			'url'     => is_array( $job ) ? (string) $job['url'] : '',
			'pending' => (bool) $pending,
			'error'   => (string) get_option( 'aaw_analysis_error', '' ),
			'record'  => $rec,
		);
	}

	private static function a_analysis_cancel( $d ) {
		return AAW_Analyzer::cancel();
	}

	/* ============================ AI engines on this server (direct) ============================ */

	private static function local_engine( $d ) {
		$e = isset( $d['engine'] ) ? sanitize_key( $d['engine'] ) : '';
		return isset( AAW_Local::ENGINES[ $e ] ) ? $e : '';
	}

	private static function a_local_doctor( $d ) {
		AAW_Local::tick( 10 );
		return AAW_Local::doctor( ! empty( $d['fresh'] ) );
	}

	private static function a_local_install( $d ) {
		$e = self::local_engine( $d );
		return $e ? AAW_Local::install( $e ) : new WP_Error( 'aaw', 'موتور نامعتبر' );
	}

	private static function a_local_install_status( $d ) {
		$e = self::local_engine( $d );
		return $e ? AAW_Local::install_status( $e ) : new WP_Error( 'aaw', 'موتور نامعتبر' );
	}

	private static function a_local_login_save( $d ) {
		$e = self::local_engine( $d );
		return $e ? AAW_Local::save_login( $e, (string) ( $d['value'] ?? '' ) ) : new WP_Error( 'aaw', 'موتور نامعتبر' );
	}

	private static function a_local_login_start( $d ) {
		return AAW_Local::login_start();
	}

	private static function a_local_login_status( $d ) {
		return AAW_Local::login_status();
	}

	private static function a_local_login_import( $d ) {
		return AAW_Local::import_github_codex();
	}

	private static function a_local_signout( $d ) {
		$e = self::local_engine( $d );
		return $e ? AAW_Local::sign_out( $e ) : new WP_Error( 'aaw', 'موتور نامعتبر' );
	}

	private static function a_local_test( $d ) {
		$e = self::local_engine( $d );
		if ( ! $e ) {
			return new WP_Error( 'aaw', 'موتور نامعتبر' );
		}
		$id = AAW_Local::start( 'test', $e, array( 'status' => 'test' ), array( 'label' => 'تست اتصال ' . AAW_Local::ENGINES[ $e ]['name'] ) );
		return is_wp_error( $id ) ? $id : array( 'id' => $id );
	}

	private static function a_local_jobs( $d ) {
		AAW_Local::tick( 15 );
		$id  = sanitize_key( $d['id'] ?? '' );
		$all = AAW_Local::jobs_summary();
		if ( $id ) {
			foreach ( $all as $j ) {
				if ( $j['id'] === $id ) {
					return array( 'job' => $j, 'state' => AAW_Local::state( $j['engine'] ) );
				}
			}
			return new WP_Error( 'aaw', 'کار پیدا نشد.' );
		}
		return array( 'jobs' => $all );
	}

	private static function a_local_cancel( $d ) {
		return AAW_Local::cancel( sanitize_key( $d['id'] ?? '' ) );
	}

	/** Route of one subscription account: direct from this server, or through GitHub. */
	private static function a_local_route( $d ) {
		$e     = self::local_engine( $d );
		$route = 'local' === ( $d['route'] ?? '' ) ? 'local' : 'github';
		if ( ! $e ) {
			return new WP_Error( 'aaw', 'موتور نامعتبر' );
		}
		AAW_Settings::update( array( 'local_route_' . $e => $route ) );
		$warn = '';
		if ( 'local' === $route ) {
			$ok   = AAW_Local::ready( $e );
			$warn = is_wp_error( $ok ) ? wp_strip_all_tags( $ok->get_error_message() ) : '';
		}
		AAW_Logs::add( 'info', 'local', AAW_Local::ENGINES[ $e ]['name'] . ': روش اجرا → ' . ( 'local' === $route ? 'مستقیم از همین سرور (بدون GitHub)' : 'از طریق GitHub' ) );
		return array( 'message' => 'local' === $route ? 'از این پس ' . AAW_Local::ENGINES[ $e ]['name'] . ' مستقیم روی همین سرور اجرا می‌شود و هیچ کاری به GitHub فرستاده نمی‌شود.' : 'از این پس ' . AAW_Local::ENGINES[ $e ]['name'] . ' از طریق GitHub اجرا می‌شود.', 'warning' => $warn );
	}

	private static function a_local_settings( $d ) {
		$node = trim( (string) ( $d['local_node_path'] ?? '' ) );
		if ( '' !== $node && ( '/' !== substr( $node, 0, 1 ) || 'node' !== basename( $node ) ) ) {
			return new WP_Error( 'aaw', 'مسیر Node.js باید مسیر کامل فایل node باشد (مثلاً /opt/alt/alt-nodejs22/root/usr/bin/node).' );
		}
		AAW_Settings::update(
			array(
				'local_node_path' => $node,
				'local_bin_claude' => trim( (string) ( $d['local_bin_claude'] ?? '' ) ),
				'local_bin_codex'  => trim( (string) ( $d['local_bin_codex'] ?? '' ) ),
				'local_timeout'    => absint( $d['local_timeout'] ?? 20 ),
			)
		);
		delete_transient( 'aaw_local_nodes' );
		return array( 'message' => 'ذخیره شد.' );
	}

	private static function a_analysis_add( $d ) {
		$r = AAW_Analyzer::add_topics( (array) ( $d['topics'] ?? array() ), ! empty( $d['create_categories'] ) );
		return array( 'message' => sprintf( '%d موضوع به صف تولید اضافه شد%s.', $r['added'], $r['skipped'] ? ' (' . $r['skipped'] . ' مورد تکراری رد شد)' : '' ) ) + $r;
	}

	private static function a_timeline( $d ) {
		return array(
			'future' => AAW_Timeline::future( max( 3, min( 40, absint( $d['runs'] ?? 15 ) ) ) ),
			'past'   => AAW_Timeline::past( 60 ),
			'now'    => AAW_Timeline::now(),
		);
	}

	private static function a_now( $d ) {
		return AAW_Timeline::now();
	}

	private static function a_worker_unlock( $d ) {
		$r = AAW_Cloudflare::call_worker( 'unlock', array(), 20 );
		AAW_Topics::release_stale();
		return is_wp_error( $r ) ? $r : array( 'message' => 'قفل اجرای ورکر آزاد شد.' );
	}

	/* ============================ Providers ============================ */

	private static function a_key_save( $d ) {
		$id  = isset( $d['provider'] ) ? sanitize_key( $d['provider'] ) : '';
		$key = isset( $d['key'] ) ? trim( (string) $d['key'] ) : '';
		$p   = AAW_Providers::get( $id );
		if ( ! $p ) {
			return new WP_Error( 'aaw', 'پرووایدر یافت نشد.' );
		}
		if ( '' === $key || preg_match( '/\s/', $key ) ) {
			return new WP_Error( 'aaw', 'کلید API نامعتبر است.' );
		}
		if ( 'claude_pro' === $id ) {
			return self::save_claude_token( $key );
		}
		if ( ! AAW_Cloudflare::is_deployed() ) {
			return new WP_Error( 'aaw', 'ابتدا در تب «کلادفلر» ورکر را مستقر کنید؛ کلیدها مستقیماً در Secrets کلادفلر ذخیره می‌شوند و در وردپرس نگهداری نمی‌شوند.' );
		}
		$r = AAW_Cloudflare::put_secret( AAW_Providers::secret_name( $id ), $key );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		AAW_Settings::set_key_meta( $id, AAW_Crypto::mask( $key ) );
		AAW_Logs::add( 'success', 'secret', 'کلید API «' . $p['name'] . '» در Secrets کلادفلر ذخیره شد.' );
		return array( 'message' => 'کلید در Secrets کلادفلر ذخیره شد.', 'mask' => AAW_Crypto::mask( $key ) );
	}

	private static function a_key_delete( $d ) {
		$id = isset( $d['provider'] ) ? sanitize_key( $d['provider'] ) : '';
		$r  = AAW_Cloudflare::delete_secret( AAW_Providers::secret_name( $id ), 'claude_pro' === $id ? AAW_Settings::get( 'runner_name' ) : null );
		AAW_Settings::set_key_meta( $id, null );
		if ( is_wp_error( $r ) && 404 !== ( $r->get_error_data()['status'] ?? 0 ) ) {
			return $r;
		}
		return array( 'message' => 'کلید از کلادفلر حذف شد.' );
	}

	/** Store the Claude subscription token (claude setup-token) on the runner worker. */
	private static function save_claude_token( $token ) {
		if ( ! AAW_Cloudflare::is_configured() ) {
			return new WP_Error( 'aaw', 'ابتدا در تب کلادفلر، Account ID و API Token را ذخیره کنید.' );
		}
		if ( 0 !== strpos( $token, 'sk-ant-oat' ) ) {
			return new WP_Error( 'aaw', 'این توکن شبیه خروجی `claude setup-token` نیست (باید با sk-ant-oat شروع شود). کلید API کنسول اینجا کار نمی‌کند.' );
		}
		$runner = AAW_Settings::get( 'runner_name', 'aria-claude-pro' );
		$exists = AAW_Cloudflare::script_exists( $runner );
		if ( is_wp_error( $exists ) ) {
			return $exists;
		}
		if ( ! $exists ) {
			return new WP_Error( 'aaw', 'ورکر Runner با نام «' . $runner . '» روی حساب کلادفلر پیدا نشد. ابتدا بسته Runner را مستقر کنید (راهنمای همین بخش).' );
		}
		$r = AAW_Cloudflare::put_secret( 'CLAUDE_CODE_OAUTH_TOKEN', $token, $runner );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$r = AAW_Cloudflare::put_secret( 'AAW_SHARED_SECRET', AAW_Settings::shared_secret(), $runner );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		AAW_Settings::set_key_meta( 'claude_pro', AAW_Crypto::mask( $token ) );
		AAW_Logs::add( 'success', 'secret', 'توکن اشتراک Claude در Secrets ورکر Runner ذخیره شد.' );
		return array( 'message' => 'توکن اشتراک Claude در Secrets کلادفلر (ورکر ' . $runner . ') ذخیره شد.', 'mask' => AAW_Crypto::mask( $token ) );
	}

	private static function a_claude_pro_connect( $d ) {
		if ( ! empty( $d['runner_name'] ) ) {
			AAW_Settings::update( array( 'runner_name' => $d['runner_name'] ) );
		}
		if ( isset( $d['fallback'] ) ) {
			AAW_Settings::update( array( 'claude_pro_fallback' => $d['fallback'] ) );
		}
		$token = isset( $d['token'] ) ? trim( (string) $d['token'] ) : '';
		if ( '' !== $token ) {
			$r = self::save_claude_token( $token );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		} else {
			$meta = AAW_Settings::key_meta();
			if ( empty( $meta['claude_pro'] ) ) {
				return new WP_Error( 'aaw', 'توکن اشتراک Claude را وارد کنید.' );
			}
			$runner = AAW_Settings::get( 'runner_name' );
			$exists = AAW_Cloudflare::script_exists( $runner );
			if ( true !== $exists ) {
				return is_wp_error( $exists ) ? $exists : new WP_Error( 'aaw', 'ورکر Runner «' . $runner . '» پیدا نشد.' );
			}
			$r = AAW_Cloudflare::put_secret( 'AAW_SHARED_SECRET', AAW_Settings::shared_secret(), $runner );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		AAW_Settings::update( array( 'claude_pro_enabled' => true ) );
		$dep = AAW_Cloudflare::deploy();
		if ( is_wp_error( $dep ) ) {
			AAW_Settings::update( array( 'claude_pro_enabled' => false ) );
			return new WP_Error( 'aaw', 'اتصال ورکر اصلی به Runner ناموفق بود: ' . $dep->get_error_message() );
		}
		if ( ! empty( $d['make_active'] ) ) {
			AAW_Settings::update( array( 'provider' => 'claude_pro', 'model' => AAW_Providers::model_for( 'claude_pro' ) ) );
		}
		AAW_Logs::add( 'success', 'deploy', 'Claude Pro (Runner روی Cloudflare Containers) به ورکر اصلی متصل شد.' );
		return array( 'message' => 'Claude Pro متصل شد. حالا «تست» را بزنید (اولین اجرا به خاطر روشن شدن کانتینر ممکن است تا یک دقیقه طول بکشد).' );
	}

	private static function a_claude_pro_disconnect( $d ) {
		AAW_Settings::update( array( 'claude_pro_enabled' => false ) );
		if ( 'claude_pro' === AAW_Settings::get( 'provider' ) ) {
			AAW_Settings::update( array( 'provider' => 'openai' ) );
		}
		$dep = AAW_Cloudflare::is_configured() ? AAW_Cloudflare::deploy() : true;
		return is_wp_error( $dep ) ? $dep : array( 'message' => 'اتصال Claude Pro قطع شد.' );
	}

	/* ============================ Subscription (GitHub runner) ============================ */

	private static function a_gh_connect( $d ) {
		$token = isset( $d['token'] ) ? trim( sanitize_text_field( $d['token'] ) ) : '';
		if ( '' === $token || false !== strpos( $token, '•' ) ) {
			$token = AAW_GitHub::token();
		}
		if ( '' === $token ) {
			return new WP_Error( 'aaw', 'توکن GitHub را وارد کنید.' );
		}
		$user = AAW_GitHub::user( $token );
		if ( is_wp_error( $user ) ) {
			return $user;
		}
		$owner = ! empty( $d['owner'] ) ? sanitize_text_field( $d['owner'] ) : $user['login'];
		AAW_Settings::secure_set( 'gh_token', $token );
		AAW_Settings::update(
			array(
				'gh_owner'  => $owner,
				'gh_repo'   => ! empty( $d['repo'] ) ? $d['repo'] : 'aria-ai-runner',
				'gh_branch' => '',
			)
		);
		$repo = AAW_GitHub::ensure_repo();
		if ( is_wp_error( $repo ) ) {
			return $repo;
		}
		AAW_Settings::update( array( 'gh_branch' => $repo['default_branch'] ?? 'main' ) );
		$r = AAW_GitHub::push_files();
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$r = AAW_GitHub::sync_base_secrets();
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		AAW_Settings::update( array( 'gh_connected_at' => time() ) );
		AAW_Logs::add( 'success', 'github', 'GitHub متصل شد و مخزن خصوصی ' . $owner . '/' . AAW_GitHub::repo() . ' آماده است.' );
		$warn = AAW_Cloudflare::is_deployed() ? '' : ' توجه: ورکر کلادفلر هنوز مستقر نشده؛ زمان‌بندی خودکار و تصویر شاخص به آن نیاز دارند.';
		return array( 'message' => 'GitHub متصل شد؛ مخزن خصوصی، Workflow و Secrets ساخته شدند.' . $warn, 'repo' => AAW_GitHub::repo_url() );
	}

	private static function a_gh_sub_save( $d ) {
		if ( ! AAW_GitHub::is_connected() ) {
			return new WP_Error( 'aaw', 'ابتدا مرحله «اتصال GitHub» را انجام دهید.' );
		}
		$engine = isset( $d['engine'] ) && 'codex' === $d['engine'] ? 'codex' : 'claude';
		$value  = isset( $d['value'] ) ? trim( (string) wp_unslash( $d['value'] ) ) : '';
		if ( '' === $value ) {
			return new WP_Error( 'aaw', 'مقدار توکن خالی است.' );
		}
		if ( 'claude' === $engine ) {
			if ( 0 !== strpos( $value, 'sk-ant-oat' ) || preg_match( '/\s/', $value ) ) {
				return new WP_Error( 'aaw', 'این توکن خروجی `claude setup-token` نیست (باید با sk-ant-oat شروع شود). کلید API کنسول اینجا کاربرد ندارد.' );
			}
			$r = AAW_GitHub::put_secret( 'CLAUDE_CODE_OAUTH_TOKEN', $value );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			AAW_Settings::set_key_meta( 'sub_claude', AAW_Crypto::mask( $value ) );
			$id = 'sub_claude';
		} else {
			$json = json_decode( $value, true );
			if ( ! is_array( $json ) || ( empty( $json['tokens'] ) && empty( $json['OPENAI_API_KEY'] ) ) ) {
				return new WP_Error( 'aaw', 'محتوای auth.json معتبر نیست. کل فایل را کپی کنید (از { تا }).' );
			}
			if ( ! empty( $json['OPENAI_API_KEY'] ) && empty( $json['tokens'] ) ) {
				return new WP_Error( 'aaw', 'این auth.json با کلید API ساخته شده، نه با اکانت ChatGPT. «codex login» را با گزینه Sign in with ChatGPT اجرا کنید.' );
			}
			$compact = wp_json_encode( $json );
			$r       = AAW_GitHub::put_secret( 'CODEX_AUTH_JSON', $compact );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			if ( AAW_Cloudflare::is_configured() && AAW_Settings::get( 'kv_namespace_id' ) ) {
				AAW_Cloudflare::kv_put( 'codex_auth', $compact ); // Freshest copy lives in Cloudflare KV.
			}
			AAW_Settings::set_key_meta( 'sub_codex', 'auth.json · ChatGPT' );
			$id = 'sub_codex';
		}
		if ( ! empty( $d['model'] ) ) {
			$map        = AAW_Settings::get( 'provider_models', array() );
			$map[ $id ] = sanitize_text_field( $d['model'] );
			AAW_Settings::update( array( 'provider_models' => $map ) );
		}
		if ( ! empty( $d['make_primary'] ) ) {
			self::activate_sub( $id, ! empty( $d['fallback_free'] ) );
		}
		if ( 'sub_codex' === $id && ! empty( $d['image_role'] ) ) {
			AAW_Priority::promote( 'image', 'sub_codex' );
		}
		AAW_Logs::add( 'success', 'secret', 'اعتبارنامه اکانت ' . ( 'claude' === $engine ? 'Claude' : 'ChatGPT' ) . ' در Secrets مخزن خصوصی GitHub ذخیره شد.' );
		return array( 'message' => 'ذخیره شد. حالا «تست اتصال» را بزنید؛ نتیجه تا ۱ تا ۳ دقیقه دیگر در گزارش‌ها و جدول اجراها دیده می‌شود.' );
	}

	/** Put a subscription account first in the content list (others stay as fallbacks). */
	private static function activate_sub( $id, $fallback_free ) {
		$chain = array_values( array_diff( AAW_Priority::text_chain(), array( $id ) ) );
		array_unshift( $chain, $id );
		if ( $fallback_free && ! in_array( 'workers_ai', $chain, true ) ) {
			$chain[] = 'workers_ai';
		}
		$chain = array_values( array_filter( $chain, function ( $x ) { return AAW_Priority::text_ready( $x )[0]; } ) );
		$r     = AAW_Priority::save_text( $chain ? $chain : array( $id ) );
		if ( is_wp_error( $r ) ) {
			AAW_Settings::update( array( 'provider' => $id, 'model' => AAW_Providers::model_for( $id ) ) );
		}
	}

	private static function a_gh_activate( $d ) {
		$id = isset( $d['provider'] ) && in_array( $d['provider'], array( 'sub_claude', 'sub_codex' ), true ) ? $d['provider'] : '';
		if ( ! $id ) {
			return new WP_Error( 'aaw', 'اکانت نامعتبر' );
		}
		$meta = AAW_Settings::key_meta();
		if ( empty( $meta[ $id ] ) ) {
			return new WP_Error( 'aaw', 'ابتدا توکن این اکانت را ذخیره کنید.' );
		}
		self::activate_sub( $id, ! empty( $d['fallback_free'] ) );
		return array( 'message' => 'از این پس مقاله‌ها با اکانت اشتراکی شما نوشته می‌شوند.' );
	}

	private static function a_gh_test( $d ) {
		if ( ! AAW_GitHub::is_connected() ) {
			return new WP_Error( 'aaw', 'GitHub متصل نیست.' );
		}
		$engine = isset( $d['engine'] ) && 'codex' === $d['engine'] ? 'codex' : 'claude';
		if ( AAW_Pull::active() ) {
			$p = AAW_Pull::dispatch_subscription( 'test', 0, $engine );
			if ( 'dispatched' !== ( $p['status'] ?? '' ) ) {
				return new WP_Error( 'aaw', $p['reason'] ?? 'اجرا شروع نشد.' );
			}
			return array( 'message' => 'تست در GitHub شروع شد (اتصال معکوس). ۱ تا ۳ دقیقه بعد «دریافت نتایج» را بزنید یا صفحه را تازه کنید؛ نتیجه در گزارش‌ها ثبت می‌شود.', 'url' => AAW_GitHub::repo_url() . '/actions' );
		}
		$r      = AAW_GitHub::dispatch( 'test', 0, $engine );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$op = AAW_Activity::start( 'test', 'تست اکانت اشتراکی ' . ( 'codex' === $engine ? 'ChatGPT' : 'Claude' ) . ' در GitHub Actions', array( 'url' => AAW_GitHub::repo_url() . '/actions' ) );
		AAW_Activity::finish( $op, true, 'اجرا در GitHub شروع شد؛ نتیجه نهایی در گزارش‌ها ثبت می‌شود.' );
		return array( 'message' => 'تست در GitHub شروع شد؛ نتیجه تا ۱ تا ۳ دقیقه دیگر در جدول اجراها و گزارش‌ها ثبت می‌شود.', 'url' => AAW_GitHub::repo_url() . '/actions' );
	}

	private static function a_gh_runs( $d ) {
		if ( ! AAW_GitHub::is_connected() ) {
			return array( 'runs' => array(), 'secrets' => array() );
		}
		$runs    = AAW_GitHub::runs( 10 );
		$secrets = AAW_GitHub::list_secrets();
		if ( is_wp_error( $runs ) ) {
			return $runs;
		}
		return array(
			'runs'     => $runs,
			'secrets'  => is_wp_error( $secrets ) ? array() : $secrets,
			'outdated' => AAW_Settings::get( 'gh_files_version' ) !== AAW_VERSION,
		);
	}

	private static function a_gh_sync( $d ) {
		$r = AAW_GitHub::push_files();
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$r = AAW_GitHub::sync_base_secrets();
		return is_wp_error( $r ) ? $r : array( 'message' => 'فایل‌های Runner و Secrets پایه در GitHub به‌روز شدند.' );
	}

	private static function a_gh_disconnect( $d ) {
		AAW_Settings::secure_set( 'gh_token', '' );
		AAW_Settings::update( array( 'gh_connected_at' => 0 ) );
		AAW_Settings::set_key_meta( 'sub_claude', null );
		AAW_Settings::set_key_meta( 'sub_codex', null );
		AAW_Priority::drop_subs();
		return array( 'message' => 'اتصال GitHub از افزونه حذف شد. (مخزن و Secrets آن در GitHub باقی می‌مانند؛ در صورت تمایل مخزن را از GitHub حذف کنید.)' );
	}

	private static function a_provider_test( $d ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 330 ); // phpcs:ignore
		}
		$id    = isset( $d['provider'] ) ? sanitize_key( $d['provider'] ) : '';
		$model = isset( $d['model'] ) ? sanitize_text_field( $d['model'] ) : '';
		$rt    = AAW_Providers::runtime( $id, $model );
		if ( ! $rt ) {
			return new WP_Error( 'aaw', 'پرووایدر یافت نشد.' );
		}
		if ( 'github_runner' === $rt['format'] ) {
			return self::a_gh_test( array( 'engine' => $rt['engine'] ) );
		}
		$op = AAW_Activity::start( 'test', 'تست اتصال هوش مصنوعی: ' . $rt['name'] . ( $rt['model'] ? ' (' . $rt['model'] . ')' : '' ) );
		AAW_Activity::step( $op, 'ارسال پیام آزمایشی از ورکر کلادفلر به ' . $rt['name'] . '…' );
		$r = AAW_Cloudflare::call_worker( 'test', array( 'provider' => $rt ), 'claude_code' === $rt['format'] ? 300 : 90 );
		if ( is_wp_error( $r ) ) {
			AAW_Activity::finish( $op, false, $r->get_error_message() );
			return $r;
		}
		AAW_Activity::finish( $op, true, 'پاسخ «' . $r['text'] . '» در ' . $r['ms'] . 'ms' );
		AAW_Logs::add( 'success', 'test', 'تست اتصال ' . $rt['name'] . ' موفق بود (' . $r['ms'] . 'ms)', array( 'provider' => $id, 'model' => $rt['model'], 'duration_ms' => $r['ms'] ) );
		return array( 'message' => 'اتصال موفق: «' . $r['text'] . '» در ' . number_format_i18n( $r['ms'] ) . ' میلی‌ثانیه', 'ms' => $r['ms'] );
	}

	private static function a_provider_models( $d ) {
		$id = isset( $d['provider'] ) ? sanitize_key( $d['provider'] ) : '';
		$rt = AAW_Providers::runtime( $id );
		if ( ! $rt ) {
			return new WP_Error( 'aaw', 'پرووایدر یافت نشد.' );
		}
		$r = AAW_Cloudflare::call_worker( 'models', array( 'provider' => $rt ), 45 );
		return is_wp_error( $r ) ? $r : array( 'models' => array_slice( (array) $r['models'], 0, 400 ) );
	}

	private static function a_custom_save( $d ) {
		$c = AAW_Providers::sanitize_custom( $d );
		if ( ! $c ) {
			return new WP_Error( 'aaw', 'نام و Base URL الزامی است.' );
		}
		$list  = AAW_Settings::custom_providers();
		$found = false;
		foreach ( $list as $i => $row ) {
			if ( $row['id'] === $c['id'] ) {
				$list[ $i ] = $c;
				$found      = true;
			}
		}
		if ( ! $found ) {
			$list[] = $c;
		}
		AAW_Settings::save_custom_providers( $list );
		$msg = 'پرووایدر شخصی ذخیره شد.';
		if ( ! empty( $d['key'] ) && AAW_Cloudflare::is_deployed() ) {
			$r = AAW_Cloudflare::put_secret( AAW_Providers::secret_name( $c['id'] ), trim( $d['key'] ) );
			if ( ! is_wp_error( $r ) ) {
				AAW_Settings::set_key_meta( $c['id'], AAW_Crypto::mask( trim( $d['key'] ) ) );
				$msg .= ' کلید در Secrets کلادفلر ذخیره شد.';
			} else {
				$msg .= ' (ذخیره کلید ناموفق: ' . $r->get_error_message() . ')';
			}
		}
		return array( 'message' => $msg, 'provider' => $c );
	}

	private static function a_custom_delete( $d ) {
		$id   = isset( $d['id'] ) ? sanitize_key( $d['id'] ) : '';
		$list = array_values( array_filter( AAW_Settings::custom_providers(), function ( $r ) use ( $id ) {
			return $r['id'] !== $id;
		} ) );
		AAW_Settings::save_custom_providers( $list );
		if ( AAW_Cloudflare::is_deployed() ) {
			AAW_Cloudflare::delete_secret( AAW_Providers::secret_name( $id ) );
		}
		AAW_Settings::set_key_meta( $id, null );
		if ( AAW_Settings::get( 'provider' ) === $id ) {
			AAW_Settings::update( array( 'provider' => 'openai' ) );
		}
		return array( 'message' => 'پرووایدر حذف شد.' );
	}

	/* ============================ Topics ============================ */

	private static function topic_out( $r ) {
		$r['category_name'] = $r['category_id'] ? get_cat_name( $r['category_id'] ) : '';
		$r['edit_url']      = $r['post_id'] ? get_edit_post_link( $r['post_id'], 'raw' ) : '';
		$r['post_status']   = $r['post_id'] ? get_post_status( $r['post_id'] ) : '';
		$r['generated_h']   = $r['generated_at'] ? wp_date( 'Y/m/d H:i', strtotime( $r['generated_at'] . ' UTC' ) ) : '';
		return $r;
	}

	private static function a_topics_list( $d ) {
		$q = AAW_Topics::query(
			array(
				'status'   => isset( $d['status'] ) ? sanitize_key( $d['status'] ) : '',
				'search'   => isset( $d['search'] ) ? sanitize_text_field( $d['search'] ) : '',
				'per_page' => 1000,
			)
		);
		return array(
			'items'  => array_map( array( __CLASS__, 'topic_out' ), $q['items'] ),
			'total'  => $q['total'],
			'counts' => AAW_Topics::counts(),
		);
	}

	private static function a_topic_add( $d ) {
		$r = AAW_Topics::add( $d );
		return is_wp_error( $r ) ? $r : array( 'id' => $r, 'message' => 'موضوع اضافه شد.' );
	}

	private static function a_topics_bulk( $d ) {
		$r = AAW_Topics::add_bulk( isset( $d['text'] ) ? $d['text'] : '', 'manual', ! empty( $d['skip_duplicates'] ) );
		return array( 'message' => sprintf( '%d موضوع اضافه شد%s.', $r['added'], $r['skipped'] ? ' و ' . $r['skipped'] . ' مورد تکراری رد شد' : '' ) ) + $r;
	}

	private static function a_topic_update( $d ) {
		$id = isset( $d['id'] ) ? absint( $d['id'] ) : 0;
		unset( $d['id'] );
		return AAW_Topics::update( $id, $d ) ? array( 'message' => 'موضوع به‌روز شد.', 'item' => self::topic_out( AAW_Topics::get( $id ) ) ) : new WP_Error( 'aaw', 'به‌روزرسانی انجام نشد.' );
	}

	private static function a_topics_delete( $d ) {
		$n = AAW_Topics::delete( isset( $d['ids'] ) ? (array) $d['ids'] : array() );
		return array( 'message' => $n . ' موضوع حذف شد.' );
	}

	private static function a_topics_reorder( $d ) {
		AAW_Topics::reorder( isset( $d['ids'] ) ? (array) $d['ids'] : array() );
		return array( 'message' => 'ترتیب ذخیره شد.' );
	}

	private static function a_topic_move( $d ) {
		AAW_Topics::move( absint( $d['id'] ?? 0 ), sanitize_key( $d['where'] ?? '' ) );
		return array( 'message' => 'جابجا شد.' );
	}

	private static function a_topics_status( $d ) {
		$n = AAW_Topics::bulk_status( isset( $d['ids'] ) ? (array) $d['ids'] : array(), sanitize_key( $d['status'] ?? '' ) );
		return array( 'message' => $n . ' مورد به‌روز شد.' );
	}

	private static function a_topic_duplicate( $d ) {
		$r = AAW_Topics::duplicate( absint( $d['id'] ?? 0 ) );
		return $r ? array( 'message' => 'کپی ساخته شد.' ) : new WP_Error( 'aaw', 'کپی انجام نشد.' );
	}

	private static function a_topics_export( $d ) {
		return array( 'filename' => 'aria-topics-' . gmdate( 'Ymd' ) . '.csv', 'content' => AAW_Topics::export_csv() );
	}

	private static function a_topics_import( $d ) {
		$n = AAW_Topics::import_csv( $d['content'] ?? '' );
		return array( 'message' => $n . ' موضوع از فایل وارد شد.' );
	}

	/** Signed request the browser forwards to the worker. */
	private static function ticket( $route, array $payload ) {
		if ( ! AAW_Cloudflare::is_deployed() ) {
			return new WP_Error( 'aaw', 'ورکر هنوز روی کلادفلر مستقر نشده است (تب کلادفلر).' );
		}
		$body = wp_json_encode( $payload, JSON_UNESCAPED_UNICODE );
		return array(
			'url'     => trailingslashit( AAW_Cloudflare::endpoint() ) . $route,
			'headers' => AAW_Security::sign( $route, $body ) + array( 'Content-Type' => 'application/json' ),
			'body'    => $body,
		);
	}

	/**
	 * Server-side fallback when the browser cannot reach the worker directly
	 * (e.g. workers.dev filtered on the admin's network).
	 */
	private static function a_proxy( $d ) {
		$map  = array( 'run' => 'a_run_ticket', 'suggest' => 'a_suggest_ticket', 'generate' => 'a_generate_ticket', 'analyze' => 'a_analysis_ticket' );
		$kind = sanitize_key( $d['kind'] ?? '' );
		if ( ! isset( $map[ $kind ] ) ) {
			return new WP_Error( 'aaw', 'درخواست نامعتبر' );
		}
		$t = call_user_func( array( __CLASS__, $map[ $kind ] ), $d );
		if ( is_wp_error( $t ) ) {
			return $t;
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 600 ); // phpcs:ignore
		}
		ignore_user_abort( true );
		$headers                 = (array) $t['headers'];
		$headers['X-AAW-Stream'] = '1';
		$t0                      = microtime( true );
		$res                     = wp_remote_post( $t['url'], array( 'timeout' => 540, 'headers' => $headers, 'body' => $t['body'] ) );
		if ( is_wp_error( $res ) ) {
			return AAW_Errors::network( $res, $t['url'], microtime( true ) - $t0 );
		}
		return AAW_Cloudflare::parse_worker_response( $res );
	}

	private static function a_suggest_ticket( $d ) {
		$count    = max( 1, min( 30, absint( $d['count'] ?? 10 ) ) );
		$existing = array_merge(
			wp_list_pluck( AAW_Topics::query( array( 'per_page' => 200 ) )['items'], 'title' ),
			array_map( 'get_the_title', get_posts( array( 'post_type' => 'post', 'post_status' => 'any', 'posts_per_page' => 80, 'fields' => 'ids', 'no_found_rows' => true ) ) )
		);
		$prompt = AAW_Prompt::topic_ideas_prompt( $count, $existing );
		if ( ! empty( $d['hint'] ) ) {
			$prompt .= "\nتمرکز ویژه روی: " . sanitize_text_field( $d['hint'] );
		}
		return self::ticket( 'suggest', array( 'runtime' => AAW_REST::runtime(), 'prompt' => $prompt ) );
	}

	private static function a_suggest_add( $d ) {
		$lines = array();
		foreach ( (array) ( $d['topics'] ?? array() ) as $t ) {
			$title = sanitize_text_field( str_replace( '|', ' ', $t['title'] ?? '' ) );
			$kw    = is_array( $t['keywords'] ?? null ) ? implode( ', ', $t['keywords'] ) : (string) ( $t['keywords'] ?? '' );
			if ( $title ) {
				$lines[] = $title . ( $kw ? ' | ' . str_replace( '|', ' ', $kw ) : '' );
			}
		}
		$r = AAW_Topics::add_bulk( implode( "\n", $lines ), 'ai' );
		return array( 'message' => $r['added'] . ' موضوع پیشنهادی به صف اضافه شد.' );
	}

	private static function a_run_ticket( $d ) {
		$lic = AAW_License::can_generate();
		if ( is_wp_error( $lic ) ) {
			return $lic;
		}
		return self::ticket( 'run', array( 'topic_id' => absint( $d['topic_id'] ?? 0 ) ) );
	}

	private static function a_generate_ticket( $d ) {
		$lic = AAW_License::can_generate();
		if ( is_wp_error( $lic ) ) {
			return $lic;
		}
		$topic = array(
			'id'          => 0,
			'title'       => sanitize_text_field( $d['topic'] ?? '' ),
			'keywords'    => sanitize_text_field( $d['keywords'] ?? '' ),
			'category_id' => 0,
			'word_count'  => 0,
			'tone'        => '',
			'notes'       => '',
			'attempts'    => 0,
		);
		if ( '' === $topic['title'] ) {
			return new WP_Error( 'aaw', 'موضوع آزمایشی را وارد کنید.' );
		}
		$runtime                       = AAW_REST::runtime();
		$runtime['image']['enabled']   = false;
		return self::ticket( 'generate', array( 'runtime' => $runtime, 'job' => AAW_REST::build_job( $topic ) ) );
	}

	private static function a_save_generated( $d ) {
		$article = isset( $d['article'] ) && is_array( $d['article'] ) ? $d['article'] : array();
		$meta    = isset( $d['meta'] ) && is_array( $d['meta'] ) ? $d['meta'] : array();
		$id      = AAW_Post_Builder::create( $article, array(), $meta );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		AAW_Logs::add( 'success', 'draft', 'پیش‌نویس از تولید آزمایشی ذخیره شد: ' . get_the_title( $id ), array( 'post_id' => $id, 'provider' => $meta['provider'] ?? '', 'model' => $meta['model'] ?? '', 'tokens_in' => $meta['tokens_in'] ?? 0, 'tokens_out' => $meta['tokens_out'] ?? 0 ) );
		return array( 'message' => 'پیش‌نویس ذخیره شد.', 'edit_url' => get_edit_post_link( $id, 'raw' ) );
	}

	/* ============================ Review ============================ */

	private static function a_review_list( $d ) {
		$status = isset( $d['status'] ) && in_array( $d['status'], array( 'draft', 'pending', 'future', 'publish' ), true ) ? array( $d['status'] ) : array( 'draft', 'pending' );
		$posts  = get_posts(
			array(
				'post_type'      => 'any',
				'post_status'    => $status,
				'meta_key'       => '_aaw_generated',
				'posts_per_page' => 100,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		$items = array();
		foreach ( $posts as $p ) {
			$items[] = array(
				'id'        => $p->ID,
				'title'     => $p->post_title,
				'status'    => $p->post_status,
				'date'      => wp_date( 'Y/m/d H:i', get_post_timestamp( $p ) ),
				'words'     => (int) get_post_meta( $p->ID, '_aaw_word_count', true ),
				'keyword'   => get_post_meta( $p->ID, '_aaw_focus_keyword', true ),
				'model'     => get_post_meta( $p->ID, '_aaw_model', true ),
				'provider'  => get_post_meta( $p->ID, '_aaw_provider', true ),
				'meta_desc' => get_post_meta( $p->ID, '_aaw_meta_description', true ),
				'excerpt'   => wp_trim_words( wp_strip_all_tags( $p->post_content ), 40 ),
				'thumb'     => get_the_post_thumbnail_url( $p, 'medium' ),
				'edit_url'  => get_edit_post_link( $p->ID, 'raw' ),
				'preview'   => get_preview_post_link( $p ),
				'cats'      => implode( '، ', wp_list_pluck( get_the_category( $p->ID ), 'name' ) ),
				'topic_id'  => (int) get_post_meta( $p->ID, '_aaw_topic_id', true ),
				'ai_state'  => AAW_Revise::state( $p->ID ),
				'rev_pending' => (bool) get_post_meta( $p->ID, '_aaw_revision_pending', true ),
				'revisions' => count( array_filter( (array) get_post_meta( $p->ID, AAW_Revise::META_HISTORY, true ) ) ),
				'img_prompt' => (string) get_post_meta( $p->ID, '_aaw_image_prompt', true ),
			);
		}
		return array( 'items' => $items );
	}

	private static function a_review_action( $d ) {
		$id = absint( $d['id'] ?? 0 );
		$op = sanitize_key( $d['op'] ?? '' );
		if ( ! $id || ! get_post_meta( $id, '_aaw_generated', true ) ) {
			return new WP_Error( 'aaw', 'مقاله یافت نشد.' );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'aaw', 'دسترسی غیرمجاز' );
		}
		switch ( $op ) {
			case 'publish':
				wp_publish_post( $id );
				AAW_Logs::add( 'success', 'approve', 'تایید و انتشار: ' . get_the_title( $id ), array( 'post_id' => $id ) );
				return array( 'message' => 'مقاله منتشر شد.', 'url' => get_permalink( $id ) );
			case 'schedule':
				$raw = str_replace( 'T', ' ', sanitize_text_field( $d['date'] ?? '' ) );
				if ( ! preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/', $raw ) ) {
					return new WP_Error( 'aaw', 'تاریخ نامعتبر است.' );
				}
				$local = substr( $raw, 0, 16 ) . ':00';
				$gmt   = get_gmt_from_date( $local );
				if ( strtotime( $gmt . ' UTC' ) < time() ) {
					return new WP_Error( 'aaw', 'تاریخ انتشار باید در آینده باشد.' );
				}
				wp_update_post( array( 'ID' => $id, 'post_status' => 'future', 'post_date' => $local, 'post_date_gmt' => $gmt, 'edit_date' => true ) );
				return array( 'message' => 'انتشار زمان‌بندی شد.' );
			case 'pending':
				wp_update_post( array( 'ID' => $id, 'post_status' => 'pending' ) );
				return array( 'message' => 'به وضعیت «در انتظار بررسی» رفت.' );
			case 'trash':
				wp_trash_post( $id );
				return array( 'message' => 'به زباله‌دان منتقل شد.' );
			case 'regenerate':
				$topic_id = (int) get_post_meta( $id, '_aaw_topic_id', true );
				if ( ! $topic_id || ! AAW_Topics::get( $topic_id ) ) {
					return new WP_Error( 'aaw', 'موضوع مرتبط با این مقاله در صف وجود ندارد.' );
				}
				wp_trash_post( $id );
				AAW_Topics::update( $topic_id, array( 'status' => 'pending', 'attempts' => 0, 'post_id' => 0, 'error' => null, 'priority' => 2 ) );
				AAW_Topics::move( $topic_id, 'top' );
				return array( 'message' => 'مقاله حذف و موضوع برای تولید مجدد به ابتدای صف رفت.', 'topic_id' => $topic_id );
		}
		return new WP_Error( 'aaw', 'عملیات نامعتبر' );
	}

	/* ============================ Logs ============================ */

	private static function a_logs_list( $d ) {
		$q = AAW_Logs::query(
			array(
				'level'    => sanitize_key( $d['level'] ?? '' ),
				'event'    => sanitize_key( $d['event'] ?? '' ),
				'search'   => sanitize_text_field( $d['search'] ?? '' ),
				'page'     => absint( $d['page'] ?? 1 ),
				'per_page' => 50,
			)
		);
		foreach ( $q['items'] as &$r ) {
			$r['time_h'] = wp_date( 'Y/m/d H:i:s', strtotime( $r['created_at'] . ' UTC' ) );
			$r['edit']   = $r['post_id'] ? get_edit_post_link( $r['post_id'], 'raw' ) : '';
		}
		unset( $r );
		return $q;
	}

	private static function a_logs_clear( $d ) {
		AAW_Logs::clear();
		return array( 'message' => 'گزارش‌ها پاک شد.' );
	}

	private static function a_logs_export( $d ) {
		return array( 'filename' => 'aria-logs-' . gmdate( 'Ymd' ) . '.csv', 'content' => AAW_Logs::export_csv() );
	}

	private static function a_test_notify( $d ) {
		$ok = AAW_Notifier::telegram( 'پیام آزمایشی ARIAGH.AIWRITER: اتصال تلگرام برقرار است.' );
		if ( AAW_Settings::get( 'notify_email' ) ) {
			$to = AAW_Settings::get( 'notify_email_to' ) ? AAW_Settings::get( 'notify_email_to' ) : get_option( 'admin_email' );
			wp_mail( $to, 'آزمایش اعلان ARIAGH.AIWRITER', 'این یک ایمیل آزمایشی است.' );
		}
		AAW_Notifier::webhook( 'test', array( 'title' => 'آزمایش وب‌هوک' ) );
		return array( 'message' => 'اعلان‌های آزمایشی ارسال شد' . ( AAW_Settings::get( 'telegram_enabled' ) ? ( $ok ? ' (تلگرام موفق)' : ' (تلگرام ناموفق)' ) : '' ) . '.' );
	}

	/* ============================ License ============================ */

	private static function a_license_activate( $d ) {
		$r = AAW_License::activate( isset( $d['key'] ) ? (string) $d['key'] : '' );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return array( 'message' => 'لایسنس با موفقیت روی ' . $r['domain'] . ' فعال شد.', 'state' => $r );
	}

	private static function a_license_check( $d ) {
		$r = AAW_License::check( true );
		return array( 'message' => $r['label'] . ( $r['message'] ? ' — ' . $r['message'] : '' ), 'state' => $r );
	}

	private static function a_license_deactivate( $d ) {
		$r = AAW_License::deactivate();
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return array( 'message' => 'لایسنس روی این سایت غیرفعال شد.', 'state' => $r );
	}

	/** Explain a raw error string reported by the browser (worker / provider errors). */
	private static function a_explain( $d ) {
		$raw = substr( sanitize_textarea_field( (string) ( $d['error'] ?? '' ) ), 0, 2000 );
		$msg = AAW_Errors::explain( $raw );
		if ( $msg === $raw ) {
			$msg = AAW_Errors::format( 'خطای ورکر یا سرویس هوش مصنوعی', 'پیام اصلی سرویس در جزئیات فنی آمده است؛ این الگو در فهرست خطاهای شناخته‌شده نیست.', 'جزئیات فنی را بررسی کنید؛ «گزارش‌ها» و «عیب‌یابی» تب کلادفلر اطلاعات بیشتری می‌دهند.', $raw );
		}
		return array( 'message' => $msg );
	}

	/* ============================ Background jobs ============================ */

	/** Manual "generate now" as a background job (push mode: the worker posts drafts itself). */
	private static function a_run_bg( $d ) {
		$lic = AAW_License::can_generate();
		if ( is_wp_error( $lic ) ) {
			return $lic;
		}
		if ( ! AAW_BG::available() ) {
			return new WP_Error( 'aaw', 'no_bg' );
		}
		$id = AAW_BG::start( 'run', array( 'topic_id' => absint( $d['topic_id'] ?? 0 ) ) );
		return is_wp_error( $id ) ? $id : array( 'id' => $id );
	}

	private static function a_bg_status( $d ) {
		$j = AAW_BG::get( (string) ( $d['id'] ?? '' ) );
		if ( is_wp_error( $j ) ) {
			return $j;
		}
		$out = array(
			'status' => (string) ( $j['status'] ?? 'unknown' ),
			'step'   => AAW_BG::step_label( $j['step'] ?? '' ),
			'error'  => ! empty( $j['error'] ) ? AAW_Errors::explain( (string) $j['error'], 'ورکر کلادفلر' ) : '',
			'result' => $j['result'] ?? null,
		);
		if ( 'done' === $out['status'] && ! empty( $j['result']['delivered'] ) ) {
			$out['poll'] = AAW_Pull::poll();
		}
		if ( 'done' === $out['status'] && ! empty( $j['result']['playbook'] ) && empty( $j['result']['delivered'] ) ) {
			AAW_Knowledge::save( $j['result'] );
		}
		if ( 'done' === $out['status'] && ! empty( $j['result']['theme'] ) && empty( $j['result']['delivered'] ) ) {
			AAW_Images::save_theme( $j['result'] );
		}
		if ( 'done' === $out['status'] && ! empty( $j['result']['image']['base64'] ) ) {
			$out['preview'] = 'data:' . ( $j['result']['image']['mime'] ?? 'image/png' ) . ';base64,' . $j['result']['image']['base64'];
			$out['result']  = array( 'refs_used' => (int) ( $j['result']['image']['refs_used'] ?? 0 ), 'engine' => (string) ( $j['result']['image']['engine'] ?? '' ) );
		}
		return $out;
	}

	/* ============================ Images & knowledge ============================ */

	private static function a_image_key_save( $d ) {
		$engine = sanitize_key( $d['engine'] ?? '' );
		$key    = trim( (string) ( $d['key'] ?? '' ) );
		$def    = AAW_Images::engines()[ $engine ] ?? null;
		if ( ! $def || '' === $def['secret'] ) {
			return new WP_Error( 'aaw', 'این موتور به کلید جداگانه نیاز ندارد.' );
		}
		if ( '' === $key || preg_match( '/\s/', $key ) ) {
			return new WP_Error( 'aaw', 'کلید نامعتبر است.' );
		}
		if ( 'higgsfield' === $engine && false === strpos( $key, ':' ) ) {
			return new WP_Error( 'aaw', AAW_Errors::format( 'فرمت کلید Higgsfield درست نیست', 'Higgsfield دو مقدار دارد: Key ID و Key Secret.', 'آن‌ها را به شکل KEY_ID:KEY_SECRET (با دونقطه) وارد کنید.' ) );
		}
		if ( ! AAW_Cloudflare::is_deployed() ) {
			return new WP_Error( 'aaw', 'ابتدا در تب «کلادفلر» ورکر را مستقر کنید؛ کلیدها فقط در Secrets کلادفلر ذخیره می‌شوند.' );
		}
		$r = AAW_Cloudflare::put_secret( $def['secret'], $key );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$meta_id = $def['key'] ? $def['key'] : $engine;
		AAW_Settings::set_key_meta( in_array( $engine, array( 'openai', 'gemini' ), true ) ? $engine : 'img_' . $engine, AAW_Crypto::mask( $key ) );
		AAW_Logs::add( 'success', 'secret', 'کلید موتور تصویر «' . $def['name'] . '» در Secrets کلادفلر ذخیره شد.' );
		return array( 'message' => 'کلید در Secrets کلادفلر ذخیره شد.', 'mask' => AAW_Crypto::mask( $key ), 'id' => $meta_id );
	}

	/** Generate a test image with the current engine, refs and theme (background job). */
	private static function a_image_test( $d ) {
		if ( ! AAW_BG::available() ) {
			return new WP_Error( 'aaw', AAW_Errors::format( 'تست تصویر نیاز به ورکر به‌روز دارد', 'کارهای پس‌زمینه روی ورکر فعال نیست.', 'در تب کلادفلر «استقرار مجدد» را بزنید.' ) );
		}
		$title = sanitize_text_field( $d['title'] ?? '' );
		if ( '' === $title ) {
			$title = AAW_Settings::get( 'niche' ) ? AAW_Settings::get( 'niche' ) : get_bloginfo( 'name' );
		}
		$refs = AAW_Images::references_for( array( 'title' => $title, 'keywords' => sanitize_text_field( $d['keywords'] ?? '' ) ) );
		$eng  = sanitize_key( $d['engine'] ?? '' );
		$all  = AAW_Images::engines();
		if ( 'sub_codex' === $eng ) {
			return new WP_Error( 'aaw', 'اکانت ChatGPT از طریق GitHub تصویر می‌سازد و تست فوری ندارد؛ در صف بازبینی روی یک مقاله «فقط تصویر جدید» را بزنید.' );
		}
		$cfg  = ( $eng && isset( $all[ $eng ] ) ) ? AAW_Images::runtime( $eng ) : AAW_Images::runtime();
		$cfg['inline_count'] = 0;
		$cfg['enabled']      = true;
		if ( $eng ) {
			unset( $cfg['fallbacks'] );
		}
		$id   = AAW_BG::start( 'image', array( 'cfg' => $cfg, 'article' => array( 'title' => $title, 'image_prompt' => $title ), 'refs' => $refs ) );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		return array(
			'id'       => $id,
			'products' => $refs['product_names'],
			'refs'     => count( $refs['products'] ) + count( $refs['styles'] ),
		);
	}

	private static function a_style_learn( $d ) {
		if ( ! AAW_BG::available() ) {
			return new WP_Error( 'aaw', AAW_Errors::format( 'یادگیری تم نیاز به ورکر به‌روز دارد', 'کارهای پس‌زمینه روی ورکر فعال نیست.', 'در تب کلادفلر «استقرار مجدد» را بزنید.' ) );
		}
		$id = AAW_BG::start( 'style_learn', AAW_Images::style_learn_payload(), true );
		return is_wp_error( $id ) ? $id : array( 'id' => $id );
	}

	private static function a_seo_learn( $d ) {
		$gh = AAW_SiteData::available();
		$id = AAW_Knowledge::start( true );
		return is_wp_error( $id ) ? $id : array( 'id' => $id, 'github' => $gh, 'since' => time() );
	}

	private static function a_knowledge( $d ) {
		return array( 'seo' => AAW_Knowledge::get(), 'theme' => get_option( AAW_Images::THEME, array() ) );
	}

	/* ============================ Search Console & merging duplicates ============================ */

	private static function a_gsc_key_save( $d ) {
		return AAW_GSC::save_key( (string) ( $d['json'] ?? '' ) ); // $d is already unslashed once (dispatch).
	}

	private static function a_gsc_client_save( $d ) {
		return AAW_GSC::save_client( (string) ( $d['client_id'] ?? '' ), (string) ( $d['client_secret'] ?? '' ) );
	}

	private static function a_gsc_auth_url( $d ) {
		return AAW_GSC::auth_url();
	}

	private static function a_gsc_disconnect( $d ) {
		return AAW_GSC::disconnect();
	}

	private static function a_gsc_report( $d ) {
		$r = AAW_GSC::report();
		return $r ? array( 'report' => self::gsc_view( $r ) ) : array( 'report' => null );
	}

	private static function a_gsc_sites( $d ) {
		return AAW_GSC::sites();
	}

	private static function a_gsc_site_save( $d ) {
		$site = sanitize_text_field( (string) ( $d['site'] ?? '' ) );
		if ( ! preg_match( '#^(sc-domain:[a-z0-9.-]+|https?://\S+)$#i', $site ) ) {
			return new WP_Error( 'aaw', 'property نامعتبر است.' );
		}
		AAW_Settings::update( array( 'gsc_site' => $site ) );
		return array( 'message' => 'property سرچ کنسول ذخیره شد: ' . $site );
	}

	/** Get fresh data (first call) or continue a resumable download (next calls). */
	private static function a_gsc_refresh( $d ) {
		$r = ! empty( $d['continue'] ) ? AAW_GSC::collect() : AAW_GSC::refresh( max( 7, min( 480, absint( $d['days'] ?? 90 ) ) ) );
		if ( null === $r ) {
			return array( 'done' => false, 'progress' => AAW_Transfer::progress( 'gsc_get', 'report' ) );
		}
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return array( 'done' => true, 'report' => self::gsc_view( $r ) );
	}

	private static function gsc_view( array $r ) {
		$posts = function ( $q ) {
			$near = AAW_Dedupe::nearest( $q, '', 1, array( 'post' ) );
			return $near && $near[0]['score'] >= 0.5 ? array( 'id' => $near[0]['id'], 'title' => $near[0]['title'] ) : null;
		};
		$striking = array();
		foreach ( array_slice( (array) $r['striking'], 0, 40 ) as $s ) {
			$s['post']  = $posts( $s['q'] );
			$striking[] = $s;
		}
		return array( 'site' => $r['site'], 'days' => $r['days'], 'at' => (int) ( $r['at'] / 1000 ), 'totals' => $r['totals'], 'striking' => $striking, 'low_ctr' => array_slice( (array) $r['low_ctr'], 0, 25 ), 'top' => array_slice( (array) $r['top'], 0, 40 ), 'cannibal' => count( (array) $r['cannibal'] ) );
	}

	private static function a_gsc_add_topics( $d ) {
		$topics = array();
		foreach ( array_slice( (array) ( $d['queries'] ?? array() ), 0, 30 ) as $q ) {
			$q = sanitize_text_field( (string) $q );
			if ( '' !== $q ) {
				$topics[] = array( 'title' => $q, 'focus_keyword' => $q, 'keywords' => array( $q ), 'reason' => 'فرصت سرچ کنسول' );
			}
		}
		$r = AAW_Analyzer::add_topics( $topics );
		return array( 'message' => sprintf( '%d موضوع از سرچ کنسول به صف اضافه شد%s.', $r['added'], $r['skipped'] ? ' (' . $r['skipped'] . ' تکراری رد شد)' : '' ) ) + $r;
	}

	private static function a_merge_list( $d ) {
		$redirects = array();
		foreach ( AAW_Merge::redirects() as $from => $m ) {
			$redirects[] = array( 'from' => $from, 'to' => get_permalink( (int) $m['to'] ), 'title' => get_the_title( (int) $m['to'] ) );
		}
		return array(
			'pairs'     => AAW_Merge::candidates( ! empty( $d['force'] ) ),
			'history'   => array_map( function ( $m ) { unset( $m['backup'] ); $m['when'] = wp_date( 'Y/m/d H:i', (int) $m['t'] ); return $m; }, array_slice( AAW_Merge::history(), 0, 30 ) ),
			'redirects' => $redirects,
			'gsc'       => AAW_GSC::connected(),
		);
	}

	private static function a_merge_start( $d ) {
		$keep = absint( $d['keep'] ?? 0 );
		$drop = absint( $d['drop'] ?? 0 );
		if ( ! current_user_can( 'edit_post', $keep ) || ! current_user_can( 'edit_post', $drop ) ) {
			return new WP_Error( 'aaw', 'دسترسی ویرایش این نوشته‌ها را ندارید.' );
		}
		$id = AAW_Merge::request( $keep, $drop, ! isset( $d['links'] ) || ! empty( $d['links'] ) );
		return is_wp_error( $id ) ? $id : array( 'id' => $id, 'message' => 'ادغام با هوش مصنوعی شروع شد. چند دقیقه دیگر مقاله ادغام‌شده ثبت و ریدایرکت ۳۰۱ خودکار ساخته می‌شود (پیشرفت در «فعالیت زنده»).' );
	}

	private static function a_merge_undo( $d ) {
		$r = AAW_Merge::undo( absint( $d['drop'] ?? 0 ) );
		return is_wp_error( $r ) ? $r : array( 'message' => 'ادغام بازگردانی شد.' );
	}

	/* ============================ ChatGPT sign-in with a one-time code ============================ */

	/**
	 * Sign in with the ChatGPT account without installing anything: GitHub runs the official
	 * device-code login, WordPress shows the link + code, the user signs in on chatgpt.com.
	 */
	private static function a_codex_login_start( $d ) {
		if ( ! AAW_GitHub::is_connected() ) {
			return new WP_Error( 'aaw', AAW_Errors::format( 'ابتدا GitHub را وصل کنید', 'ورود ChatGPT روی GitHub Actions مخزن خصوصی شما انجام می‌شود.', 'در تب «اکانت اشتراکی» مرحله «اتصال GitHub» را انجام دهید (یک‌بار).' ) );
		}
		if ( ! AAW_Cloudflare::is_deployed() ) {
			return new WP_Error( 'aaw', 'ابتدا ورکر کلادفلر را مستقر کنید؛ اعتبارنامه ChatGPT در KV کلادفلر خودتان نگهداری می‌شود.' );
		}
		$id = AAW_BG::new_id( 'l' );
		$r  = AAW_GitHub::dispatch( 'codex_login', 0, 'codex', $id );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		update_option( 'aaw_codex_login', array( 'id' => $id, 't' => time(), 'text' => ! empty( $d['text'] ), 'image' => ! isset( $d['image'] ) || ! empty( $d['image'] ) ), false );
		AAW_Logs::add( 'info', 'github', 'ورود به اکانت ChatGPT با کد تأیید شروع شد (GitHub Actions).' );
		return array( 'id' => $id, 'url' => AAW_GitHub::repo_url() . '/actions' );
	}

	private static function a_codex_login_status( $d ) {
		$st = get_option( 'aaw_codex_login', array() );
		$id = sanitize_key( $d['id'] ?? ( $st['id'] ?? '' ) );
		if ( ! $id ) {
			return new WP_Error( 'aaw', 'ورودی در جریان نیست.' );
		}
		$r = AAW_Cloudflare::call_worker( 'login_status', array( 'id' => $id, 'action' => 'get' ), AAW_Transfer::PIECE_TO );
		if ( is_wp_error( $r ) ) {
			return array( 'state' => 'waiting', 'note' => 'در حال بررسی…' );
		}
		$s     = (array) ( $r['status'] ?? array() );
		$state = (string) ( $s['state'] ?? 'waiting' );
		if ( 'done' === $state && ! get_option( 'aaw_codex_login_done_' . $id ) ) {
			update_option( 'aaw_codex_login_done_' . $id, 1, false );
			AAW_Settings::set_key_meta( 'sub_codex', 'ChatGPT · ورود با کد' );
			if ( ! empty( $st['image'] ) ) {
				AAW_Priority::promote( 'image', 'sub_codex' );
			}
			if ( ! empty( $st['text'] ) ) {
				$chain = array_values( array_diff( AAW_Priority::text_chain(), array( 'sub_codex' ) ) );
				array_unshift( $chain, 'sub_codex' );
				AAW_Priority::save_text( $chain );
			}
			AAW_Logs::add( 'success', 'secret', 'اکانت ChatGPT با کد تأیید وصل شد؛ اعتبارنامه در KV کلادفلر شما ذخیره است و خودکار تمدید می‌شود.' );
			delete_option( 'aaw_codex_login' );
		}
		$elapsed = time() - (int) ( $st['t'] ?? time() );
		return array(
			'state'   => $state,
			'url'     => esc_url_raw( (string) ( $s['url'] ?? '' ) ),
			'code'    => sanitize_text_field( (string) ( $s['code'] ?? '' ) ),
			'error'   => (string) ( $s['error'] ?? '' ),
			'detail'  => (string) ( $s['detail'] ?? '' ),
			'elapsed' => $elapsed,
			'roles'   => AAW_Priority::roles( 'sub_codex' ),
		);
	}

	/* ============================ Main AI tabs: priority lists ============================ */

	private static function a_priority( $d ) {
		return array(
			'text'   => AAW_Priority::text_items(),
			'image'  => AAW_Priority::image_items(),
			'gh'     => AAW_GitHub::is_connected(),
			'images' => (bool) AAW_Settings::get( 'featured_image' ),
		);
	}

	private static function a_priority_save( $d ) {
		$kind   = 'image' === ( $d['kind'] ?? '' ) ? 'image' : 'text';
		if ( ! empty( $d['promote'] ) ) {
			$r = AAW_Priority::promote( $kind, sanitize_key( $d['promote'] ) );
			return is_wp_error( $r ) ? $r : array( 'message' => 'اولویت اول شد. ترتیب کامل را در تب «' . ( 'image' === $kind ? 'هوش مصنوعی تولید تصویر' : 'هوش مصنوعی تولید محتوا' ) . '» ببینید.' );
		}
		$order  = array_map( 'sanitize_key', (array) ( $d['order'] ?? array() ) );
		$models = isset( $d['models'] ) && is_array( $d['models'] ) ? $d['models'] : array();
		if ( 'image' === $kind && isset( $d['enabled'] ) ) {
			AAW_Settings::update( array( 'featured_image' => ! empty( $d['enabled'] ) ) );
			if ( empty( $d['enabled'] ) && ! $order ) {
				return array( 'message' => 'تولید تصویر برای مقالات خاموش شد.', 'image' => AAW_Priority::image_items() );
			}
		}
		$r = 'image' === $kind ? AAW_Priority::save_image( $order, $models ) : AAW_Priority::save_text( $order, $models );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$names = array();
		foreach ( 'image' === $kind ? AAW_Priority::image_items() : AAW_Priority::text_items() as $it ) {
			if ( $it['on'] ) {
				$names[] = $it['name'];
			}
		}
		AAW_Logs::add( 'info', 'settings', ( 'image' === $kind ? 'اولویت هوش مصنوعی تصویر: ' : 'اولویت هوش مصنوعی محتوا: ' ) . implode( ' ← ', $names ) );
		return array(
			'message' => 'ذخیره شد. ترتیب: ' . implode( ' ← ', $names ),
			'text'    => AAW_Priority::text_items(),
			'image'   => AAW_Priority::image_items(),
			'label'   => AAW_Priority::first_label( $kind ),
		);
	}

	/** Subscription tab: which job each connected account does. */
	private static function a_sub_role( $d ) {
		$id = sanitize_key( $d['provider'] ?? '' );
		$r  = AAW_Priority::set_role( $id, ! empty( $d['text'] ), ! empty( $d['image'] ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$roles = AAW_Priority::roles( $id );
		$name  = 'sub_codex' === $id ? 'ChatGPT' : 'Claude';
		$what  = array_filter( array( $roles['text'] ? 'محتوا (اولویت ' . $roles['text'] . ')' : '', $roles['image'] ? 'تصویر (اولویت ' . $roles['image'] . ')' : '' ) );
		return array( 'roles' => $roles, 'message' => $name . ': ' . ( $what ? implode( ' و ', $what ) : 'فعلاً برای هیچ کاری استفاده نمی‌شود (وصل باقی می‌ماند)' ) );
	}

	private static function a_site_crawl( $d ) {
		if ( ! AAW_SiteData::available() ) {
			return new WP_Error( 'aaw', AAW_Errors::format( 'دیتابیس GitHub در دسترس نیست', 'برای خواندن سایت از GitHub، اتصال GitHub (تب اکانت اشتراکی) و ورکر کلادفلر لازم است.', 'ابتدا GitHub را وصل کنید؛ اکانت اشتراکی لازم نیست.' ) );
		}
		$r = AAW_SiteData::start_crawl( null );
		return is_wp_error( $r ) ? $r : array( 'id' => $r['id'], 'message' => 'GitHub شروع به خواندن سایت کرد. ۲ تا ۱۰ دقیقه بعد نسخه پشتیبان جدید جایگزین قبلی می‌شود.', 'url' => AAW_GitHub::repo_url() . '/actions' );
	}

	private static function a_site_status( $d ) {
		if ( AAW_SiteData::crawling() ) {
			AAW_Pull::poll();
		}
		return AAW_SiteData::status();
	}

	/* ============================ Live activity ============================ */

	/** Browser-driven operations (provider tests, direct worker calls) register here. */
	private static function a_act_start( $d ) {
		$kinds = array( 'test', 'run', 'generate', 'suggest', 'analyze', 'image', 'models' );
		$kind  = in_array( $d['kind'] ?? '', $kinds, true ) ? $d['kind'] : 'test';
		return array( 'id' => AAW_Activity::start( $kind, sanitize_text_field( $d['label'] ?? '' ) ) );
	}

	private static function a_act_end( $d ) {
		AAW_Activity::finish( sanitize_key( $d['id'] ?? '' ), ! empty( $d['ok'] ), sanitize_textarea_field( (string) ( $d['detail'] ?? '' ) ) );
		return array( 'ok' => true );
	}

	private static function a_activity( $d ) {
		global $wpdb;
		$processing = $wpdb->get_results( 'SELECT id, title, locked_at FROM ' . AAW_Topics::table() . " WHERE status = 'processing' ORDER BY locked_at DESC LIMIT 10", ARRAY_A ); // phpcs:ignore
		$since      = absint( $d['since'] ?? 0 );
		$logs       = $wpdb->get_results( $wpdb->prepare( 'SELECT id, created_at, level, event, message FROM ' . AAW_Logs::table() . ' WHERE id > %d ORDER BY id DESC LIMIT 30', $since ), ARRAY_A ); // phpcs:ignore
		foreach ( (array) $logs as &$l ) {
			$l['time'] = wp_date( 'H:i:s', strtotime( $l['created_at'] . ' UTC' ) );
		}
		unset( $l );
		return array(
			'ops'        => AAW_Activity::feed(),
			'processing' => (array) $processing,
			'logs'       => (array) $logs,
			'running'    => AAW_Activity::running_count(),
			'now'        => AAW_Timeline::now(),
		);
	}

	private static function a_activity_clear( $d ) {
		AAW_Activity::clear_finished();
		return array( 'message' => 'عملیات تمام‌شده پاک شد.' );
	}

	/* ============================ Revise / image only ============================ */

	private static function a_revise( $d ) {
		$pid = absint( $d['post_id'] ?? 0 );
		if ( ! current_user_can( 'edit_post', $pid ) ) {
			return new WP_Error( 'aaw', 'اجازه ویرایش این نوشته را ندارید.' );
		}
		$id = AAW_Revise::request_revision( $pid, (string) ( $d['text'] ?? '' ) );
		return is_wp_error( $id ) ? $id : array( 'id' => $id, 'message' => 'دستور اصلاح ثبت شد؛ هوش مصنوعی در حال اعمال آن است. پیشرفت را در تب «فعالیت زنده» ببینید.' );
	}

	private static function a_post_image( $d ) {
		$pid = absint( $d['post_id'] ?? 0 );
		if ( ! current_user_can( 'edit_post', $pid ) ) {
			return new WP_Error( 'aaw', 'اجازه ویرایش این نوشته را ندارید.' );
		}
		$id = AAW_Revise::request_image( $pid, (string) ( $d['prompt'] ?? '' ), ! empty( $d['inline'] ) );
		return is_wp_error( $id ) ? $id : array( 'id' => $id, 'message' => 'ساخت تصویر جدید شروع شد؛ متن مقاله تغییری نمی‌کند.' );
	}

	private static function a_revision_publish( $d ) {
		$pid = absint( $d['post_id'] ?? 0 );
		if ( ! current_user_can( 'edit_post', $pid ) ) {
			return new WP_Error( 'aaw', 'اجازه ویرایش این نوشته را ندارید.' );
		}
		$r = AAW_Revise::publish_pending( $pid );
		return is_wp_error( $r ) ? $r : array( 'message' => 'اصلاحات روی نوشته اعمال شد.' );
	}
}
