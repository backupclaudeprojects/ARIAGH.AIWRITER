<?php
/**
 * Transfers for slow / time-limited hosts.
 *
 * Some hosts (many Iranian data centres) kill every international connection after
 * ~15 seconds and upload at only a few KB/s. Everything big therefore moves in small
 * pieces that each finish in a few seconds:
 *  - the piece size adapts to the measured speed (faster link → bigger pieces);
 *  - a failed piece is retried smaller instead of failing the whole job;
 *  - downloads are resumable across PHP requests (progress is kept in a temp file),
 *    so a result that needs 3 minutes simply arrives over the next few cron ticks.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Transfer {

	const OPT      = 'aaw_net';
	const TARGET_S = 5;     // Aim: each piece takes ~5 s.
	const PIECE_TO = 13;    // Hard timeout per piece (below the common 15 s cut).
	const MIN_DOWN = 8192;
	const MAX_DOWN = 786432;
	const MIN_UP   = 6144;

	private static $started = 0;

	/* ------------------------------------------------------------ speed */

	public static function speeds() {
		$n = get_option( self::OPT, array() );
		$n = is_array( $n ) ? $n : array();
		return array(
			'down' => (float) ( $n['down'] ?? 6000 ),  // bytes/s; conservative start.
			'up'   => (float) ( $n['up'] ?? 3000 ),
			'fail' => (int) ( $n['fail'] ?? 0 ),
			'cut'  => (float) ( $n['cut'] ?? 0 ),
			'fs_down' => (int) ( $n['fs_down'] ?? 0 ),  // Smallest piece size that failed (learned ceiling).
			'fs_up'   => (int) ( $n['fs_up'] ?? 0 ),
			'at'   => (int) ( $n['at'] ?? 0 ),
		);
	}

	/** Record one piece: success updates the speed (EWMA), failure halves it. */
	public static function record( $dir, $bytes, $secs, $ok = true, $size = 0 ) {
		$n   = self::speeds();
		$key = 'up' === $dir ? 'up' : 'down';
		$fs  = 'fs_' . $key;
		if ( $ok ) {
			$bps       = $bytes / max( 0.25, (float) $secs );
			$n[ $key ] = 0.6 * $n[ $key ] + 0.4 * $bps;
			$n['fail'] = max( 0, $n['fail'] - 1 );
			if ( $n[ $fs ] > 0 ) {
				$n[ $fs ] = (int) ( $n[ $fs ] * 1.02 ); // Slowly allow bigger pieces again.
			}
		} else {
			if ( $size > 0 ) {
				$n[ $fs ] = $n[ $fs ] > 0 ? min( $n[ $fs ], (int) $size ) : (int) $size;
			}
			$n[ $key ] = max( 'up' === $key ? 1200 : 1600, $n[ $key ] * 0.4 );
			$n['fail']++;
			// Learn the host's hard connection limit (a piece that died after N seconds).
			if ( $secs >= 1.5 && $secs < self::PIECE_TO - 0.5 ) {
				$n['cut'] = $n['cut'] > 0 ? min( $n['cut'], $secs ) : $secs;
			}
		}
		$n['at'] = time();
		update_option( self::OPT, $n, false );
	}

	/** Seconds one piece should take: 5 s, or less when the host cuts connections sooner. */
	public static function target() {
		$cut = self::speeds()['cut'];
		return $cut > 0 ? max( 0.8, min( self::TARGET_S, $cut * 0.35 ) ) : self::TARGET_S;
	}

	public static function down_chunk() {
		$sp = self::speeds();
		$c  = (int) ( $sp['down'] * self::target() );
		if ( $sp['fs_down'] > 0 ) {
			$c = min( $c, (int) ( $sp['fs_down'] * 0.75 ) );
		}
		return max( self::MIN_DOWN, min( self::MAX_DOWN, $c ) );
	}

	public static function up_chunk() {
		$max = max( 8, (int) AAW_Settings::get( 'net_part_kb', 16 ) ) * 1024;
		$sp  = self::speeds();
		$c   = (int) ( $sp['up'] * self::target() );
		if ( $sp['fs_up'] > 0 ) {
			$c = min( $c, (int) ( $sp['fs_up'] * 0.75 ) );
		}
		return max( self::MIN_UP, min( $max, $c ) );
	}

	/* ------------------------------------------------------------ time budget */

	/** Seconds this PHP request may still spend on transfers. */
	public static function reset_clock() {
		self::$started = 0;
	}

	public static function time_left() {
		if ( ! self::$started ) {
			self::$started = microtime( true );
		}
		if ( defined( 'AAW_TRANSFER_BUDGET' ) && AAW_TRANSFER_BUDGET > 0 ) {
			return AAW_TRANSFER_BUDGET - ( microtime( true ) - self::$started );
		}
		$max = (int) ini_get( 'max_execution_time' );
		$cap = ( $max > 0 ? min( 40, $max - 8 ) : 40 );
		if ( ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			$cap = max( $cap, 20 );
		}
		return $cap - ( microtime( true ) - self::$started );
	}

	/* ------------------------------------------------------------ temp storage */

	private static function dir() {
		$u = wp_upload_dir( null, false );
		$d = trailingslashit( $u['basedir'] ) . 'aaw-tmp/';
		if ( ! is_dir( $d ) ) {
			wp_mkdir_p( $d );
			@file_put_contents( $d . 'index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore
			@file_put_contents( $d . '.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore
		}
		return $d;
	}

	private static function file( $route, $id ) {
		return self::dir() . sanitize_key( $route . '-' . $id ) . '.part';
	}

	private static function state_key( $route, $id ) {
		return 'aaw_dl_' . substr( md5( $route . '|' . $id ), 0, 16 );
	}

	/**
	 * Ranged download of a worker resource (blob_get / result_get).
	 *
	 * @return string|null|WP_Error Full data, null = not finished yet (continue later), or error.
	 */
	public static function download( $route, $field, $id ) {
		$sk    = self::state_key( $route, $id );
		$st    = get_option( $sk, array() );
		$st    = is_array( $st ) ? $st : array();
		$st   += array( 'off' => 0, 'total' => 0, 'fails' => 0, 'done' => false, 't' => time() );
		$file  = self::file( $route, $id );
		if ( ! file_exists( $file ) && $st['off'] > 0 ) {
			$st['off'] = 0; // Temp file vanished → restart this item.
		}
		if ( $st['done'] && file_exists( $file ) ) {
			return (string) file_get_contents( $file ); // phpcs:ignore
		}
		while ( true ) {
			if ( self::time_left() < 4 ) {
				update_option( $sk, $st, false );
				return null;
			}
			$len = self::down_chunk();
			$t0  = microtime( true );
			$r   = AAW_Cloudflare::call_worker( $route, array( $field => $id, 'offset' => (int) $st['off'], 'len' => $len ), self::PIECE_TO );
			$dt  = microtime( true ) - $t0;
			if ( is_wp_error( $r ) ) {
				if ( false !== stripos( $r->get_error_message(), 'not found' ) ) {
					self::release( $route, $id );
					return new WP_Error( 'aaw_dl', 'فایل نتیجه در کلادفلر پیدا نشد (منقضی شده یا قبلاً دریافت شده).' );
				}
				self::record( 'down', 0, $dt, false, $len );
				$st['fails']++;
				update_option( $sk, $st, false );
				if ( $st['fails'] >= 8 ) {
					return new WP_Error( 'aaw_dl', 'دریافت تکه‌ای نتیجه از کلادفلر بعد از ۸ تلاش با تکه‌های کوچک‌تر هم موفق نشد: ' . $r->get_error_message() );
				}
				continue; // Retry with a smaller piece.
			}
			$data = (string) ( $r['data'] ?? '' );
			if ( false === file_put_contents( $file, $data, $st['off'] > 0 ? FILE_APPEND : 0 ) ) { // phpcs:ignore
				return new WP_Error( 'aaw_dl', 'نوشتن فایل موقت در پوشه uploads/aaw-tmp ممکن نشد (دسترسی نوشتن را بررسی کنید).' );
			}
			self::record( 'down', strlen( $data ) + 120, $dt, true );
			$st['off']  += strlen( $data );
			$st['total'] = (int) ( $r['total'] ?? 0 );
			$st['fails'] = 0;
			if ( $st['off'] >= $st['total'] || '' === $data ) {
				$st['done'] = true;
				update_option( $sk, $st, false );
				return (string) file_get_contents( $file ); // phpcs:ignore
			}
			update_option( $sk, $st, false );
		}
	}

	/** Progress (0–100) of a pending download, for the UI. */
	public static function progress( $route, $id ) {
		$st = get_option( self::state_key( $route, $id ), array() );
		return ( is_array( $st ) && ! empty( $st['total'] ) ) ? (int) min( 100, round( 100 * $st['off'] / $st['total'] ) ) : 0;
	}

	public static function release( $route, $id ) {
		delete_option( self::state_key( $route, $id ) );
		$f = self::file( $route, $id );
		if ( file_exists( $f ) ) {
			@unlink( $f ); // phpcs:ignore
		}
	}

	/** Remove temp files older than 3 days (results expire on Cloudflare after 3 days). */
	public static function cleanup() {
		foreach ( (array) glob( self::dir() . '*.part' ) as $f ) {
			if ( $f && filemtime( $f ) < time() - 3 * DAY_IN_SECONDS ) {
				@unlink( $f ); // phpcs:ignore
			}
		}
	}
}
