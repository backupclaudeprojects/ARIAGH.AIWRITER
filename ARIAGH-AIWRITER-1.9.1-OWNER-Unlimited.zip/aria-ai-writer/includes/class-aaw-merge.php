<?php
/**
 * Duplicate / overlapping articles: find them (Search Console + content similarity),
 * merge two of them into one with the AI, 301-redirect the removed one and fix links.
 * Everything is reversible ("بازگردانی").
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Merge {

	const REDIRECTS = 'aaw_redirects';
	const HISTORY   = 'aaw_merges';
	const PENDING   = 'aaw_merge_pending';

	/* ------------------------------------------------------------ find */

	/**
	 * Pairs of published posts that compete or repeat each other.
	 *
	 * @return array<int,array>
	 */
	public static function candidates( $force = false ) {
		$c = $force ? false : get_transient( 'aaw_merge_candidates' );
		if ( is_array( $c ) ) {
			return $c;
		}
		$posts = array();
		foreach ( AAW_Dedupe::corpus() as $it ) {
			if ( 'post' === $it['type'] && 'publish' === $it['st'] ) {
				$posts[ $it['id'] ] = $it;
			}
		}
		$merged = array_map( 'intval', array_keys( self::history_by_drop() ) );
		$pairs  = array();
		$add    = function ( $a, $b, $why, $score, $queries = array() ) use ( &$pairs, $posts, $merged ) {
			if ( $a === $b || ! isset( $posts[ $a ], $posts[ $b ] ) || in_array( $a, $merged, true ) || in_array( $b, $merged, true ) ) {
				return;
			}
			$k = min( $a, $b ) . '-' . max( $a, $b );
			if ( ! isset( $pairs[ $k ] ) ) {
				$pairs[ $k ] = array( 'a' => min( $a, $b ), 'b' => max( $a, $b ), 'why' => array(), 'score' => 0, 'queries' => array() );
			}
			$pairs[ $k ]['why'][]  = $why;
			$pairs[ $k ]['score']  = max( $pairs[ $k ]['score'], $score );
			$pairs[ $k ]['queries'] = array_values( array_unique( array_merge( $pairs[ $k ]['queries'], $queries ) ) );
		};

		// 1) Search Console: several pages of this site rank for the same query (keyword cannibalization).
		$rep = AAW_GSC::report();
		foreach ( (array) ( $rep['cannibal'] ?? array() ) as $c ) {
			$ids = array();
			foreach ( (array) $c['pages'] as $p ) {
				$id = url_to_postid( $p['u'] );
				if ( $id && isset( $posts[ $id ] ) ) {
					$ids[ $id ] = true;
				}
			}
			$ids = array_keys( $ids );
			for ( $i = 0; $i < count( $ids ); $i++ ) {
				for ( $j = $i + 1; $j < count( $ids ); $j++ ) {
					$add( $ids[ $i ], $ids[ $j ], 'gsc', min( 1, 0.6 + $c['i'] / 5000 ), array( $c['q'] ) );
				}
			}
		}
		// 2) Content: titles / focus keywords that say the same thing.
		$list = array_values( $posts );
		$n    = min( 800, count( $list ) );
		for ( $i = 0; $i < $n; $i++ ) {
			for ( $j = $i + 1; $j < $n; $j++ ) {
				$s = AAW_Dedupe::score( $list[ $i ]['tok'], $list[ $j ]['tok'] );
				if ( $s >= 0.6 ) {
					$add( $list[ $i ]['id'], $list[ $j ]['id'], 'content', $s );
				}
			}
		}
		$out = array();
		foreach ( $pairs as $p ) {
			$out[] = self::describe( $p );
		}
		usort( $out, function ( $x, $y ) { return ( count( $y['why'] ) <=> count( $x['why'] ) ) ?: ( $y['score'] <=> $x['score'] ); } );
		$out = array_slice( $out, 0, 60 );
		set_transient( 'aaw_merge_candidates', $out, 6 * HOUR_IN_SECONDS );
		return $out;
	}

	private static function describe( array $p ) {
		$side = function ( $id ) {
			$st = AAW_GSC::page_stats( get_permalink( $id ) );
			$p  = get_post( $id );
			return array(
				'id'     => (int) $id,
				'title'  => get_the_title( $id ),
				'url'    => get_permalink( $id ),
				'edit'   => admin_url( 'post.php?post=' . $id . '&action=edit' ),
				'words'  => $p ? count( preg_split( '/\s+/u', trim( wp_strip_all_tags( $p->post_content ) ), -1, PREG_SPLIT_NO_EMPTY ) ) : 0,
				'date'   => $p ? mysql2date( 'Y/m/d', $p->post_date ) : '',
				'clicks' => (int) ( $st['c'] ?? 0 ),
				'impr'   => (int) ( $st['i'] ?? 0 ),
				'pos'    => (float) ( $st['p'] ?? 0 ),
			);
		};
		$a = $side( $p['a'] );
		$b = $side( $p['b'] );
		// Keep the stronger page: more clicks → more impressions → longer → older.
		$keep = ( $a['clicks'] !== $b['clicks'] ) ? ( $a['clicks'] > $b['clicks'] ? 'a' : 'b' ) : ( ( $a['impr'] !== $b['impr'] ) ? ( $a['impr'] > $b['impr'] ? 'a' : 'b' ) : ( $a['words'] >= $b['words'] ? 'a' : 'b' ) );
		return array(
			'a'       => $a,
			'b'       => $b,
			'keep'    => $keep,
			'why'     => array_values( array_unique( $p['why'] ) ),
			'score'   => round( (float) $p['score'], 2 ),
			'queries' => array_slice( $p['queries'], 0, 6 ),
		);
	}

	/* ------------------------------------------------------------ merge */

	public static function prompts( $keep, $drop ) {
		$k      = AAW_Revise::article_from_post( $keep );
		$d      = AAW_Revise::article_from_post( $drop );
		$system = AAW_Knowledge::prompt_block()
			. "تو ویراستار ارشد سئو و فروش این سایت هستی. دو مقاله که موضوع یکسان یا خیلی نزدیک دارند باید به یک مقاله کامل، بهتر و بدون تکرار تبدیل شوند (رفع همپوشانی کلمات کلیدی).\n"
			. "قواعد: موضوع، کلمه کلیدی اصلی و عنوان مقاله «اصلی» حفظ شود؛ همه اطلاعات مفید و منحصربه‌فرد مقاله «دوم» به جای مناسب اضافه شود؛ مطالب تکراری فقط یک‌بار بیاید؛ سرفصل‌ها منطقی و کامل؛ سؤالات متداول هر دو ادغام و تکراری‌ها حذف شود؛ همه لینک‌ها به‌خصوص لینک محصولات حفظ شود (لینک به خود مقاله دوم حذف شود)؛ لحن و فرمت سایت؛ فارسی معیار با نیم‌فاصله؛ هیچ ادعای نادرست اضافه نکن.\n"
			. AAW_Products::prompt_block( $k['title'], $k['focus_keyword'] )
			. "\n## فرمت خروجی\n" . AAW_Prompt::output_schema();
		$user   = "مقاله اصلی (می‌ماند):\n" . wp_json_encode( $k, JSON_UNESCAPED_UNICODE ) . "\n\nمقاله دوم (حذف و به مقاله اصلی ریدایرکت می‌شود؛ مطالب مفیدش باید منتقل شود):\n" . wp_json_encode( $d, JSON_UNESCAPED_UNICODE ) . "\n\nمقاله ادغام‌شده کامل را فقط به شکل JSON برگردان.";
		return array( 'system' => $system, 'prompt' => $user );
	}

	/** Start an AI merge of $drop into $keep. */
	public static function request( $keep, $drop, $fix_links = true ) {
		$keep = absint( $keep );
		$drop = absint( $drop );
		if ( ! $keep || ! $drop || $keep === $drop || ! get_post( $keep ) || ! get_post( $drop ) ) {
			return new WP_Error( 'aaw', 'دو نوشته معتبر برای ادغام لازم است.' );
		}
		$p   = self::prompts( $keep, $drop );
		$rid = 'mg' . $drop . 'x' . strtolower( wp_generate_password( 4, false, false ) );
		$id  = AAW_Revise::dispatch_rewrite( $keep, $p, $rid, 'ادغام «' . get_the_title( $drop ) . '» در «' . get_the_title( $keep ) . '»' );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$pend         = get_option( self::PENDING, array() );
		$pend         = is_array( $pend ) ? $pend : array();
		$pend[ $rid ] = array( 'keep' => $keep, 'drop' => $drop, 'links' => (bool) $fix_links, 't' => time(), 'user' => get_current_user_id() );
		update_option( self::PENDING, $pend, false );
		AAW_Logs::add( 'info', 'revise', 'ادغام «' . get_the_title( $drop ) . '» در «' . get_the_title( $keep ) . '» با هوش مصنوعی شروع شد.', array( 'post_id' => $keep ) );
		return $id;
	}

	public static function is_merge_request( $request_id ) {
		$pend = get_option( self::PENDING, array() );
		return is_array( $pend ) && isset( $pend[ (string) $request_id ] );
	}

	/** The AI returned the merged article: apply it to the keeper, then redirect the other post. */
	public static function apply( $keep, array $article, $request_id ) {
		$pend = get_option( self::PENDING, array() );
		$job  = $pend[ $request_id ] ?? null;
		if ( ! $job || (int) $job['keep'] !== (int) $keep ) {
			return new WP_Error( 'aaw', 'درخواست ادغام پیدا نشد.' );
		}
		$drop = (int) $job['drop'];
		$kp   = get_post( $keep );
		$dp   = get_post( $drop );
		if ( ! $kp || ! $dp ) {
			return new WP_Error( 'aaw', 'یکی از دو نوشته ادغام حذف شده است.' );
		}
		// Backup for «بازگردانی».
		$backup = array( 'content' => $kp->post_content, 'title' => $kp->post_title, 'excerpt' => $kp->post_excerpt, 'drop_status' => $dp->post_status );
		$r      = AAW_Post_Builder::update_from_article( $keep, $article );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$res = self::redirect_and_retire( $keep, $drop, ! empty( $job['links'] ) );
		$h   = get_option( self::HISTORY, array() );
		$h   = is_array( $h ) ? $h : array();
		$h[] = array( 'keep' => $keep, 'drop' => $drop, 'from' => $res['path'], 'drop_title' => $dp->post_title, 'keep_title' => get_the_title( $keep ), 'links' => $res['links'], 't' => time(), 'backup' => $backup, 'undone' => false );
		update_option( self::HISTORY, array_slice( $h, -100 ), false );
		unset( $pend[ $request_id ] );
		update_option( self::PENDING, $pend, false );
		delete_transient( 'aaw_merge_candidates' );
		AAW_Dedupe::flush();
		update_post_meta( $keep, AAW_Revise::META_STATE, array( 'state' => 'revised', 'note' => 'ادغام با «' . $dp->post_title . '»', 't' => time() ) );
		AAW_Logs::add( 'success', 'revise', sprintf( 'ادغام انجام شد: «%s» در «%s» ادغام، با ریدایرکت ۳۰۱ به آن منتقل و به پیش‌نویس رفت%s.', $dp->post_title, get_the_title( $keep ), $res['links'] ? '؛ ' . $res['links'] . ' لینک داخلی اصلاح شد' : '' ), array( 'post_id' => $keep ) );
		return true;
	}

	/** 301 old URL → keeper, move the old post to drafts, point internal links to the keeper. */
	public static function redirect_and_retire( $keep, $drop, $fix_links = true ) {
		$old_url = get_permalink( $drop );
		$new_url = get_permalink( $keep );
		$path    = self::path( $old_url );
		if ( '/' !== $path && self::path( $new_url ) !== $path ) {
			$map          = self::redirects();
			$map[ $path ] = array( 'to' => (int) $keep, 'from_id' => (int) $drop, 't' => time() );
			update_option( self::REDIRECTS, $map, true );
		}
		wp_update_post( array( 'ID' => $drop, 'post_status' => 'draft' ) );
		update_post_meta( $drop, '_aaw_merged_into', (int) $keep );
		$links = $fix_links ? self::replace_links( $old_url, $new_url, array( $keep, $drop ) ) : 0;
		return array( 'path' => $path, 'links' => $links );
	}

	public static function replace_links( $old_url, $new_url, array $skip = array() ) {
		global $wpdb;
		$variants = array_unique( array( $old_url, rawurldecode( $old_url ), untrailingslashit( $old_url ), untrailingslashit( rawurldecode( $old_url ) ) ) );
		$like     = array();
		foreach ( $variants as $v ) {
			$like[] = $wpdb->prepare( 'post_content LIKE %s', '%' . $wpdb->esc_like( $v ) . '%' );
		}
		$ids = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_status IN ('publish','draft','future','pending') AND post_type IN ('post','page','product') AND (" . implode( ' OR ', $like ) . ') LIMIT 300' ); // phpcs:ignore
		$n   = 0;
		foreach ( (array) $ids as $id ) {
			$id = (int) $id;
			if ( in_array( $id, array_map( 'intval', $skip ), true ) ) {
				continue;
			}
			$p = get_post( $id );
			if ( ! $p ) {
				continue;
			}
			$c = $p->post_content;
			foreach ( $variants as $v ) {
				// Only inside href="…" so visible text is never changed by accident.
				$c = preg_replace_callback( '~(href=["\'])' . preg_quote( $v, '~' ) . '/?(["\'#?])~u', function ( $m ) use ( $new_url ) { return $m[1] . $new_url . $m[2]; }, $c );
			}
			if ( $c !== $p->post_content ) {
				wp_update_post( array( 'ID' => $id, 'post_content' => $c ) );
				$n++;
			}
		}
		return $n;
	}

	/* ------------------------------------------------------------ undo */

	public static function undo( $drop ) {
		$drop = absint( $drop );
		$h    = get_option( self::HISTORY, array() );
		foreach ( (array) $h as $i => $m ) {
			if ( (int) $m['drop'] !== $drop || ! empty( $m['undone'] ) ) {
				continue;
			}
			$map = self::redirects();
			unset( $map[ $m['from'] ] );
			update_option( self::REDIRECTS, $map, true );
			wp_update_post( array( 'ID' => $drop, 'post_status' => $m['backup']['drop_status'] ? $m['backup']['drop_status'] : 'publish' ) );
			delete_post_meta( $drop, '_aaw_merged_into' );
			wp_update_post( array( 'ID' => (int) $m['keep'], 'post_content' => $m['backup']['content'], 'post_title' => $m['backup']['title'], 'post_excerpt' => $m['backup']['excerpt'] ) );
			$h[ $i ]['undone'] = time();
			update_option( self::HISTORY, $h, false );
			delete_transient( 'aaw_merge_candidates' );
			AAW_Dedupe::flush();
			AAW_Logs::add( 'info', 'revise', 'ادغام «' . $m['drop_title'] . '» بازگردانی شد (ریدایرکت حذف و هر دو مقاله به حالت قبل برگشتند؛ لینک‌های داخلی اصلاح‌شده تغییر نکردند).' );
			return true;
		}
		return new WP_Error( 'aaw', 'ادغامی برای بازگردانی پیدا نشد.' );
	}

	public static function history() {
		$h = get_option( self::HISTORY, array() );
		return array_reverse( is_array( $h ) ? $h : array() );
	}

	private static function history_by_drop() {
		$o = array();
		foreach ( self::history() as $m ) {
			if ( empty( $m['undone'] ) ) {
				$o[ (int) $m['drop'] ] = $m;
			}
		}
		return $o;
	}

	/* ------------------------------------------------------------ redirects */

	public static function redirects() {
		$m = get_option( self::REDIRECTS, array() );
		return is_array( $m ) ? $m : array();
	}

	public static function path( $url ) {
		$p = '/' . trim( strtolower( rawurldecode( (string) wp_parse_url( (string) $url, PHP_URL_PATH ) ) ), '/' );
		// Plain permalinks (?p=123): key on the id, never on "/" (that would redirect the home page).
		parse_str( (string) wp_parse_url( (string) $url, PHP_URL_QUERY ), $q );
		foreach ( array( 'p', 'page_id' ) as $k ) {
			if ( ! empty( $q[ $k ] ) ) {
				return $p . '?' . $k . '=' . absint( $q[ $k ] );
			}
		}
		return $p;
	}

	/** template_redirect: 301 from a merged (retired) article to the article it was merged into. */
	public static function maybe_redirect() {
		$map = self::redirects();
		if ( ! $map || is_admin() ) {
			return;
		}
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore
		$path = self::path( $uri );
		if ( ! isset( $map[ $path ] ) ) {
			return;
		}
		$to = get_permalink( (int) $map[ $path ]['to'] );
		if ( $to && 'publish' === get_post_status( (int) $map[ $path ]['to'] ) && self::path( $to ) !== $path ) {
			wp_safe_redirect( $to, 301, 'ARIAGH.AIWRITER' );
			exit;
		}
	}
}
