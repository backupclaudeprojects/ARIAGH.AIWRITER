<?php
/**
 * Admin screens.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Admin {

	private static $instance = null;
	private $hook            = '';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_init', array( $this, 'redirect_after_activation' ) );
		add_action( 'admin_notices', array( $this, 'notices' ) );
		add_action( 'add_meta_boxes', array( $this, 'meta_box' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'editor_assets' ) );
	}

	/* ---------------- Post editor: "AI editor" meta box ---------------- */

	public function meta_box() {
		$types = array_unique( array( 'post', (string) AAW_Settings::get( 'post_type' ) ) );
		foreach ( $types as $t ) {
			if ( post_type_exists( $t ) ) {
				add_meta_box( 'aaw-ai-editor', 'ARIAGH.AIWRITER – اصلاح با هوش مصنوعی', array( $this, 'render_meta_box' ), $t, 'side', 'high' );
			}
		}
	}

	public function render_meta_box( $post ) {
		$state = AAW_Revise::state( $post->ID );
		$hist  = array_reverse( array_filter( (array) get_post_meta( $post->ID, AAW_Revise::META_HISTORY, true ) ) );
		$labels = array( 'revising' => 'در حال اصلاح…', 'revised' => 'اصلاح شد', 'revision_ready' => 'نسخه اصلاح‌شده آماده انتشار است', 'imaging' => 'در حال ساخت تصویر…', 'image_ready' => 'تصویر جدید ثبت شد', 'error' => 'خطا' );
		echo '<div class="aaw-mb" data-aaw-mb="' . esc_attr( $post->ID ) . '">';
		if ( ! empty( $state['state'] ) && isset( $labels[ $state['state'] ] ) ) {
			echo '<p class="aaw-mb-state is-' . esc_attr( $state['state'] ) . '"><b>' . esc_html( $labels[ $state['state'] ] ) . '</b>' . ( 'error' === $state['state'] && ! empty( $state['note'] ) ? '<br><small>' . esc_html( strtok( (string) $state['note'], "\n" ) ) . '</small>' : '' ) . '</p>';
		}
		if ( get_post_meta( $post->ID, '_aaw_revision_pending', true ) ) {
			echo '<p><button type="button" class="button button-primary" data-aaw-mb-op="publish_rev">انتشار اصلاحات روی نوشته</button></p>';
		}
		echo '<p><label for="aaw-mb-text"><b>دستور اصلاح برای هوش مصنوعی</b></label><textarea id="aaw-mb-text" rows="5" style="width:100%" placeholder="مثلاً: لحن صمیمی‌تر، یک جدول مقایسه اضافه کن، به محصول X لینک بده…"></textarea></p>';
		echo '<p><button type="button" class="button" data-aaw-mb-op="revise">ارسال برای اصلاح</button></p>';
		echo '<hr><p><label for="aaw-mb-img"><b>فقط تصویر جدید</b> <small>(متن تغییر نمی‌کند)</small></label><textarea id="aaw-mb-img" rows="3" style="width:100%" placeholder="تصویر چطور باشد؟">' . esc_textarea( (string) get_post_meta( $post->ID, '_aaw_image_prompt', true ) ) . '</textarea></p>';
		echo '<p><label><input type="checkbox" id="aaw-mb-inline"> تصاویر داخل متن هم</label></p>';
		echo '<p><button type="button" class="button" data-aaw-mb-op="image">ساخت تصویر جدید</button></p>';
		echo '<p class="aaw-mb-msg" style="color:#1D4ED8"></p>';
		if ( $hist ) {
			echo '<details><summary>تاریخچه اصلاحات (' . esc_html( number_format_i18n( count( $hist ) ) ) . ')</summary><ul style="margin:6px 0 0">';
			foreach ( array_slice( $hist, 0, 8 ) as $h ) {
				echo '<li style="margin-bottom:6px"><small>' . esc_html( wp_date( 'Y/m/d H:i', (int) ( $h['t'] ?? 0 ) ) ) . ' · ' . esc_html( 'done' === ( $h['status'] ?? '' ) ? 'انجام شد' : 'در انتظار' ) . '</small><br>' . esc_html( mb_substr( (string) ( $h['text'] ?? '' ), 0, 140 ) ) . '</li>';
			}
			echo '</ul></details>';
		}
		echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=aaw&tab=activity' ) ) . '">مشاهده پیشرفت در «فعالیت زنده»</a></p></div>';
	}

	public function editor_assets( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}
		wp_enqueue_script( 'aaw-editor', AAW_URL . 'assets/js/editor.js', array( 'jquery' ), AAW_VERSION, true );
		wp_localize_script( 'aaw-editor', 'AAW_ED', array( 'ajax' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'aaw_admin' ) ) );
	}

	public static function tabs() {
		return array(
			'text_ai'    => array( 'هوش مصنوعی تولید محتوا', 'content', 'اصلی' ),
			'image_ai'   => array( 'هوش مصنوعی تولید تصویر', 'image', 'اصلی' ),
			'dashboard'  => array( 'داشبورد', 'dashboard', 'نمای کلی' ),
			'review'     => array( 'صف بازبینی', 'review', 'نمای کلی' ),
			'strategy'   => array( 'تحلیل هوشمند سایت', 'wand', 'نمای کلی' ),
			'timeline'   => array( 'خط زمانی', 'calendar', 'نمای کلی' ),
			'activity'   => array( 'فعالیت زنده', 'activity', 'نمای کلی' ),
			'topics'     => array( 'موضوعات', 'list', 'محتوا' ),
			'prompt'     => array( 'پرامپت', 'prompt', 'محتوا' ),
			'content'    => array( 'ساختار محتوا', 'content', 'محتوا' ),
			'seo'        => array( 'سئو و انتشار', 'seo', 'محتوا' ),
			'images'     => array( 'تنظیمات تصاویر', 'image', 'محتوا' ),
			'knowledge'  => array( 'دانش سئو', 'book', 'محتوا' ),
			'gsc'        => array( 'سرچ کنسول و ادغام مقالات', 'trending', 'محتوا' ),
			'ai'         => array( 'کلیدهای API و مدل‌ها', 'key', 'زیرساخت' ),
			'subscription' => array( 'اکانت اشتراکی', 'user', 'زیرساخت' ),
			'engines'    => array( 'موتور هوش مصنوعی روی سرور', 'cpu', 'زیرساخت' ),
			'schedule'   => array( 'زمان‌بندی', 'clock', 'زیرساخت' ),
			'cloudflare' => array( 'کلادفلر', 'cloud', 'زیرساخت' ),
			'notify'     => array( 'اعلان‌ها', 'bell', 'سیستم' ),
			'logs'       => array( 'گزارش‌ها', 'activity', 'سیستم' ),
			'tools'      => array( 'ابزارها', 'wrench', 'سیستم' ),
			'features'   => array( 'قابلیت‌ها', 'layers', 'سیستم' ),
			'license'    => array( 'لایسنس و حساب', 'key', 'حساب کاربری' ),
		);
	}

	public function menu() {
		$cap        = current_user_can( AAW_CAP ) ? AAW_CAP : 'manage_options';
		$count      = AAW_Plugin::pending_review_count();
		$bubble     = $count ? ' <span class="awaiting-mod">' . number_format_i18n( $count ) . '</span>' : '';
		$icon       = 'data:image/svg+xml;base64,' . base64_encode( (string) file_get_contents( AAW_DIR . 'assets/img/menu-icon.svg' ) ); // phpcs:ignore
		$this->hook = add_menu_page( 'ARIAGH.AIWRITER', 'AIWRITER' . $bubble, $cap, 'aaw', array( $this, 'render' ), $icon, 26 );
		foreach ( self::tabs() as $slug => $t ) {
			add_submenu_page( 'aaw', $t[0], $t[0], $cap, 'dashboard' === $slug ? 'aaw' : 'aaw&tab=' . $slug, 'dashboard' === $slug ? array( $this, 'render' ) : '__return_null' );
		}
	}

	public function assets( $hook ) {
		if ( $hook !== $this->hook ) {
			return;
		}
		if ( AAW_Settings::get( 'load_font' ) ) {
			wp_enqueue_style( 'aaw-font', 'https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&display=swap', array(), null );
		}
		wp_enqueue_style( 'aaw-admin', AAW_URL . 'assets/css/admin.css', array(), AAW_VERSION );
		wp_enqueue_script( 'jquery-ui-sortable' );
		if ( in_array( $this->current_tab(), array( 'images', 'image_ai' ), true ) ) {
			wp_enqueue_media(); // Media Library picker for theme samples.
		}
		wp_enqueue_script( 'aaw-admin', AAW_URL . 'assets/js/admin.js', array( 'jquery', 'jquery-ui-sortable' ), AAW_VERSION, true );

		$providers = array();
		$meta      = AAW_Settings::key_meta();
		foreach ( AAW_Providers::all() as $id => $p ) {
			$providers[ $id ] = array(
				'id'       => $id,
				'name'     => $p['name'],
				'models'   => $p['models'],
				'default'  => $p['default_model'],
				'model'    => AAW_Providers::model_for( $id ),
				'hasKey'   => isset( $meta[ $id ] ) || ! $p['requires_key'],
				'mask'     => isset( $meta[ $id ] ) ? $meta[ $id ]['mask'] : '',
				'custom'   => ! empty( $p['custom'] ),
				'base_url' => $p['base_url'],
				'format'   => $p['format'],
				'raw'      => ! empty( $p['custom'] ) ? $p : null,
			);
		}

		$icons = array();
		foreach ( array( 'check', 'check-circle', 'x', 'trash', 'grip', 'edit', 'copy', 'play', 'refresh', 'eye', 'external', 'chevrons-up', 'chevrons-down', 'alert', 'info', 'loader', 'sparkles', 'plus', 'calendar', 'undo', 'image', 'hash', 'folder', 'clock', 'cpu', 'key', 'more', 'send', 'target', 'x-circle', 'pause', 'review', 'inbox', 'download', 'content', 'search', 'wand', 'trending', 'globe', 'layers', 'zap', 'server', 'user', 'book', 'lock', 'link', 'seo', 'database', 'list', 'settings' ) as $i ) {
			$icons[ $i ] = AAW_Icons::get( $i, 16 );
		}

		wp_localize_script(
			'aaw-admin',
			'AAW',
			array(
				'ajax'       => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'aaw_admin' ),
				'tab'        => $this->current_tab(),
				'providers'  => $providers,
				'active'     => AAW_Settings::get( 'provider' ),
				'deployed'   => AAW_Cloudflare::is_deployed(),
				'pull'       => AAW_Pull::active(),
				'local'      => AAW_Pull::site_is_local(),
				'workerUrl'  => AAW_Settings::get( 'worker_url' ),
				'workerStream' => AAW_Settings::get( 'deployed_version' ) === AAW_VERSION,
				'bg'         => AAW_BG::available(),
				'pendingJobs' => count( (array) get_option( AAW_Pull::PENDING, array() ) ),
				'icons'      => $icons,
				'categories' => array_map(
					function ( $c ) {
						return array( 'id' => $c->term_id, 'name' => $c->name );
					},
					get_categories( array( 'hide_empty' => false ) )
				),
				'tones'      => AAW_Prompt::tones(),
				'presets'    => AAW_Prompt::presets(),
				'nextRun'    => AAW_Cloudflare::next_run_ts(),
				'now'        => time(),
			)
		);
	}

	public function current_tab() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard'; // phpcs:ignore
		return array_key_exists( $tab, self::tabs() ) ? $tab : 'dashboard';
	}

	public function redirect_after_activation() {
		if ( get_option( 'aaw_activated_redirect' ) ) {
			delete_option( 'aaw_activated_redirect' );
			if ( ! isset( $_GET['activate-multi'] ) && current_user_can( 'manage_options' ) ) { // phpcs:ignore
				wp_safe_redirect( admin_url( 'admin.php?page=aaw&tab=cloudflare' ) );
				exit;
			}
		}
	}

	public function notices() {
		$screen = get_current_screen();
		if ( ! $screen || $screen->id !== $this->hook ) {
			return;
		}
		// Worker code pasted manually in the Cloudflare dashboard? (health reports the code version)
		if ( AAW_Cloudflare::is_deployed() && AAW_Settings::get( 'deployed_version' ) !== AAW_VERSION ) {
			$caps = AAW_Cloudflare::caps();
			if ( ! empty( $caps['code'] ) && AAW_VERSION === $caps['code'] ) {
				AAW_Settings::update( array( 'deployed_version' => AAW_VERSION ) );
				delete_option( 'aaw_autodeploy_error' );
			}
		}
		// Keep the worker in sync with the plugin: redeploy automatically once per new version.
		if ( AAW_Cloudflare::is_deployed() && AAW_Cloudflare::is_configured() && AAW_Settings::get( 'deployed_version' ) !== AAW_VERSION && get_option( 'aaw_autodeploy' ) !== AAW_VERSION ) {
			update_option( 'aaw_autodeploy', AAW_VERSION, false );
			$r = AAW_Cloudflare::deploy();
			if ( is_wp_error( $r ) ) {
				update_option( 'aaw_autodeploy_error', $r->get_error_message(), false );
				AAW_Logs::add( 'error', 'deploy', 'به‌روزرسانی خودکار ورکر ناموفق بود: ' . $r->get_error_message() );
			} else {
				delete_option( 'aaw_autodeploy_error' );
				AAW_Logs::add( 'success', 'deploy', 'ورکر کلادفلر به‌صورت خودکار به نسخه ' . AAW_VERSION . ' به‌روز شد.' );
				echo '<div class="notice notice-success is-dismissible"><p>ورکر کلادفلر به‌صورت خودکار به نسخه ' . esc_html( AAW_VERSION ) . ' به‌روز شد.</p></div>';
			}
		}
		if ( AAW_Cloudflare::is_deployed() && AAW_Settings::get( 'deployed_version' ) !== AAW_VERSION ) {
			if ( get_option( 'aaw_autodeploy_error' ) ) {
				// Slow host could not upload the new worker: one-time manual update from the admin's own computer.
				echo '<div class="notice notice-warning"><p><b>ورکر کلادفلر باید یک‌بار دستی به‌روز شود.</b> هاست نتوانست کد جدید ورکر را بفرستد (اینترنت بین‌المللی هاست کند/محدود است). از کامپیوتر خودتان این کار را بکنید (۱ دقیقه):</p><ol>'
					. '<li><a href="' . esc_url( AAW_URL . 'worker/worker.js' ) . '" download>فایل worker.js را دانلود کنید</a>.</li>'
					. '<li>در <a href="https://dash.cloudflare.com/?to=/:account/workers-and-pages" target="_blank" rel="noopener">داشبورد کلادفلر → Workers &amp; Pages</a> روی ورکر «' . esc_html( AAW_Cloudflare::script() ) . '» و سپس «Edit code» بزنید.</li>'
					. '<li>همه کد را پاک و محتوای فایل دانلودشده را جای‌گذاری کنید و «Deploy» را بزنید. (کلیدها و تنظیمات ورکر سر جایشان می‌مانند.)</li>'
					. '<li>این صفحه را تازه کنید؛ افزونه نسخه جدید را خودش تشخیص می‌دهد.</li></ol>'
					. '<p>از این نسخه به بعد به‌روزرسانی‌های ورکر از طریق خود کلادفلر ارسال می‌شود و این کار دستی تکرار نمی‌شود. یا دوباره «استقرار مجدد» را در تب کلادفلر امتحان کنید.</p></div>';
			} else {
				echo '<div class="notice notice-warning"><p>نسخه ورکر کلادفلر قدیمی است. از تب کلادفلر «استقرار مجدد» را بزنید.</p></div>';
			}
		}
	}

	public function render() {
		$tab   = $this->current_tab();
		$tabs  = self::tabs();
		$s     = AAW_Settings::all();
		$group = '';
		?>
		<div class="aaw-app" dir="rtl" data-tab="<?php echo esc_attr( $tab ); ?>">
			<header class="aaw-top">
				<a class="aaw-brand" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw' ) ); ?>">
					<img class="aaw-wordmark" src="<?php echo esc_url( AAW_URL . 'assets/img/logo.svg' ); ?>" alt="ARIAGH.AIWRITER" width="210" height="34">
					<small>نویسنده هوشمند مقالات سئو · نسخه <?php echo esc_html( AAW_VERSION ); ?></small>
				</a>
				<div class="aaw-top-status">
					<span class="aaw-chip <?php echo AAW_Cloudflare::is_deployed() ? 'is-ok' : 'is-warn'; ?>"><?php AAW_Icons::e( 'cloud', 15 ); ?> <?php echo AAW_Cloudflare::is_deployed() ? 'ورکر فعال' : 'ورکر مستقر نشده'; ?></span>
					<?php $lic = AAW_License::state(); $running = AAW_Activity::running_count(); ?>
					<a class="aaw-chip <?php echo $running ? 'is-info aaw-live' : ''; ?>" id="aaw-live-chip" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=activity' ) ); ?>"><?php AAW_Icons::e( 'activity', 15 ); ?> <span data-live-count><?php echo $running ? esc_html( number_format_i18n( $running ) ) . ' در حال انجام' : 'فعالیت زنده'; ?></span></a>
					<a class="aaw-chip <?php echo 'active' === $lic['status'] ? 'is-ok' : ( 'trial' === $lic['status'] ? 'is-info' : 'is-bad' ); ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=license' ) ); ?>"><?php AAW_Icons::e( 'key', 15 ); ?> <?php echo esc_html( $lic['label'] ); ?></a>
					<span class="aaw-chip <?php echo $s['paused'] ? 'is-warn' : 'is-info'; ?>" id="aaw-next-chip"><?php AAW_Icons::e( 'clock', 15 ); ?> <span data-countdown="<?php echo esc_attr( AAW_Cloudflare::next_run_ts() ); ?>"><?php echo $s['paused'] ? 'متوقف' : '—'; ?></span></span>
					<button type="button" class="aaw-btn aaw-btn-primary" data-action="run-now"><?php AAW_Icons::e( 'play', 16 ); ?> تولید فوری مقاله</button>
				</div>
			</header>
			<div class="aaw-shell">
				<nav class="aaw-nav" aria-label="بخش‌ها">
					<div class="aaw-nav-main">
						<?php foreach ( array( 'text_ai' => 'text', 'image_ai' => 'image' ) as $slug => $k ) : ?>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=' . $slug ) ); ?>" class="aaw-nav-tile <?php echo $slug === $tab ? 'is-active' : ''; ?>">
								<span class="aaw-nav-tile-ic"><?php AAW_Icons::e( $tabs[ $slug ][1], 20 ); ?></span>
								<span class="aaw-nav-tile-txt"><b><?php echo esc_html( $tabs[ $slug ][0] ); ?></b><small data-prio-label="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( AAW_Priority::first_label( $k ) ); ?></small></span>
							</a>
						<?php endforeach; ?>
					</div>
					<div class="aaw-nav-minor">
					<?php foreach ( $tabs as $slug => $t ) : if ( 'اصلی' === $t[2] ) { continue; } ?>
						<?php if ( $group !== $t[2] ) : $group = $t[2]; ?>
							<div class="aaw-nav-group"><?php echo esc_html( $group ); ?></div>
						<?php endif; ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=aaw' . ( 'dashboard' === $slug ? '' : '&tab=' . $slug ) ) ); ?>" class="<?php echo $slug === $tab ? 'is-active' : ''; ?>">
							<?php AAW_Icons::e( $t[1], 18 ); ?>
							<span><?php echo esc_html( $t[0] ); ?></span>
							<?php if ( 'review' === $slug && AAW_Plugin::pending_review_count() ) : ?>
								<em class="aaw-count"><?php echo esc_html( number_format_i18n( AAW_Plugin::pending_review_count() ) ); ?></em>
							<?php endif; ?>
						</a>
					<?php endforeach; ?>
					</div>
					<div class="aaw-nav-foot">
						<kbd>Ctrl</kbd> + <kbd>S</kbd> ذخیره سریع
					</div>
				</nav>
				<main class="aaw-main">
					<?php if ( 'license' !== $tab && ! in_array( $lic['status'], array( 'active', 'trial' ), true ) ) : ?>
						<div class="aaw-license-bar is-bad"><?php AAW_Icons::e( 'lock', 18 ); ?><div><b><?php echo esc_html( $lic['label'] ); ?>.</b> <?php echo esc_html( $lic['message'] ); ?></div><a class="aaw-btn aaw-btn-sm aaw-btn-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=license' ) ); ?>">فعال‌سازی لایسنس</a></div>
					<?php elseif ( 'license' !== $tab && 'trial' === $lic['status'] ) : ?>
						<div class="aaw-license-bar"><?php AAW_Icons::e( 'sparkles', 18 ); ?><div><b>نسخه آزمایشی.</b> <?php echo esc_html( $lic['message'] ); ?></div><a class="aaw-btn aaw-btn-sm aaw-btn-ghost" href="<?php echo esc_url( admin_url( 'admin.php?page=aaw&tab=license' ) ); ?>">خرید و فعال‌سازی</a></div>
					<?php endif; ?>
					<?php
					$file = AAW_DIR . 'admin/views/' . $tab . '.php';
					if ( file_exists( $file ) ) {
						include $file;
					}
					?>
				</main>
			</div>
			<div class="aaw-toasts" aria-live="polite"></div>
			<div class="aaw-modal" hidden>
				<div class="aaw-modal-backdrop" data-close></div>
				<div class="aaw-modal-box" role="dialog" aria-modal="true">
					<div class="aaw-modal-head"><h3></h3><button type="button" class="aaw-icon-btn" data-close aria-label="بستن"><?php AAW_Icons::e( 'x', 18 ); ?></button></div>
					<div class="aaw-modal-body"></div>
					<div class="aaw-modal-foot"></div>
				</div>
			</div>
		</div>
		<?php
	}

	/* ================= Field helpers used by views ================= */

	/** Sortable priority list used by the two main AI tabs. */
	public static function prio_list( $kind, array $items ) {
		$main = array_values( array_filter( $items, function ( $it ) { return ! empty( $it['on'] ) || ! empty( $it['ready'] ); } ) );
		$rest = array_values( array_filter( $items, function ( $it ) { return empty( $it['on'] ) && empty( $it['ready'] ); } ) );
		self::prio_items( $kind, $main, 'data-prio="' . esc_attr( $kind ) . '"' );
		if ( $rest ) {
			echo '<details class="aaw-prio-more"><summary>' . esc_html( sprintf( '%s هوش مصنوعی دیگر (هنوز وصل نشده‌اند)', number_format_i18n( count( $rest ) ) ) ) . '</summary>';
			self::prio_items( $kind, $rest, 'data-prio-rest' );
			echo '<p class="aaw-muted">بعد از ثبت کلید یا اتصال، هر کدام به لیست بالا اضافه می‌شود و می‌توانید روشنش کنید.</p></details>';
		}
	}

	private static function prio_items( $kind, array $items, $attr ) {
		$kinds = array( 'sub' => 'اکانت اشتراکی', 'free' => 'رایگان', 'api' => 'API', 'custom' => 'شخصی' );
		echo '<ol class="aaw-prio" ' . $attr . '>'; // phpcs:ignore
		$rank = 0;
		foreach ( $items as $it ) {
			$on    = ! empty( $it['on'] );
			$rank += $on ? 1 : 0;
			$badge = mb_strtoupper( mb_substr( preg_replace( '/[^A-Za-z]/', '', $it['name'] ) ?: $it['name'], 0, 2 ) );
			echo '<li class="aaw-prio-item ' . ( $on ? 'is-on' : 'is-off' ) . ' ' . ( $it['ready'] ? 'is-ready' : 'not-ready' ) . '" data-id="' . esc_attr( $it['id'] ) . '" data-ready="' . ( $it['ready'] ? '1' : '0' ) . '" data-name="' . esc_attr( $it['name'] ) . '">';
			echo '<span class="aaw-prio-grip" title="برای تغییر اولویت بکشید">' . AAW_Icons::get( 'grip', 16 ) . '</span>'; // phpcs:ignore
			echo '<span class="aaw-prio-rank">' . ( $on ? esc_html( number_format_i18n( $rank ) ) : '–' ) . '</span>';
			echo '<span class="aaw-mono-badge" style="--c:' . esc_attr( $it['color'] ) . '">' . esc_html( $badge ) . '</span>';
			echo '<div class="aaw-prio-main"><b>' . esc_html( $it['name'] ) . '</b> <em class="aaw-kind k-' . esc_attr( $it['kind'] ) . '">' . esc_html( $kinds[ $it['kind'] ] ?? $it['kind'] ) . '</em>';
			if ( isset( $it['refs'] ) ) {
				echo ' <em class="aaw-kind">' . ( $it['refs'] ? esc_html( 'تا ' . number_format_i18n( $it['refs'] ) . ' مرجع' ) : 'بدون مرجع' ) . '</em>';
			}
			echo '<small class="' . ( $it['ready'] ? 'is-ok' : 'is-warn' ) . '">' . AAW_Icons::get( $it['ready'] ? 'check-circle' : 'alert', 13 ) . ' ' . esc_html( $it['note'] ) . '</small></div>'; // phpcs:ignore
			echo '<div class="aaw-prio-model">';
			if ( ! empty( $it['models'] ) || '' !== (string) $it['model'] ) {
				$dl = 'aaw-dl-' . $kind . '-' . $it['id'];
				echo '<input class="aaw-input" dir="ltr" list="' . esc_attr( $dl ) . '" data-prio-model value="' . esc_attr( $it['model'] ) . '" placeholder="مدل" title="مدل"><datalist id="' . esc_attr( $dl ) . '">';
				foreach ( (array) $it['models'] as $m ) {
					echo '<option value="' . esc_attr( $m ) . '"></option>';
				}
				echo '</datalist>';
			}
			echo '</div><div class="aaw-prio-actions">';
			if ( $it['ready'] && ( 'text' === $kind || 'sub_codex' !== $it['id'] ) ) {
				echo '<button type="button" class="aaw-icon-btn" data-action="prio-test" title="تست">' . AAW_Icons::get( 'zap', 16 ) . '</button>'; // phpcs:ignore
			}
			if ( ! $it['ready'] ) {
				$link = $it['link'] ? $it['link'] : admin_url( 'admin.php?page=aaw&tab=' . ( 'image' === $kind ? 'image_ai#aaw-img-keys' : 'ai' ) );
				echo '<a class="aaw-btn aaw-btn-sm aaw-btn-ghost" href="' . esc_url( $link ) . '">' . AAW_Icons::get( 'key', 14 ) . ' اتصال</a>'; // phpcs:ignore
			}
			echo '<label class="aaw-switch" title="روشن/خاموش"><input type="checkbox" data-prio-on ' . checked( $on, true, false ) . '><span></span></label>';
			echo '</div></li>';
		}
		echo '</ol>';
	}


	public static function head( $title, $desc = '', $icon = '', $actions = '' ) {
		echo '<div class="aaw-page-head"><div>';
		echo '<h1>' . ( $icon ? AAW_Icons::get( $icon, 22 ) : '' ) . esc_html( $title ) . '</h1>'; // phpcs:ignore
		if ( $desc ) {
			echo '<p>' . esc_html( $desc ) . '</p>';
		}
		echo '</div>';
		if ( $actions ) {
			echo '<div class="aaw-page-actions">' . $actions . '</div>'; // phpcs:ignore
		}
		echo '</div>';
	}

	public static function card_open( $title = '', $desc = '', $icon = '', $extra_class = '' ) {
		echo '<section class="aaw-card ' . esc_attr( $extra_class ) . '">';
		if ( $title ) {
			echo '<div class="aaw-card-head"><div class="aaw-card-title">' . ( $icon ? '<span class="aaw-card-ic">' . AAW_Icons::get( $icon, 18 ) . '</span>' : '' ) . '<div><h2>' . esc_html( $title ) . '</h2>' . ( $desc ? '<p>' . esc_html( $desc ) . '</p>' : '' ) . '</div></div></div>'; // phpcs:ignore
		}
		echo '<div class="aaw-card-body">';
	}

	public static function card_close() {
		echo '</div></section>';
	}

	private static function row_open( $label, $help = '', $key = '' ) {
		echo '<div class="aaw-field" data-key="' . esc_attr( $key ) . '"><div class="aaw-field-label"><label for="aaw-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label>';
		if ( $help ) {
			echo '<small>' . esc_html( $help ) . '</small>';
		}
		echo '</div><div class="aaw-field-control">';
	}

	private static function row_close() {
		echo '</div></div>';
	}

	public static function toggle( $key, $label, $help = '' ) {
		$v = AAW_Settings::get( $key );
		self::row_open( $label, $help, $key );
		printf(
			'<label class="aaw-switch"><input type="checkbox" id="aaw-%1$s" name="%1$s" value="1" %2$s><span></span></label>',
			esc_attr( $key ),
			checked( (bool) $v, true, false )
		);
		self::row_close();
	}

	public static function number( $key, $label, $help = '', $min = null, $max = null, $step = 1, $suffix = '' ) {
		$v = AAW_Settings::get( $key );
		self::row_open( $label, $help, $key );
		printf(
			'<div class="aaw-input-group"><input class="aaw-input aaw-input-sm" type="number" id="aaw-%1$s" name="%1$s" value="%2$s" %3$s %4$s step="%5$s">%6$s</div>',
			esc_attr( $key ),
			esc_attr( $v ),
			null !== $min ? 'min="' . esc_attr( $min ) . '"' : '',
			null !== $max ? 'max="' . esc_attr( $max ) . '"' : '',
			esc_attr( $step ),
			$suffix ? '<span class="aaw-suffix">' . esc_html( $suffix ) . '</span>' : ''
		);
		self::row_close();
	}

	public static function text( $key, $label, $help = '', $placeholder = '', $type = 'text' ) {
		$v = AAW_Settings::get( $key );
		if ( is_array( $v ) ) {
			$v = implode( ', ', $v );
		}
		self::row_open( $label, $help, $key );
		printf(
			'<input class="aaw-input" type="%4$s" id="aaw-%1$s" name="%1$s" value="%2$s" placeholder="%3$s" dir="auto">',
			esc_attr( $key ),
			esc_attr( $v ),
			esc_attr( $placeholder ),
			esc_attr( $type )
		);
		self::row_close();
	}

	public static function textarea( $key, $label, $help = '', $placeholder = '', $rows = 3 ) {
		$v = AAW_Settings::get( $key );
		if ( is_array( $v ) ) {
			$v = implode( "\n", $v );
		}
		self::row_open( $label, $help, $key );
		printf(
			'<textarea class="aaw-input" id="aaw-%1$s" name="%1$s" rows="%4$d" placeholder="%3$s" dir="auto">%2$s</textarea>',
			esc_attr( $key ),
			esc_textarea( $v ),
			esc_attr( $placeholder ),
			(int) $rows
		);
		self::row_close();
	}

	public static function select( $key, $label, array $choices, $help = '' ) {
		$v = AAW_Settings::get( $key );
		self::row_open( $label, $help, $key );
		echo '<div class="aaw-select-wrap"><select class="aaw-input" id="aaw-' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">';
		foreach ( $choices as $val => $text ) {
			printf( '<option value="%s" %s>%s</option>', esc_attr( $val ), selected( (string) $v, (string) $val, false ), esc_html( $text ) );
		}
		echo '</select>' . AAW_Icons::get( 'chevron-down', 16, 'aaw-select-ic' ) . '</div>'; // phpcs:ignore
		self::row_close();
	}

	public static function segmented( $key, $label, array $choices, $help = '' ) {
		$v = (string) AAW_Settings::get( $key );
		self::row_open( $label, $help, $key );
		echo '<div class="aaw-seg" role="radiogroup">';
		foreach ( $choices as $val => $text ) {
			printf(
				'<label><input type="radio" name="%1$s" value="%2$s" %3$s><span>%4$s</span></label>',
				esc_attr( $key ),
				esc_attr( $val ),
				checked( $v, (string) $val, false ),
				esc_html( $text )
			);
		}
		echo '</div>';
		self::row_close();
	}

	public static function range( $key, $label, $min, $max, $step, $help = '' ) {
		$v = AAW_Settings::get( $key );
		self::row_open( $label, $help, $key );
		printf(
			'<div class="aaw-range"><input type="range" id="aaw-%1$s" name="%1$s" min="%2$s" max="%3$s" step="%4$s" value="%5$s"><output>%5$s</output></div>',
			esc_attr( $key ),
			esc_attr( $min ),
			esc_attr( $max ),
			esc_attr( $step ),
			esc_attr( $v )
		);
		self::row_close();
	}

	public static function save_bar( $label = 'ذخیره تنظیمات' ) {
		echo '<div class="aaw-savebar"><span class="aaw-dirty-note">' . AAW_Icons::get( 'info', 15 ) . ' تغییرات ذخیره‌نشده دارید</span><button type="submit" class="aaw-btn aaw-btn-primary">' . AAW_Icons::get( 'save', 16 ) . ' ' . esc_html( $label ) . '</button></div>'; // phpcs:ignore
	}

	public static function categories_choices( $none = 'بدون دسته پیش‌فرض' ) {
		$out = array( 0 => $none );
		foreach ( get_categories( array( 'hide_empty' => false ) ) as $c ) {
			$out[ $c->term_id ] = $c->name;
		}
		return $out;
	}
}
