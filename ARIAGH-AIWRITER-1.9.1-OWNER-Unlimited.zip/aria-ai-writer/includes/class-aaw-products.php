<?php
/**
 * Real product links inside articles (WooCommerce).
 * Finds the store products related to an article, hands their exact URLs/prices to
 * the AI with a strict "link these" instruction, and – as a safety net – adds a
 * product box if the AI still didn't link any of them.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Products {

	public static function enabled() {
		return AAW_Settings::get( 'product_links' ) && post_type_exists( 'product' );
	}

	/** @return array<int,array{id:int,name:string,url:string,price:string,stock:bool,desc:string}> */
	public static function related( $title, $keywords = '', $n = 0 ) {
		if ( ! self::enabled() ) {
			return array();
		}
		$n   = $n ? $n : max( 1, (int) AAW_Settings::get( 'product_links_count', 3 ) );
		$ids = array();
		foreach ( AAW_Dedupe::nearest( (string) $title, (string) $keywords, $n * 2, array( 'product' ) ) as $p ) {
			if ( 'publish' === $p['status'] && $p['score'] >= 0.15 ) {
				$ids[] = (int) $p['id'];
			}
		}
		if ( count( $ids ) < $n ) {
			// Fill with best sellers so every article can promote something real.
			$best = get_posts( array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => $n, 'fields' => 'ids', 'no_found_rows' => true, 'meta_key' => 'total_sales', 'orderby' => 'meta_value_num', 'order' => 'DESC' ) ); // phpcs:ignore
			$ids  = array_merge( $ids, (array) $best );
		}
		$out = array();
		foreach ( array_slice( array_values( array_unique( $ids ) ), 0, $n ) as $id ) {
			$out[] = self::details( $id );
		}
		$out = array_values( array_filter( $out ) );
		// In-stock products first (keep relevance order otherwise).
		$i = 0;
		foreach ( $out as &$o ) {
			$o['_o'] = ( $o['stock'] ? 0 : 1000 ) + $i++;
		}
		unset( $o );
		usort( $out, function ( $a, $b ) { return $a['_o'] <=> $b['_o']; } );
		foreach ( $out as &$o ) {
			unset( $o['_o'] );
		}
		unset( $o );
		return $out;
	}

	public static function details( $id ) {
		$price = '';
		$stock = true;
		$desc  = '';
		if ( function_exists( 'wc_get_product' ) ) {
			$p = wc_get_product( $id );
			if ( ! $p ) {
				return null;
			}
			$price = trim( html_entity_decode( wp_strip_all_tags( $p->get_price_html() ), ENT_QUOTES, 'UTF-8' ) );
			$stock = $p->is_in_stock();
			$desc  = wp_strip_all_tags( $p->get_short_description() );
		}
		return array(
			'id'    => (int) $id,
			'name'  => get_the_title( $id ),
			'url'   => get_permalink( $id ),
			'price' => $price,
			'stock' => (bool) $stock,
			'desc'  => function_exists( 'mb_substr' ) ? mb_substr( $desc, 0, 160 ) : substr( $desc, 0, 160 ),
		);
	}

	public static function prompt_block( $title, $keywords = '' ) {
		$list = self::related( $title, $keywords );
		if ( ! $list ) {
			return '';
		}
		$lines = array();
		foreach ( $list as $p ) {
			$lines[] = '- ' . $p['name'] . ' => ' . $p['url'] . ( $p['price'] ? ' | قیمت: ' . $p['price'] : '' ) . ( $p['stock'] ? '' : ' | (ناموجود – فقط معرفی، دعوت به خرید نکن)' ) . ( $p['desc'] ? ' | ' . $p['desc'] : '' );
		}
		return "\n## محصولات واقعی فروشگاه برای معرفی و لینک (اجباری)\nدر متن مقاله هر کدام از این محصولات را که با موضوع مرتبط است، حداقل یک بار با انکر تکست طبیعی و دقیقاً با همین آدرس لینک بده (<a href=\"آدرس\">نام یا مزیت محصول</a>). در بخش‌های مناسب مزیت واقعی محصول را برای حل مشکل خواننده توضیح بده و یک دعوت به اقدام (CTA) به سمت صفحه محصول بگذار؛ قیمتی غیر از قیمت داده‌شده ننویس و آدرس دیگری نساز:\n" . implode( "\n", $lines ) . "\n";
	}

	/** Safety net: add a product box when none of the product URLs ended up in the HTML. */
	public static function ensure_links( $html, $title, $keywords = '' ) {
		if ( ! self::enabled() || ! AAW_Settings::get( 'product_box' ) ) {
			return $html;
		}
		$list = self::related( $title, $keywords );
		if ( ! $list ) {
			return $html;
		}
		foreach ( $list as $p ) {
			if ( false !== strpos( $html, $p['url'] ) || false !== strpos( $html, rawurldecode( $p['url'] ) ) ) {
				return $html; // AI already linked a real product.
			}
		}
		$items = '';
		foreach ( $list as $p ) {
			if ( ! $p['stock'] ) {
				continue;
			}
			$items .= '<li><a href="' . esc_url( $p['url'] ) . '">' . esc_html( $p['name'] ) . '</a>' . ( $p['price'] ? ' <span class="aaw-price">' . esc_html( $p['price'] ) . '</span>' : '' ) . '</li>';
		}
		if ( '' === $items ) {
			return $html;
		}
		return $html . '<div class="aaw-products-cta"><h3>' . esc_html( AAW_Settings::get( 'product_box_title' ) ) . '</h3><ul>' . $items . '</ul></div>';
	}
}
