<?php
/**
 * Main plugin orchestrator.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Plugin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		AAW_Installer::maybe_upgrade();
		load_plugin_textdomain( 'aria-ai-writer', false, dirname( plugin_basename( AAW_FILE ) ) . '/languages' );

		add_action( 'rest_api_init', array( 'AAW_REST', 'register' ) );
		AAW_License::register_hooks();
		add_action( 'aaw_daily', array( $this, 'daily' ) );
		add_action( 'aaw_kv_sync', array( 'AAW_Cloudflare', 'sync_kv' ) );
		add_action( 'aaw_pull_tick', array( 'AAW_Pull', 'tick' ) );
		add_action( 'aaw_bg_poll', array( 'AAW_Pull', 'bg_poll' ) );
		add_action( 'aaw_image_retry', array( 'AAW_Revise', 'cron_image_retry' ), 10, 2 );
		add_action( 'template_redirect', array( 'AAW_Merge', 'maybe_redirect' ), 1 );
		add_action( 'save_post_post', array( 'AAW_Dedupe', 'flush' ) );
		add_action( 'save_post_product', array( 'AAW_Dedupe', 'flush' ) );
		add_action( 'deleted_post', array( 'AAW_Dedupe', 'flush' ) );
		if ( is_admin() || wp_doing_cron() ) {
			add_action( 'init', array( 'AAW_Pull', 'ensure_schedule' ) );
		}
		add_action( 'aaw_settings_updated', array( $this, 'on_settings_updated' ) );
		add_action( 'wp_head', array( $this, 'print_schema' ), 5 );
		add_action( 'wp_enqueue_scripts', array( $this, 'frontend_css' ) );

		// Posts list integration.
		add_filter( 'manage_posts_columns', array( $this, 'posts_column' ) );
		add_action( 'manage_posts_custom_column', array( $this, 'posts_column_value' ), 10, 2 );
		add_filter( 'post_row_actions', array( $this, 'row_actions' ), 10, 2 );
		add_filter( 'views_edit-post', array( $this, 'posts_view' ) );
		add_action( 'pre_get_posts', array( $this, 'filter_ai_posts' ) );
		add_action( 'admin_bar_menu', array( $this, 'admin_bar' ), 90 );
		add_action( 'wp_dashboard_setup', array( $this, 'dashboard_widget' ) );
		add_action( 'admin_post_aaw_approve', array( $this, 'approve_action' ) );
		add_action( 'aaw_local_tick', array( 'AAW_Local', 'tick' ) );
		add_action( 'admin_post_aaw_gsc_oauth', array( 'AAW_GSC', 'oauth_callback' ) );
		add_action( 'transition_post_status', array( $this, 'on_status_change' ), 10, 3 );
		add_filter( 'plugin_action_links_' . plugin_basename( AAW_FILE ), array( $this, 'action_links' ) );
		add_filter( 'plugin_row_meta', array( $this, 'row_meta' ), 10, 2 );

		if ( is_admin() ) {
			AAW_Admin::instance();
			AAW_Ajax::register();
		}
	}

	public function daily() {
		AAW_Logs::prune();
		AAW_Topics::release_stale();
		AAW_Knowledge::maybe_refresh();
		AAW_Cloudflare::sync_kv();
		AAW_Transfer::cleanup();
	}

	public function on_settings_updated( $settings ) {
		AAW_Installer::sync_editor_cap();
		if ( ! wp_next_scheduled( 'aaw_kv_sync' ) ) {
			wp_schedule_single_event( time() + 30, 'aaw_kv_sync' );
		}
	}

	public function print_schema() {
		if ( ! is_singular() ) {
			return;
		}
		$json = get_post_meta( get_queried_object_id(), '_aaw_schema', true );
		if ( ! $json ) {
			return;
		}
		$graphs = json_decode( $json, true );
		if ( ! is_array( $graphs ) ) {
			return;
		}
		$out = array(
			'@context' => 'https://schema.org',
			'@graph'   => $graphs,
		);
		echo "\n<script type=\"application/ld+json\" class=\"aaw-schema\">" . wp_json_encode( $out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ) . "</script>\n"; // phpcs:ignore
	}

	public function frontend_css() {
		if ( ! AAW_Settings::get( 'frontend_css' ) || ! is_singular() || ! get_post_meta( get_queried_object_id(), '_aaw_generated', true ) ) {
			return;
		}
		$accent = sanitize_hex_color( AAW_Settings::get( 'toc_accent', '#4f46e5' ) );
		$accent = $accent ? $accent : '#4f46e5';
		$css    = ".aaw-toc{border:1px solid #e5e7eb;border-radius:14px;padding:14px 18px;margin:22px 0;background:#fafafa}.aaw-toc summary{cursor:pointer;font-weight:700;color:{$accent}}.aaw-toc ol,.aaw-toc ul{margin:10px 0 0;padding-inline-start:22px}.aaw-toc a{text-decoration:none}.aaw-toc a:hover{color:{$accent}}.aaw-takeaways{border-inline-start:4px solid {$accent};background:#f5f7ff;border-radius:12px;padding:14px 18px;margin:20px 0}.aaw-takeaways h3{margin-top:0}.aaw-faq-item{border:1px solid #e5e7eb;border-radius:12px;padding:12px 16px;margin:10px 0}.aaw-faq-item summary{cursor:pointer;font-weight:600}.aaw-faq-answer{margin-top:8px}.aaw-products-cta{border:1px solid #e5e7eb;border-radius:14px;padding:14px 18px;margin:24px 0;background:#fafafa}.aaw-products-cta h3{margin-top:0}.aaw-products-cta ul{margin:0;padding-inline-start:20px}.aaw-products-cta .aaw-price{color:{$accent};font-weight:700;margin-inline-start:6px}";
		wp_register_style( 'aaw-front', false, array(), AAW_VERSION );
		wp_enqueue_style( 'aaw-front' );
		wp_add_inline_style( 'aaw-front', $css );
	}

	/* ---------------- Posts list ---------------- */

	public function posts_column( $cols ) {
		if ( AAW_Settings::get( 'posts_column' ) ) {
			$cols['aaw'] = 'هوش مصنوعی';
		}
		return $cols;
	}

	public function posts_column_value( $col, $post_id ) {
		if ( 'aaw' !== $col ) {
			return;
		}
		if ( get_post_meta( $post_id, '_aaw_generated', true ) ) {
			$model = get_post_meta( $post_id, '_aaw_model', true );
			$wc    = (int) get_post_meta( $post_id, '_aaw_word_count', true );
			echo '<span title="' . esc_attr( $model ) . '" style="display:inline-flex;align-items:center;gap:4px;color:#4f46e5">' . AAW_Icons::get( 'sparkles', 14 ) . ' ' . esc_html( number_format_i18n( $wc ) ) . ' کلمه</span>'; // phpcs:ignore
		} else {
			echo '<span style="color:#cbd5e1">—</span>';
		}
	}

	public function row_actions( $actions, $post ) {
		if ( get_post_meta( $post->ID, '_aaw_generated', true ) && in_array( $post->post_status, array( 'draft', 'pending' ), true ) && current_user_can( 'publish_post', $post->ID ) ) {
			$url                 = wp_nonce_url( admin_url( 'admin-post.php?action=aaw_approve&post=' . $post->ID ), 'aaw_approve_' . $post->ID );
			$actions['aaw_ok']   = '<a href="' . esc_url( $url ) . '" style="color:#059669">تایید و انتشار</a>';
		}
		return $actions;
	}

	public function approve_action() {
		$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
		check_admin_referer( 'aaw_approve_' . $post_id );
		if ( ! current_user_can( 'publish_post', $post_id ) ) {
			wp_die( 'دسترسی غیرمجاز' );
		}
		wp_publish_post( $post_id );
		AAW_Logs::add( 'success', 'approve', 'مقاله تایید و منتشر شد: ' . get_the_title( $post_id ), array( 'post_id' => $post_id ) );
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url( 'edit.php' ) );
		exit;
	}

	public function posts_view( $views ) {
		global $wpdb;
		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = '_aaw_generated' AND p.post_status NOT IN ('trash','auto-draft')" ); // phpcs:ignore
		if ( $count ) {
			$current      = isset( $_GET['aaw'] ) ? ' class="current"' : ''; // phpcs:ignore
			$views['aaw'] = '<a href="' . esc_url( admin_url( 'edit.php?aaw=1' ) ) . '"' . $current . '>تولید هوش مصنوعی <span class="count">(' . number_format_i18n( $count ) . ')</span></a>';
		}
		return $views;
	}

	public function filter_ai_posts( $q ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( is_admin() && $q->is_main_query() && isset( $_GET['aaw'] ) && $screen && 'edit' === $screen->base ) { // phpcs:ignore
			$q->set( 'meta_key', '_aaw_generated' );
		}
	}

	/** Cached (per request + 10 min transient) so admin pages never repeat the query. */
	public static function pending_review_count() {
		static $n = null;
		if ( null !== $n ) {
			return $n;
		}
		$c = get_transient( 'aaw_pending_review' );
		if ( false !== $c ) {
			$n = (int) $c;
			return $n;
		}
		global $wpdb;
		$n = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = '_aaw_generated' AND p.post_status IN ('draft','pending')" ); // phpcs:ignore
		set_transient( 'aaw_pending_review', $n, 10 * MINUTE_IN_SECONDS );
		return $n;
	}

	public function admin_bar( $bar ) {
		if ( ! AAW_Settings::get( 'admin_bar' ) || ! current_user_can( AAW_CAP ) ) {
			return;
		}
		$n = self::pending_review_count();
		$bar->add_node(
			array(
				'id'    => 'aaw',
				'title' => '<span class="ab-icon dashicons dashicons-edit-page" style="top:2px"></span><span class="ab-label">بازبینی مقالات ' . ( $n ? '(' . number_format_i18n( $n ) . ')' : '' ) . '</span>',
				'href'  => admin_url( 'admin.php?page=aaw&tab=review' ),
			)
		);
	}

	public function dashboard_widget() {
		if ( ! AAW_Settings::get( 'dashboard_widget' ) || ! current_user_can( AAW_CAP ) ) {
			return;
		}
		wp_add_dashboard_widget(
			'aaw_widget',
			'ARIAGH.AIWRITER',
			function () {
				$c     = AAW_Topics::counts();
				$n     = self::pending_review_count();
				$next  = AAW_Cloudflare::next_run_ts();
				echo '<p>در انتظار بازبینی: <strong>' . esc_html( number_format_i18n( $n ) ) . '</strong> مقاله</p>';
				echo '<p>موضوعات در صف: <strong>' . esc_html( number_format_i18n( $c['pending'] ) ) . '</strong> | تولیدشده: <strong>' . esc_html( number_format_i18n( $c['done'] ) ) . '</strong></p>';
				echo '<p>اجرای بعدی: <strong>' . ( $next ? esc_html( wp_date( 'Y/m/d H:i', $next ) ) : '—' ) . '</strong></p>';
				echo '<p><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=aaw&tab=review' ) ) . '">صف بازبینی</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=aaw&tab=topics' ) ) . '">موضوعات</a></p>';
			}
		);
	}

	public function on_status_change( $new, $old, $post ) {
		if ( $new !== $old && 'post' === $post->post_type ) {
			delete_transient( 'aaw_pending_review' );
		}
		if ( 'publish' === $new && 'publish' !== $old && get_post_meta( $post->ID, '_aaw_generated', true ) ) {
			update_post_meta( $post->ID, '_aaw_approved_at', time() );
		}
	}

	public function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=aaw' ) ) . '">داشبورد</a>' );
		if ( ! AAW_License::is_active() ) {
			$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=aaw&tab=license' ) ) . '" style="color:#1D4ED8;font-weight:600">فعال‌سازی لایسنس</a>';
		}
		return $links;
	}

	public function row_meta( $links, $file ) {
		if ( plugin_basename( AAW_FILE ) !== $file ) {
			return $links;
		}
		$map = array( 'docs_url' => 'راهنما', 'support_url' => 'پشتیبانی', 'account_url' => 'حساب کاربری' );
		foreach ( $map as $k => $label ) {
			$u = AAW_License::config( $k );
			if ( $u ) {
				$links[] = '<a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">' . esc_html( $label ) . '</a>';
			}
		}
		return $links;
	}
}
