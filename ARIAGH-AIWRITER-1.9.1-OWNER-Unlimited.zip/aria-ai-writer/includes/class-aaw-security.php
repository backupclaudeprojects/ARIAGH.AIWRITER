<?php
/**
 * HMAC request signing between WordPress and the Cloudflare Worker.
 *
 * Signature = hex( HMAC-SHA256( secret, timestamp + "." + nonce + "." + route + "." + body ) )
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Security {

	const WINDOW = 300; // Seconds a signed request stays valid.

	public static function sign( $route, $body, $ts = null, $nonce = null ) {
		$ts    = $ts ? $ts : time();
		$nonce = $nonce ? $nonce : wp_generate_password( 20, false, false );
		$sig   = hash_hmac( 'sha256', $ts . '.' . $nonce . '.' . $route . '.' . $body, AAW_Settings::shared_secret() );
		return array(
			'X-AAW-Timestamp' => (string) $ts,
			'X-AAW-Nonce'     => $nonce,
			'X-AAW-Signature' => $sig,
		);
	}

	/**
	 * Verify an incoming REST request from the worker.
	 *
	 * @param WP_REST_Request $request Request.
	 * @param string          $route   Logical route name.
	 * @return true|WP_Error
	 */
	public static function verify( $request, $route ) {
		$ts    = (int) $request->get_header( 'x_aaw_timestamp' );
		$nonce = (string) $request->get_header( 'x_aaw_nonce' );
		$sig   = (string) $request->get_header( 'x_aaw_signature' );
		if ( ! $ts || ! $nonce || ! $sig ) {
			return new WP_Error( 'aaw_auth', 'امضای درخواست موجود نیست.', array( 'status' => 401 ) );
		}
		if ( abs( time() - $ts ) > self::WINDOW ) {
			return new WP_Error( 'aaw_auth', 'زمان درخواست منقضی شده است (ساعت سرور را بررسی کنید).', array( 'status' => 401 ) );
		}
		if ( ! preg_match( '/^[A-Za-z0-9_\-]{8,64}$/', $nonce ) ) {
			return new WP_Error( 'aaw_auth', 'Nonce نامعتبر.', array( 'status' => 401 ) );
		}
		$allow = AAW_Settings::get( 'rest_ip_allow', array() );
		if ( ! empty( $allow ) ) {
			$ip = self::client_ip();
			if ( ! in_array( $ip, $allow, true ) ) {
				return new WP_Error( 'aaw_auth', 'IP مجاز نیست: ' . $ip, array( 'status' => 403 ) );
			}
		}
		$expected = hash_hmac( 'sha256', $ts . '.' . $nonce . '.' . $route . '.' . $request->get_body(), AAW_Settings::shared_secret() );
		if ( ! hash_equals( $expected, $sig ) ) {
			return new WP_Error( 'aaw_auth', 'امضای درخواست نامعتبر است. کلید مشترک را دوباره همگام‌سازی کنید.', array( 'status' => 401 ) );
		}
		$key = 'aaw_n_' . md5( $nonce );
		if ( get_transient( $key ) ) {
			return new WP_Error( 'aaw_auth', 'درخواست تکراری (Replay) رد شد.', array( 'status' => 401 ) );
		}
		set_transient( $key, 1, self::WINDOW * 2 );
		return true;
	}

	public static function client_ip() {
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'REMOTE_ADDR' ) as $h ) {
			if ( ! empty( $_SERVER[ $h ] ) ) {
				return sanitize_text_field( wp_unslash( $_SERVER[ $h ] ) );
			}
		}
		return '';
	}

	/**
	 * Short-lived token the admin browser uses to call the worker directly (Run now, etc).
	 */
	public static function browser_token( $action, $ttl = 900 ) {
		$payload = rtrim( strtr( base64_encode( wp_json_encode( array(
			'act' => $action,
			'exp' => time() + $ttl,
			'n'   => wp_generate_password( 12, false, false ),
		) ) ), '+/', '-_' ), '=' );
		return $payload . '.' . hash_hmac( 'sha256', $payload, AAW_Settings::shared_secret() );
	}
}
