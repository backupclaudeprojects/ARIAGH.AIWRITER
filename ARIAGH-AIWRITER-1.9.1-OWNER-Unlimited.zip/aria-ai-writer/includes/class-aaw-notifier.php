<?php
/**
 * Notifications: email, Telegram bot, generic webhook.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Notifier {

	public static function draft_created( $post_id ) {
		$s     = AAW_Settings::all();
		$title = get_the_title( $post_id );
		$edit  = admin_url( 'post.php?post=' . (int) $post_id . '&action=edit' );
		$msg   = sprintf( "مقاله جدید آماده بازبینی است:\n%s\n\nویرایش و تایید:\n%s", $title, $edit );
		if ( $s['notify_email'] ) {
			$to = $s['notify_email_to'] ? $s['notify_email_to'] : get_option( 'admin_email' );
			wp_mail( $to, '[' . $s['site_name'] . '] پیش‌نویس جدید: ' . $title, $msg );
		}
		self::telegram( $msg );
		self::webhook( 'draft.created', array( 'post_id' => $post_id, 'title' => $title, 'edit_url' => $edit, 'preview_url' => get_preview_post_link( $post_id ) ) );
	}

	public static function failure( $message, $topic_title = '' ) {
		$s = AAW_Settings::all();
		if ( ! $s['notify_on_fail'] ) {
			return;
		}
		$msg = "خطا در تولید مقاله" . ( $topic_title ? " «{$topic_title}»" : '' ) . ":\n" . $message;
		if ( $s['notify_email'] ) {
			$to = $s['notify_email_to'] ? $s['notify_email_to'] : get_option( 'admin_email' );
			wp_mail( $to, '[' . $s['site_name'] . '] خطای تولید محتوا', $msg );
		}
		self::telegram( $msg );
		self::webhook( 'run.failed', array( 'error' => $message, 'topic' => $topic_title ) );
	}

	public static function telegram( $text ) {
		$s     = AAW_Settings::all();
		$token = AAW_Settings::secure_get( 'telegram_token' );
		if ( ! $s['telegram_enabled'] || ! $token || ! $s['telegram_chat'] ) {
			return false;
		}
		$r = wp_remote_post(
			'https://api.telegram.org/bot' . rawurlencode( $token ) . '/sendMessage',
			array(
				'timeout' => 15,
				'body'    => array(
					'chat_id'                  => $s['telegram_chat'],
					'text'                     => mb_substr( $text, 0, 4000 ),
					'disable_web_page_preview' => 'true',
				),
			)
		);
		return ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r );
	}

	public static function webhook( $event, $data ) {
		$url = AAW_Settings::get( 'webhook_url' );
		if ( ! $url || ! wp_http_validate_url( $url ) ) {
			return false;
		}
		$body = wp_json_encode( array( 'event' => $event, 'site' => home_url(), 'data' => $data, 'time' => time(), 'text' => isset( $data['title'] ) ? 'پیش‌نویس جدید: ' . $data['title'] : ( $data['error'] ?? '' ) ), JSON_UNESCAPED_UNICODE );
		wp_remote_post(
			$url,
			array(
				'timeout'  => 10,
				'blocking' => false,
				'headers'  => array(
					'Content-Type'    => 'application/json',
					'X-AAW-Signature' => hash_hmac( 'sha256', $body, AAW_Settings::shared_secret() ),
				),
				'body'     => $body,
			)
		);
		return true;
	}
}
