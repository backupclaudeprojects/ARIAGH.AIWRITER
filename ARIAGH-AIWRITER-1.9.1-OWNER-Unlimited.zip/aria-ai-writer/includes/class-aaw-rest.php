<?php
/**
 * REST API consumed by the Cloudflare Worker (HMAC-signed).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_REST {

	const NS = 'aaw/v1';

	public static function register() {
		$routes = array(
			'ping'   => 'ping',
			'job'    => 'job',
			'topics' => 'add_topics',
			'draft'  => 'draft',
			'fail'   => 'fail',
			'log'    => 'log',
		);
		foreach ( $routes as $route => $cb ) {
			register_rest_route(
				self::NS,
				'/' . $route,
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, $cb ),
					'permission_callback' => function ( $request ) use ( $route ) {
						return AAW_Security::verify( $request, $route );
					},
				)
			);
		}
	}

	private static function body( $request ) {
		$d = json_decode( $request->get_body(), true );
		return is_array( $d ) ? $d : array();
	}

	public static function ping( $request ) {
		update_option( 'aaw_last_ping', time(), false );
		return array(
			'ok'      => true,
			'site'    => home_url(),
			'version' => AAW_VERSION,
			'time'    => time(),
			'queue'   => AAW_Topics::counts(),
		);
	}

	/** Runtime configuration sent to the worker (no secrets). */
	public static function runtime() {
		$s     = AAW_Settings::all();
		$chain = array();
		$ids   = array_unique( array_merge( array( $s['provider'] ), (array) $s['fallbacks'] ) );
		foreach ( $ids as $id ) {
			$r = AAW_Providers::runtime( $id, $id === $s['provider'] && $s['model'] ? $s['model'] : '' );
			if ( $r ) {
				$chain[] = $r;
			}
		}
		return array(
			'providers' => $chain,
			'params'    => array(
				'temperature' => (float) $s['temperature'],
				'max_tokens'  => (int) $s['max_tokens'],
				'top_p'       => (float) $s['top_p'],
				'json_mode'   => (bool) $s['json_mode'],
				'timeout'     => (int) $s['request_timeout'],
				'retries'     => (int) $s['retries'],
				'two_pass'    => (bool) $s['two_pass'],
			),
			'image'     => AAW_Images::runtime(),
			'gsc'       => class_exists( 'AAW_GSC' ) && AAW_GSC::connected() ? AAW_GSC::site() : '',
			'site'      => array(
				'name'     => $s['site_name'],
				'language' => $s['language'],
			),
		);
	}

	public static function build_job( array $topic ) {
		$s       = AAW_Settings::all();
		$context = array();
		if ( 'ai_pick' === $s['category_mode'] ) {
			$context['categories'] = wp_list_pluck( get_categories( array( 'hide_empty' => false, 'number' => 80 ) ), 'name' );
		}
		if ( in_array( $s['internal_links_mode'], array( 'ai', 'both' ), true ) && $s['internal_links_count'] > 0 ) {
			$pool             = AAW_Post_Builder::link_pool( (int) $s['internal_links_pool'], $topic['title'] . ' ' . $topic['keywords'] );
			$context['links'] = array_slice( $pool, 0, 25 );
		}
		return array(
			'topic'   => array(
				'id'       => (int) $topic['id'],
				'title'    => $topic['title'],
				'keywords' => $topic['keywords'],
				'attempt'  => (int) $topic['attempts'],
			),
			'prompts' => AAW_Prompt::build( $topic, $context ),
			'images'  => AAW_Settings::get( 'featured_image' ) ? AAW_Images::references_for( $topic ) : array(),
		);
	}

	public static function job( $request ) {
		return self::job_data( self::body( $request ) );
	}

	/** Core job logic (shared by REST push mode and local pull mode). */
	public static function job_data( array $b ) {
		$trigger = isset( $b['trigger'] ) ? sanitize_key( $b['trigger'] ) : 'cron';
		$s       = AAW_Settings::all();

		if ( ! $s['enabled'] ) {
			return array( 'status' => 'skip', 'reason' => 'افزونه غیرفعال است.' );
		}
		if ( 'runner' !== $trigger ) {
			$lic = AAW_License::can_generate();
			if ( is_wp_error( $lic ) ) {
				return array( 'status' => 'skip', 'reason' => $lic->get_error_message(), 'license' => true );
			}
		}
		if ( 'cron' === $trigger && $s['paused'] ) {
			return array( 'status' => 'skip', 'reason' => 'زمان‌بندی متوقف است.' );
		}
		if ( 'cron' === $trigger && AAW_Cloudflare::needs_gating() ) {
			$last = AAW_Logs::last( 'draft', 'success' );
			$gap  = (int) $s['interval_hours'] * HOUR_IN_SECONDS - 10 * MINUTE_IN_SECONDS;
			if ( $last && ( time() - strtotime( $last['created_at'] . ' UTC' ) ) < $gap ) {
				return array( 'status' => 'skip', 'reason' => 'هنوز به بازه زمانی بعدی نرسیده‌ایم.' );
			}
		}
		if ( 'cron' === $trigger && $s['daily_limit'] > 0 && AAW_Logs::count_today( 'draft', 'success' ) >= $s['daily_limit'] ) {
			return array( 'status' => 'skip', 'reason' => 'سقف تولید روزانه تکمیل شده است.' );
		}

		// Subscription mode: the article is written by the GitHub runner with the user's chat account.
		$primary = AAW_Providers::get( $s['provider'] );
		if ( $primary && 'github_runner' === $primary['format'] && 'runner' !== $trigger && AAW_Local::is_local( $primary['engine'] ?? 'claude' ) ) {
			$r = AAW_Local::start_generate( 'cron' === $trigger ? 'cron' : 'manual', ! empty( $b['topic_id'] ) ? absint( $b['topic_id'] ) : 0, $primary['engine'] ?? 'claude' );
			return is_wp_error( $r ) ? array( 'status' => 'skip', 'reason' => $r->get_error_message() ) : $r;
		}
		if ( $primary && 'github_runner' === $primary['format'] && 'runner' !== $trigger && AAW_Pull::active() ) {
			return AAW_Pull::dispatch_subscription( 'cron' === $trigger ? 'cron' : 'manual', ! empty( $b['topic_id'] ) ? absint( $b['topic_id'] ) : 0 );
		}
		if ( $primary && 'github_runner' === $primary['format'] && 'runner' !== $trigger ) {
			if ( ! AAW_GitHub::is_connected() ) {
				return array( 'status' => 'skip', 'reason' => 'حالت اکانت اشتراکی فعال است ولی GitHub متصل نیست.' );
			}
			$d = AAW_GitHub::dispatch( 'cron' === $trigger ? 'cron' : 'manual', ! empty( $b['topic_id'] ) ? absint( $b['topic_id'] ) : 0 );
			if ( is_wp_error( $d ) ) {
				AAW_Logs::add( 'error', 'run', 'اجرای GitHub شروع نشد: ' . $d->get_error_message() );
				return array( 'status' => 'skip', 'reason' => 'اجرای GitHub شروع نشد: ' . $d->get_error_message() );
			}
			AAW_Logs::add( 'info', 'run', 'اجرای اکانت اشتراکی (' . $d['inputs']['engine'] . ') در GitHub Actions شروع شد.' );
			return array( 'status' => 'dispatched', 'reason' => 'نوشتن مقاله با اکانت اشتراکی شما در GitHub Actions شروع شد؛ چند دقیقه دیگر در صف بازبینی ظاهر می‌شود.', 'url' => AAW_GitHub::repo_url() . '/actions' );
		}
		if ( 'runner' === $trigger ) {
			// Checks already passed when the run was dispatched.
			$trigger = ( isset( $b['origin'] ) && 'cron' === $b['origin'] ) ? 'cron' : 'manual';
		}

		$count = 'manual' === $trigger ? 1 : (int) $s['posts_per_run'];
		$jobs  = array();

		if ( ! empty( $b['topic_id'] ) ) {
			$t = AAW_Topics::get( absint( $b['topic_id'] ) );
			if ( $t && 'processing' !== $t['status'] ) {
				AAW_Topics::update( $t['id'], array( 'status' => 'processing', 'locked_at' => current_time( 'mysql', true ), 'attempts' => (int) $t['attempts'] + 1 ) );
				$t['attempts'] = (int) $t['attempts'] + 1;
				$jobs[]        = self::build_job( $t );
			}
		}

		$guard = 0;
		while ( count( $jobs ) < $count && $guard++ < 20 ) {
			$t = AAW_Topics::claim_next();
			if ( ! $t ) {
				break;
			}
			if ( $s['duplicate_check'] && 1 === (int) $t['attempts'] ) {
				$dup = AAW_Dedupe::duplicate_of( $t['title'], (string) $t['keywords'] );
				if ( $dup ) {
					AAW_Topics::update( $t['id'], array( 'status' => 'skipped', 'error' => 'تکراری: مشابه «' . $dup['title'] . '» (' . round( $dup['score'] * 100 ) . '٪)', 'locked_at' => null, 'post_id' => $dup['id'] ) );
					AAW_Logs::add( 'warning', 'duplicate', 'موضوع «' . $t['title'] . '» رد شد چون با مقاله موجود «' . $dup['title'] . '» ' . round( $dup['score'] * 100 ) . '٪ هم‌پوشانی دارد.', array( 'topic_id' => $t['id'], 'post_id' => $dup['id'] ) );
					continue;
				}
			}
			$jobs[] = self::build_job( $t );
		}

		if ( empty( $jobs ) ) {
			if ( $s['auto_topics'] && empty( $b['no_ideas'] ) ) {
				$titles = AAW_Dedupe::existing_index( 150 );
				return array(
					'status'  => 'need_topics',
					'runtime' => self::runtime(),
					'ideas'   => array(
						'count'  => (int) $s['auto_topics_count'],
						'prompt' => AAW_Prompt::topic_ideas_prompt( (int) $s['auto_topics_count'], $titles ),
					),
				);
			}
			return array( 'status' => 'empty', 'reason' => 'صف موضوعات خالی است.' );
		}

		AAW_Logs::add( 'info', 'run', sprintf( 'اجرای جدید (%s) برای %d موضوع شروع شد.', 'cron' === $trigger ? 'زمان‌بندی' : 'دستی', count( $jobs ) ) );
		return array(
			'status'  => 'ok',
			'runtime' => self::runtime(),
			'jobs'    => $jobs,
		);
	}

	public static function add_topics( $request ) {
		return self::apply_topics( self::body( $request ) );
	}

	public static function apply_topics( array $b ) {
		$lines = array();
		foreach ( (array) ( $b['topics'] ?? array() ) as $t ) {
			if ( is_string( $t ) ) {
				$lines[] = str_replace( '|', ' ', $t );
			} elseif ( ! empty( $t['title'] ) ) {
				$kw      = isset( $t['keywords'] ) ? ( is_array( $t['keywords'] ) ? implode( ', ', $t['keywords'] ) : $t['keywords'] ) : '';
				$lines[] = str_replace( '|', ' ', $t['title'] ) . ( $kw ? ' | ' . str_replace( '|', ' ', $kw ) : '' );
			}
		}
		$r = AAW_Topics::add_bulk( implode( "\n", array_slice( $lines, 0, 50 ) ), 'ai' );
		AAW_Logs::add( 'info', 'topics', sprintf( 'هوش مصنوعی %d موضوع جدید به صف اضافه کرد.', $r['added'] ) );
		return $r;
	}

	public static function draft( $request ) {
		$r = self::apply_draft( self::body( $request ) );
		if ( is_wp_error( $r ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => $r->get_error_message() ), 422 );
		}
		return $r;
	}

	/** Create the post from an article payload; returns array or WP_Error. */
	public static function apply_draft( array $b ) {
		$topic   = ! empty( $b['topic_id'] ) ? AAW_Topics::get( absint( $b['topic_id'] ) ) : null;
		$meta    = isset( $b['meta'] ) && is_array( $b['meta'] ) ? $b['meta'] : array();
		$article = isset( $b['article'] ) && is_array( $b['article'] ) ? $b['article'] : array();

		$post_id = AAW_Post_Builder::create( $article, $topic ? $topic : array(), $meta );
		if ( is_wp_error( $post_id ) ) {
			if ( $topic ) {
				AAW_Topics::mark_failed( $topic['id'], $post_id->get_error_message() );
			}
			AAW_Logs::add( 'error', 'run', 'ساخت پیش‌نویس ناموفق: ' . $post_id->get_error_message(), array( 'topic_id' => $topic['id'] ?? 0 ) + $meta );
			AAW_Notifier::failure( $post_id->get_error_message(), $topic['title'] ?? '' );
			return $post_id;
		}
		if ( $topic ) {
			AAW_Topics::mark_done( $topic['id'], $post_id );
		}
		AAW_License::record_article();
		AAW_Revise::after_draft( $post_id, $article, $meta );
		AAW_Logs::add(
			'success',
			'draft',
			'پیش‌نویس جدید ساخته شد: ' . get_the_title( $post_id ),
			array(
				'topic_id'    => $topic['id'] ?? 0,
				'post_id'     => $post_id,
				'provider'    => $meta['provider'] ?? '',
				'model'       => $meta['model'] ?? '',
				'duration_ms' => $meta['duration_ms'] ?? 0,
				'tokens_in'   => $meta['tokens_in'] ?? 0,
				'tokens_out'  => $meta['tokens_out'] ?? 0,
				'context'     => array( 'fallbacks' => $meta['fallbacks'] ?? array() ),
			)
		);
		AAW_Notifier::draft_created( $post_id );
		if ( AAW_Settings::get( 'kv_sync' ) ) {
			wp_schedule_single_event( time() + 5, 'aaw_kv_sync' );
		}
		return array(
			'ok'       => true,
			'post_id'  => $post_id,
			'title'    => get_the_title( $post_id ),
			'edit_url' => admin_url( 'post.php?post=' . $post_id . '&action=edit' ),
		);
	}

	public static function fail( $request ) {
		return self::apply_fail( self::body( $request ) );
	}

	public static function apply_fail( array $b ) {
		$error = isset( $b['error'] ) ? sanitize_textarea_field( $b['error'] ) : 'خطای نامشخص';
		$topic = ! empty( $b['topic_id'] ) ? AAW_Topics::get( absint( $b['topic_id'] ) ) : null;
		$meta  = isset( $b['meta'] ) && is_array( $b['meta'] ) ? $b['meta'] : array();
		// Priority list: API engines failed → a subscription account later in the list takes the topic.
		if ( $topic && AAW_Priority::text_failover( $topic['id'], $meta ) ) {
			AAW_Logs::add( 'warning', 'run', '«' . $topic['title'] . '»: ' . $error, array( 'topic_id' => $topic['id'], 'context' => $meta ) );
			return array( 'ok' => true, 'failover' => true );
		}
		if ( $topic ) {
			AAW_Topics::mark_failed( $topic['id'], $error );
		}
		AAW_Logs::add( 'error', 'run', ( $topic ? '«' . $topic['title'] . '»: ' : '' ) . $error, array( 'topic_id' => $topic['id'] ?? 0, 'provider' => $meta['provider'] ?? '', 'model' => $meta['model'] ?? '', 'duration_ms' => $meta['duration_ms'] ?? 0, 'context' => $meta ) );
		AAW_Notifier::failure( $error, $topic['title'] ?? '' );
		return array( 'ok' => true );
	}

	public static function log( $request ) {
		$b = self::body( $request );
		AAW_Logs::add( $b['level'] ?? 'info', $b['event'] ?? 'worker', $b['message'] ?? '', array( 'context' => $b['context'] ?? null ) );
		return array( 'ok' => true );
	}
}
