<?php
/**
 * Activity & run logs.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Logs {

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'aaw_logs';
	}

	public static function create_table() {
		global $wpdb;
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			level VARCHAR(10) NOT NULL DEFAULT 'info',
			event VARCHAR(40) NOT NULL DEFAULT '',
			message TEXT NULL,
			context LONGTEXT NULL,
			topic_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			post_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			provider VARCHAR(60) NOT NULL DEFAULT '',
			model VARCHAR(120) NOT NULL DEFAULT '',
			duration_ms INT(11) NOT NULL DEFAULT 0,
			tokens_in INT(11) NOT NULL DEFAULT 0,
			tokens_out INT(11) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY level (level)
		) {$charset};";
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	public static function add( $level, $event, $message, $extra = array() ) {
		global $wpdb;
		$level = in_array( $level, array( 'info', 'success', 'warning', 'error', 'debug' ), true ) ? $level : 'info';
		if ( 'debug' === $level && ! AAW_Settings::get( 'debug' ) ) {
			return 0;
		}
		if ( 'error' === $level && class_exists( 'AAW_Errors' ) ) {
			$message = AAW_Errors::explain( $message );
		}
		$row = array(
			'created_at'  => current_time( 'mysql', true ),
			'level'       => $level,
			'event'       => sanitize_key( $event ),
			'message'     => mb_substr( wp_strip_all_tags( (string) $message ), 0, 3000 ),
			'context'     => isset( $extra['context'] ) ? wp_json_encode( $extra['context'], JSON_UNESCAPED_UNICODE ) : null,
			'topic_id'    => isset( $extra['topic_id'] ) ? absint( $extra['topic_id'] ) : 0,
			'post_id'     => isset( $extra['post_id'] ) ? absint( $extra['post_id'] ) : 0,
			'provider'    => isset( $extra['provider'] ) ? sanitize_text_field( $extra['provider'] ) : '',
			'model'       => isset( $extra['model'] ) ? sanitize_text_field( $extra['model'] ) : '',
			'duration_ms' => isset( $extra['duration_ms'] ) ? absint( $extra['duration_ms'] ) : 0,
			'tokens_in'   => isset( $extra['tokens_in'] ) ? absint( $extra['tokens_in'] ) : 0,
			'tokens_out'  => isset( $extra['tokens_out'] ) ? absint( $extra['tokens_out'] ) : 0,
		);
		$wpdb->insert( self::table(), $row ); // phpcs:ignore
		return (int) $wpdb->insert_id;
	}

	public static function query( $args = array() ) {
		global $wpdb;
		$args  = wp_parse_args(
			$args,
			array(
				'level'    => '',
				'event'    => '',
				'search'   => '',
				'per_page' => 50,
				'page'     => 1,
			)
		);
		$where = array( '1=1' );
		$vals  = array();
		if ( $args['level'] ) {
			$where[] = 'level = %s';
			$vals[]  = $args['level'];
		}
		if ( $args['event'] ) {
			$where[] = 'event = %s';
			$vals[]  = $args['event'];
		}
		if ( $args['search'] ) {
			$where[] = 'message LIKE %s';
			$vals[]  = '%' . $wpdb->esc_like( $args['search'] ) . '%';
		}
		$per    = max( 1, min( 500, (int) $args['per_page'] ) );
		$offset = ( max( 1, (int) $args['page'] ) - 1 ) * $per;
		$w      = implode( ' AND ', $where );
		$sql    = 'SELECT * FROM ' . self::table() . " WHERE {$w} ORDER BY id DESC LIMIT {$per} OFFSET {$offset}";
		$sqlc   = 'SELECT COUNT(*) FROM ' . self::table() . " WHERE {$w}";
		if ( $vals ) {
			$sql  = $wpdb->prepare( $sql, $vals ); // phpcs:ignore
			$sqlc = $wpdb->prepare( $sqlc, $vals ); // phpcs:ignore
		}
		return array(
			'items' => $wpdb->get_results( $sql, ARRAY_A ), // phpcs:ignore
			'total' => (int) $wpdb->get_var( $sqlc ), // phpcs:ignore
		);
	}

	public static function stats( $days = 30 ) {
		global $wpdb;
		$t     = self::table();
		$since = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT SUM(event='draft' AND level='success') ok, SUM(event='run' AND level='error') fail, SUM(tokens_in) tin, SUM(tokens_out) tout, AVG(NULLIF(CASE WHEN event='draft' THEN duration_ms END,0)) avgd FROM {$t} WHERE created_at >= %s", $since ), ARRAY_A ); // phpcs:ignore
		$daily = $wpdb->get_results( $wpdb->prepare( "SELECT DATE(created_at) d, SUM(event='draft' AND level='success') ok, SUM(event='run' AND level='error') fail FROM {$t} WHERE created_at >= %s GROUP BY DATE(created_at) ORDER BY d ASC", gmdate( 'Y-m-d H:i:s', time() - 14 * DAY_IN_SECONDS ) ), ARRAY_A ); // phpcs:ignore
		$ok    = (int) ( $row['ok'] ?? 0 );
		$fail  = (int) ( $row['fail'] ?? 0 );
		return array(
			'ok'         => $ok,
			'fail'       => $fail,
			'rate'       => ( $ok + $fail ) ? round( 100 * $ok / ( $ok + $fail ) ) : 0,
			'tokens_in'  => (int) ( $row['tin'] ?? 0 ),
			'tokens_out' => (int) ( $row['tout'] ?? 0 ),
			'avg_ms'     => (int) ( $row['avgd'] ?? 0 ),
			'daily'      => $daily,
		);
	}

	public static function last( $event, $level = '' ) {
		global $wpdb;
		if ( $level ) {
			return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE event = %s AND level = %s ORDER BY id DESC LIMIT 1', $event, $level ), ARRAY_A ); // phpcs:ignore
		}
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE event = %s ORDER BY id DESC LIMIT 1', $event ), ARRAY_A ); // phpcs:ignore
	}

	public static function count_today( $event, $level ) {
		global $wpdb;
		$since = gmdate( 'Y-m-d 00:00:00' );
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::table() . ' WHERE event = %s AND level = %s AND created_at >= %s', $event, $level, $since ) ); // phpcs:ignore
	}

	public static function clear() {
		global $wpdb;
		return $wpdb->query( 'TRUNCATE TABLE ' . self::table() ); // phpcs:ignore
	}

	public static function prune() {
		global $wpdb;
		$days  = (int) AAW_Settings::get( 'log_retention_days', 60 );
		$limit = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		return $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . ' WHERE created_at < %s', $limit ) ); // phpcs:ignore
	}

	public static function export_csv() {
		$rows = self::query( array( 'per_page' => 500 ) );
		$fh   = fopen( 'php://temp', 'w+' );
		fwrite( $fh, "\xEF\xBB\xBF" );
		fputcsv( $fh, array( 'time_utc', 'level', 'event', 'message', 'provider', 'model', 'duration_ms', 'tokens_in', 'tokens_out', 'topic_id', 'post_id' ) );
		foreach ( $rows['items'] as $r ) {
			fputcsv( $fh, array( $r['created_at'], $r['level'], $r['event'], $r['message'], $r['provider'], $r['model'], $r['duration_ms'], $r['tokens_in'], $r['tokens_out'], $r['topic_id'], $r['post_id'] ) );
		}
		rewind( $fh );
		$csv = stream_get_contents( $fh );
		fclose( $fh );
		return $csv;
	}
}
