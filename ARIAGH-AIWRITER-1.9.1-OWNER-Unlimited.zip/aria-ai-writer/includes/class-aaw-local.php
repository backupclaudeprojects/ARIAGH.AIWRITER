<?php
/**
 * AI engines on THIS server ("مستقیم از همین سرور").
 *
 * The official OpenAI Codex CLI (ChatGPT Plus/Pro) and Claude Code CLI (Claude Pro/Max) are
 * installed and signed in on the WordPress server itself and answer exactly the same tasks the
 * GitHub runner answers — same prompts, rules, site data, SEO knowledge, product links and image
 * references. Nothing goes through GitHub or Cloudflare when an engine is set to "direct".
 *
 * - Runs are detached processes (AAW_Proc::spawn); this class advances each job one step at a
 *   time from WP-Cron and from the open admin pages, so PHP time limits never interrupt a job.
 * - Sessions are not stored (`codex exec --ephemeral`, `claude --no-session-persistence`), so the
 *   requests never appear in the chat history of the ChatGPT / Claude apps on other devices.
 * - Sign-in only through the official ways: Codex device code (approved in the user's own browser
 *   window), Codex auth.json, Claude `setup-token` token. Passwords never pass through the plugin.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Local {

	const JOBS     = 'aaw_local_jobs';
	const STATE    = 'aaw_local_state';
	const LOGIN    = 'aaw_local_login';
	const INSTALL  = 'aaw_local_install_';
	const TICK     = 'aaw_local_tick';
	const CTX_MARK = '## داده‌های واقعی سایت';

	const ENGINES = array(
		'codex'  => array( 'name' => 'OpenAI Codex (اکانت ChatGPT)', 'bin' => 'codex', 'package' => '@openai/codex', 'node' => 18, 'provider' => 'sub_codex' ),
		'claude' => array( 'name' => 'Claude Code (اکانت Claude)', 'bin' => 'claude', 'package' => '@anthropic-ai/claude-code', 'node' => 18, 'provider' => 'sub_claude' ),
	);

	/* ============================================================ settings */

	public static function engine_of( $provider_or_engine ) {
		$e = (string) $provider_or_engine;
		if ( 'sub_codex' === $e || 'codex' === $e ) {
			return 'codex';
		}
		if ( 'sub_claude' === $e || 'claude' === $e ) {
			return 'claude';
		}
		return '';
	}

	/** "local" = this server answers (never GitHub), "github" = the GitHub runner. */
	public static function route( $engine ) {
		$engine = self::engine_of( $engine );
		return $engine && 'local' === AAW_Settings::get( 'local_route_' . $engine ) ? 'local' : 'github';
	}

	public static function is_local( $engine ) {
		return 'local' === self::route( $engine );
	}

	/** Engine of the main content provider (when it is a subscription account). */
	public static function default_engine() {
		$p = AAW_Providers::get( AAW_Settings::get( 'provider' ) );
		return ( $p && ! empty( $p['engine'] ) ) ? $p['engine'] : 'claude';
	}

	/** Can this server answer for the engine right now? true or WP_Error with the fix. */
	public static function ready( $engine ) {
		$engine = self::engine_of( $engine );
		if ( ! $engine ) {
			return new WP_Error( 'aaw', 'موتور نامعتبر برای اجرای مستقیم.' );
		}
		if ( ! AAW_Proc::can_exec() ) {
			return new WP_Error( 'aaw', self::message( 'PROC_DISABLED' ) );
		}
		if ( '' === self::binary( $engine ) ) {
			return new WP_Error( 'aaw', AAW_Errors::format( self::ENGINES[ $engine ]['name'] . ' روی این سرور نصب نیست', 'روش اجرای این اکانت «مستقیم از همین سرور» است، پس کار به GitHub فرستاده نمی‌شود.', 'در تب «موتور هوش مصنوعی روی سرور» دکمه «نصب» را بزنید، یا روش اجرا را «از طریق GitHub» بگذارید.' ) );
		}
		if ( ! self::has_login( $engine ) ) {
			return new WP_Error( 'aaw', AAW_Errors::format( 'ورود ' . self::ENGINES[ $engine ]['name'] . ' روی سرور انجام نشده است', 'برای اجرای مستقیم، اکانت باید روی همین سرور وارد شده باشد.', 'در تب «موتور هوش مصنوعی روی سرور» دکمه «ورود» را بزنید.' ) );
		}
		return true;
	}

	/**
	 * Write articles on this server (same job the GitHub runner gets).
	 *
	 * @return array|WP_Error { status: dispatched, id, reason }
	 */
	public static function start_generate( $trigger, $topic_id = 0, $engine = '' ) {
		$engine = self::engine_of( $engine ? $engine : self::default_engine() );
		$ok     = self::ready( $engine );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$payload = AAW_REST::job_data( array( 'trigger' => 'runner', 'origin' => $trigger, 'topic_id' => (int) $topic_id ) );
		if ( ! in_array( $payload['status'] ?? '', array( 'ok', 'need_topics' ), true ) ) {
			return new WP_Error( 'aaw_skip', (string) ( $payload['reason'] ?? 'کاری برای انجام نبود.' ) );
		}
		$payload['origin'] = $trigger;
		$id                = self::start( $trigger, $engine, $payload );
		if ( is_wp_error( $id ) ) {
			$topics = array();
			foreach ( (array) ( $payload['jobs'] ?? array() ) as $j ) {
				$topics[] = (int) $j['topic']['id'];
			}
			if ( $topics ) {
				AAW_Topics::bulk_status( $topics, 'pending' );
			}
			return $id;
		}
		return array( 'status' => 'dispatched', 'local' => true, 'id' => $id, 'reason' => 'نوشتن مقاله مستقیم روی همین سرور با ' . self::ENGINES[ $engine ]['name'] . ' شروع شد (بدون GitHub)؛ چند دقیقه دیگر در صف بازبینی قرار می‌گیرد. پیشرفت در «فعالیت زنده».' );
	}

	public static function model( $engine ) {
		return (string) AAW_Providers::model_for( self::ENGINES[ $engine ]['provider'] );
	}

	/* ============================================================ files & programs */

	public static function prefix() {
		return AAW_Proc::private_dir( 'cli' );
	}

	public static function binary( $engine ) {
		if ( ! isset( self::ENGINES[ $engine ] ) ) {
			return '';
		}
		$name = self::ENGINES[ $engine ]['bin'];
		$set  = trim( (string) AAW_Settings::get( 'local_bin_' . $engine ) );
		// A custom path may only point to the official program (absolute path, same name).
		if ( '' !== $set && '/' === substr( $set, 0, 1 ) && 0 === strpos( strtolower( basename( $set ) ), $name ) && @is_file( $set ) ) { // phpcs:ignore
			return $set;
		}
		$home = AAW_Proc::user_home();
		$dirs = array( self::prefix() . '/node_modules/.bin' );
		if ( $home ) {
			$dirs = array_merge( $dirs, array( $home . '/.local/bin', $home . '/.npm-global/bin', $home . '/bin', $home . '/node_modules/.bin', $home . '/.claude/local' ) );
		}
		$found = AAW_Proc::which( $name, $dirs );
		return 'codex' === $engine && $found ? self::native_codex( $found ) : $found;
	}

	/**
	 * The npm "codex" command is a Node.js launcher that starts a native (Rust) program. Running the
	 * native program directly saves the whole Node.js process — on hosts that count the memory of
	 * all processes together (CloudLinux LVE) this is often the difference between working and
	 * "memory allocation failed".
	 */
	public static function native_codex( $bin ) {
		$real = (string) @realpath( $bin ); // phpcs:ignore
		if ( '' === $real || '.js' !== substr( $real, -3 ) ) {
			return $bin; // Already native (or unknown): keep.
		}
		$arch = strtolower( php_uname( 'm' ) );
		$want = ( false !== strpos( $arch, 'aarch64' ) || false !== strpos( $arch, 'arm64' ) ) ? 'aarch64' : 'x86_64';
		$pkg  = dirname( dirname( $real ) ); // …/node_modules/@openai/codex
		$roots = array_merge( array( $pkg ), (array) glob( dirname( $pkg ) . '/codex-*' ), (array) glob( $pkg . '/node_modules/@openai/codex-*' ) );
		foreach ( $roots as $root ) {
			foreach ( array_merge( (array) glob( $root . '/vendor/*/codex/codex' ), (array) glob( $root . '/vendor/*/bin/codex' ) ) as $f ) {
				if ( false !== strpos( $f, $want ) && false !== strpos( $f, 'linux' ) && @is_file( $f ) ) { // phpcs:ignore
					@chmod( $f, 0755 ); // phpcs:ignore
					return $f;
				}
			}
		}
		return $bin;
	}

	public static function needs_node( $bin ) {
		$fh = $bin ? @fopen( $bin, 'rb' ) : false; // phpcs:ignore
		if ( ! $fh ) {
			return true;
		}
		$head = (string) fread( $fh, 64 ); // phpcs:ignore
		fclose( $fh ); // phpcs:ignore
		return 0 === strpos( $head, '#!' ) && false !== stripos( $head, 'node' );
	}

	/** All Node.js programs found on this server: [ path, version, major ]. */
	public static function nodes( $fresh = false ) {
		$cached = $fresh ? false : get_transient( 'aaw_local_nodes' );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$home  = AAW_Proc::user_home();
		$cands = array();
		$set   = trim( (string) AAW_Settings::get( 'local_node_path' ) );
		if ( '' !== $set ) {
			$cands[] = $set;
		}
		foreach ( array( '/opt/alt/alt-nodejs*/root/usr/bin/node', '/opt/cpanel/ea-nodejs*/bin/node', '/usr/local/n/versions/node/*/bin/node' ) as $g ) {
			$cands = array_merge( $cands, (array) glob( $g ) );
		}
		if ( $home ) {
			foreach ( array( $home . '/.nvm/versions/node/*/bin/node', $home . '/nodevenv/*/*/bin/node', $home . '/.volta/bin/node', $home . '/node/bin/node' ) as $g ) {
				$cands = array_merge( $cands, (array) glob( $g ) );
			}
		}
		$cands[] = AAW_Proc::which( 'node' );
		$out     = array();
		foreach ( array_unique( array_filter( $cands ) ) as $n ) {
			if ( ! @is_executable( $n ) || count( $out ) > 12 ) { // phpcs:ignore
				continue;
			}
			$r = AAW_Proc::run( array( $n, '--version' ), '', AAW_Proc::env( array( $n ) ), null, 10 );
			$v = is_wp_error( $r ) ? '' : trim( $r['out'] );
			if ( preg_match( '/^v?(\d+)\.\d+/', $v, $m ) ) {
				$out[] = array( 'path' => $n, 'version' => ltrim( $v, 'v' ), 'major' => (int) $m[1], 'npm' => @is_file( dirname( $n ) . '/npm' ) ); // phpcs:ignore
			}
		}
		usort( $out, function ( $a, $b ) { return $b['major'] <=> $a['major']; } );
		set_transient( 'aaw_local_nodes', $out, HOUR_IN_SECONDS );
		return $out;
	}

	public static function node( $min = 18 ) {
		$set = trim( (string) AAW_Settings::get( 'local_node_path' ) );
		foreach ( self::nodes() as $n ) {
			if ( ( '' === $set || $n['path'] === $set ) && $n['major'] >= $min ) {
				return $n['path'];
			}
		}
		foreach ( self::nodes() as $n ) {
			if ( $n['major'] >= $min ) {
				return $n['path'];
			}
		}
		return '';
	}

	private static function bins( $engine, $bin ) {
		$b = array( $bin );
		if ( self::needs_node( $bin ) ) {
			$b[] = self::node( self::ENGINES[ $engine ]['node'] );
		}
		return array_filter( $b );
	}

	public static function version( $engine, $fresh = false ) {
		$bin = self::binary( $engine );
		if ( '' === $bin ) {
			return '';
		}
		$key = 'aaw_lv_' . $engine . substr( md5( $bin . @filemtime( $bin ) ), 0, 8 ); // phpcs:ignore
		$v   = $fresh ? false : get_transient( $key );
		if ( false !== $v ) {
			return (string) $v;
		}
		if ( self::needs_node( $bin ) && '' === self::node( self::ENGINES[ $engine ]['node'] ) ) {
			return '';
		}
		$r = AAW_Proc::run( array( $bin, '--version' ), '', AAW_Proc::env( self::bins( $engine, $bin ), array( 'HOME' => AAW_Proc::private_dir( $engine . '-home' ) ) ), AAW_Proc::private_dir( 'runs' ), 40 );
		$v = ( ! is_wp_error( $r ) && 0 === $r['code'] ) ? trim( strtok( trim( $r['out'] ), "\n" ) ) : '';
		set_transient( $key, $v, $v ? DAY_IN_SECONDS : 5 * MINUTE_IN_SECONDS );
		if ( '' === $v && ! is_wp_error( $r ) ) {
			set_transient( 'aaw_lv_err_' . $engine, mb_substr( trim( $r['err'] . "\n" . $r['out'] ), -400 ), HOUR_IN_SECONDS );
		}
		return $v;
	}

	/* ============================================================ logins */

	/** Environment for Codex with the smallest memory footprint (shared hosts count every MB). */
	public static function codex_env( $bin, $home ) {
		$env = array(
			'CODEX_HOME'           => $home,
			'CODEX_MANAGED_BY_NPM' => '1',
			'MALLOC_ARENA_MAX'     => '2',   // glibc: no 64 MB virtual arena per thread.
			'TOKIO_WORKER_THREADS' => '2',   // async runtime threads (each reserves stack).
			'RAYON_NUM_THREADS'    => '1',
			'UV_THREADPOOL_SIZE'   => '2',
			'RUST_BACKTRACE'       => '0',
		);
		$path = dirname( dirname( $bin ) ) . '/path'; // vendor/<target>/path (bundled ripgrep).
		if ( is_dir( $path ) ) {
			$env['PATH'] = $path . ':' . implode( ':', array( dirname( $bin ), '/usr/local/bin', '/usr/bin', '/bin' ) );
		}
		return $env;
	}

	public static function codex_home() {
		$home = AAW_Proc::private_dir( 'codex-home' );
		if ( $home && ! file_exists( $home . '/config.toml' ) ) {
			AAW_Proc::write_secret( $home . '/config.toml', "cli_auth_credentials_store = \"file\"\n" );
		}
		return $home;
	}

	public static function claude_home() {
		return AAW_Proc::private_dir( 'claude-home' );
	}

	private static function parse_auth( $json ) {
		$a = json_decode( (string) $json, true );
		return ( is_array( $a ) && ( ! empty( $a['tokens'] ) || ! empty( $a['OPENAI_API_KEY'] ) ) ) ? $a : null;
	}

	private static function refreshed( $a ) {
		return is_array( $a ) && ! empty( $a['last_refresh'] ) ? (int) strtotime( (string) $a['last_refresh'] ) : 0;
	}

	public static function has_login( $engine ) {
		if ( 'codex' === $engine ) {
			return null !== self::parse_auth( AAW_Settings::secure_get( 'local_codex_auth' ) );
		}
		return '' !== (string) AAW_Settings::secure_get( 'local_claude_token' );
	}

	/** Save a login pasted by the user (auth.json for Codex, setup-token for Claude). */
	public static function save_login( $engine, $value ) {
		$value = trim( (string) $value );
		if ( 'codex' === $engine ) {
			$a = self::parse_auth( $value );
			if ( ! $a ) {
				return new WP_Error( 'aaw', AAW_Errors::format( 'auth.json معتبر نیست', 'محتوای فایل ورود Codex باید JSON و شامل tokens باشد.', 'روی کامپیوتر خودتان «codex login» را بزنید، با اکانت ChatGPT وارد شوید و کل محتوای فایل ‎~/.codex/auth.json‎ (در ویندوز ‎%USERPROFILE%\.codex\auth.json‎) را جای‌گذاری کنید — یا از دکمه «ورود با اکانت ChatGPT روی همین سرور» استفاده کنید.' ) );
			}
			if ( ! empty( $a['OPENAI_API_KEY'] ) && empty( $a['tokens'] ) ) {
				return new WP_Error( 'aaw', 'این فایل با کلید API ساخته شده، نه اکانت ChatGPT. «codex logout» و بعد «codex login» (گزینه Sign in with ChatGPT) را بزنید.' );
			}
			self::store_codex_auth( wp_json_encode( $a, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
		} else {
			if ( ! preg_match( '/^sk-ant-oat\d*-[A-Za-z0-9_\-]{20,}$/', $value ) ) {
				return new WP_Error( 'aaw', AAW_Errors::format( 'توکن Claude معتبر نیست', 'توکن اشتراک Claude با sk-ant-oat01- شروع می‌شود (کلید API که با sk-ant-api شروع می‌شود این‌جا کار نمی‌کند).', 'روی کامپیوتر خودتان دستور «claude setup-token» را اجرا کنید؛ مرورگر باز می‌شود و با اکانت Claude Pro/Max وارد می‌شوید؛ توکن نمایش داده‌شده را این‌جا جای‌گذاری کنید.' ) );
			}
			AAW_Settings::secure_set( 'local_claude_token', $value );
		}
		self::set_state( $engine, array( 'state' => 'unknown', 'code' => '', 'msg' => '' ) );
		AAW_Logs::add( 'success', 'local', 'ورود ' . self::ENGINES[ $engine ]['name'] . ' برای اجرای مستقیم روی سرور ذخیره شد.' );
		return array( 'message' => 'ورود ذخیره شد. حالا «تست اتصال» را بزنید.' );
	}

	private static function store_codex_auth( $json ) {
		AAW_Settings::secure_set( 'local_codex_auth', (string) $json );
		$home = self::codex_home();
		if ( $home ) {
			AAW_Proc::write_secret( $home . '/auth.json', (string) $json );
		}
	}

	public static function sign_out( $engine ) {
		if ( 'codex' === $engine ) {
			AAW_Settings::secure_set( 'local_codex_auth', '' );
			@unlink( self::codex_home() . '/auth.json' ); // phpcs:ignore
		} else {
			AAW_Settings::secure_set( 'local_claude_token', '' );
		}
		self::set_state( $engine, array( 'state' => 'unknown', 'code' => '', 'msg' => '', 'last_ok' => 0 ) );
		return array( 'message' => 'ورود حذف شد.' );
	}

	/** Copy the ChatGPT login the GitHub runner uses (Cloudflare KV) to this server. */
	public static function import_github_codex() {
		if ( ! AAW_Cloudflare::is_deployed() ) {
			return new WP_Error( 'aaw', 'ورکر کلادفلر مستقر نیست؛ ورود GitHub در دسترس نیست.' );
		}
		$r = AAW_Cloudflare::call_worker( 'codex_auth', array( 'action' => 'get' ), 25 );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		if ( empty( $r['data'] ) || ! self::parse_auth( $r['data'] ) ) {
			return new WP_Error( 'aaw', 'ورودی ChatGPT در کلادفلر ذخیره نشده است؛ از ورود با کد یا auth.json استفاده کنید.' );
		}
		self::store_codex_auth( (string) $r['data'] );
		return array( 'message' => 'همان ورود ChatGPT که GitHub استفاده می‌کند روی این سرور هم ذخیره شد.' );
	}

	/** Before a Codex run: newest auth.json wins (settings, folder, or the GitHub runner's copy). */
	private static function codex_before() {
		$home   = self::codex_home();
		$saved  = self::parse_auth( AAW_Settings::secure_get( 'local_codex_auth' ) );
		$file   = self::parse_auth( file_exists( $home . '/auth.json' ) ? (string) file_get_contents( $home . '/auth.json' ) : '' ); // phpcs:ignore
		$best   = $saved;
		if ( $file && self::refreshed( $file ) > self::refreshed( $best ) ) {
			$best = $file;
		}
		if ( AAW_Cloudflare::is_deployed() && 'github' === self::route( 'codex' ) ) {
			// Only when GitHub also uses this login (route switched back and forth).
			$r  = AAW_Cloudflare::call_worker( 'codex_auth', array( 'action' => 'get' ), 12 );
			$kv = ! is_wp_error( $r ) ? self::parse_auth( $r['data'] ?? '' ) : null;
			if ( $kv && self::refreshed( $kv ) > self::refreshed( $best ) ) {
				$best = $kv;
			}
		}
		if ( $best ) {
			$json = wp_json_encode( $best, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			AAW_Proc::write_secret( $home . '/auth.json', $json );
			if ( $best !== $saved ) {
				AAW_Settings::secure_set( 'local_codex_auth', $json );
			}
		}
		return $home;
	}

	/** After a Codex run: OpenAI rotates refresh tokens — keep the refreshed one everywhere. */
	private static function codex_after() {
		$home = self::codex_home();
		$file = self::parse_auth( file_exists( $home . '/auth.json' ) ? (string) file_get_contents( $home . '/auth.json' ) : '' ); // phpcs:ignore
		$old  = self::parse_auth( AAW_Settings::secure_get( 'local_codex_auth' ) );
		if ( $file && self::refreshed( $file ) > self::refreshed( $old ) ) {
			$json = wp_json_encode( $file, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			AAW_Settings::secure_set( 'local_codex_auth', $json );
			if ( AAW_Cloudflare::is_deployed() && isset( AAW_Settings::key_meta()['sub_codex'] ) ) {
				AAW_Cloudflare::call_worker( 'codex_auth', array( 'action' => 'put', 'data' => $json ), 12 ); // GitHub runner copy stays valid.
			}
		}
	}

	/* ---------- ChatGPT sign-in on this server (official device code, approved in the user's browser) ---------- */

	public static function login_start() {
		$bin = self::binary( 'codex' );
		if ( '' === $bin ) {
			return new WP_Error( 'aaw', 'ابتدا Codex را روی سرور نصب کنید (دکمه «نصب»).' );
		}
		$dir = AAW_Proc::private_dir( 'login' );
		AAW_Proc::kill( $dir );
		AAW_Proc::rrmdir( $dir );
		$dir  = AAW_Proc::private_dir( 'login' );
		$home = $dir . '/home';
		wp_mkdir_p( $home );
		AAW_Proc::write_secret( $home . '/config.toml', "cli_auth_credentials_store = \"file\"\n" );
		$r = AAW_Proc::spawn( array( $bin, 'login', '--device-auth' ), $dir, AAW_Proc::env( self::bins( 'codex', $bin ), self::codex_env( $bin, $home ) ), 960 );
		if ( is_wp_error( $r ) ) {
			return self::proc_error( $r, 'codex' );
		}
		update_option( self::LOGIN, array( 'status' => 'starting', 'at' => time() ), false );
		return self::login_status();
	}

	public static function parse_device( $text ) {
		$t    = preg_replace( "/\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07]*\x07/", '', (string) $text );
		$url  = preg_match( '#https://[^\s"\'<>]*(?:device|activate|codex)[^\s"\'<>]*#i', $t, $m ) ? $m[0] : ( preg_match( '#https://auth\.openai\.com[^\s"\'<>]*#i', $t, $m2 ) ? $m2[0] : '' );
		$code = preg_match( '/\b([A-Z0-9]{4,5}-[A-Z0-9]{4,6})\b/', $t, $c ) ? $c[1] : '';
		return $url && $code ? array( 'url' => rtrim( $url, ').,' ), 'code' => $code ) : null;
	}

	public static function login_status() {
		$s   = get_option( self::LOGIN, array( 'status' => 'idle' ) );
		$s   = is_array( $s ) ? $s : array( 'status' => 'idle' );
		if ( ! in_array( $s['status'], array( 'starting', 'waiting' ), true ) ) {
			return $s;
		}
		$dir = AAW_Proc::private_dir( 'login' );
		$st  = AAW_Proc::status( $dir );
		$txt = AAW_Proc::read( $dir, 'out.txt' ) . "\n" . AAW_Proc::read( $dir, 'err.txt' );
		$dev = self::parse_device( $txt );
		if ( $dev && 'starting' === $s['status'] ) {
			$s = array( 'status' => 'waiting', 'url' => esc_url_raw( $dev['url'] ), 'code' => $dev['code'], 'at' => time() );
		}
		if ( 'done' === $st['state'] ) {
			$auth = self::parse_auth( file_exists( $dir . '/home/auth.json' ) ? (string) file_get_contents( $dir . '/home/auth.json' ) : '' ); // phpcs:ignore
			if ( 0 === $st['code'] && $auth ) {
				self::store_codex_auth( wp_json_encode( $auth, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
				self::set_state( 'codex', array( 'state' => 'unknown', 'code' => '', 'msg' => '' ) );
				AAW_Logs::add( 'success', 'local', 'ورود اکانت ChatGPT روی همین سرور انجام شد (کد یک‌بارمصرف رسمی OpenAI).' );
				$s = array( 'status' => 'done', 'at' => time() );
			} else {
				$e = self::classify( 'codex', array( 'code' => $st['code'], 'out' => $txt, 'err' => '' ) );
				$s = array( 'status' => 'failed', 'message' => ( false !== stripos( $txt, 'device' ) && false !== stripos( $txt, 'not enabled' ) ) ? 'ورود با کد دستگاه در اکانت شما فعال نیست: در chatgpt.com → Settings → Security گزینه «Allow device code login» را روشن کنید و دوباره بزنید.' : $e['msg'], 'at' => time() );
			}
			AAW_Proc::rrmdir( $dir );
		} elseif ( 'lost' === $st['state'] || time() - (int) $s['at'] > 16 * MINUTE_IN_SECONDS ) {
			AAW_Proc::kill( $dir );
			$s = array( 'status' => 'failed', 'message' => 'زمان ورود تمام شد یا برنامه متوقف شد. دوباره «ورود با اکانت ChatGPT» را بزنید.', 'at' => time() );
		}
		update_option( self::LOGIN, $s, false );
		return $s;
	}

	/* ============================================================ install */

	public static function install( $engine ) {
		if ( ! AAW_Proc::can_exec() ) {
			return new WP_Error( 'aaw', self::message( 'PROC_DISABLED' ) );
		}
		$node = self::node( self::ENGINES[ $engine ]['node'] );
		if ( '' === $node ) {
			return new WP_Error( 'aaw', self::message( self::nodes() ? 'NODE_OLD' : 'NODE_MISSING' ) );
		}
		$npm = dirname( $node ) . '/npm';
		if ( ! @is_file( $npm ) ) { // phpcs:ignore
			return new WP_Error( 'aaw', 'کنار Node.js برنامه npm پیدا نشد (' . $node . '). از هاست بخواهید npm را فعال کند یا در cPanel → Setup Node.js App یک برنامه بسازید.' );
		}
		$dir = AAW_Proc::private_dir( 'install-' . $engine );
		AAW_Proc::kill( $dir );
		$cache = AAW_Proc::private_dir( 'npm-cache' );
		$cmd   = array( $node, $npm, 'install', '--prefix', self::prefix(), '--no-audit', '--no-fund', '--omit=dev', '--loglevel=error', '--cache', $cache, self::ENGINES[ $engine ]['package'] . '@latest' );
		$r     = AAW_Proc::spawn( $cmd, $dir, AAW_Proc::env( array( $node ), array( 'HOME' => AAW_Proc::private_dir( 'npm-home' ), 'npm_config_update_notifier' => 'false' ) ), 900 );
		if ( is_wp_error( $r ) ) {
			return self::proc_error( $r, $engine );
		}
		update_option( self::INSTALL . $engine, array( 'status' => 'running', 'at' => time() ), false );
		AAW_Logs::add( 'info', 'local', 'نصب ' . self::ENGINES[ $engine ]['name'] . ' روی سرور شروع شد (npm).' );
		return self::install_status( $engine );
	}

	public static function install_status( $engine ) {
		$s = get_option( self::INSTALL . $engine, array( 'status' => 'idle' ) );
		$s = is_array( $s ) ? $s : array( 'status' => 'idle' );
		if ( 'running' !== $s['status'] ) {
			return $s;
		}
		$dir = AAW_Proc::private_dir( 'install-' . $engine );
		$st  = AAW_Proc::status( $dir );
		if ( 'running' === $st['state'] ) {
			$s['elapsed'] = time() - (int) $s['at'];
			return $s;
		}
		$log = trim( AAW_Proc::read( $dir, 'err.txt', 3000 ) . "\n" . AAW_Proc::read( $dir, 'out.txt', 2000 ) );
		delete_transient( 'aaw_local_nodes' );
		foreach ( array( 'claude', 'codex' ) as $e ) {
			delete_transient( 'aaw_lv_err_' . $e );
		}
		if ( 'done' === $st['state'] && 0 === $st['code'] && '' !== self::binary( $engine ) && '' !== self::version( $engine, true ) ) {
			$s = array( 'status' => 'done', 'at' => time(), 'version' => self::version( $engine ) );
			AAW_Logs::add( 'success', 'local', self::ENGINES[ $engine ]['name'] . ' روی سرور نصب شد: ' . $s['version'] );
		} else {
			$e = self::classify( $engine, array( 'code' => (int) $st['code'], 'out' => $log, 'err' => '' ) );
			$s = array( 'status' => 'failed', 'at' => time(), 'message' => 'lost' === $st['state'] ? 'برنامه نصب توسط هاست متوقف شد (محدودیت زمان/حافظه). نصب را از SSH یا ترمینال cPanel انجام دهید: ' . self::ssh_command( $engine ) : $e['msg'], 'log' => mb_substr( AAW_Errors_Redact::clean( $log ), -1500 ) );
			AAW_Logs::add( 'error', 'local', 'نصب ' . self::ENGINES[ $engine ]['name'] . ' ناموفق بود: ' . $s['message'] );
		}
		update_option( self::INSTALL . $engine, $s, false );
		return $s;
	}

	public static function ssh_command( $engine ) {
		return 'npm install --prefix ' . self::prefix() . ' ' . self::ENGINES[ $engine ]['package'] . '@latest';
	}

	/* ============================================================ state & diagnostics */

	public static function state( $engine ) {
		$all = get_option( self::STATE, array() );
		$s   = is_array( $all ) && isset( $all[ $engine ] ) ? (array) $all[ $engine ] : array();
		return array_merge( array( 'state' => 'unknown', 'code' => '', 'msg' => '', 'at' => 0, 'last_ok' => 0, 'test' => null ), $s );
	}

	private static function set_state( $engine, array $changes ) {
		$all            = get_option( self::STATE, array() );
		$all            = is_array( $all ) ? $all : array();
		$all[ $engine ] = array_merge( self::state( $engine ), $changes, array( 'at' => time() ) );
		update_option( self::STATE, $all, false );
	}

	/** Everything the engines screen shows (no program is started except cached version checks). */
	public static function doctor( $fresh = false ) {
		if ( $fresh ) {
			delete_transient( 'aaw_local_nodes' );
		}
		$can   = AAW_Proc::can_exec();
		$nodes = $can ? self::nodes( $fresh ) : array();
		$priv  = AAW_Proc::base_dir();
		$env   = array(
			array( 'label' => 'اجرای برنامه از PHP (proc_open)', 'ok' => $can, 'detail' => $can ? 'فعال' : 'غیرفعال در هاست: ' . implode( ', ', AAW_Proc::blocked() ) ),
			array( 'label' => 'پوشه خصوصی ورود و فایل‌ها', 'ok' => '' !== $priv && @is_writable( $priv ), 'detail' => $priv ? ( false === strpos( $priv, (string) ABSPATH ) ? 'خارج از پوشه عمومی سایت' : 'داخل uploads با قانون عدم دسترسی' ) : 'قابل ساخت نیست' ), // phpcs:ignore
			array( 'label' => 'اجرای پس‌زمینه (setsid / nohup)', 'ok' => $can && ( '' !== AAW_Proc::which( 'setsid' ) || '' !== AAW_Proc::which( 'nohup' ) ), 'detail' => AAW_Proc::which( 'setsid' ) ? 'setsid' : ( AAW_Proc::which( 'nohup' ) ? 'nohup' : 'پیدا نشد' ) ),
			array( 'label' => 'Node.js نسخه ۱۸ یا بالاتر', 'ok' => '' !== self::node( 18 ), 'detail' => self::node( 18 ) ? self::node( 18 ) : ( $nodes ? 'نسخه قدیمی: ' . $nodes[0]['version'] : 'پیدا نشد' ) ),
		);
		$lim = $can ? AAW_Proc::limits() : array( 'soft' => 0, 'hard' => 0 );
		$eff = $lim['hard'] ? $lim['hard'] : 0; // The plugin raises the soft limit up to the hard one.
		$env[] = array( 'label' => 'سقف حافظه مجازی برنامه‌ها', 'ok' => ! $eff || $eff >= 2000000, 'detail' => ( $eff ? round( $eff / 1024 ) . ' MB' : 'نامحدود' ) . ( $lim['soft'] && $lim['soft'] !== $lim['hard'] ? ' (پیش‌فرض PHP ' . round( $lim['soft'] / 1024 ) . ' MB؛ افزونه خودکار تا سقف بالا می‌برد)' : '' ) . ( $eff && $eff < 2000000 ? ' — Codex حدود ۱ تا ۲ گیگ لازم دارد؛ از هاست افزایش VMEM / Memory Limit را بخواهید.' : '' ) . ' سقف LVE (CloudLinux) از داخل PHP دیده نمی‌شود.' );
		$engines = array();
		foreach ( self::ENGINES as $id => $e ) {
			$bin   = $can ? self::binary( $id ) : '';
			$ver   = $bin ? self::version( $id, $fresh ) : '';
			$st    = self::state( $id );
			$inst  = self::install_status( $id );
			$login = self::has_login( $id );
			if ( ! $can ) {
				$status = 'unsupported';
			} elseif ( 'running' === $inst['status'] ) {
				$status = 'installing';
			} elseif ( '' === $bin || '' === $ver ) {
				$status = 'not_installed';
			} elseif ( ! $login ) {
				$status = 'auth_required';
			} elseif ( 'auth' === $st['state'] ) {
				$status = 'auth_required';
			} elseif ( 'ok' === $st['state'] ) {
				$status = 'ready';
			} elseif ( 'error' === $st['state'] ) {
				$status = 'error';
			} else {
				$status = 'needs_test';
			}
			$engines[ $id ] = array(
				'engine'   => $id,
				'name'     => $e['name'],
				'package'  => $e['package'],
				'status'   => $status,
				'path'     => $bin,
				'node'     => $bin && self::needs_node( $bin ) ? self::node( $e['node'] ) : ( $bin ? 'لازم نیست (برنامه بومی)' : '' ),
				'version'  => $ver,
				'ver_err'  => $bin && ! $ver ? (string) get_transient( 'aaw_lv_err_' . $id ) : '',
				'login'    => $login,
				'route'    => self::route( $id ),
				'model'    => self::model( $id ),
				'state'    => $st,
				'install'  => $inst,
				'ssh'      => self::ssh_command( $id ),
			);
		}
		return array( 'env' => $env, 'nodes' => $nodes, 'engines' => $engines, 'prefix' => self::prefix(), 'jobs' => self::jobs_summary(), 'login' => self::login_status() );
	}

	/* ============================================================ errors */

	public static function classify( $engine, array $r ) {
		$text = (string) ( $r['err'] ?? '' ) . "\n" . (string) ( $r['out'] ?? '' );
		$code = isset( $r['code'] ) ? (int) $r['code'] : 0;
		$c    = 'RUN_FAILED';
		if ( 124 === $code || 137 === $code && false !== stripos( $text, 'timeout' ) ) {
			$c = 'TIMEOUT';
		} elseif ( 127 === $code || preg_match( '/ENOENT|not found: (node|codex|claude)|No such file or directory/i', $text ) ) {
			$c = 'NOT_FOUND';
		} elseif ( preg_match( '/device code|device.auth.*(disabled|not (enabled|allowed))/i', $text ) && preg_match( '/not (enabled|allowed)|disabled/i', $text ) ) {
			$c = 'DEVICE_DISABLED';
		} elseif ( preg_match( '/\b401\b|unauthori[sz]ed|not logged in|please (run )?\/?login|log ?in again|invalid[_ ](api[_ ])?key|invalid.{0,20}token|token.{0,30}(expired|revoked|invalid)|refresh token|authentication (failed|error|required)|OAuth token has expired|re-?authenticate/i', $text ) ) {
			$c = 'AUTH';
		} elseif ( preg_match( '/usage limit|rate.?limit|quota|limit reached|reached your|\b429\b|too many requests|upgrade to (plus|pro)/i', $text ) ) {
			$c = 'QUOTA';
		} elseif ( 137 === $code || 134 === $code || preg_match( '/\bKilled\b|out of memory|ENOMEM|Cannot allocate memory|heap out of memory|memory allocation|failed to allocate|mmap|dumped core/i', $text ) ) {
			$c = 'MEMORY';
		} elseif ( preg_match( '/ENOTFOUND|EAI_AGAIN|ECONNRESET|ECONNREFUSED|ETIMEDOUT|EHOSTUNREACH|socket hang up|stream (disconnected|error)|connection (reset|refused|closed|timed out)|error sending request|fetch failed|network|getaddrinfo|tls|certificate|unable to (connect|reach)|403 forbidden|unsupported_country|not available in your (country|region)/i', $text ) ) {
			$c = 'NETWORK';
		} elseif ( preg_match( '/EACCES|permission denied|EPERM/i', $text ) ) {
			$c = 'PERMISSION';
		}
		return array( 'code' => $c, 'msg' => self::message( $c, $engine ), 'detail' => mb_substr( AAW_Errors_Redact::clean( trim( $text ) ), -500 ) );
	}

	public static function message( $code, $engine = '' ) {
		$n = isset( self::ENGINES[ $engine ] ) ? self::ENGINES[ $engine ]['name'] : 'برنامه';
		$m = array(
			'PROC_DISABLED'   => 'هاست اجرای برنامه از PHP را بسته است (proc_open غیرفعال). از پشتیبانی هاست بخواهید proc_open را برای این سایت فعال کند، یا روش اجرا را «از طریق GitHub» بگذارید.',
			'NODE_MISSING'    => 'Node.js روی سرور پیدا نشد. در cPanel از «Setup Node.js App» نسخه ۲۰ یا ۲۲ را فعال کنید (یا از هاست بخواهید Node.js نصب کند) و دوباره «بررسی دوباره» را بزنید.',
			'NODE_OLD'        => 'نسخه Node.js سرور قدیمی است (حداقل ۱۸ لازم است). در cPanel → Setup Node.js App نسخه ۲۰ یا ۲۲ را انتخاب کنید.',
			'NOT_FOUND'       => $n . ' روی سرور پیدا نشد یا Node.js آن در دسترس نیست. دکمه «نصب / تعمیر» را بزنید.',
			'AUTH'            => 'ورود ' . $n . ' معتبر نیست یا منقضی شده است. دوباره وارد شوید (دکمه «ورود») و «تست اتصال» را بزنید.',
			'QUOTA'           => 'سهمیه اشتراک ' . $n . ' فعلاً تمام شده است (محدودیت پیام/تصویر). چند ساعت بعد دوباره امتحان کنید یا موتور دیگری را در اولویت بگذارید.',
			'MEMORY'          => 'هاست به برنامه حافظه کافی نداد و برنامه متوقف شد («memory allocation failed»). افزونه سقف قابل افزایش را خودکار بالا برد و برنامه بومی Codex را بدون Node.js اجرا کرد، ولی سقف حساب هاست کمتر از نیاز است (Codex حدود ۱ تا ۲ گیگ حافظه مجازی می‌خواهد). از پشتیبانی هاست بخواهید برای این حساب «LVE Virtual Memory (VMEM)» و «Physical Memory (PMEM)» را دست‌کم ۲ گیگ کند و در LiteSpeed مقدار «Memory Soft/Hard Limit» برنامه lsphp را ۲۰۴۷M یا بیشتر بگذارد؛ تا آن موقع روش اجرا را «از طریق GitHub» بگذارید.',
			'NETWORK'         => 'برنامه روی سرور به سرورهای ' . ( 'claude' === $engine ? 'Anthropic' : 'OpenAI' ) . ' وصل نشد (اینترنت بین‌المللی هاست قطع/محدود است یا IP سرور تحریم است). روی هاست‌های ایرانی حالت مستقیم معمولاً کار نمی‌کند؛ روش اجرا را «از طریق GitHub» بگذارید یا از هاست خارج از ایران استفاده کنید.',
			'TIMEOUT'         => 'کار بیش از زمان مجاز طول کشید و متوقف شد. دوباره امتحان کنید؛ اگر تکرار شد زمان مجاز را در تنظیمات پیشرفته بیشتر کنید.',
			'PERMISSION'      => 'هاست اجازه اجرای فایل برنامه را نداد (Permission denied). «نصب / تعمیر» را بزنید یا از هاست بخواهید اجرای فایل در پوشه خانگی را مجاز کند.',
			'DEVICE_DISABLED' => 'ورود با کد دستگاه در اکانت ChatGPT شما فعال نیست: chatgpt.com → Settings → Security → «Allow device code login» را روشن کنید.',
			'LOST'            => 'برنامه توسط هاست متوقف شد (بدون پیام). معمولاً محدودیت حافظه یا تعداد پردازه‌های هاست است. دوباره امتحان کنید؛ اگر تکرار شد روش اجرا را «از طریق GitHub» بگذارید.',
			'START_FAILED'    => 'هاست اجازه شروع برنامه را نداد.',
			'NO_SHELL'        => 'پوسته sh روی سرور پیدا نشد؛ اجرای پس‌زمینه ممکن نیست.',
			'RUN_FAILED'      => $n . ' روی سرور خطا داد. جزئیات را ببینید.',
		);
		return $m[ $code ] ?? $m['RUN_FAILED'];
	}

	private static function proc_error( WP_Error $e, $engine ) {
		return new WP_Error( 'aaw', self::message( $e->get_error_message(), $engine ) );
	}

	/* ============================================================ jobs */

	private static function job_file( $id ) {
		return AAW_Proc::private_dir( 'jobs' ) . '/' . preg_replace( '/[^a-z0-9]/i', '', $id ) . '.json';
	}

	private static function load( $id ) {
		$f = self::job_file( $id );
		$j = file_exists( $f ) ? json_decode( (string) file_get_contents( $f ), true ) : null; // phpcs:ignore
		return is_array( $j ) ? $j : null;
	}

	private static function store( array $job ) {
		$job['updated'] = time();
		AAW_Proc::write_secret( self::job_file( $job['id'] ), wp_json_encode( $job, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );
		$idx               = get_option( self::JOBS, array() );
		$idx               = is_array( $idx ) ? $idx : array();
		$idx[ $job['id'] ] = array( 'id' => $job['id'], 'trigger' => $job['trigger'], 'engine' => $job['engine'], 'label' => $job['label'], 'status' => $job['status'], 'step' => $job['step'], 'created' => $job['created'], 'updated' => $job['updated'], 'error' => $job['error'] );
		// Keep the 30 most recent.
		if ( count( $idx ) > 30 ) {
			uasort( $idx, function ( $a, $b ) { return $b['created'] <=> $a['created']; } );
			foreach ( array_slice( array_keys( $idx ), 30 ) as $old ) {
				@unlink( self::job_file( $old ) ); // phpcs:ignore
				unset( $idx[ $old ] );
			}
		}
		update_option( self::JOBS, $idx, false );
	}

	public static function jobs_summary() {
		$idx = get_option( self::JOBS, array() );
		$idx = is_array( $idx ) ? array_values( $idx ) : array();
		usort( $idx, function ( $a, $b ) { return $b['created'] <=> $a['created']; } );
		return array_slice( $idx, 0, 12 );
	}

	public static function active_count() {
		$n = 0;
		foreach ( (array) get_option( self::JOBS, array() ) as $j ) {
			if ( in_array( $j['status'], array( 'queued', 'running' ), true ) ) {
				$n++;
			}
		}
		return $n;
	}

	/**
	 * Queue a task for this server. Same trigger names and payloads as the GitHub runner.
	 *
	 * @return string|WP_Error job id
	 */
	public static function start( $trigger, $engine, array $payload, array $opt = array() ) {
		$engine = self::engine_of( $engine );
		$ok     = self::ready( $engine );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$id  = ! empty( $opt['id'] ) ? preg_replace( '/[^a-z0-9]/i', '', $opt['id'] ) : AAW_BG::new_id( 'l' );
		$job = array(
			'id'      => $id,
			'trigger' => (string) $trigger,
			'engine'  => $engine,
			'model'   => self::model( $engine ),
			'label'   => (string) ( $opt['label'] ?? self::label( $trigger, $payload ) ),
			'payload' => $payload,
			'post_id' => (int) ( $opt['post_id'] ?? ( $payload['post_id'] ?? 0 ) ),
			'kind'    => (string) ( $opt['kind'] ?? $trigger ),
			'status'  => 'queued',
			'step'    => 'در صف اجرای مستقیم روی سرور',
			'ctx'     => array(),
			'run'     => '',
			'error'   => '',
			'created' => time(),
			'updated' => time(),
			'op'      => '',
		);
		if ( empty( $opt['silent'] ) ) {
			$job['op'] = AAW_Activity::start( 'image' === $trigger ? 'image' : ( 'revise' === $trigger ? 'revise' : ( 'analyze' === $trigger ? 'analyze' : 'run' ) ), $job['label'] . ' — مستقیم روی سرور (' . ( 'codex' === $engine ? 'ChatGPT' : 'Claude' ) . ')', array( 'local' => $id ) );
		}
		self::store( $job );
		AAW_Logs::add( 'info', 'local', $job['label'] . ': مستقیم روی همین سرور با ' . self::ENGINES[ $engine ]['name'] . ' شروع شد (بدون GitHub).' );
		self::schedule( 5 );
		self::tick( 8 ); // Start the first step right away.
		return $id;
	}

	private static function label( $trigger, array $p ) {
		$m = array( 'test' => 'تست اتصال', 'analyze' => 'تحلیل هوشمند سایت', 'revise' => 'اصلاح مقاله', 'image' => 'ساخت تصویر', 'seo_learn' => 'ساخت دانش سئو', 'manual' => 'نوشتن مقاله', 'cron' => 'نوشتن مقاله زمان‌بندی‌شده' );
		$l = $m[ $trigger ] ?? 'کار هوش مصنوعی';
		if ( ! empty( $p['post_id'] ) ) {
			$l .= ': ' . get_the_title( (int) $p['post_id'] );
		}
		return $l;
	}

	public static function cancel( $id ) {
		$job = self::load( $id );
		if ( ! $job ) {
			return new WP_Error( 'aaw', 'کار پیدا نشد.' );
		}
		if ( $job['run'] ) {
			AAW_Proc::kill( $job['run'] );
			AAW_Proc::rrmdir( $job['run'] );
		}
		self::finish( $job, false, 'توسط کاربر لغو شد.' );
		return array( 'message' => 'لغو شد.' );
	}

	public static function schedule( $delay = 20 ) {
		if ( ! wp_next_scheduled( self::TICK ) ) {
			wp_schedule_single_event( time() + max( 5, (int) $delay ), self::TICK );
		}
	}

	/** Cron / admin-page driver: advance running jobs, start the next one. */
	public static function tick( $budget = 20 ) {
		if ( ! AAW_Proc::can_exec() || ! self::active_count() ) {
			return;
		}
		$lock = AAW_Proc::private_dir( 'jobs' ) . '/.lock';
		$fh   = @fopen( $lock, 'c' ); // phpcs:ignore
		if ( ! $fh || ! @flock( $fh, LOCK_EX | LOCK_NB ) ) { // phpcs:ignore
			return; // Another request is advancing the jobs right now.
		}
		$t0 = microtime( true );
		try {
			$guard = 0;
			while ( microtime( true ) - $t0 < $budget && $guard++ < 12 ) {
				$job = self::current();
				if ( ! $job ) {
					break;
				}
				$more = self::advance( $job );
				if ( ! $more ) {
					break; // A program is running: check again on the next tick.
				}
			}
		} catch ( Throwable $e ) {
			AAW_Logs::add( 'error', 'local', 'اجرای مستقیم: ' . $e->getMessage() );
		}
		@flock( $fh, LOCK_UN ); // phpcs:ignore
		@fclose( $fh ); // phpcs:ignore
		if ( self::active_count() ) {
			self::schedule( 20 );
		}
	}

	/** The running job, else the oldest queued one (one program at a time: one login, one token). */
	private static function current() {
		$idx = (array) get_option( self::JOBS, array() );
		uasort( $idx, function ( $a, $b ) { return $a['created'] <=> $b['created']; } );
		foreach ( array( 'running', 'queued' ) as $want ) {
			foreach ( $idx as $j ) {
				if ( $want === $j['status'] ) {
					$job = self::load( $j['id'] );
					if ( $job ) {
						return $job;
					}
					unset( $idx[ $j['id'] ] );
					update_option( self::JOBS, $idx, false );
				}
			}
		}
		return null;
	}

	/**
	 * One step. @return bool true = call again now (something finished / started instantly).
	 */
	private static function advance( array $job ) {
		if ( 'queued' === $job['status'] ) {
			$job['status'] = 'running';
			return self::step( $job, null );
		}
		if ( ! $job['run'] ) {
			return self::step( $job, null );
		}
		$st = AAW_Proc::status( $job['run'] );
		$to = max( 5, (int) AAW_Settings::get( 'local_timeout' ) ) * 60 + 120;
		if ( 'running' === $st['state'] && $st['age'] < $to ) {
			if ( ! empty( $job['op'] ) && $st['age'] > 15 ) {
				AAW_Activity::step( $job['op'], $job['step'] . ' · ' . self::ago( $st['age'] ) );
			}
			return false;
		}
		if ( 'running' === $st['state'] ) {
			AAW_Proc::kill( $job['run'] );
			$res = array( 'ok' => false, 'code' => 'TIMEOUT', 'error' => self::message( 'TIMEOUT', $job['engine'] ) );
		} elseif ( 'lost' === $st['state'] ) {
			$res = array( 'ok' => false, 'code' => 'LOST', 'error' => self::message( 'LOST', $job['engine'] ) );
		} else {
			$res = self::collect( $job, (int) $st['code'] );
		}
		AAW_Proc::rrmdir( $job['run'] );
		$job['run'] = '';
		if ( ! $res['ok'] && in_array( $res['code'], array( 'AUTH', 'QUOTA', 'NETWORK', 'MEMORY', 'NOT_FOUND', 'PERMISSION' ), true ) ) {
			self::set_state( $job['engine'], array( 'state' => 'AUTH' === $res['code'] ? 'auth' : 'error', 'code' => $res['code'], 'msg' => $res['error'] ) );
		} elseif ( $res['ok'] ) {
			self::set_state( $job['engine'], array( 'state' => 'ok', 'code' => '', 'msg' => '', 'last_ok' => time() ) );
		}
		return self::step( $job, $res );
	}

	private static function ago( $s ) {
		return $s < 60 ? $s . ' ثانیه' : floor( $s / 60 ) . ' دقیقه';
	}

	/* ---------- one AI request ("a message in the chat, like a normal user") ---------- */

	/**
	 * Start one request. $o: web (Claude may search the web), image (Codex makes an image file),
	 * refs (reference image files), out (image file name).
	 */
	private static function ask( array &$job, $await, $system, $prompt, array $o = array() ) {
		$engine = $job['engine'];
		$bin    = self::binary( $engine );
		$dir    = AAW_Proc::private_dir( 'runs' ) . '/run-' . $job['id'] . '-' . strtolower( wp_generate_password( 6, false, false ) );
		wp_mkdir_p( $dir );
		@chmod( $dir, 0700 ); // phpcs:ignore
		$model = $job['model'];
		if ( 'claude' === $engine ) {
			AAW_Proc::write_secret( $dir . '/system.txt', $system ? $system : 'You are a helpful writer.' );
			AAW_Proc::write_secret( $dir . '/in.txt', (string) $prompt );
			$cmd = array( $bin, '-p', '--output-format', 'json', '--model', $model ? $model : 'sonnet' );
			if ( ! empty( $o['web'] ) ) {
				$cmd = array_merge( $cmd, array( '--tools', 'WebSearch,WebFetch', '--allowedTools', 'WebSearch,WebFetch', '--max-turns', '40' ) );
			} else {
				$cmd = array_merge( $cmd, array( '--tools', '', '--max-turns', '2' ) );
			}
			$cmd = array_merge( $cmd, array( '--no-session-persistence', '--system-prompt-file', $dir . '/system.txt' ) );
			$env = AAW_Proc::env( self::bins( 'claude', $bin ), array( 'HOME' => self::claude_home(), 'CLAUDE_CODE_OAUTH_TOKEN' => (string) AAW_Settings::secure_get( 'local_claude_token' ), 'CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC' => '1' ) );
		} else {
			$home = self::codex_before();
			if ( ! empty( $o['image'] ) ) {
				$target = $dir . '/' . $o['out'];
				$task   = (string) $prompt . "\n\nSave the final image as " . $target . ' (PNG). Do not create any other files and do not run unrelated commands.';
				AAW_Proc::write_secret( $dir . '/in.txt', $task );
				$cmd = array( $bin, 'exec', '--skip-git-repo-check', '--sandbox', 'workspace-write', '--ephemeral', '--json', '-C', $dir );
				if ( ! empty( $o['refs'] ) ) {
					$cmd[] = '-i';
					$cmd[] = implode( ',', $o['refs'] );
				}
				$cmd[] = '-';
			} else {
				AAW_Proc::write_secret( $dir . '/in.txt', ( $system ? "# Instructions\n" . $system . "\n\n# Task\n" : '' ) . $prompt . "\n\nReturn only the requested output. Do not run commands or edit files." );
				$cmd = array( $bin, 'exec', '--skip-git-repo-check', '--sandbox', 'read-only', '--ephemeral', '--json', '-o', $dir . '/last.txt' );
				if ( $model ) {
					$cmd[] = '-m';
					$cmd[] = $model;
				}
				$cmd[] = '-';
			}
			$env = AAW_Proc::env( self::bins( 'codex', $bin ), self::codex_env( $bin, $home ) );
		}
		$r = AAW_Proc::spawn( $cmd, $dir, $env, max( 5, (int) AAW_Settings::get( 'local_timeout' ) ) * 60 );
		if ( is_wp_error( $r ) ) {
			AAW_Proc::rrmdir( $dir );
			return array( 'ok' => false, 'code' => $r->get_error_message(), 'error' => self::message( $r->get_error_message(), $engine ) );
		}
		$job['run']            = $dir;
		$job['ctx']['await']   = $await;
		$job['ctx']['img_out'] = $o['out'] ?? '';
		$job['ctx']['t_ask']   = time();
		return null; // Started.
	}

	/** Read a finished request. */
	private static function collect( array $job, $code ) {
		$dir    = $job['run'];
		$engine = $job['engine'];
		$out    = AAW_Proc::read( $dir, 'out.txt' );
		$err    = AAW_Proc::read( $dir, 'err.txt', 20000 );
		if ( 'claude' === $engine ) {
			$lines = array_values( array_filter( array_map( 'trim', explode( "\n", trim( $out ) ) ) ) );
			$data  = $lines ? json_decode( end( $lines ), true ) : null;
			if ( is_array( $data ) && empty( $data['is_error'] ) && ( ! isset( $data['subtype'] ) || 'success' === $data['subtype'] ) && isset( $data['result'] ) ) {
				$u = (array) ( $data['usage'] ?? array() );
				return array( 'ok' => true, 'text' => (string) $data['result'], 'usage' => array( 'in' => (int) ( $u['input_tokens'] ?? 0 ), 'out' => (int) ( $u['output_tokens'] ?? 0 ) ) );
			}
			$why = is_array( $data ) ? (string) ( $data['result'] ?? ( $data['subtype'] ?? '' ) ) : '';
			$e   = self::classify( $engine, array( 'code' => $code, 'out' => $why . "\n" . $out, 'err' => $err ) );
			if ( 'MEMORY' === $e['code'] && AAW_Proc::limits_text( $dir ) ) {
				$e['msg'] .= "\n" . AAW_Proc::limits_text( $dir );
			}
			return array( 'ok' => false, 'code' => $e['code'], 'error' => $e['msg'] . ( $e['detail'] ? "\nجزئیات: " . mb_substr( $e['detail'], -300 ) : '' ) );
		}
		self::codex_after();
		$events = '';
		foreach ( explode( "\n", $out ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || '{' !== $line[0] ) {
				continue;
			}
			$ev = json_decode( $line, true );
			if ( is_array( $ev ) && in_array( $ev['type'] ?? '', array( 'error', 'turn.failed' ), true ) ) {
				$events .= ' ' . (string) ( $ev['message'] ?? ( $ev['error']['message'] ?? '' ) );
			}
		}
		if ( ! empty( $job['ctx']['img_out'] ) ) {
			$file = self::find_image( $dir . '/' . $job['ctx']['img_out'], (int) $job['ctx']['t_ask'] );
			if ( $file ) {
				$bin = (string) file_get_contents( $file ); // phpcs:ignore
				$mime = preg_match( '/\.jpe?g$/i', $file ) ? 'image/jpeg' : ( preg_match( '/\.webp$/i', $file ) ? 'image/webp' : 'image/png' );
				return array( 'ok' => true, 'image' => array( 'base64' => base64_encode( $bin ), 'mime' => $mime, 'engine' => 'sub_codex' ) ); // phpcs:ignore
			}
		} else {
			$text = trim( AAW_Proc::read( $dir, 'last.txt' ) );
			if ( '' !== $text && 0 === $code ) {
				return array( 'ok' => true, 'text' => $text, 'usage' => array( 'in' => 0, 'out' => 0 ) );
			}
		}
		$e = self::classify( $engine, array( 'code' => $code, 'out' => $events . "\n" . $out, 'err' => $err ) );
		if ( 'MEMORY' === $e['code'] && AAW_Proc::limits_text( $dir ) ) {
			$e['msg'] .= "\n" . AAW_Proc::limits_text( $dir );
		}
		if ( 'RUN_FAILED' === $e['code'] && ! empty( $job['ctx']['img_out'] ) ) {
			$e['msg'] = 'Codex تصویری نساخت. ' . $e['msg'];
		}
		return array( 'ok' => false, 'code' => $e['code'], 'error' => $e['msg'] . ( $e['detail'] ? "\nجزئیات: " . mb_substr( $e['detail'], -300 ) : '' ) );
	}

	/** The image Codex saved: the requested file, else the newest one in its generated_images folder. */
	private static function find_image( $target, $since ) {
		if ( file_exists( $target ) && filesize( $target ) > 200 ) {
			return $target;
		}
		$best = null;
		$gen  = self::codex_home() . '/generated_images';
		if ( is_dir( $gen ) ) {
			$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $gen, FilesystemIterator::SKIP_DOTS ) );
			foreach ( $it as $f ) {
				if ( preg_match( '/\.(png|jpe?g|webp)$/i', $f->getFilename() ) && $f->getMTime() >= $since - 2 && ( ! $best || $f->getMTime() > $best[1] ) ) {
					$best = array( $f->getPathname(), $f->getMTime() );
				}
			}
		}
		return $best ? $best[0] : '';
	}

	/* ---------- the tasks (same behaviour as the GitHub runner) ---------- */

	/** @return bool true = call again (no program running). */
	private static function step( array $job, $res ) {
		$t   = $job['trigger'];
		$fn  = in_array( $t, array( 'test', 'analyze', 'revise', 'image', 'seo_learn' ), true ) ? 'task_' . $t : 'task_generate';
		$job = self::$fn( $job, $res );
		if ( null === $job ) {
			return true; // Finished (already stored).
		}
		self::store( $job );
		return '' === $job['run'];
	}

	private static function fail_ask( array $job, $started ) {
		// ask() returned an error instead of starting: claimed topics are released as failed.
		$topics = array();
		if ( ! empty( $job['payload']['jobs'] ) ) {
			foreach ( array_slice( (array) $job['payload']['jobs'], (int) ( $job['ctx']['i'] ?? 0 ) ) as $j ) {
				$topics[] = (int) $j['topic']['id'];
			}
		}
		self::finish( $job, false, $started['error'], array(), $topics );
		return null;
	}

	private static function task_test( array $job, $res ) {
		if ( null === $res ) {
			$job['step'] = 'ارسال پیام آزمایشی';
			$s           = self::ask( $job, 'test', 'You are a connectivity test.', 'Reply with exactly: OK' );
			return $s ? self::fail_ask( $job, $s ) : $job;
		}
		$ms = ( time() - (int) $job['created'] ) * 1000;
		if ( $res['ok'] ) {
			self::set_state( $job['engine'], array( 'state' => 'ok', 'last_ok' => time(), 'test' => array( 'ok' => true, 'text' => mb_substr( trim( $res['text'] ), 0, 60 ), 'sec' => (int) round( $ms / 1000 ), 'at' => time() ) ) );
			self::finish( $job, true, 'پاسخ: «' . mb_substr( trim( $res['text'] ), 0, 40 ) . '»' );
		} else {
			self::set_state( $job['engine'], array( 'test' => array( 'ok' => false, 'text' => $res['error'], 'at' => time() ) ) );
			self::finish( $job, false, $res['error'] );
		}
		return null;
	}

	private static function task_revise( array $job, $res ) {
		$p = $job['payload'];
		if ( null === $res ) {
			$job['step'] = 'ارسال مقاله و دستور اصلاح';
			$s           = self::ask( $job, 'write', (string) ( $p['system'] ?? '' ), (string) ( $p['prompt'] ?? '' ) );
			return $s ? self::fail_ask( $job, $s ) : $job;
		}
		if ( ! $res['ok'] ) {
			self::finish( $job, false, $res['error'] );
			return null;
		}
		$article = self::parse_json( $res['text'] );
		if ( ( ! $article || empty( $article['content_html'] ) ) && 'write' === $job['ctx']['await'] ) {
			$job['step'] = 'تبدیل خروجی به ساختار مقاله';
			$s           = self::ask( $job, 'fix', 'Convert into ONE valid JSON object with keys: title, seo_title, meta_description, focus_keyword, excerpt, content_html, faq. JSON only.', mb_substr( $res['text'], 0, 60000 ) );
			return $s ? self::fail_ask( $job, $s ) : $job;
		}
		if ( ! $article || empty( $article['content_html'] ) ) {
			self::finish( $job, false, 'خروجی اصلاح قابل پردازش نبود.' );
			return null;
		}
		$article['_meta'] = array( 'provider' => 'sub_' . $job['engine'], 'runner' => 'local' );
		self::finish( $job, true, '', array( 'revisions' => array( array( 'post_id' => (int) ( $p['post_id'] ?? 0 ), 'article' => $article, 'request_id' => (string) ( $p['request_id'] ?? '' ) ) ) ) );
		return null;
	}

	private static function task_image( array $job, $res ) {
		$p = $job['payload'];
		if ( 'codex' !== $job['engine'] ) {
			self::finish( $job, false, 'ساخت تصویر فقط با اکانت ChatGPT (Codex) ممکن است.' );
			return null;
		}
		if ( null === $res ) {
			$job['ctx']['refs']   = self::ref_files( $job );
			$job['ctx']['inline'] = array();
			$job['ctx']['k']      = -1;
			$job['step']          = 'ارسال عکس‌های مرجع و متن مقاله به ChatGPT برای ساخت تصویر شاخص';
			$s                    = self::ask( $job, 'featured', '', self::image_task( $p, (string) ( $p['prompt'] ?? '' ), count( $job['ctx']['refs'] ) ), array( 'image' => true, 'refs' => $job['ctx']['refs'], 'out' => 'featured.png' ) );
			return $s ? self::fail_ask( $job, $s ) : $job;
		}
		if ( 'featured' === $job['ctx']['await'] ) {
			if ( ! $res['ok'] ) {
				self::finish( $job, false, $res['error'] );
				return null;
			}
			$res['image']['refs_used'] = count( $job['ctx']['refs'] );
			$job['ctx']['image']       = $res['image'];
		} elseif ( $res['ok'] ) {
			$it                     = $p['inline'][ $job['ctx']['k'] ];
			$job['ctx']['inline'][] = array_merge( $res['image'], array( 'alt' => (string) ( $it['alt'] ?? '' ), 'after_h2' => (int) ( $it['after_h2'] ?? 0 ) ) );
		} elseif ( 'QUOTA' === $res['code'] ) {
			$job['ctx']['k'] = PHP_INT_MAX - 1; // Stop the inline images; keep what we have.
		}
		$job['ctx']['k']++;
		$inl = (array) ( $p['inline'] ?? array() );
		if ( $job['ctx']['k'] < count( $inl ) ) {
			$it          = $inl[ $job['ctx']['k'] ];
			$job['step'] = 'تصویر داخل متن ' . ( $job['ctx']['k'] + 1 ) . ' از ' . count( $inl );
			$s           = self::ask( $job, 'inline', '', self::image_task( $p, (string) $it['prompt'], count( $job['ctx']['refs'] ) ), array( 'image' => true, 'refs' => $job['ctx']['refs'], 'out' => 'inline-' . $job['ctx']['k'] . '.png' ) );
			if ( ! $s ) {
				return $job;
			}
		}
		$data = array( 'images' => array( array( 'post_id' => (int) ( $p['post_id'] ?? 0 ), 'topic_id' => (int) ( $p['topic_id'] ?? 0 ), 'image' => $job['ctx']['image'], 'inline' => $job['ctx']['inline'], 'prompt' => (string) ( $p['prompt'] ?? '' ), 'replace_inline' => ! empty( $p['replace_inline'] ) ) ) );
		self::cleanup_refs( $job );
		self::finish( $job, true, 'تصویر' . ( $job['ctx']['inline'] ? ' و ' . count( $job['ctx']['inline'] ) . ' تصویر داخل متن' : '' ) . ' با ' . count( $job['ctx']['refs'] ) . ' عکس مرجع ساخته شد.', $data );
		return null;
	}

	/** The message sent with the reference photos — editable in «تنظیمات تصاویر». */
	public static function image_task( array $p, $prompt, $nrefs ) {
		$text = "Use your built-in image generation (\$imagegen skill / image_gen tool) to create exactly ONE image.\n" . self::image_message( $p, $prompt, $nrefs );
		if ( $nrefs ) {
			$text .= "\nThe attached images are references: product photos first (keep the exact product, packaging, label and colors), then sample images from previous articles (match their composition, color palette, lighting and mood).";
		}
		return $text . "\nNo text, letters or watermark in the image unless the instructions above ask for it.";
	}

	/** The editable message (Persian by default) with the article's details filled in. */
	public static function image_message( array $p, $prompt, $nrefs = 0 ) {
		$post_id = (int) ( $p['post_id'] ?? 0 );
		$tpl     = trim( (string) AAW_Settings::get( 'image_chat_prompt' ) );
		if ( '' === $tpl ) {
			$tpl = self::default_image_prompt();
		}
		$summary = '';
		if ( $post_id && get_post( $post_id ) ) {
			$summary = mb_substr( trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) get_post_field( 'post_content', $post_id ) ) ) ), 0, 1500 );
		}
		$names = implode( '، ', (array) ( $p['refs']['product_names'] ?? array() ) );
		$repl  = array(
			'{title}'       => $post_id ? get_the_title( $post_id ) : '',
			'{keyword}'     => $post_id ? (string) get_post_meta( $post_id, '_aaw_focus_keyword', true ) : '',
			'{description}' => $prompt,
			'{article}'     => $summary,
			'{products}'    => $names,
			'{style}'       => (string) AAW_Settings::get( 'image_style' ),
			'{refs}'        => (string) $nrefs,
		);
		return strtr( $tpl, $repl );
	}

	public static function default_image_prompt() {
		return "سلام! برای مقاله‌ای با عنوان «{title}» (کلمه کلیدی: {keyword}) یک تصویر شاخص می‌خواهم.\nتوضیح تصویر: {description}\nعکس‌های پیوست، عکس محصولات ما ({products}) و نمونه تصاویری است که برای مقاله‌های قبلی ساخته‌ایم. دقیقاً با همین محصولات (بسته‌بندی، برچسب و رنگ واقعی) و در همان سبک نمونه‌ها بساز.\nخلاصه متن مقاله:\n{article}\nسبک: {style}";
	}

	/** Reference images as local files: chosen product photos + related products + style samples. */
	private static function ref_files( array $job ) {
		$p     = $job['payload'];
		$dir   = AAW_Proc::private_dir( 'runs' ) . '/refs-' . $job['id'];
		wp_mkdir_p( $dir );
		$files = array();
		$i     = 0;
		$max   = max( 1, min( 10, (int) AAW_Settings::get( 'image_max_refs' ) ) );
		foreach ( array_merge( (array) ( $p['refs']['products'] ?? array() ), (array) ( $p['refs']['styles'] ?? array() ) ) as $r ) {
			if ( count( $files ) >= $max ) {
				break;
			}
			$bin = '';
			if ( ! empty( $r['id'] ) && get_attached_file( (int) $r['id'] ) && file_exists( get_attached_file( (int) $r['id'] ) ) ) {
				$src = AAW_Images::ref_from_attachment( (int) $r['id'] ); // Resized JPEG copy.
				$bin = ! empty( $src['b64'] ) ? base64_decode( $src['b64'] ) : (string) @file_get_contents( get_attached_file( (int) $r['id'] ) ); // phpcs:ignore
			} elseif ( ! empty( $r['b64'] ) ) {
				$bin = (string) base64_decode( $r['b64'] ); // phpcs:ignore
			} elseif ( ! empty( $r['url'] ) && 0 === strpos( $r['url'], home_url() ) ) {
				$up   = wp_upload_dir( null, false );
				$path = str_replace( trailingslashit( $up['baseurl'] ), trailingslashit( $up['basedir'] ), $r['url'] );
				$bin  = file_exists( $path ) ? (string) file_get_contents( $path ) : ''; // phpcs:ignore
			}
			if ( strlen( $bin ) > 100 ) {
				$f = $dir . '/ref-' . ( $i++ ) . '.jpg';
				file_put_contents( $f, $bin ); // phpcs:ignore
				$files[] = $f;
			}
		}
		return $files;
	}

	private static function cleanup_refs( array $job ) {
		AAW_Proc::rrmdir( AAW_Proc::private_dir( 'runs' ) . '/refs-' . $job['id'] );
	}

	private static function task_analyze( array $job, $res ) {
		$a = $job['payload'];
		if ( null === $res ) {
			$prompt = (string) ( $a['prompt'] ?? '' );
			$extra  = 0;
			if ( ! empty( $a['gsc'] ) && AAW_Cloudflare::is_deployed() ) {
				$g = AAW_Cloudflare::call_worker( 'gsc', array( 'action' => 'text', 'site' => (string) $a['gsc'] ), 25 );
				if ( ! is_wp_error( $g ) && ! empty( $g['text'] ) ) {
					$prompt .= $g['text'];
				}
			}
			if ( ! empty( $a['competitors'] ) && AAW_Cloudflare::is_deployed() ) {
				$c = AAW_Cloudflare::call_worker( 'competitors', array( 'urls' => array_slice( (array) $a['competitors'], 0, 5 ) ), 40 );
				if ( ! is_wp_error( $c ) && ! empty( $c['text'] ) ) {
					$prompt .= "\n\n# داده‌های واقعی جمع‌آوری‌شده از سایت رقبا" . $c['text'];
					$extra   = (int) ( $c['fetched'] ?? 0 );
				}
			}
			$job['ctx']['fetched'] = $extra;
			$job['step']           = 'تحلیل استراتژیک با هوش مصنوعی روی سرور' . ( 'claude' === $job['engine'] ? ' (با جستجوی وب)' : '' );
			$s                     = self::ask( $job, 'write', (string) ( $a['system'] ?? '' ), $prompt, array( 'web' => 'claude' === $job['engine'] ) );
			return $s ? self::fail_ask( $job, $s ) : $job;
		}
		if ( ! $res['ok'] ) {
			self::finish( $job, false, $res['error'] );
			return null;
		}
		$an = self::parse_json( $res['text'] );
		if ( ( ! $an || empty( $an['topics'] ) ) && 'write' === $job['ctx']['await'] ) {
			$job['step'] = 'تبدیل خروجی تحلیل به ساختار استاندارد';
			$s           = self::ask( $job, 'fix', 'Return the same content as ONE valid JSON object with keys summary, audience, business_type, pillars, gaps, competitors, trends, seo_notes, topics. JSON only.', mb_substr( $res['text'], 0, 60000 ) );
			return $s ? self::fail_ask( $job, $s ) : $job;
		}
		if ( ! $an || empty( $an['topics'] ) ) {
			self::finish( $job, false, 'خروجی تحلیل قابل پردازش نبود.' );
			return null;
		}
		$meta = array( 'provider' => 'sub_' . $job['engine'], 'model' => $job['model'] ? $job['model'] : ( 'claude' === $job['engine'] ? 'sonnet' : 'default' ), 'web' => 'claude' === $job['engine'], 'competitors_fetched' => (int) $job['ctx']['fetched'], 'runner' => 'local', 'ms' => ( time() - (int) $job['created'] ) * 1000, 'stats' => (array) ( $a['stats'] ?? array() ) );
		self::finish( $job, true, count( $an['topics'] ) . ' موضوع پیشنهادی', array( 'analysis' => array( 'result' => $an, 'meta' => $meta ) ) );
		return null;
	}

	private static function task_seo_learn( array $job, $res ) {
		$p = $job['payload'];
		if ( null === $res ) {
			$notes = array();
			$t0    = microtime( true );
			foreach ( array_slice( (array) ( $p['sources'] ?? array() ), 0, 8 ) as $u ) {
				if ( microtime( true ) - $t0 > 12 || ! preg_match( '#^https?://#i', (string) $u ) ) {
					break;
				}
				$r = wp_remote_get( $u, array( 'timeout' => 6, 'user-agent' => 'Mozilla/5.0 (compatible; ARIAGH-AIWRITER/1.9)' ) );
				if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
					continue;
				}
				$html  = (string) wp_remote_retrieve_body( $r );
				$title = preg_match( '#<title[^>]*>(.*?)</title>#is', $html, $m ) ? trim( wp_strip_all_tags( $m[1] ) ) : $u;
				$main  = preg_match( '#<(article|main)[^>]*>(.*?)</\1>#is', $html, $mm ) ? $mm[2] : $html;
				$text  = mb_substr( trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( preg_replace( '#<(script|style)[^>]*>.*?</\1>#is', '', $main ) ) ) ), 0, 5500 );
				if ( mb_strlen( $text ) > 400 ) {
					$notes[] = array( 'url' => $u, 'title' => mb_substr( $title, 0, 140 ), 'text' => $text );
				}
			}
			$job['ctx']['sources'] = wp_list_pluck( $notes, 'url' );
			$job['step']           = 'ساخت دستورالعمل سئو روی سرور';
			$s                     = self::ask( $job, 'write', 'You are a senior SEO strategist. Return JSON only.', self::seo_prompt( $p, $notes ), array( 'web' => 'claude' === $job['engine'] && ! empty( $p['web'] ) ) );
			return $s ? self::fail_ask( $job, $s ) : $job;
		}
		if ( ! $res['ok'] ) {
			delete_option( 'aaw_seo_learning' );
			self::finish( $job, false, $res['error'] );
			return null;
		}
		$d  = self::parse_json( $res['text'] );
		$pb = trim( (string) ( $d['playbook'] ?? '' ) );
		if ( mb_strlen( $pb ) < 300 && mb_strlen( $res['text'] ) > 300 && '{' !== substr( ltrim( $res['text'] ), 0, 1 ) ) {
			$pb = trim( $res['text'] );
		}
		if ( mb_strlen( $pb ) < 300 ) {
			delete_option( 'aaw_seo_learning' );
			self::finish( $job, false, 'دستورالعمل سئو ساخته نشد (خروجی کوتاه بود).' );
			return null;
		}
		$k = array( 'playbook' => mb_substr( $pb, 0, 9000 ), 'highlights' => array_slice( (array) ( $d['highlights'] ?? array() ), 0, 8 ), 'version' => (string) ( $d['version'] ?? gmdate( 'Y-m-d' ) ), 'sources' => (array) $job['ctx']['sources'], 'engine' => 'sub_' . $job['engine'], 'model' => $job['model'], 'at' => gmdate( 'c' ), 'store' => 'local' );
		self::finish( $job, true, 'دانش سئو ساخته شد.', array( 'seo_playbook' => $k ) );
		return null;
	}

	public static function seo_prompt( array $p, array $notes ) {
		$today = gmdate( 'Y-m-d' );
		$src   = '';
		foreach ( $notes as $n ) {
			$src .= '### ' . $n['title'] . "\n" . $n['url'] . "\n" . $n['text'] . "\n\n";
		}
		$src = $src ? mb_substr( $src, 0, 60000 ) : '(منبعی دریافت نشد؛ از دانش به‌روز خود استفاده کن و این را در highlights ذکر کن)';
		return 'امروز ' . $today . ' است. تو یک متخصص ارشد سئو هستی. از منابع زیر (راهنماهای رسمی گوگل، مقالات معتبر بین‌المللی و ایرانی)' . ( ! empty( $p['web'] ) ? ' و جستجوی زنده وب برای آخرین به‌روزرسانی‌های الگوریتم گوگل' : '' ) . ' یک «دستورالعمل فشرده و عملی نوشتن مقاله سئو» برای سایت «' . ( $p['site'] ?? '' ) . '» در حوزه «' . ( $p['niche'] ?? '' ) . '» به زبان ' . ( 'en' === ( $p['language'] ?? '' ) ? 'انگلیسی' : 'فارسی' ) . " استخراج کن.\nفقط نکاتی که در نوشتن و ساختار مقاله قابل اجراست؛ خلاصه، بدون تکرار، حداکثر ۹۰۰ کلمه. بخش‌ها: ۱) اصول محتوای مفید و E-E-A-T ۲) ساختار، عنوان، متا، سرفصل‌ها و طول ۳) کلمه کلیدی، نیت جستجو و موضوعات مرتبط (بدون Keyword stuffing) ۴) بهینه‌سازی برای AI Overviews و موتورهای پاسخ (GEO): پاسخ مستقیم، تعریف‌ها، جدول، فهرست ۵) اسکیما و FAQ ۶) لینک داخلی/خارجی و لینک به محصولات ۷) نکات خاص زبان فارسی و جستجوی کاربران ایرانی ۸) کارهای ممنوع طبق سیاست‌های اسپم گوگل ۹) چک‌لیست نهایی.\n" . 'فقط JSON: {"playbook":"متن markdown","highlights":["۵ تغییر/نکته مهم اخیر"],"version":"' . $today . "\"}\n\nمنابع:\n" . $src;
	}

	/** Articles: ideas when the queue is empty, then each topic (outline → article → JSON fix) → draft. */
	private static function task_generate( array $job, $res ) {
		$p   = $job['payload'];
		$ctx = &$job['ctx'];
		if ( null === $res && isset( $ctx['i'] ) ) {
			return self::next_article( $job ); // The previous request was lost: ask again.
		}
		if ( null === $res ) {
			$ctx['i']      = 0;
			$ctx['drafts'] = 0;
			$ctx['errors'] = 0;
			if ( 'need_topics' === ( $p['status'] ?? '' ) && ! empty( $p['ideas']['prompt'] ) ) {
				$job['step'] = 'صف خالی است: ایده‌پردازی موضوعات';
				$s           = self::ask( $job, 'ideas', 'You are an SEO content strategist. Return JSON only.', (string) $p['ideas']['prompt'] );
				return $s ? self::fail_ask( $job, $s ) : $job;
			}
			return self::next_article( $job );
		}
		$await = $ctx['await'] ?? '';
		if ( 'ideas' === $await ) {
			if ( ! $res['ok'] ) {
				self::finish( $job, false, $res['error'] );
				return null;
			}
			$d     = self::parse_json( $res['text'] );
			$ideas = array();
			foreach ( (array) ( $d['topics'] ?? ( $d['ideas'] ?? array() ) ) as $t ) {
				$t = is_string( $t ) ? array( 'title' => $t ) : (array) $t;
				if ( ! empty( $t['title'] ) ) {
					$ideas[] = $t;
				}
			}
			if ( $ideas ) {
				AAW_REST::apply_topics( array( 'topics' => $ideas ) );
			}
			$job['payload'] = AAW_REST::job_data( array( 'trigger' => 'runner', 'origin' => $job['payload']['origin'] ?? 'manual', 'no_ideas' => true ) );
			return self::next_article( $job );
		}
		$j = $p['jobs'][ $ctx['i'] ] ?? null;
		if ( ! $j ) {
			return self::next_article( $job );
		}
		if ( ! $res['ok'] ) {
			if ( 'outline' === $await && ! in_array( $res['code'], array( 'AUTH', 'QUOTA', 'NETWORK' ), true ) ) {
				$ctx['meta']['outline_error'] = $res['error'];
				return self::write_article( $job, $ctx['user'] );
			}
			AAW_REST::apply_fail( array( 'topic_id' => (int) $j['topic']['id'], 'error' => $res['error'], 'meta' => array( 'provider' => 'sub_' . $job['engine'], 'runner' => 'local' ) ) );
			$ctx['errors']++;
			if ( in_array( $res['code'], array( 'AUTH', 'QUOTA', 'NETWORK', 'MEMORY', 'NOT_FOUND' ), true ) ) {
				// The engine cannot work right now: the remaining topics go back to the queue.
				foreach ( array_slice( (array) $p['jobs'], $ctx['i'] + 1 ) as $rest ) {
					AAW_Topics::update( (int) $rest['topic']['id'], array( 'status' => 'pending', 'locked_at' => null ) );
				}
				self::finish( $job, false, $res['error'] );
				return null;
			}
			$ctx['i']++;
			return self::next_article( $job );
		}
		if ( 'outline' === $await ) {
			$o = self::parse_json( $res['text'] );
			$u = $ctx['user'];
			if ( $o && ( ! empty( $o['outline'] ) || ! empty( $o['title'] ) ) ) {
				$u                      .= "\n\nطرح کلی (Outline) مصوب که باید دقیقاً بر اساس آن بنویسی:\n" . wp_json_encode( $o, JSON_UNESCAPED_UNICODE );
				$ctx['meta']['outline'] = true;
			}
			return self::write_article( $job, $u );
		}
		$article = self::parse_json( $res['text'] );
		if ( ( ! $article || empty( $article['content_html'] ) ) && 'write' === $await ) {
			$ctx['raw']  = mb_substr( $res['text'], 0, 60000 );
			$job['step'] = 'تبدیل خروجی به ساختار مقاله';
			$s           = self::ask( $job, 'fix', 'Convert the article into ONE valid JSON object with keys: title, seo_title, meta_description, slug, focus_keyword, secondary_keywords, tags, category, excerpt, content_html, faq, image_prompt, image_alt. Return JSON only.', $ctx['raw'] );
			return $s ? self::fail_ask( $job, $s ) : $job;
		}
		if ( ! $article || empty( $article['content_html'] ) ) {
			$raw = 'fix' === $await ? (string) ( $ctx['raw'] ?? '' ) : $res['text'];
			if ( preg_match( '/<(p|h2|ul)\b/i', $raw ) ) {
				$article = array( 'title' => $j['topic']['title'], 'content_html' => $raw );
			}
		}
		if ( ! $article || empty( $article['content_html'] ) ) {
			AAW_REST::apply_fail( array( 'topic_id' => (int) $j['topic']['id'], 'error' => 'خروجی مدل قابل تبدیل به مقاله نبود.', 'meta' => array( 'runner' => 'local' ) ) );
			$ctx['errors']++;
		} else {
			$meta = array_merge( (array) ( $ctx['meta'] ?? array() ), array( 'provider' => 'sub_' . $job['engine'], 'model' => $job['model'] ? $job['model'] : ( 'claude' === $job['engine'] ? 'sonnet' : 'default' ), 'runner' => 'local', 'duration_ms' => ( time() - (int) ( $ctx['t_job'] ?? $job['created'] ) ) * 1000 ) );
			$x    = AAW_REST::apply_draft( array( 'topic_id' => (int) $j['topic']['id'], 'article' => $article, 'meta' => $meta ) );
			if ( is_wp_error( $x ) ) {
				$ctx['errors']++;
				AAW_Logs::add( 'error', 'local', $x->get_error_message() );
			} else {
				$ctx['drafts']++;
				$pid = (int) ( $x['post_id'] ?? 0 );
				// Article images with an API engine run on Cloudflare (the ChatGPT engine is started by after_draft()).
				if ( $pid && ! empty( $p['runtime']['image']['enabled'] ) && 'sub_codex' !== AAW_Images::engine() && AAW_Settings::get( 'featured_image' ) && ! has_post_thumbnail( $pid ) && AAW_BG::available() ) {
					AAW_Revise::request_image( $pid, (string) ( $article['image_prompt'] ?? '' ), (int) AAW_Settings::get( 'image_inline_count' ) > 0 );
				}
			}
		}
		$ctx['i']++;
		return self::next_article( $job );
	}

	private static function next_article( array $job ) {
		$p   = $job['payload'];
		$ctx = &$job['ctx'];
		if ( 'ok' !== ( $p['status'] ?? '' ) || empty( $p['jobs'][ $ctx['i'] ] ) ) {
			$ok = $ctx['drafts'] > 0 || ( 0 === $ctx['errors'] && 'ok' !== ( $p['status'] ?? '' ) );
			$msg = $ctx['drafts'] ? $ctx['drafts'] . ' پیش‌نویس ساخته شد' . ( $ctx['errors'] ? '، ' . $ctx['errors'] . ' خطا' : '' ) : ( 'ok' !== ( $p['status'] ?? '' ) ? (string) ( $p['reason'] ?? 'کاری برای انجام نبود.' ) : 'مقاله‌ای ساخته نشد.' );
			self::finish( $job, $ok, $msg );
			return null;
		}
		$j            = $p['jobs'][ $ctx['i'] ];
		$ctx['meta']  = array();
		$ctx['t_job'] = time();
		$user         = (string) $j['prompts']['user'];
		if ( false === strpos( $user, self::CTX_MARK ) ) {
			$user .= self::site_context( (string) $j['topic']['title'], $j['topic']['keywords'] ?? '', (string) $j['prompts']['system'] . $user );
		}
		$ctx['user'] = $user;
		$n           = count( $p['jobs'] ) > 1 ? ' (' . ( $ctx['i'] + 1 ) . ' از ' . count( $p['jobs'] ) . ')' : '';
		if ( ! empty( $p['runtime']['params']['two_pass'] ) && ! empty( $j['prompts']['outline'] ) ) {
			$job['step'] = 'طرح کلی مقاله «' . $j['topic']['title'] . '»' . $n;
			$s           = self::ask( $job, 'outline', (string) $j['prompts']['system'], (string) $j['prompts']['outline'] );
			return $s ? self::fail_ask( $job, $s ) : $job;
		}
		$job['step'] = 'نوشتن مقاله «' . $j['topic']['title'] . '»' . $n;
		return self::write_article( $job, $user );
	}

	private static function write_article( array $job, $user ) {
		$j = $job['payload']['jobs'][ $job['ctx']['i'] ];
		if ( 'outline' === ( $job['ctx']['await'] ?? '' ) ) {
			$job['step'] = 'نوشتن مقاله «' . $j['topic']['title'] . '»';
		}
		$s = self::ask( $job, 'write', (string) $j['prompts']['system'], $user );
		return $s ? self::fail_ask( $job, $s ) : $job;
	}

	/** Real site data for the article (same block the GitHub runner adds from the site backup). */
	public static function site_context( $title, $keywords, $existing = '' ) {
		$kw    = is_array( $keywords ) ? implode( ' ', $keywords ) : (string) $keywords;
		$lines = array();
		$dups  = array();
		$rel   = array();
		foreach ( AAW_Dedupe::nearest( $title, $kw, 10, array( 'post' ) ) as $p ) {
			if ( 'publish' !== $p['status'] ) {
				continue;
			}
			$row = '- ' . $p['title'] . ' => ' . get_permalink( (int) $p['id'] );
			if ( $p['score'] >= 0.7 && count( $dups ) < 3 ) {
				$dups[] = $row;
			} elseif ( $p['score'] >= 0.12 && count( $rel ) < 6 ) {
				$rel[] = $row;
			}
		}
		if ( $dups ) {
			$lines[] = "هشدار تکرار: این مقاله‌ها موضوع بسیار نزدیکی دارند. مقاله تکراری ننویس؛ زاویه و نیت جستجوی متفاوتی انتخاب کن و به آن‌ها لینک بده:\n" . implode( "\n", $dups );
		}
		if ( $rel && false === strpos( $existing, '## لینک‌سازی داخلی' ) ) {
			$lines[] = "### مقالات مرتبط موجود برای لینک داخلی (۲ تا ۴ لینک با انکر طبیعی و دقیقاً همین آدرس‌ها)\n" . implode( "\n", $rel );
		}
		$cats = array();
		$q    = AAW_Dedupe::tokens( $title . ' ' . $kw );
		foreach ( get_categories( array( 'hide_empty' => true, 'number' => 200 ) ) as $c ) {
			$s = AAW_Dedupe::score( $q, AAW_Dedupe::tokens( $c->name ) );
			if ( $s > 0 ) {
				$cats[] = array( $s, '- ' . $c->name . ' => ' . get_category_link( $c->term_id ) );
			}
		}
		usort( $cats, function ( $a, $b ) { return $b[0] <=> $a[0]; } );
		if ( $cats ) {
			$lines[] = "### دسته‌بندی‌های مرتبط\n" . implode( "\n", wp_list_pluck( array_slice( $cats, 0, 3 ), 1 ) );
		}
		if ( ! $lines ) {
			return '';
		}
		return "\n" . self::CTX_MARK . ' (مستقیم از پایگاه داده سایت، ' . wp_date( 'Y-m-d' ) . ")\n" . implode( "\n", $lines ) . "\nهیچ آدرسی از خودت نساز؛ فقط از آدرس‌های بالا استفاده کن.\n";
	}

	/** End a job: hand the results to the same code that handles GitHub results. */
	private static function finish( array $job, $ok, $detail = '', array $data = array(), array $topics = array() ) {
		if ( ! $ok ) {
			$data['fatal'] = $detail ? $detail : 'خطای نامشخص';
		}
		$job['status'] = $ok ? 'done' : 'error';
		$job['error']  = $ok ? '' : $data['fatal'];
		$job['step']   = $ok ? ( $detail ? $detail : 'انجام شد' ) : 'خطا';
		$job['run']    = '';
		unset( $job['payload']['jobs'] ); // Keep the stored job small.
		self::store( $job );
		if ( ! empty( $job['op'] ) ) {
			AAW_Activity::finish( $job['op'], $ok, $ok ? $detail : AAW_Errors::explain( (string) $data['fatal'] ) );
		}
		if ( 'test' !== $job['trigger'] ) {
			AAW_Pull::ingest( $job['id'], $data, array( 'kind' => $job['kind'], 'post_id' => $job['post_id'], 'topics' => $topics ) );
		}
		AAW_Logs::add( $ok ? 'success' : 'error', 'local', $job['label'] . ' (مستقیم روی سرور): ' . ( $ok ? $detail : $data['fatal'] ) );
	}

	/* ============================================================ JSON from model text */

	public static function parse_json( $text ) {
		$t = trim( preg_replace( '#<think>.*?</think>#is', '', (string) $text ) );
		$t = preg_replace( '/^\xEF\xBB\xBF/', '', $t );
		if ( preg_match( '/```(?:json)?\s*(.*?)```/is', $t, $m ) ) {
			$t = trim( $m[1] );
		}
		$a = strpos( $t, '{' );
		$b = strrpos( $t, '}' );
		if ( false === $a || false === $b || $b <= $a ) {
			return null;
		}
		$c = substr( $t, $a, $b - $a + 1 );
		$j = json_decode( $c, true );
		if ( is_array( $j ) ) {
			return $j;
		}
		// Repair raw newlines inside strings and trailing commas.
		$out = '';
		$in  = false;
		$esc = false;
		$len = strlen( $c );
		for ( $i = 0; $i < $len; $i++ ) {
			$ch = $c[ $i ];
			if ( $in ) {
				if ( $esc ) {
					$esc  = false;
					$out .= $ch;
					continue;
				}
				if ( '\\' === $ch ) {
					$esc  = true;
					$out .= $ch;
					continue;
				}
				if ( '"' === $ch ) {
					$in = false;
				} elseif ( "\n" === $ch ) {
					$out .= '\\n';
					continue;
				} elseif ( "\r" === $ch ) {
					continue;
				} elseif ( "\t" === $ch ) {
					$out .= '\\t';
					continue;
				}
				$out .= $ch;
			} else {
				if ( '"' === $ch ) {
					$in = true;
				}
				$out .= $ch;
			}
		}
		$j = json_decode( preg_replace( '/,\s*([}\]])/', '$1', $out ), true );
		return is_array( $j ) ? $j : null;
	}
}

/** Remove secrets from logs before they are saved or shown. */
class AAW_Errors_Redact {
	public static function clean( $s ) {
		$s = preg_replace( '/sk-ant-[A-Za-z0-9_\-]{10,}/', 'sk-ant-***', (string) $s );
		$s = preg_replace( '/(eyJ[A-Za-z0-9_\-]{10,}\.)[A-Za-z0-9_\-\.]+/', '$1***', $s );
		$s = preg_replace( '/("?(access_token|refresh_token|id_token|api_key|token)"?\s*[:=]\s*"?)[^"\s,]+/i', '$1***', $s );
		return preg_replace( "/\x1b\[[0-9;?]*[A-Za-z]/", '', $s );
	}
}
