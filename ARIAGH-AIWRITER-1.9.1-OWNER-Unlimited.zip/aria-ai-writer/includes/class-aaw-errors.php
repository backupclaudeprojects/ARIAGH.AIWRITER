<?php
/**
 * Error explainer: turns raw technical errors (cURL, HTTP, Cloudflare, AI providers,
 * GitHub, PHP) into an exact cause + fix in Persian, and runs live network probes
 * for connection errors so the reported cause is measured, not guessed.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Errors {

	const MARK = 'علت:';

	/** @var callable|null DNS resolver override (tests). */
	public static $resolver = null;

	/** cURL / transport errors that warrant a live network diagnosis. */
	const NET_CODES = array( 5, 6, 7, 28, 35, 52, 55, 56, 92 );

	/**
	 * Rules: [ regex, title, cause, fix ].
	 */
	private static function rules() {
		return array(
			// ---------------- Transport (cURL) ----------------
			array( '/cURL error 6\b|Could not resolve host|getaddrinfo|Name or service not known/i', 'آدرس مقصد پیدا نشد (خطای DNS)', 'سرور سایت شما نتوانست IP دامنه مقصد را پیدا کند؛ یا آدرس اشتباه است، یا DNS هاست/سیستم شما کار نمی‌کند، یا دامنه در شبکه شما فیلتر شده است.', 'آدرس را بررسی کنید. اگر آدرس workers.dev است و در شبکه ایران مسدود است، در تب کلادفلر یک «دامنه اختصاصی ورکر» وصل کنید. روی لوکال، اینترنت/DNS سیستم را بررسی کنید.' ),
			array( '/cURL error 7\b|Failed to connect|Connection refused|couldn\'t connect/i', 'اتصال به مقصد برقرار نشد', 'سرور شما اصلاً نتوانست به مقصد وصل شود؛ معمولاً فایروال هاست ترافیک خروجی (پورت 443) را بسته، یا مقصد در شبکه شما فیلتر است.', 'از هاست بخواهید ترافیک خروجی HTTPS به *.workers.dev و api.cloudflare.com را باز کند، یا دامنه اختصاصی ورکر بسازید.' ),
			array( '/cURL error 28\b|Operation timed out|timed out after|Connection timed out/i', 'زمان انتظار تمام شد (Timeout)', 'پاسخ در مهلت تعیین‌شده نرسید؛ یا شبکه کند/فیلتر است یا کار (مثل تحلیل با هوش مصنوعی) طولانی‌تر از محدودیت هاست/شبکه شما طول کشید.', 'افزونه را به آخرین نسخه به‌روز کنید و «استقرار مجدد» ورکر را بزنید (اتصال زنده برای کارهای طولانی). اگر باز تکرار شد، مدل سریع‌تر یا تعداد موضوع کمتر انتخاب کنید.' ),
			array( '/cURL error 35\b|SSL connect error|OpenSSL SSL_connect|unexpected eof while reading|SSL_ERROR_SYSCALL/i', 'دست‌دهی امن SSL قطع شد', 'اتصال رمزنگاری‌شده در مرحله شروع قطع شد؛ این الگو معمولاً نشانه فیلترینگ/DPI روی دامنه مقصد یا OpenSSL خیلی قدیمی روی سرور است.', 'دامنه اختصاصی ورکر (روی دامنه خودتان در کلادفلر) بسازید؛ اگر روی لوکال هستید OpenSSL/cURL (نسخه XAMPP/PHP) را به‌روز کنید.' ),
			array( '/cURL error 52\b|Empty reply from server/i', 'مقصد اتصال را بدون هیچ پاسخی بست (Empty reply)', 'اتصال برقرار شد ولی قبل از رسیدن حتی یک بایت پاسخ، از سمت مقابل یا یک واسط (پراکسی/فایروال هاست، VPN، فیلترینگ) بسته شد. رایج‌ترین حالت: درخواست طولانی (مثل تحلیل هوشمند) و قطع اتصال‌های بی‌فعالیت توسط شبکه.', 'نسخه 1.6 به بعد کارهای طولانی را در پس‌زمینه کلادفلر اجرا می‌کند (فقط درخواست‌های کوتاه): افزونه را به‌روز و در تب کلادفلر «استقرار مجدد» را بزنید.' ),
			array( '/cURL error 56\b|Recv failure|Connection reset|connection was reset/i', 'اتصال وسط کار قطع (Reset) شد', 'در حین دریافت پاسخ، اتصال از سمت شبکه/مقصد ریست شد؛ معمولاً فیلترینگ، VPN ناپایدار یا فایروال هاست.', 'دامنه اختصاصی ورکر بسازید یا از هاست بپرسید آیا اتصال‌های خروجی طولانی را قطع می‌کند؛ سپس «استقرار مجدد» ورکر.' ),
			array( '/cURL error 60\b|SSL certificate problem|certificate verify failed|unable to get local issuer/i', 'گواهی SSL مقصد تایید نشد', 'فهرست گواهی‌های معتبر (CA) روی سرور شما قدیمی یا ناقص است.', 'وردپرس و PHP را به‌روز کنید. روی XAMPP/لوکال در php.ini مقدار curl.cainfo و openssl.cafile را به فایل cacert.pem معتبر بدهید.' ),
			array( '/cURL error 77\b|error setting certificate verify locations/i', 'فایل گواهی‌های CA روی سرور پیدا نشد', 'مسیر فایل CA در تنظیمات PHP اشتباه است.', 'در php.ini مسیر curl.cainfo را اصلاح کنید یا خالی بگذارید تا وردپرس از فایل داخلی خودش استفاده کند.' ),
			array( '/cURL error 18\b|transfer closed with/i', 'پاسخ ناقص دریافت شد', 'اتصال قبل از کامل شدن پاسخ بسته شد.', 'دوباره تلاش کنید؛ اگر تکرار شد، ورکر را «استقرار مجدد» کنید.' ),
			array( '/cURL error 47\b|Maximum \(\d+\) redirects/i', 'تغییر مسیر بی‌پایان', 'آدرس مقصد مدام به آدرس دیگری ریدایرکت می‌شود.', 'آدرس REST سایت و ورکر را بررسی کنید (http/https و www).' ),
			array( '/cURL error (5|97)\b|proxy/i', 'مشکل پراکسی سرور', 'وردپرس برای اتصال به بیرون از پراکسی (WP_PROXY_HOST) استفاده می‌کند و پراکسی پاسخ نمی‌دهد.', 'تنظیمات WP_PROXY_* در wp-config.php را بررسی یا حذف کنید.' ),
			array( '/User has blocked requests through HTTP|WP_HTTP_BLOCK_EXTERNAL/i', 'وردپرس درخواست‌های خارجی را مسدود کرده است', 'در wp-config.php ثابت WP_HTTP_BLOCK_EXTERNAL فعال است.', 'آن را حذف کنید یا دامنه‌ها را در WP_ACCESSIBLE_HOSTS اضافه کنید: *.workers.dev,api.cloudflare.com,api.github.com' ),
			array( '/A valid URL was not provided/i', 'آدرس مقصد نامعتبر است', 'آدرس ورکر/سرور خالی یا اشتباه ذخیره شده است.', 'در تب کلادفلر «استقرار مجدد» بزنید یا آدرس ورکر دستی را درست وارد کنید.' ),

			// ---------------- Cloudflare edge codes ----------------
			array( '/error code:\s*1016|\b1016\b.*origin/i', 'کلادفلر به سایت شما نرسید (Origin DNS error 1016)', 'دامنه سایت شما در DNS عمومی به جایی اشاره نمی‌کند یا سایت لوکال/خصوصی است و از اینترنت در دسترس نیست.', 'اگر سایت لوکال یا پشت فایروال است، در تب کلادفلر حالت «اتصال معکوس» را انتخاب کنید؛ در غیر این صورت رکورد DNS دامنه را درست کنید.' ),
			array( '/error code:\s*1101|Worker threw exception/i', 'ورکر هنگام اجرا خطا داد (1101)', 'کد ورکر یک استثنای مدیریت‌نشده داشت؛ معمولاً ورکر قدیمی است یا Binding ها ناقص‌اند.', 'در تب کلادفلر «استقرار مجدد» را بزنید و در صورت تکرار، گزارش Cloudflare → Workers → Logs را ببینید.' ),
			array( '/error code:\s*1102|exceeded (its )?(CPU|resource) limit|Worker exceeded/i', 'ورکر از سقف CPU پلن رایگان عبور کرد (1102)', 'پردازش یک درخواست بیش از سقف CPU پلن رایگان Workers طول کشید (معمولاً پردازش پاسخ خیلی بزرگ).', 'تعداد موضوع/طول مقاله را کمتر کنید یا پلن Workers Paid (۵ دلار) را فعال کنید.' ),
			array( '/error code:\s*1015|rate limited/i', 'کلادفلر درخواست‌ها را محدود کرد (1015)', 'تعداد درخواست‌ها در زمان کوتاه زیاد بوده است.', 'چند دقیقه صبر کنید و دوباره تلاش کنید.' ),
			array( '/error code:\s*10(20|10|12)|Access denied/i', 'فایروال کلادفلر سایت شما درخواست را مسدود کرد', 'WAF، Bot Fight Mode یا قانون امنیتی روی دامنه سایت شما درخواست ورکر را بلاک کرده است.', 'در Cloudflare → Security برای مسیر /wp-json/aaw/v1/ استثنا بسازید و Bot Fight Mode را برای آن خاموش کنید.' ),
			array( '/HTTP (520|521|522|523|524)\b|error code:\s*52[0-4]/i', 'کلادفلر از سرور سایت پاسخ نگرفت (52x)', 'سرور هاست شما خاموش، کند یا درخواست را رد کرده است (524 = پاسخ بیش از ۱۰۰ ثانیه طول کشید).', 'وضعیت هاست را بررسی کنید؛ برای 524 مقدار max_execution_time و منابع هاست را افزایش دهید.' ),

			// ---------------- Worker / plugin protocol ----------------
			array( '/Signature expired|timestamp|clock|expired request|Request expired|زمان.*(سرور|ساعت)/iu', 'ساعت سرور شما با زمان واقعی اختلاف دارد', 'درخواست‌ها برای امنیت فقط ۵ دقیقه معتبرند و ساعت سرور/سیستم شما بیش از این اختلاف دارد.', 'ساعت و منطقه زمانی سرور یا کامپیوتر (برای لوکال) را با اینترنت همگام کنید.' ),
			array( '/Invalid signature|Bad signature|Missing signature|missing shared secret|signature mismatch|امضا.*(نامعتبر|اشتباه)/iu', 'امضای امنیتی درخواست تایید نشد', 'کلید امضای مشترک بین وردپرس و ورکر یکسان نیست (مثلاً افزونه دوباره نصب شده یا کلید عوض شده).', 'در تب کلادفلر «استقرار مجدد» را بزنید تا کلید دوباره هماهنگ شود.' ),
			array( '/IP مجاز نیست/u', 'IP ورکر در فهرست مجاز نیست', 'در تنظیمات امنیتی افزونه محدودیت IP فعال است و IP کلادفلر در آن نیست.', 'در تب ابزارها فیلد «IPهای مجاز REST» را خالی کنید (IPهای کلادفلر ثابت نیستند).' ),
			array( '/Replay|nonce already used/i', 'درخواست تکراری رد شد', 'یک درخواست امضاشده دوبار ارسال شده است (محافظت ضد تکرار).', 'صفحه را تازه کنید و دوباره تلاش کنید.' ),
			array( '/Unknown route|rest_no_route/i', 'مسیر درخواست پیدا نشد', 'نسخه ورکر یا مسیر REST وردپرس با نسخه افزونه هماهنگ نیست، یا REST API سایت غیرفعال است.', 'در تب کلادفلر «استقرار مجدد» را بزنید؛ اگر خطا از وردپرس است، پیوندهای یکتا را یک‌بار ذخیره کنید و افزونه‌های امنیتی را برای /wp-json/aaw/v1 باز کنید.' ),
			array( '/KV binding missing|WP_API binding is missing|binding/i', 'تنظیمات ورکر ناقص است', 'اتصال‌های KV یا آدرس وردپرس روی ورکر تعریف نشده‌اند (ورکر قدیمی یا دستی مستقر شده).', 'در تب کلادفلر «استقرار مجدد» را بزنید.' ),
			array( '/rest_forbidden|rest_cookie_invalid_nonce|403 Forbidden|HTTP 403/i', 'دسترسی رد شد (403)', 'افزونه امنیتی، فایروال هاست یا WAF درخواست را بلاک کرده است.', 'Wordfence/iThemes/فایروال هاست را برای مسیر /wp-json/aaw/v1/ باز کنید.' ),

			// ---------------- AI providers ----------------
			array( '/Higgsfield:?\s*not_enough_credits|higgsfield.*(credit|balance)/i', 'موجودی حساب API هیگزفیلد (Higgsfield) تمام شده است', 'کلید شما درست است ولی حساب API هیگزفیلد پول ندارد. توجه: اشتراک سایت higgsfield.ai و API دو حساب جدا هستند؛ اعتبار اشتراک سایت برای API قابل استفاده نیست و API از موجودی دلاری جداگانه کم می‌کند.', 'در open.higgsfield.ai وارد شوید و موجودی API را شارژ کنید (حداقل ۵ دلار)، یا در تب «هوش مصنوعی تولید تصویر» یک موتور دیگر (مثلاً Workers AI رایگان) را بعد از Higgsfield روشن بگذارید. تا آن موقع افزونه خودکار با Workers AI تصویر می‌سازد.' ),
			array( '/not_enough_credits|insufficient_quota|exceeded your current quota|billing|credit balance|insufficient (balance|credit)|payment required|HTTP 402|موجودی/iu', 'اعتبار حساب هوش مصنوعی تمام شده است', 'سرویس هوش مصنوعی به‌دلیل تمام شدن اعتبار/شارژ یا نبود روش پرداخت، درخواست را رد کرد.', 'حساب پرووایدر را شارژ کنید یا در تب هوش مصنوعی پرووایدر دیگری (یا Workers AI رایگان) را پشتیبان قرار دهید.' ),
			array( '/invalid[_ ]api[_ ]key|Incorrect API key|invalid x-api-key|authentication_error|API key not valid|Unauthorized|HTTP 401/i', 'کلید API هوش مصنوعی نامعتبر است', 'کلید واردشده اشتباه، باطل یا برای این سرویس نیست.', 'در تب هوش مصنوعی کلید جدید بسازید و ذخیره کنید، سپس «تست اتصال» بزنید.' ),
			array( '/model_not_found|model .* does not exist|The model .* not found|unknown model|invalid model|no such model/i', 'نام مدل وجود ندارد', 'مدل انتخاب‌شده برای این حساب/پرووایدر در دسترس نیست یا نامش اشتباه است.', 'در تب هوش مصنوعی «دریافت مدل‌ها» را بزنید و یک مدل از فهرست انتخاب کنید.' ),
			array( '/rate[_ ]limit|Too Many Requests|HTTP 429|RESOURCE_EXHAUSTED/i', 'محدودیت تعداد درخواست پرووایدر', 'در بازه کوتاه درخواست زیادی به سرویس هوش مصنوعی ارسال شده یا سهمیه دقیقه‌ای/روزانه پر شده است.', 'چند دقیقه بعد دوباره تلاش کنید، فاصله زمان‌بندی را بیشتر کنید یا پرووایدر پشتیبان تعریف کنید.' ),
			array( '/context_length|maximum context|too many tokens|prompt is too long|max_tokens/i', 'متن ورودی/خروجی از ظرفیت مدل بیشتر است', 'طول پرامپت یا مقاله درخواستی از حد مدل عبور کرده است.', 'طول مقاله یا تعداد موضوعات تحلیل را کمتر کنید یا مدلی با ظرفیت بالاتر انتخاب کنید.' ),
			array( '/overloaded|HTTP 529|HTTP 503|Service Unavailable|temporarily unavailable/i', 'سرویس هوش مصنوعی موقتاً در دسترس نیست', 'سرورهای پرووایدر شلوغ یا در حال تعمیر هستند.', 'چند دقیقه بعد دوباره تلاش کنید؛ پرووایدر پشتیبان این حالت را خودکار پوشش می‌دهد.' ),
			array( '/unsupported_country|not available in your (country|region)|region.*not supported|location is not supported/i', 'پرووایدر این منطقه جغرافیایی را پشتیبانی نمی‌کند', 'سرویس هوش مصنوعی درخواست را به‌دلیل موقعیت جغرافیایی رد کرد.', 'از پرووایدر دیگری مثل OpenRouter، AvalAI یا GapGPT استفاده کنید.' ),
			array( '/content[_ ]policy|safety|flagged|blocked by/i', 'محتوا توسط فیلتر ایمنی پرووایدر رد شد', 'موضوع یا متن درخواست با سیاست محتوایی سرویس هوش مصنوعی مغایر تشخیص داده شد.', 'موضوع را بازنویسی کنید یا مدل دیگری انتخاب کنید.' ),
			array( '/invalid JSON|JSON.*(parse|نامعتبر)|Unexpected token|پاسخ.*JSON/iu', 'پاسخ هوش مصنوعی ساختار درستی نداشت', 'مدل به‌جای خروجی ساختاریافته (JSON) متن ناقص یا نامعتبر برگرداند؛ معمولاً مدل ضعیف یا قطع شدن پاسخ.', 'یک مدل قوی‌تر انتخاب کنید یا دوباره تلاش کنید.' ),

			// ---------------- GitHub / Cloudflare API ----------------
			array( '/Bad credentials/i', 'توکن GitHub نامعتبر یا منقضی است', 'توکن دسترسی GitHub باطل شده یا تاریخ انقضایش گذشته است.', 'در تب اکانت اشتراکی توکن جدید با دسترسی repo و workflow بسازید.' ),
			array( '/Resource not accessible by (personal access )?token|requires.*workflow scope|refusing to allow/i', 'توکن GitHub دسترسی کافی ندارد', 'توکن مجوزهای repo و workflow را ندارد.', 'توکن جدید با تیک repo و workflow بسازید (لینک مستقیم در تب اکانت اشتراکی).' ),
			array( '/Authentication error|\[10000\]|Invalid API Token|\[9109\]/i', 'توکن کلادفلر نامعتبر است یا دسترسی کافی ندارد', 'توکن اشتباه است یا مجوزهای Workers Scripts:Edit / Workers KV Storage:Edit را ندارد.', 'طبق راهنمای تب کلادفلر توکن جدید بسازید و Account را درست انتخاب کنید.' ),

			// ---------------- Google Search Console ----------------
			array( '/redirect_uri_mismatch/i', 'آدرس بازگشت گوگل (Redirect URI) یکسان نیست', 'آدرسی که در Google Cloud → Clients → Authorized redirect URIs ثبت کرده‌اید با آدرس نمایش‌داده‌شده در افزونه دقیقاً یکی نیست (حتی یک حرف، http/https یا www).', 'آدرس را از کادر اتصال سرچ کنسول با دکمه «کپی» بردارید و در کلاینت گوگل جای‌گذاری و Save کنید؛ چند دقیقه بعد دوباره «ورود با حساب گوگل» را بزنید.' ),
			array( '/Invalid PKCS8|PKCS8|private_key\).*خراب/iu', 'کلید خصوصی Service Account خراب ذخیره شده است', 'مقدار private_key فایل JSON هنگام ذخیره سالم نماند (در نسخه‌های قبل از 1.8.7 خط‌های جدید کلید حذف می‌شد).', 'افزونه را به 1.8.7 به‌روز و «استقرار مجدد» ورکر را بزنید، سپس JSON را دوباره ذخیره کنید؛ یا ساده‌تر از روش «Client ID و Client Secret» وصل شوید.' ),
			array( '/invalid_grant/i', 'اجازه دسترسی گوگل منقضی شده است', 'اجازه‌ای که به افزونه داده بودید لغو شده یا منقضی شده است. برنامه‌ای که در حالت Testing است هر ۷ روز اجازه را باطل می‌کند.', 'در Google Auth Platform → Audience روی «Publish app» بزنید (In production)، سپس «ورود با حساب گوگل» را دوباره بزنید.' ),
			array( '/invalid_client|unauthorized_client/i', 'Client ID یا Client Secret گوگل اشتباه است', 'گوگل مشخصات کلاینت را نپذیرفت (کلاینت حذف شده، Secret عوض شده یا اشتباه کپی شده).', 'از Google Auth Platform → Clients هر دو مقدار را دوباره کپی و ذخیره کنید.' ),

			// ---------------- PHP / server ----------------
			array( '/Maximum execution time/i', 'زمان اجرای PHP تمام شد', 'max_execution_time هاست کمتر از زمان لازم برای این عملیات است.', 'مقدار max_execution_time را در php.ini یا از هاست به حداقل 300 ثانیه برسانید.' ),
			array( '/Allowed memory size/i', 'حافظه PHP کافی نیست', 'memory_limit سرور برای این عملیات کم است.', 'در wp-config.php مقدار WP_MEMORY_LIMIT را 256M کنید یا از هاست بخواهید.' ),
			array( '/HTTP 500|Internal Server Error|critical error/i', 'خطای داخلی (500)', 'سرویس مقصد (ورکر کلادفلر یا PHP سایت) هنگام اجرا خطا داد؛ «جزئیات فنی» پایین علت دقیق را نشان می‌دهد.', 'WP_DEBUG_LOG را فعال و فایل wp-content/debug.log را بررسی کنید.' ),
			array( '/HTTP 404/i', 'آدرس پیدا نشد (404)', 'آدرس مقصد وجود ندارد؛ معمولاً ورکر حذف شده یا آدرس REST تغییر کرده است.', 'در تب کلادفلر «بررسی وضعیت» و «استقرار مجدد» را بزنید.' ),
		);
	}

	/** Extract the cURL error number from a message, 0 if none. */
	public static function curl_code( $msg ) {
		return preg_match( '/cURL error (\d+)/i', (string) $msg, $m ) ? (int) $m[1] : 0;
	}

	public static function is_network( $msg ) {
		$c = self::curl_code( $msg );
		if ( $c ) {
			return in_array( $c, self::NET_CODES, true );
		}
		return (bool) preg_match( '/Empty reply|Connection reset|timed out|Failed to connect|Could not resolve host|SSL connect error/i', (string) $msg );
	}

	/**
	 * Build the explained message.
	 *
	 * @param string|WP_Error $err   Raw error.
	 * @param string          $where Optional step/context label.
	 */
	public static function explain( $err, $where = '' ) {
		$raw = is_wp_error( $err ) ? $err->get_error_message() : (string) $err;
		if ( false !== strpos( $raw, self::MARK ) ) {
			return $raw; // Already explained.
		}
		foreach ( self::rules() as $r ) {
			if ( preg_match( $r[0], $raw ) ) {
				return self::format( $r[1], $r[2], $r[3], $raw, $where );
			}
		}
		return $raw;
	}

	public static function format( $title, $cause, $fix, $raw = '', $where = '' ) {
		$out = ( $where ? $where . ' — ' : '' ) . $title . "\n" . self::MARK . ' ' . $cause . "\nراه‌حل: " . $fix;
		$raw = trim( wp_strip_all_tags( (string) $raw ) );
		if ( $raw && false === strpos( $title . $cause, $raw ) ) {
			$out .= "\nجزئیات فنی: " . ( function_exists( 'mb_substr' ) ? mb_substr( $raw, 0, 300 ) : substr( $raw, 0, 300 ) );
		}
		return $out;
	}

	/**
	 * Explain a failed HTTP call to $url. For transport errors, run live probes to
	 * determine the exact cause.
	 *
	 * @param WP_Error $err     Transport error from wp_remote_*.
	 * @param string   $url     Target URL.
	 * @param float    $elapsed Seconds the failed call took.
	 * @param string   $what    Human name of the target (e.g. «ورکر کلادفلر»).
	 * @return WP_Error
	 */
	public static function network( $err, $url, $elapsed = 0.0, $what = 'ورکر کلادفلر', $bytes = 0 ) {
		$raw = is_wp_error( $err ) ? $err->get_error_message() : (string) $err;
		if ( ! self::is_network( $raw ) ) {
			return new WP_Error( 'aaw_net', self::explain( $raw ) );
		}
		$d = self::diagnose( $url, $elapsed, $what, $raw, (int) $bytes );
		return new WP_Error( 'aaw_net', self::format( $d['title'], $d['cause'], $d['fix'], $raw . ' | ' . $d['evidence'] ), array( 'diagnosis' => $d ) );
	}

	/** POST 96KB to the worker's /ping and measure throughput (KB/s). */
	public static function upload_probe( $url ) {
		$data = str_repeat( 'a', 96 * 1024 );
		$t0   = microtime( true );
		$r    = wp_remote_post( $url, array( 'timeout' => 12, 'body' => $data, 'headers' => array( 'Content-Type' => 'application/octet-stream' ) ) );
		$dt   = max( 0.05, microtime( true ) - $t0 );
		if ( is_wp_error( $r ) ) {
			return array( 'kbps' => round( 96 / 12, 1 ), 'failed' => true );
		}
		$j = json_decode( (string) wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $j ) || empty( $j['bytes'] ) ) {
			return null; // Old worker without /ping.
		}
		return array( 'kbps' => round( 96 / $dt, 1 ), 'secs' => round( $dt, 1 ) );
	}

	/**
	 * Live probes: DNS → health endpoint → general internet.
	 *
	 * @return array{title:string,cause:string,fix:string,evidence:string,verdict:string}
	 */
	public static function diagnose( $url, $elapsed, $what, $raw, $bytes = 0 ) {
		$host    = (string) wp_parse_url( $url, PHP_URL_HOST );
		$scheme  = (string) wp_parse_url( $url, PHP_URL_SCHEME );
		$port    = (int) wp_parse_url( $url, PHP_URL_PORT );
		$secs    = (int) round( $elapsed );
		$ev      = array( 'مدت درخواست ناموفق: ' . $secs . ' ثانیه' . ( $bytes ? ' · حجم ارسالی: ' . round( $bytes / 1024 ) . 'KB' : '' ) );
		$is_wdev = (bool) preg_match( '/\.workers\.dev$/i', $host );

		// 1) DNS.
		$ip = $host ? ( is_callable( self::$resolver ) ? call_user_func( self::$resolver, $host ) : gethostbyname( $host ) ) : '';
		if ( ! $host || ( $ip === $host && ! filter_var( $host, FILTER_VALIDATE_IP ) ) ) {
			return array(
				'verdict'  => 'dns',
				'title'    => 'آدرس ' . $what . ' روی سرور شما قابل شناسایی نیست (DNS)',
				'cause'    => 'سرور/کامپیوتر شما نتوانست IP دامنه ' . $host . ' را پیدا کند؛ یعنی مشکل از DNS شبکه شماست یا این دامنه در شبکه شما مسدود است.' . ( $is_wdev ? ' دامنه‌های workers.dev در برخی شبکه‌های ایران مسدودند.' : '' ),
				'fix'      => $is_wdev ? 'در تب کلادفلر یک «دامنه اختصاصی ورکر» روی دامنه خودتان وصل کنید و آن را ذخیره کنید.' : 'DNS سرور را بررسی کنید (مثلاً 1.1.1.1) و آدرس را اصلاح کنید.',
				'evidence' => implode( ' · ', array_merge( $ev, array( 'DNS: ناموفق' ) ) ),
			);
		}
		$ev[] = 'DNS: ' . $ip;

		// 2) Short request to the same host.
		$probe = ( $scheme ? $scheme : 'https' ) . '://' . $host . ( $port ? ':' . $port : '' ) . ( preg_match( '/workers\.dev$/i', $host ) || false !== strpos( (string) $url, '/wp-json/' ) ? '/health' : '/' );
		$t0    = microtime( true );
		$h     = wp_remote_get( $probe, array( 'timeout' => 12, 'redirection' => 0 ) );
		$hs    = round( microtime( true ) - $t0, 1 );
		$h_ok  = ! is_wp_error( $h ); // Any HTTP answer proves the host is reachable.
		$ev[]  = 'تست کوتاه ' . $host . ': ' . ( $h_ok ? 'موفق در ' . $hs . ' ثانیه (HTTP ' . wp_remote_retrieve_response_code( $h ) . ')' : $h->get_error_message() );

		if ( $h_ok ) {
			// Upload-speed probe: is the request simply too big for this link in the time it allows?
			$up = self::upload_probe( ( $scheme ? $scheme : 'https' ) . '://' . $host . ( $port ? ':' . $port : '' ) . '/ping' );
			if ( $up ) {
				$ev[] = ! empty( $up['failed'] ) ? 'آپلود آزمایشی ۹۶KB کامل نشد' : 'سرعت آپلود به کلادفلر: ' . $up['kbps'] . 'KB/s';
				$need = $bytes && $up['kbps'] > 0 ? $bytes / 1024 / $up['kbps'] : 0;
				if ( ! empty( $up['failed'] ) && $bytes > 32 * 1024 ) {
					return array(
						'verdict'  => 'slow_upload',
						'title'    => 'ارسال اطلاعات از هاست شما به کلادفلر خیلی کند یا محدود است',
						'cause'    => 'درخواست ' . round( $bytes / 1024 ) . ' کیلوبایتی بعد از ' . $secs . ' ثانیه قطع شد و حتی ارسال آزمایشی ۹۶ کیلوبایت هم کامل نشد؛ درخواست‌های کوچک کار می‌کنند ولی ارسال حجم بالا از هاست به خارج قطع می‌شود.',
						'fix'      => 'افزونه اندازه تکه‌ها را خودکار با همین سرعت تنظیم می‌کند و فایل‌های بزرگ (فایل‌های GitHub، به‌روزرسانی ورکر) را از طریق خود کلادفلر می‌فرستد؛ کار در اجرای بعدی ادامه پیدا می‌کند. راه قطعی: رفع محدودیت اینترنت بین‌المللی توسط هاست یا هاست خارج از ایران.',
						'evidence' => implode( ' · ', $ev ),
					);
				}
				if ( $bytes > 32 * 1024 && $need > 0.6 * max( 1, $elapsed ) ) {
					return array(
						'verdict'  => 'slow_upload',
						'title'    => 'ارسال اطلاعات از هاست شما به کلادفلر خیلی کند است',
						'cause'    => 'سرعت آپلود اندازه‌گیری‌شده از سرور سایت به کلادفلر حدود ' . $up['kbps'] . ' کیلوبایت بر ثانیه است؛ ارسال ' . round( $bytes / 1024 ) . ' کیلوبایت حدود ' . round( $need ) . ' ثانیه طول می‌کشد، اما شبکه هاست اتصال را بعد از ' . $secs . ' ثانیه قطع می‌کند.',
						'fix'      => 'نسخه ' . AAW_VERSION . ' اطلاعات را فشرده و در تکه‌هایی با اندازه خودکار (هر تکه حدود ۵ ثانیه) می‌فرستد و فایل‌های بزرگ را از طریق کلادفلر ارسال می‌کند. راه قطعی‌تر: از هاست بخواهید سرعت/محدودیت اتصال بین‌المللی را بردارد یا از هاست خارج از ایران استفاده کنید.',
						'evidence' => implode( ' · ', $ev ),
					);
				}
			}
			$streaming = AAW_Settings::get( 'deployed_version' ) === AAW_VERSION;
			if ( $elapsed >= max( 2, $hs * 3 + 1 ) && $streaming ) {
				return array(
					'verdict'  => 'hard_cut',
					'title'    => 'شبکه/هاست شما هر اتصال را بعد از حدود ' . $secs . ' ثانیه قطع می‌کند',
					'cause'    => $what . ' سالم است (تست کوتاه در ' . $hs . ' ثانیه موفق شد) و اتصال زنده هم فعال بود، ولی اتصال دقیقاً پس از ' . $secs . ' ثانیه بسته شد؛ یعنی محدودیت «حداکثر مدت اتصال» روی هاست، پراکسی یا VPN شما وجود دارد، نه مشکل ورکر.',
					'fix'      => AAW_BG::available() ? 'نیازی به کاری از طرف شما نیست: افزونه از این پس همه انتقال‌ها را در تکه‌های چندثانیه‌ای با اندازه خودکار انجام می‌دهد، تکه ناموفق را کوچک‌تر دوباره می‌فرستد و دریافت نتیجه را در اجرای بعدی از همان‌جا ادامه می‌دهد (کار از دست نمی‌رود). اگر ورکر هنوز قدیمی است، در تب کلادفلر «استقرار مجدد» را بزنید. راه قطعی‌تر: برداشتن محدودیت مدت اتصال بین‌المللی توسط هاست.' : 'در تب کلادفلر «استقرار مجدد» را بزنید تا «کارهای پس‌زمینه» (Durable Object) روی ورکر فعال شود؛ از آن به بعد کارهای طولانی روی کلادفلر انجام می‌شوند و سایت فقط درخواست‌های چندثانیه‌ای می‌فرستد که این محدودیت روی آن‌ها اثری ندارد.',
					'evidence' => implode( ' · ', $ev ),
				);
			}
			if ( $elapsed >= max( 2, $hs * 3 + 1 ) ) {
				return array(
					'verdict'  => 'long_cut',
					'title'    => 'اتصال طولانی بعد از ' . $secs . ' ثانیه توسط شبکه/هاست شما قطع شد',
					'cause'    => $what . ' سالم است و درخواست کوتاه در ' . $hs . ' ثانیه جواب داد، ولی درخواست طولانی (کار هوش مصنوعی) بعد از ' . $secs . ' ثانیه بدون پاسخ بسته شد. یعنی یک واسط بین سرور شما و کلادفلر (پراکسی یا فایروال هاست، VPN، یا محدودیت شبکه) اتصال‌های بی‌فعالیت طولانی را قطع می‌کند.',
					'fix'      => 'در تب کلادفلر «استقرار مجدد» را بزنید تا ورکر نسخه ' . AAW_VERSION . ' نصب شود: کارهای طولانی در پس‌زمینه کلادفلر اجرا می‌شوند و اتصال‌ها کوتاه یا زنده می‌مانند.',
					'evidence' => implode( ' · ', $ev ),
				);
			}
			return array(
				'verdict'  => 'worker_dropped',
				'title'    => $what . ' درخواست را بدون پاسخ رها کرد',
				'cause'    => 'اتصال به ' . $what . ' سالم است ولی همین درخواست پس از ' . $secs . ' ثانیه بدون پاسخ بسته شد؛ یعنی ورکر حین پردازش متوقف شده (معمولاً عبور از سقف منابع پلن رایگان یا نسخه قدیمی ورکر).',
				'fix'      => 'در تب کلادفلر «استقرار مجدد» را بزنید؛ اگر تکرار شد، Cloudflare → Workers → ' . AAW_Settings::get( 'worker_name' ) . ' → Logs را ببینید یا تعداد موضوع/طول مقاله را کمتر کنید.',
				'evidence' => implode( ' · ', $ev ),
			);
		}

		// 3) Is the internet reachable at all?
		$g    = wp_remote_get( 'https://www.cloudflare.com/cdn-cgi/trace', array( 'timeout' => 10 ) );
		$g_ok = ! is_wp_error( $g );
		$ev[] = 'تست اینترنت (cloudflare.com): ' . ( $g_ok ? 'موفق' : $g->get_error_message() );

		if ( $g_ok ) {
			return array(
				'verdict'  => 'host_blocked',
				'title'    => 'دسترسی سرور شما به ' . $host . ' مسدود است',
				'cause'    => 'سرور شما به اینترنت و کلادفلر دسترسی دارد، ولی اتصال به ' . $host . ' قطع می‌شود؛ یعنی این دامنه مشخصاً در شبکه/هاست شما فیلتر یا بلاک است' . ( $is_wdev ? ' (مسدودی workers.dev در شبکه‌های ایران رایج است).' : '.' ),
				'fix'      => 'در تب کلادفلر «دامنه اختصاصی ورکر» را روی یک ساب‌دامین از دامنه خودتان (مثلاً ai.yoursite.com) تنظیم کنید؛ یا از هاست بخواهید این دامنه را آزاد کند.',
				'evidence' => implode( ' · ', $ev ),
			);
		}
		return array(
			'verdict'  => 'no_internet',
			'title'    => 'سرور سایت شما به اینترنت خارج دسترسی ندارد',
			'cause'    => 'نه ' . $host . ' و نه cloudflare.com از روی سرور شما در دسترس نیستند؛ یعنی ترافیک خروجی سرور (یا اینترنت/VPN کامپیوتر برای سایت لوکال) قطع یا به پراکسی نیاز دارد.',
			'fix'      => 'اینترنت/VPN سیستم را بررسی کنید؛ روی هاست از پشتیبانی بخواهید دسترسی خروجی HTTPS را باز کند؛ اگر پراکسی لازم است WP_PROXY_HOST را در wp-config تنظیم کنید.',
			'evidence' => implode( ' · ', $ev ),
		);
	}
}
