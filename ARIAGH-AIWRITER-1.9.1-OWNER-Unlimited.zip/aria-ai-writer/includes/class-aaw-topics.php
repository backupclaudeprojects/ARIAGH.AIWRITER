<?php
/**
 * Topic queue stored in a dedicated table.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_Topics {

	const STATUSES = array( 'pending', 'processing', 'done', 'failed', 'skipped', 'paused' );

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'aaw_topics';
	}

	public static function create_table() {
		global $wpdb;
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			title TEXT NOT NULL,
			keywords TEXT NULL,
			category_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			word_count INT(11) NOT NULL DEFAULT 0,
			tone VARCHAR(40) NOT NULL DEFAULT '',
			notes TEXT NULL,
			priority TINYINT(4) NOT NULL DEFAULT 0,
			position INT(11) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			attempts TINYINT(4) NOT NULL DEFAULT 0,
			post_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			error TEXT NULL,
			source VARCHAR(20) NOT NULL DEFAULT 'manual',
			locked_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			generated_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY status_pos (status, position),
			KEY post_id (post_id)
		) {$charset};";
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	public static function sanitize_row( array $data ) {
		$out = array();
		if ( isset( $data['title'] ) ) {
			$out['title'] = mb_substr( sanitize_text_field( $data['title'] ), 0, 300 );
		}
		if ( isset( $data['keywords'] ) ) {
			$kw              = is_array( $data['keywords'] ) ? $data['keywords'] : preg_split( '/[,،\n]+/u', (string) $data['keywords'] );
			$kw              = array_filter( array_map( 'trim', array_map( 'sanitize_text_field', $kw ) ), 'strlen' );
			$out['keywords'] = implode( '، ', array_slice( array_unique( $kw ), 0, 20 ) );
		}
		if ( isset( $data['category_id'] ) ) {
			$out['category_id'] = absint( $data['category_id'] );
		}
		if ( isset( $data['word_count'] ) ) {
			$out['word_count'] = min( 12000, absint( $data['word_count'] ) );
		}
		if ( isset( $data['tone'] ) ) {
			$out['tone'] = sanitize_key( $data['tone'] );
		}
		if ( isset( $data['notes'] ) ) {
			$out['notes'] = sanitize_textarea_field( $data['notes'] );
		}
		if ( isset( $data['priority'] ) ) {
			$out['priority'] = max( 0, min( 2, (int) $data['priority'] ) );
		}
		if ( isset( $data['status'] ) && in_array( $data['status'], self::STATUSES, true ) ) {
			$out['status'] = $data['status'];
		}
		if ( isset( $data['source'] ) ) {
			$out['source'] = sanitize_key( $data['source'] );
		}
		return $out;
	}

	public static function add( array $data ) {
		global $wpdb;
		$row = self::sanitize_row( $data );
		if ( empty( $row['title'] ) ) {
			return new WP_Error( 'aaw_topic', 'عنوان موضوع خالی است.' );
		}
		$max                = (int) $wpdb->get_var( 'SELECT MAX(position) FROM ' . self::table() ); // phpcs:ignore
		$row['position']    = isset( $data['position_top'] ) && $data['position_top'] ? self::min_position() - 1 : $max + 1;
		$row['created_at']  = current_time( 'mysql', true );
		$row['status']      = isset( $row['status'] ) ? $row['status'] : 'pending';
		$wpdb->insert( self::table(), $row ); // phpcs:ignore
		return (int) $wpdb->insert_id;
	}

	private static function min_position() {
		global $wpdb;
		return (int) $wpdb->get_var( 'SELECT MIN(position) FROM ' . self::table() ); // phpcs:ignore
	}

	/**
	 * Bulk add. Each line: "title | keyword1, keyword2 | category name or id | words".
	 */
	public static function add_bulk( $text, $source = 'manual', $skip_duplicates = true ) {
		$lines   = preg_split( '/\r\n|\n|\r/', (string) $text );
		$added   = 0;
		$skipped = 0;
		$existing = $skip_duplicates ? self::all_titles_normalized() : array();
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			$parts = array_map( 'trim', explode( '|', $line ) );
			$title = ltrim( $parts[0], "-*•0123456789.) \t" );
			if ( '' === $title ) {
				continue;
			}
			$norm = self::normalize( $title );
			if ( $skip_duplicates && isset( $existing[ $norm ] ) ) {
				++$skipped;
				continue;
			}
			if ( $skip_duplicates && AAW_Settings::get( 'duplicate_check' ) && class_exists( 'AAW_Dedupe' ) ) {
				$kw_line = $parts[1] ?? '';
				if ( AAW_Dedupe::queued_duplicate( $title, $kw_line ) || AAW_Dedupe::duplicate_of( $title, $kw_line ) ) {
					++$skipped;
					continue;
				}
			}
			$data = array(
				'title'  => $title,
				'source' => $source,
			);
			if ( ! empty( $parts[1] ) ) {
				$data['keywords'] = $parts[1];
			}
			if ( ! empty( $parts[2] ) ) {
				$data['category_id'] = self::resolve_category( $parts[2] );
			}
			if ( ! empty( $parts[3] ) ) {
				$data['word_count'] = absint( $parts[3] );
			}
			$r = self::add( $data );
			if ( ! is_wp_error( $r ) ) {
				++$added;
				$existing[ $norm ] = true;
			}
		}
		return array(
			'added'   => $added,
			'skipped' => $skipped,
		);
	}

	public static function resolve_category( $value ) {
		if ( is_numeric( $value ) ) {
			return absint( $value );
		}
		$term = get_term_by( 'name', $value, 'category' );
		if ( ! $term ) {
			$term = get_term_by( 'slug', sanitize_title( $value ), 'category' );
		}
		if ( $term ) {
			return (int) $term->term_id;
		}
		$new = wp_insert_term( sanitize_text_field( $value ), 'category' );
		return is_wp_error( $new ) ? 0 : (int) $new['term_id'];
	}

	public static function normalize( $s ) {
		$s = str_replace( array( 'ي', 'ك', '‌', 'ۀ', 'ة' ), array( 'ی', 'ک', ' ', 'ه', 'ه' ), (string) $s );
		$s = preg_replace( '/[^\p{L}\p{N}\s]/u', '', $s );
		$s = preg_replace( '/\s+/u', ' ', $s );
		return trim( mb_strtolower( $s ) );
	}

	public static function all_titles_normalized() {
		global $wpdb;
		$rows = $wpdb->get_col( 'SELECT title FROM ' . self::table() ); // phpcs:ignore
		$out  = array();
		foreach ( $rows as $t ) {
			$out[ self::normalize( $t ) ] = true;
		}
		return $out;
	}

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
	}

	public static function update( $id, array $data ) {
		global $wpdb;
		$row = self::sanitize_row( $data );
		foreach ( array( 'post_id', 'attempts' ) as $int_key ) {
			if ( isset( $data[ $int_key ] ) ) {
				$row[ $int_key ] = absint( $data[ $int_key ] );
			}
		}
		if ( array_key_exists( 'error', $data ) ) {
			$row['error'] = null === $data['error'] ? null : mb_substr( sanitize_textarea_field( $data['error'] ), 0, 2000 );
		}
		if ( array_key_exists( 'locked_at', $data ) ) {
			$row['locked_at'] = $data['locked_at'];
		}
		if ( array_key_exists( 'generated_at', $data ) ) {
			$row['generated_at'] = $data['generated_at'];
		}
		if ( empty( $row ) ) {
			return false;
		}
		return false !== $wpdb->update( self::table(), $row, array( 'id' => (int) $id ) ); // phpcs:ignore
	}

	public static function delete( $ids ) {
		global $wpdb;
		$ids = array_filter( array_map( 'absint', (array) $ids ) );
		if ( empty( $ids ) ) {
			return 0;
		}
		$in = implode( ',', $ids );
		return (int) $wpdb->query( 'DELETE FROM ' . self::table() . " WHERE id IN ({$in})" ); // phpcs:ignore
	}

	public static function duplicate( $id ) {
		$row = self::get( $id );
		if ( ! $row ) {
			return false;
		}
		unset( $row['id'] );
		$row['title'] = $row['title'] . ' (کپی)';
		return self::add( $row );
	}

	public static function reorder( array $ids ) {
		global $wpdb;
		$pos = 1;
		foreach ( $ids as $id ) {
			$wpdb->update( self::table(), array( 'position' => $pos++ ), array( 'id' => absint( $id ) ) ); // phpcs:ignore
		}
		return true;
	}

	public static function move( $id, $where ) {
		global $wpdb;
		$t = self::table();
		if ( 'top' === $where ) {
			$min = (int) $wpdb->get_var( "SELECT MIN(position) FROM {$t}" ); // phpcs:ignore
			return self::update_position( $id, $min - 1 );
		}
		if ( 'bottom' === $where ) {
			$max = (int) $wpdb->get_var( "SELECT MAX(position) FROM {$t}" ); // phpcs:ignore
			return self::update_position( $id, $max + 1 );
		}
		return false;
	}

	private static function update_position( $id, $pos ) {
		global $wpdb;
		return false !== $wpdb->update( self::table(), array( 'position' => (int) $pos ), array( 'id' => absint( $id ) ) ); // phpcs:ignore
	}

	public static function bulk_status( array $ids, $status ) {
		global $wpdb;
		if ( ! in_array( $status, self::STATUSES, true ) ) {
			return 0;
		}
		$ids = array_filter( array_map( 'absint', $ids ) );
		if ( empty( $ids ) ) {
			return 0;
		}
		$in  = implode( ',', $ids );
		$extra = 'pending' === $status ? ', attempts = 0, error = NULL, locked_at = NULL' : '';
		return (int) $wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . " SET status = %s{$extra} WHERE id IN ({$in})", $status ) ); // phpcs:ignore
	}

	public static function query( $args = array() ) {
		global $wpdb;
		$args  = wp_parse_args(
			$args,
			array(
				'status'   => '',
				'search'   => '',
				'per_page' => 200,
				'page'     => 1,
			)
		);
		$where = array( '1=1' );
		$vals  = array();
		if ( $args['status'] && in_array( $args['status'], self::STATUSES, true ) ) {
			$where[] = 'status = %s';
			$vals[]  = $args['status'];
		}
		if ( $args['search'] ) {
			$where[] = '(title LIKE %s OR keywords LIKE %s)';
			$like    = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$vals[]  = $like;
			$vals[]  = $like;
		}
		$per    = max( 1, min( 1000, (int) $args['per_page'] ) );
		$offset = ( max( 1, (int) $args['page'] ) - 1 ) * $per;
		$sql    = 'SELECT * FROM ' . self::table() . ' WHERE ' . implode( ' AND ', $where ) . " ORDER BY FIELD(status,'processing','pending','failed','paused','skipped','done'), priority DESC, position ASC, id ASC LIMIT {$per} OFFSET {$offset}";
		$sqlc   = 'SELECT COUNT(*) FROM ' . self::table() . ' WHERE ' . implode( ' AND ', $where );
		if ( $vals ) {
			$sql  = $wpdb->prepare( $sql, $vals ); // phpcs:ignore
			$sqlc = $wpdb->prepare( $sqlc, $vals ); // phpcs:ignore
		}
		return array(
			'items' => $wpdb->get_results( $sql, ARRAY_A ), // phpcs:ignore
			'total' => (int) $wpdb->get_var( $sqlc ), // phpcs:ignore
		);
	}

	public static function counts() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT status, COUNT(*) c FROM ' . self::table() . ' GROUP BY status', ARRAY_A ); // phpcs:ignore
		$out  = array_fill_keys( self::STATUSES, 0 );
		$out['total'] = 0;
		foreach ( (array) $rows as $r ) {
			$out[ $r['status'] ] = (int) $r['c'];
			$out['total']       += (int) $r['c'];
		}
		return $out;
	}

	/** Release topics stuck in "processing" for more than 30 minutes. */
	public static function release_stale() {
		global $wpdb;
		$limit = gmdate( 'Y-m-d H:i:s', time() - 90 * MINUTE_IN_SECONDS );
		return (int) $wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . " SET status = 'pending', locked_at = NULL WHERE status = 'processing' AND locked_at < %s", $limit ) ); // phpcs:ignore
	}

	/**
	 * Atomically lock and return the next topic.
	 */
	public static function claim_next() {
		global $wpdb;
		self::release_stale();
		$t   = self::table();
		$max = (int) AAW_Settings::get( 'max_attempts', 3 );
		$statuses = AAW_Settings::get( 'retry_failed' ) ? "'pending','failed'" : "'pending'";
		for ( $i = 0; $i < 3; $i++ ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE status IN ({$statuses}) AND attempts < %d ORDER BY (status = 'failed') ASC, priority DESC, position ASC, id ASC LIMIT 1", $max ), ARRAY_A ); // phpcs:ignore
			if ( ! $row ) {
				return null;
			}
			$now = current_time( 'mysql', true );
			$ok  = $wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status = 'processing', locked_at = %s, attempts = attempts + 1 WHERE id = %d AND status = %s", $now, $row['id'], $row['status'] ) ); // phpcs:ignore
			if ( $ok ) {
				$row['status']   = 'processing';
				$row['attempts'] = (int) $row['attempts'] + 1;
				return $row;
			}
		}
		return null;
	}

	public static function mark_done( $id, $post_id ) {
		return self::update(
			$id,
			array(
				'status'       => 'done',
				'post_id'      => $post_id,
				'error'        => null,
				'locked_at'    => null,
				'generated_at' => current_time( 'mysql', true ),
			)
		);
	}

	public static function mark_failed( $id, $error ) {
		$row = self::get( $id );
		if ( ! $row ) {
			return false;
		}
		return self::update(
			$id,
			array(
				'status'    => 'failed',
				'error'     => $error,
				'locked_at' => null,
			)
		);
	}

	public static function export_csv() {
		$rows = self::query( array( 'per_page' => 1000 ) );
		$fh   = fopen( 'php://temp', 'w+' );
		fwrite( $fh, "\xEF\xBB\xBF" );
		fputcsv( $fh, array( 'title', 'keywords', 'category', 'word_count', 'priority', 'status', 'post_id', 'notes' ) );
		foreach ( $rows['items'] as $r ) {
			$cat = $r['category_id'] ? get_cat_name( $r['category_id'] ) : '';
			fputcsv( $fh, array( $r['title'], $r['keywords'], $cat, $r['word_count'], $r['priority'], $r['status'], $r['post_id'], $r['notes'] ) );
		}
		rewind( $fh );
		$csv = stream_get_contents( $fh );
		fclose( $fh );
		return $csv;
	}

	public static function import_csv( $csv ) {
		$csv   = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $csv );
		$lines = preg_split( '/\r\n|\n|\r/', $csv );
		$added = 0;
		$head  = null;
		$existing = self::all_titles_normalized();
		foreach ( $lines as $line ) {
			if ( '' === trim( $line ) ) {
				continue;
			}
			$cols = str_getcsv( $line );
			if ( null === $head && isset( $cols[0] ) && 'title' === strtolower( trim( $cols[0] ) ) ) {
				$head = $cols;
				continue;
			}
			$title = isset( $cols[0] ) ? trim( $cols[0] ) : '';
			if ( '' === $title || isset( $existing[ self::normalize( $title ) ] ) ) {
				continue;
			}
			$data = array(
				'title'    => $title,
				'keywords' => isset( $cols[1] ) ? $cols[1] : '',
				'source'   => 'import',
			);
			if ( ! empty( $cols[2] ) ) {
				$data['category_id'] = self::resolve_category( $cols[2] );
			}
			if ( ! empty( $cols[3] ) ) {
				$data['word_count'] = absint( $cols[3] );
			}
			if ( isset( $cols[4] ) ) {
				$data['priority'] = (int) $cols[4];
			}
			if ( ! empty( $cols[7] ) ) {
				$data['notes'] = $cols[7];
			}
			if ( ! is_wp_error( self::add( $data ) ) ) {
				++$added;
				$existing[ self::normalize( $title ) ] = true;
			}
		}
		return $added;
	}

	/** Compare against published/draft post titles to avoid duplicate articles. */
	public static function similar_post_exists( $title, $threshold = 85 ) {
		global $wpdb;
		$norm   = self::normalize( $title );
		$titles = $wpdb->get_results( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type = 'post' AND post_status IN ('publish','draft','pending','future') ORDER BY ID DESC LIMIT 2000", ARRAY_A ); // phpcs:ignore
		foreach ( $titles as $t ) {
			$pct = 0;
			similar_text( $norm, self::normalize( $t['post_title'] ), $pct );
			if ( $pct >= $threshold ) {
				return (int) $t['ID'];
			}
		}
		return 0;
	}
}
