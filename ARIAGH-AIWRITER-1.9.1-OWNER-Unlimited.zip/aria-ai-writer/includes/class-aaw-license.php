<?php
/**
 * Commercial licensing: activation, signed offline tokens (Ed25519), trial,
 * daily re-validation and automatic updates from the ARIAGH license server.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AAW_License {

	const OPTION      = 'aaw_license';
	const TRIAL       = 'aaw_trial';
	const UPDATE_KEY  = 'aaw_update_info';
	const GRACE_DAYS  = 14;

	private static $cfg = null;

	/* ============================ Config ============================ */

	public static function config( $key = null ) {
		if ( null === self::$cfg ) {
			$file = defined( 'AAW_DIR' ) ? AAW_DIR . 'license-config.php' : '';
			$cfg  = ( $file && file_exists( $file ) ) ? include $file : array();
			$cfg  = is_array( $cfg ) ? $cfg : array();
			$cfg  = array_merge(
				array(
					'product'        => 'ariagh-aiwriter',
					'product_name'   => 'ARIAGH.AIWRITER',
					'api'            => '',
					'public_key'     => '',
					'store_url'      => '',
					'buy_url'        => '',
					'account_url'    => '',
					'support_url'    => '',
					'docs_url'       => '',
					'trial_days'     => 7,
					'trial_articles' => 5,
					'edition'        => 'standard',
				),
				$cfg
			);
			foreach ( array_keys( $cfg ) as $k ) {
				$const = 'AAW_LICENSE_' . strtoupper( $k );
				if ( defined( $const ) ) {
					$cfg[ $k ] = constant( $const );
				}
			}
			$cfg['api'] = untrailingslashit( (string) $cfg['api'] );
			if ( ! $cfg['buy_url'] && $cfg['store_url'] ) {
				$cfg['buy_url'] = $cfg['store_url'];
			}
			self::$cfg = $cfg;
		}
		if ( null === $key ) {
			return self::$cfg;
		}
		return isset( self::$cfg[ $key ] ) ? self::$cfg[ $key ] : null;
	}

	/** Reset cached config (tests). */
	public static function flush() {
		self::$cfg = null;
	}

	/** Owner edition: unlimited, no activation, no server. */
	public static function is_owner() {
		return 'owner' === self::config( 'edition' );
	}

	public static function is_configured() {
		return '' !== self::config( 'api' ) && '' !== self::config( 'public_key' );
	}

	/* ============================ Helpers ============================ */

	/** Canonical domain used for activation (lowercase host, no www, no port). */
	public static function normalize_domain( $url ) {
		$url  = trim( (string) $url );
		$host = wp_parse_url( false === strpos( $url, '://' ) ? 'http://' . $url : $url, PHP_URL_HOST );
		$host = strtolower( (string) $host );
		$host = preg_replace( '/^www\./', '', $host );
		return rtrim( $host, '.' );
	}

	public static function domain() {
		return self::normalize_domain( home_url() );
	}

	public static function b64url_encode( $s ) {
		return rtrim( strtr( base64_encode( $s ), '+/', '-_' ), '=' );
	}

	public static function b64url_decode( $s ) {
		$s = strtr( (string) $s, '-_', '+/' );
		$p = strlen( $s ) % 4;
		if ( $p ) {
			$s .= str_repeat( '=', 4 - $p );
		}
		return base64_decode( $s, true ); // phpcs:ignore
	}

	public static function mask_key( $key ) {
		$key = (string) $key;
		if ( strlen( $key ) < 10 ) {
			return $key ? '••••' : '';
		}
		return substr( $key, 0, 5 ) . str_repeat( '•', 6 ) . substr( $key, -4 );
	}

	public static function sanitize_key_input( $key ) {
		return strtoupper( preg_replace( '/[^A-Za-z0-9\-]/', '', (string) $key ) );
	}

	private static function data() {
		$d = get_option( self::OPTION, array() );
		return is_array( $d ) ? array_merge( array( 'token' => '', 'last_check' => 0, 'last_error' => '', 'activated_at' => 0 ), $d ) : array( 'token' => '', 'last_check' => 0, 'last_error' => '', 'activated_at' => 0 );
	}

	private static function save( array $d ) {
		update_option( self::OPTION, $d, false );
	}

	public static function key() {
		return (string) AAW_Settings::secure_get( 'license_key' );
	}

	/* ============================ Token ============================ */

	/**
	 * Verify a signed token from the license server.
	 *
	 * @return array|WP_Error Payload.
	 */
	public static function verify_token( $token, $public_key = null ) {
		$public_key = null === $public_key ? self::config( 'public_key' ) : $public_key;
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return new WP_Error( 'aaw_license', 'افزونه sodium روی PHP سرور فعال نیست.' );
		}
		$parts = explode( '.', (string) $token );
		if ( 2 !== count( $parts ) ) {
			return new WP_Error( 'aaw_license', 'توکن لایسنس نامعتبر است.' );
		}
		$pk  = base64_decode( (string) $public_key, true ); // phpcs:ignore
		$sig = self::b64url_decode( $parts[1] );
		if ( ! $pk || SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES !== strlen( $pk ) || ! $sig || SODIUM_CRYPTO_SIGN_BYTES !== strlen( $sig ) ) {
			return new WP_Error( 'aaw_license', 'امضای لایسنس قابل بررسی نیست.' );
		}
		if ( ! sodium_crypto_sign_verify_detached( $sig, $parts[0], $pk ) ) {
			return new WP_Error( 'aaw_license', 'امضای لایسنس معتبر نیست.' );
		}
		$payload = json_decode( (string) self::b64url_decode( $parts[0] ), true );
		if ( ! is_array( $payload ) ) {
			return new WP_Error( 'aaw_license', 'محتوای لایسنس خوانا نیست.' );
		}
		return $payload;
	}

	/* ============================ State ============================ */

	/**
	 * Current license state.
	 *
	 * @return array{status:string,label:string,message:string,can_generate:bool,license:array,trial:array}
	 */
	public static function state() {
		$d     = self::data();
		$trial = self::trial();
		$now   = time();
		$out   = array(
			'status'       => 'trial',
			'label'        => 'نسخه آزمایشی',
			'message'      => '',
			'can_generate' => false,
			'license'      => array(),
			'trial'        => $trial,
			'key_mask'     => self::mask_key( self::key() ),
			'domain'       => self::domain(),
			'configured'   => self::is_configured(),
			'last_check'   => (int) $d['last_check'],
			'last_error'   => (string) $d['last_error'],
		);

		if ( self::is_owner() ) {
			$out['status']       = 'active';
			$out['label']        = 'نسخه مالک · نامحدود';
			$out['message']      = 'نسخه اختصاصی مالک: بدون محدودیت سایت، زمان و تعداد مقاله؛ نیازی به فعال‌سازی نیست.';
			$out['can_generate'] = true;
			$out['license']      = array( 'plan' => 'مالک (نامحدود)', 'sites' => 0, 'expires' => 0, 'domain' => self::domain() );
			$out['key_mask']     = 'OWNER';
			return $out;
		}

		if ( $d['token'] ) {
			$p = self::verify_token( $d['token'] );
			if ( ! is_wp_error( $p ) ) {
				$out['license'] = $p;
				$problem        = '';
				if ( ( $p['product'] ?? '' ) !== self::config( 'product' ) ) {
					$problem = 'این لایسنس برای محصول دیگری صادر شده است.';
				} elseif ( self::normalize_domain( $p['domain'] ?? '' ) !== self::domain() ) {
					$problem = 'این لایسنس برای دامنه ' . ( $p['domain'] ?? '' ) . ' فعال شده است؛ دوباره فعال‌سازی کنید.';
				} elseif ( 'active' !== ( $p['status'] ?? '' ) ) {
					$problem = 'لایسنس غیرفعال یا باطل شده است.';
				}
				if ( $problem ) {
					$out['status']  = 'invalid';
					$out['label']   = 'لایسنس نامعتبر';
					$out['message'] = $problem;
					return $out;
				}
				if ( ! empty( $p['expires'] ) && $now > (int) $p['expires'] ) {
					$out['status']  = 'expired';
					$out['label']   = 'لایسنس منقضی شده';
					$out['message'] = 'اعتبار لایسنس در ' . wp_date( 'Y/m/d', (int) $p['expires'] ) . ' تمام شده است. برای ادامه تولید مقاله، تمدید کنید.';
					return $out;
				}
				if ( $now > (int) ( $p['valid_until'] ?? 0 ) ) {
					$out['status']  = 'stale';
					$out['label']   = 'نیاز به بررسی لایسنس';
					$out['message'] = 'مدتی است ارتباط با سرور لایسنس برقرار نشده. دکمه «بررسی مجدد» را بزنید.';
					return $out;
				}
				$out['status']       = 'active';
				$out['label']        = 'لایسنس فعال';
				$out['can_generate'] = true;
				$out['message']      = empty( $p['expires'] ) ? 'لایسنس دائمی' : 'معتبر تا ' . wp_date( 'Y/m/d', (int) $p['expires'] );
				return $out;
			}
			$out['status']  = 'invalid';
			$out['label']   = 'لایسنس نامعتبر';
			$out['message'] = $p->get_error_message();
			return $out;
		}

		if ( $trial['active'] ) {
			$out['status']       = 'trial';
			$out['label']        = 'نسخه آزمایشی';
			$out['can_generate'] = true;
			$out['message']      = sprintf( '%d روز و %d مقاله از دوره آزمایشی باقی مانده است.', $trial['days_left'], $trial['articles_left'] );
		} else {
			$out['status']  = 'trial_ended';
			$out['label']   = 'پایان دوره آزمایشی';
			$out['message'] = 'دوره آزمایشی تمام شد. برای ادامه تولید خودکار مقاله، لایسنس تهیه و فعال کنید.';
		}
		return $out;
	}

	public static function is_active() {
		$s = self::state();
		return 'active' === $s['status'];
	}

	/** @return true|WP_Error */
	public static function can_generate() {
		$s = self::state();
		if ( $s['can_generate'] ) {
			return true;
		}
		return new WP_Error( 'aaw_license', $s['message'] ? $s['message'] : 'برای تولید مقاله، لایسنس را فعال کنید.' );
	}

	/* ============================ Trial ============================ */

	public static function trial() {
		$t = get_option( self::TRIAL, array() );
		if ( ! is_array( $t ) || empty( $t['started'] ) ) {
			$t = array( 'started' => time(), 'articles' => 0 );
			update_option( self::TRIAL, $t, false );
		}
		$days      = max( 0, (int) self::config( 'trial_days' ) );
		$max       = max( 0, (int) self::config( 'trial_articles' ) );
		$ends      = (int) $t['started'] + $days * DAY_IN_SECONDS;
		$days_left = max( 0, (int) ceil( ( $ends - time() ) / DAY_IN_SECONDS ) );
		$art_left  = max( 0, $max - (int) $t['articles'] );
		return array(
			'started'       => (int) $t['started'],
			'ends'          => $ends,
			'days'          => $days,
			'articles'      => (int) $t['articles'],
			'max_articles'  => $max,
			'days_left'     => $days_left,
			'articles_left' => $art_left,
			'active'        => $days > 0 && $max > 0 && time() < $ends && $art_left > 0,
		);
	}

	/** Count a generated article against the trial quota. */
	public static function record_article() {
		if ( self::is_owner() || self::is_active() ) {
			return;
		}
		$t             = get_option( self::TRIAL, array() );
		$t             = is_array( $t ) ? $t : array();
		$t['started']  = ! empty( $t['started'] ) ? (int) $t['started'] : time();
		$t['articles'] = (int) ( $t['articles'] ?? 0 ) + 1;
		update_option( self::TRIAL, $t, false );
	}

	/* ============================ Server API ============================ */

	private static function api( $route, array $body, $timeout = 25 ) {
		if ( ! self::is_configured() ) {
			return new WP_Error( 'aaw_license', 'سرور لایسنس در این نسخه پیکربندی نشده است. نسخه رسمی را از فروشگاه دریافت کنید.' );
		}
		$body = array_merge(
			array(
				'product'  => self::config( 'product' ),
				'domain'   => self::domain(),
				'site_url' => home_url(),
				'version'  => defined( 'AAW_VERSION' ) ? AAW_VERSION : '',
				'wp'       => function_exists( 'get_bloginfo' ) ? get_bloginfo( 'version' ) : '',
				'php'      => PHP_VERSION,
			),
			$body
		);
		$res = wp_remote_post(
			self::config( 'api' ) . '/' . ltrim( $route, '/' ),
			array(
				'timeout' => $timeout,
				'headers' => array( 'Content-Type' => 'application/json', 'Accept' => 'application/json' ),
				'body'    => wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $res ) ) {
			$e = AAW_Errors::network( $res, self::config( 'api' ), 0, 'سرور لایسنس' );
			return new WP_Error( 'aaw_license', $e->get_error_message(), array( 'network' => true ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$json = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $json ) ) {
			return new WP_Error( 'aaw_license', 'پاسخ نامعتبر از سرور لایسنس (HTTP ' . $code . ').', array( 'network' => true ) );
		}
		if ( $code >= 400 || empty( $json['success'] ) ) {
			return new WP_Error( 'aaw_license', ! empty( $json['message'] ) ? (string) $json['message'] : 'درخواست لایسنس رد شد.', array( 'code' => $json['code'] ?? '', 'http' => $code ) );
		}
		return $json;
	}

	private static function store_token( $token ) {
		$p = self::verify_token( $token );
		if ( is_wp_error( $p ) ) {
			return $p;
		}
		if ( self::normalize_domain( $p['domain'] ?? '' ) !== self::domain() ) {
			return new WP_Error( 'aaw_license', 'دامنه توکن با دامنه این سایت یکی نیست.' );
		}
		$d               = self::data();
		$d['token']      = $token;
		$d['last_check'] = time();
		$d['last_error'] = '';
		if ( empty( $d['activated_at'] ) ) {
			$d['activated_at'] = time();
		}
		self::save( $d );
		delete_transient( self::UPDATE_KEY );
		return $p;
	}

	/** @return array|WP_Error */
	public static function activate( $key ) {
		$key = self::sanitize_key_input( $key );
		if ( strlen( $key ) < 12 ) {
			return new WP_Error( 'aaw_license', 'کلید لایسنس را کامل وارد کنید.' );
		}
		$r = self::api( 'license/activate', array( 'license_key' => $key ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		if ( empty( $r['token'] ) ) {
			return new WP_Error( 'aaw_license', 'سرور لایسنس توکن برنگرداند.' );
		}
		AAW_Settings::secure_set( 'license_key', $key );
		$p = self::store_token( $r['token'] );
		if ( is_wp_error( $p ) ) {
			return $p;
		}
		if ( class_exists( 'AAW_Logs' ) ) {
			AAW_Logs::add( 'success', 'system', 'لایسنس ' . self::config( 'product_name' ) . ' روی ' . self::domain() . ' فعال شد.' );
		}
		return self::state();
	}

	/** Re-validate with the server; keeps the cached token on network errors (grace). */
	public static function check( $force = false ) {
		$key = self::key();
		$d   = self::data();
		if ( ! $key || ! self::is_configured() ) {
			return self::state();
		}
		if ( ! $force && ( time() - (int) $d['last_check'] ) < 6 * HOUR_IN_SECONDS ) {
			return self::state();
		}
		$r = self::api( 'license/check', array( 'license_key' => $key ) );
		if ( is_wp_error( $r ) ) {
			$err  = $r->get_error_data();
			$d    = self::data();
			$d['last_error'] = $r->get_error_message();
			if ( empty( $err['network'] ) ) {
				// Server explicitly rejected the license (revoked / expired / deleted).
				$d['token'] = '';
			}
			$d['last_check'] = time();
			self::save( $d );
			return self::state();
		}
		if ( ! empty( $r['token'] ) ) {
			$p = self::store_token( $r['token'] );
			if ( is_wp_error( $p ) ) {
				$d               = self::data();
				$d['last_error'] = $p->get_error_message();
				self::save( $d );
			}
		}
		return self::state();
	}

	public static function deactivate() {
		$key = self::key();
		$r   = $key ? self::api( 'license/deactivate', array( 'license_key' => $key ) ) : true;
		AAW_Settings::secure_set( 'license_key', '' );
		self::save( array( 'token' => '', 'last_check' => time(), 'last_error' => '', 'activated_at' => 0 ) );
		delete_transient( self::UPDATE_KEY );
		if ( is_wp_error( $r ) && empty( $r->get_error_data()['network'] ) ) {
			return $r;
		}
		return self::state();
	}

	/** Plans published by the store (cached). */
	public static function plans( $force = false ) {
		if ( ! self::is_configured() ) {
			return array();
		}
		$c = $force ? false : get_transient( 'aaw_store_plans' );
		if ( is_array( $c ) ) {
			return $c;
		}
		$res   = wp_remote_get( self::config( 'api' ) . '/store/plans', array( 'timeout' => 10 ) );
		$json  = is_wp_error( $res ) ? null : json_decode( (string) wp_remote_retrieve_body( $res ), true );
		$plans = array();
		if ( is_array( $json ) && ! empty( $json['plans'] ) && is_array( $json['plans'] ) ) {
			foreach ( array_slice( $json['plans'], 0, 6 ) as $p ) {
				$plans[] = array(
					'name'     => sanitize_text_field( $p['name'] ?? '' ),
					'price'    => wp_strip_all_tags( (string) ( $p['price'] ?? '' ) ),
					'sites'    => (int) ( $p['sites'] ?? 1 ),
					'period'   => sanitize_text_field( $p['period'] ?? '' ),
					'url'      => esc_url_raw( $p['url'] ?? '' ),
					'featured' => ! empty( $p['featured'] ),
					'features' => array_map( 'sanitize_text_field', array_slice( (array) ( $p['features'] ?? array() ), 0, 8 ) ),
				);
			}
		}
		set_transient( 'aaw_store_plans', $plans, $plans ? 12 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
		return $plans;
	}

	/* ============================ Updates ============================ */

	public static function register_hooks() {
		add_action( 'aaw_license_check', array( __CLASS__, 'cron_check' ) );
		if ( ( is_admin() || wp_doing_cron() ) && ! wp_next_scheduled( 'aaw_license_check' ) ) {
			wp_schedule_event( time() + 600, 'daily', 'aaw_license_check' );
		}
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject_update' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'plugins_api' ), 20, 3 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'clear_update_cache' ), 10, 0 );
		add_action( 'in_plugin_update_message-' . plugin_basename( AAW_FILE ), array( __CLASS__, 'update_message' ), 10, 2 );
	}

	public static function cron_check() {
		self::check( true );
	}

	public static function clear_update_cache() {
		delete_transient( self::UPDATE_KEY );
	}

	/** @return array|null */
	public static function remote_info( $force = false ) {
		if ( ! self::is_configured() ) {
			return null;
		}
		$c = $force ? false : get_transient( self::UPDATE_KEY );
		if ( is_array( $c ) ) {
			return $c;
		}
		$r = self::api( 'update/check', array( 'license_key' => self::key() ), 15 );
		if ( is_wp_error( $r ) ) {
			set_transient( self::UPDATE_KEY, array( 'error' => $r->get_error_message() ), HOUR_IN_SECONDS );
			return null;
		}
		$info = isset( $r['update'] ) && is_array( $r['update'] ) ? $r['update'] : array();
		set_transient( self::UPDATE_KEY, $info, 12 * HOUR_IN_SECONDS );
		return $info;
	}

	public static function inject_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$info = self::remote_info();
		if ( empty( $info['version'] ) ) {
			return $transient;
		}
		$base = plugin_basename( AAW_FILE );
		$item = (object) array(
			'id'            => $base,
			'slug'          => AAW_SLUG,
			'plugin'        => $base,
			'new_version'   => $info['version'],
			'url'           => self::config( 'store_url' ),
			'package'       => isset( $info['package'] ) ? $info['package'] : '',
			'tested'        => isset( $info['tested'] ) ? $info['tested'] : '',
			'requires'      => isset( $info['requires'] ) ? $info['requires'] : '5.8',
			'requires_php'  => isset( $info['requires_php'] ) ? $info['requires_php'] : '7.4',
			'icons'         => array( '1x' => AAW_URL . 'assets/img/icon-128x128.png', '2x' => AAW_URL . 'assets/img/icon-256x256.png' ),
			'banners'       => array( 'low' => AAW_URL . 'assets/img/banner-772x250.png', 'high' => AAW_URL . 'assets/img/banner-1544x500.png' ),
		);
		if ( version_compare( $info['version'], AAW_VERSION, '>' ) ) {
			$transient->response[ $base ] = $item;
		} else {
			$transient->no_update[ $base ] = $item;
		}
		return $transient;
	}

	public static function plugins_api( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || AAW_SLUG !== $args->slug ) {
			return $result;
		}
		$info = self::remote_info();
		return (object) array(
			'name'          => self::config( 'product_name' ),
			'slug'          => AAW_SLUG,
			'version'       => ! empty( $info['version'] ) ? $info['version'] : AAW_VERSION,
			'author'        => '<a href="' . esc_url( self::config( 'store_url' ) ) . '">ARIAGH</a>',
			'homepage'      => self::config( 'store_url' ),
			'requires'      => $info['requires'] ?? '5.8',
			'tested'        => $info['tested'] ?? '',
			'requires_php'  => $info['requires_php'] ?? '7.4',
			'last_updated'  => $info['last_updated'] ?? '',
			'download_link' => $info['package'] ?? '',
			'sections'      => array(
				'description' => 'تولید خودکار مقالات حرفه‌ای و سئوشده با هوش مصنوعی، زمان‌بندی روی Cloudflare و ذخیره در پیش‌نویس برای تایید شما.',
				'changelog'   => ! empty( $info['changelog'] ) ? wp_kses_post( $info['changelog'] ) : '—',
			),
			'banners'       => array( 'low' => AAW_URL . 'assets/img/banner-772x250.png', 'high' => AAW_URL . 'assets/img/banner-1544x500.png' ),
			'icons'         => array( '1x' => AAW_URL . 'assets/img/icon-128x128.png', '2x' => AAW_URL . 'assets/img/icon-256x256.png' ),
		);
	}

	public static function update_message( $data, $response ) {
		if ( empty( $response->package ) ) {
			echo ' <strong>برای دریافت خودکار این به‌روزرسانی، <a href="' . esc_url( admin_url( 'admin.php?page=aaw&tab=license' ) ) . '">لایسنس معتبر</a> فعال کنید.</strong>';
		}
	}
}
