/* ARIAGH.AIWRITER – post editor meta box (AI revise / new image). Loaded only on post edit screens. */
(function ($) {
	'use strict';
	const E = window.AAW_ED || {};
	const call = (action, data) => new Promise((resolve, reject) => {
		$.post(E.ajax, { action: 'aaw_' + action, nonce: E.nonce, data: JSON.stringify(data || {}) })
			.done((r) => (r && r.success ? resolve(r.data || {}) : reject(new Error((r && r.data && r.data.message) || 'خطا'))))
			.fail((x) => reject(new Error((x.responseJSON && x.responseJSON.data && x.responseJSON.data.message) || 'HTTP ' + x.status)));
	});
	$(document).on('click', '[data-aaw-mb-op]', function () {
		const $box = $(this).closest('[data-aaw-mb]');
		const id = Number($box.data('aaw-mb'));
		const op = $(this).data('aaw-mb-op');
		const $msg = $box.find('.aaw-mb-msg').css('color', '#1D4ED8');
		const $btn = $(this).prop('disabled', true);
		let p;
		if (op === 'revise') {
			const text = String($('#aaw-mb-text').val() || '').trim();
			if (!text) { $msg.text('دستور اصلاح را بنویسید.'); $btn.prop('disabled', false); return; }
			p = call('revise', { post_id: id, text });
		} else if (op === 'image') {
			p = call('post_image', { post_id: id, prompt: $('#aaw-mb-img').val(), inline: $('#aaw-mb-inline').is(':checked') });
		} else {
			if (!window.confirm('نسخه اصلاح‌شده جایگزین متن فعلی شود؟')) { $btn.prop('disabled', false); return; }
			p = call('revision_publish', { post_id: id });
		}
		$msg.text('در حال ارسال…');
		p.then((r) => {
			$msg.text((r.message || 'انجام شد.') + (op === 'publish_rev' ? ' صفحه تازه می‌شود…' : ' پس از پایان، صفحه را تازه کنید (تغییرات ذخیره‌نشده ویرایشگر را قبلاً ذخیره کنید).'));
			if (op === 'publish_rev') setTimeout(() => location.reload(), 1200);
		}).catch((e) => { $msg.css('color', '#b91c1c').text(e.message.split('\n').slice(0, 3).join(' – ')); })
			.finally(() => $btn.prop('disabled', false));
	});
})(jQuery);
