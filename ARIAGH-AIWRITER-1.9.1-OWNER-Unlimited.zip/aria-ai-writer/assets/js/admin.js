/* ARIAGH.AIWRITER – Admin UI */
(function ($) {
	'use strict';

	const A = window.AAW || {};
	const I = A.icons || {};
	const $app = $('.aaw-app');
	if (!$app.length) return;

	/* =========================================================
	 * Utilities
	 * ======================================================= */
	const fa = (n) => (Number(n) || 0).toLocaleString('fa-IR');
	const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

	/** Render explained errors (title / علت / راه‌حل / جزئیات) as readable HTML. */
	function fmtErr(msg) {
		const lines = String(msg == null ? '' : msg).split('\n');
		return lines.map((l, i) => {
			const e = esc(l);
			if (i === 0) return lines.length > 1 ? '<b>' + e + '</b>' : e;
			if (/^(علت|راه‌حل):/.test(l)) return '<div class="aaw-err-line">' + e.replace(/^(علت|راه‌حل):/, '<b>$1:</b>') + '</div>';
			if (/^جزئیات فنی:/.test(l)) return '<div class="aaw-err-tech" dir="auto">' + e + '</div>';
			return '<div>' + e + '</div>';
		}).join('');
	}

	/** Exact reason for a failed admin-ajax request (no JSON from WordPress). */
	function explainAjaxFail(xhr) {
		const st = xhr.status;
		const txt = String(xhr.responseText || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 240);
		if (/Maximum execution time/i.test(txt)) return 'زمان اجرای PHP تمام شد\nعلت: max_execution_time هاست/لوکال کمتر از زمان لازم برای این عملیات است و PHP وسط کار متوقف شد.\nراه‌حل: در php.ini مقدار max_execution_time را حداقل 300 کنید (روی هاست از پشتیبانی بخواهید).\nجزئیات فنی: ' + txt;
		if (/Allowed memory size/i.test(txt)) return 'حافظه PHP تمام شد\nعلت: memory_limit برای این عملیات کافی نیست.\nراه‌حل: در wp-config.php بنویسید define(\'WP_MEMORY_LIMIT\', \'256M\');\nجزئیات فنی: ' + txt;
		if (st === 0) return 'ارتباط مرورگر با سایت قطع شد\nعلت: درخواست قبل از پاسخ از سمت مرورگر/شبکه قطع شد (اینترنت یا VPN قطع شد، صفحه عوض شد، یا سرور لوکال خاموش است).\nراه‌حل: اتصال را بررسی و صفحه را تازه کنید؛ نتیجه کارهای طولانی در بخش گزارش‌ها ثبت می‌شود.';
		if (st === 403) return 'درخواست توسط سایت رد شد (403)\nعلت: نشست ورود منقضی شده یا یک افزونه امنیتی/فایروال هاست درخواست admin-ajax را بلاک کرده است.\nراه‌حل: صفحه را تازه کنید و دوباره وارد شوید؛ اگر تکرار شد، فایروال (Wordfence، ModSecurity هاست) را برای admin-ajax.php بررسی کنید.';
		if (st === 502 || st === 504 || st === 524) return 'هاست سایت در زمان مجاز پاسخ نداد (HTTP ' + st + ')\nعلت: وب‌سرور/پراکسی جلوی سایت (Nginx، کلادفلر) قبل از تمام شدن کار PHP اتصال را بست؛ عملیات طولانی‌تر از محدودیت هاست بود.\nراه‌حل: محدودیت زمان (fastcgi_read_timeout / proxy timeout) را از هاست افزایش دهید؛ برای کارهای طولانی حالت اتصال مستقیم را استفاده کنید.';
		if (st === 500) return 'خطای PHP روی سایت (500)\nعلت: هنگام اجرای این عملیات یک خطای PHP رخ داد.\nراه‌حل: در wp-config.php مقدار WP_DEBUG_LOG را true کنید و آخرین خطای wp-content/debug.log را ببینید.' + (txt ? '\nجزئیات فنی: ' + txt : '');
		if (st === 400 && txt === '0') return 'عملیات در وردپرس ثبت نشده است (400)\nعلت: افزونه به‌طور کامل بارگذاری نشده یا کش/افزونه دیگری admin-ajax را تغییر داده است.\nراه‌حل: افزونه را غیرفعال/فعال کنید و کش را پاک کنید.';
		return 'پاسخ نامعتبر از سایت (HTTP ' + st + ')\nعلت: وردپرس به‌جای JSON خروجی دیگری برگرداند؛ معمولاً یک خطای PHP یا متن اضافه از افزونه/قالب دیگر.\nراه‌حل: WP_DEBUG_LOG را فعال و debug.log را بررسی کنید.' + (txt ? '\nجزئیات فنی: ' + txt : '');
	}

	/** Replace raw error texts marked with data-explain by their exact explanation. */
	function explainPending() {
		$('[data-explain]').each(function () {
			const $el = $(this); const raw = $el.attr('data-explain'); $el.removeAttr('data-explain');
			ajax('explain', { error: raw }).then((r) => { if (r.message) $el.html(fmtErr(r.message)); }).catch(() => {});
		});
	}

	function ajax(action, data) {
		return new Promise((resolve, reject) => {
			$.post(A.ajax, { action: 'aaw_' + action, nonce: A.nonce, data: JSON.stringify(data || {}) })
				.done((r) => {
					if (r && r.success) resolve(r.data || {});
					else reject(new Error((r && r.data && r.data.message) || 'خطای ناشناخته'));
				})
				.fail((xhr) => {
					const m = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message;
					reject(new Error(m || explainAjaxFail(xhr)));
				});
		});
	}

	async function workerFetch(ticket, proxy) {
		let res;
		const headers = Object.assign({}, ticket.headers, A.workerStream ? { 'X-AAW-Stream': '1' } : {});
		try {
			res = await fetch(ticket.url, { method: 'POST', headers, body: ticket.body, mode: 'cors' });
		} catch (e) {
			if (proxy) {
				toast('info', 'مرورگر به ورکر دسترسی نداشت؛ درخواست از طریق سرور وردپرس ارسال شد…');
				return ajax('proxy', proxy);
			}
			throw new Error('مرورگر به ورکر کلادفلر وصل نشد\nعلت: درخواست قبل از رسیدن به ورکر مسدود شد؛ یعنی آدرس ورکر در شبکه/اینترنت شما فیلتر است، VPN یا افزونه مسدودکننده تبلیغات آن را بلاک کرده، یا ورکر قدیمی است و CORS را نمی‌پذیرد.\nراه‌حل: در تب کلادفلر «استقرار مجدد» را بزنید؛ اگر حل نشد، دامنه اختصاصی ورکر بسازید.\nجزئیات فنی: ' + e.message);
		}
		let text = '';
		try { text = await res.text(); } catch (_) { /* ignore */ }
		let data = null;
		try { data = JSON.parse(text); } catch (_) { /* ignore */ }
		if (data && data.ok !== false && res.ok) return data;
		const raw = (data && data.error) || (text.match(/error code:\s*\d{4}/i) || [''])[0] || ('HTTP ' + res.status + (text ? ': ' + text.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').slice(0, 160) : ''));
		// Ask WordPress to explain the raw worker/provider error precisely.
		let explained = raw;
		try { explained = (await ajax('explain', { error: raw })).message || raw; } catch (_) { /* keep raw */ }
		throw new Error(explained);
	}

	function toast(type, msg, ms) {
		const icon = type === 'success' ? I['check-circle'] : type === 'error' ? I.alert : I.info;
		const long = String(msg || '').indexOf('\n') !== -1;
		const $t = $('<div class="aaw-toast is-' + type + (long ? ' is-long' : '') + '">' + (icon || '') + '<div>' + fmtErr(msg) + '</div>' + (long ? '<button type="button" class="aaw-toast-x" aria-label="بستن">×</button>' : '') + '</div>');
		$('.aaw-toasts').append($t);
		$t.on('click', '.aaw-toast-x', () => $t.remove());
		setTimeout(() => { $t.addClass('is-out'); setTimeout(() => $t.remove(), 300); }, ms || (type === 'error' ? (long ? 30000 : 9000) : 3800));
	}

	function busy($btn, on) {
		$btn = $($btn);
		if (on) {
			$btn.addClass('is-loading').prop('disabled', true);
			const $ic = $btn.find('.aaw-ic').first();
			$btn.data('ic', $ic.prop('outerHTML'));
			if ($ic.length) $ic.replaceWith(I.loader);
			else $btn.prepend(I.loader);
		} else {
			$btn.removeClass('is-loading').prop('disabled', false);
			const old = $btn.data('ic');
			const $cur = $btn.find('.aaw-ic').first();
			if (old) $cur.replaceWith(old); else $cur.remove();
		}
	}

	async function withBusy(btn, fn) {
		busy(btn, true);
		try { return await fn(); } catch (e) { toast('error', e.message); } finally { busy(btn, false); }
	}

	const Modal = {
		$el: $('.aaw-modal'),
		open(opts) {
			const $m = this.$el;
			$m.find('.aaw-modal-head h3').text(opts.title || '');
			const $b = $m.find('.aaw-modal-body').empty();
			if (typeof opts.body === 'string') $b.html(opts.body); else $b.append(opts.body);
			const $f = $m.find('.aaw-modal-foot').empty();
			(opts.buttons || []).forEach((b) => {
				const $btn = $('<button type="button" class="aaw-btn ' + (b.cls || 'aaw-btn-ghost') + '">' + (b.icon ? I[b.icon] || '' : '') + ' ' + esc(b.text) + '</button>');
				$btn.on('click', () => b.click && b.click($btn));
				$f.append($btn);
			});
			$m.find('.aaw-modal-box').toggleClass('is-wide', !!opts.wide);
			$m.prop('hidden', false);
			setTimeout(() => $b.find('input,textarea,select').filter(':visible').first().trigger('focus'), 50);
			return $m;
		},
		close() { this.$el.prop('hidden', true); },
		body() { return this.$el.find('.aaw-modal-body'); },
	};
	$app.on('click', '[data-close]', () => Modal.close());

	function confirmBox(title, text, okText, danger) {
		return new Promise((resolve) => {
			Modal.open({
				title,
				body: '<p>' + esc(text) + '</p>',
				buttons: [
					{ text: okText || 'تایید', cls: danger ? 'aaw-btn-danger' : 'aaw-btn-primary', click: () => { Modal.close(); resolve(true); } },
					{ text: 'انصراف', click: () => { Modal.close(); resolve(false); } },
				],
			});
		});
	}

	function download(name, content, mime) {
		const blob = new Blob([content], { type: mime || 'text/plain;charset=utf-8' });
		const a = document.createElement('a');
		a.href = URL.createObjectURL(blob);
		a.download = name;
		document.body.appendChild(a);
		a.click();
		setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
	}

	function pickFile($input) {
		return new Promise((resolve) => {
			$input.off('change').on('change', function () {
				const f = this.files && this.files[0];
				if (!f) return resolve(null);
				const r = new FileReader();
				r.onload = () => resolve(r.result);
				r.readAsText(f, 'utf-8');
				this.value = '';
			});
			$input.trigger('click');
		});
	}

	const statusLabels = { pending: 'در صف', processing: 'در حال تولید', done: 'تولید شد', failed: 'خطا', skipped: 'رد شده', paused: 'متوقف' };
	const postStatus = { draft: 'پیش‌نویس', pending: 'در انتظار بررسی', future: 'زمان‌بندی‌شده', publish: 'منتشرشده', trash: 'زباله‌دان' };

	/* =========================================================
	 * Countdown
	 * ======================================================= */
	function tickCountdowns() {
		const now = Math.floor(Date.now() / 1000);
		$('[data-countdown]').each(function () {
			const t = Number($(this).attr('data-countdown'));
			if (!t) return;
			let d = t - now;
			if (d < 0) { $(this).text('در حال اجرا…'); return; }
			const h = Math.floor(d / 3600); d %= 3600;
			const m = Math.floor(d / 60); const s = d % 60;
			const pad = (x) => String(x).padStart(2, '0');
			const txt = $(this).data('long') ? fa(h) + ':' + pad(m).replace(/\d/g, (x) => fa(x)) + ':' + pad(s).replace(/\d/g, (x) => fa(x)) : 'اجرای بعدی ' + (h ? fa(h) + ' ساعت و ' : '') + fa(m) + ' دقیقه دیگر';
			$(this).text(txt);
		});
	}
	tickCountdowns();
	setInterval(tickCountdowns, 1000);

	/* =========================================================
	 * Settings forms
	 * ======================================================= */
	function collect($form) {
		const out = {};
		$form.find('input[name], select[name], textarea[name]').each(function () {
			const el = this;
			const name = el.name;
			if (!name || el.disabled) return;
			if (name.endsWith('[]')) {
				const key = name.slice(0, -2);
				out[key] = out[key] || [];
				if (el.checked) out[key].push(el.value);
				return;
			}
			if (el.type === 'checkbox') out[name] = el.checked;
			else if (el.type === 'radio') { if (el.checked) out[name] = el.value; }
			else out[name] = el.value;
		});
		return out;
	}

	function applyShowIf($scope) {
		$scope.find('[data-show-if]').each(function () {
			const [k, v] = $(this).attr('data-show-if').split('=');
			const $f = $scope.find('[name="' + k + '"]');
			const val = $f.filter(':radio').length ? $f.filter(':checked').val() : $f.val();
			$(this).toggleClass('is-hidden', val !== v);
		});
	}

	$('form[data-settings]').each(function () {
		const $form = $(this);
		applyShowIf($form);
		$form.on('input change', 'input, select, textarea', function () {
			$form.addClass('is-dirty');
			applyShowIf($form);
			if (this.type === 'range') $(this).siblings('output').text(this.value);
		});
		$form.on('submit', async function (e) {
			e.preventDefault();
			const $btn = $form.find('button[type=submit]').first();
			await withBusy($btn, async () => {
				const r = await ajax('save_settings', { settings: collect($form) });
				$form.removeClass('is-dirty');
				toast('success', r.message);
				if (r.next_run) $('[data-countdown]').attr('data-countdown', r.next_run.ts);
				if ($form.is('[data-ai-form]') && $form.find('[name=provider]').length) A.active = $form.find('[name=provider]').val();
				$form.find('input[type=password]').val('');
			});
		});
	});

	window.addEventListener('beforeunload', (e) => {
		if ($('form.is-dirty').length) { e.preventDefault(); e.returnValue = ''; }
	});

	// Interval chips.
	$app.on('click', '[data-interval-chips] button', function () {
		const h = $(this).data('h');
		$(this).addClass('is-active').siblings().removeClass('is-active');
		$('[name=interval_hours]').val(h).trigger('change');
	});
	$app.on('input', '[name=interval_hours]', function () {
		const v = Number(this.value);
		$('[data-interval-chips] button').each(function () { $(this).toggleClass('is-active', Number($(this).data('h')) === v); });
	});

	$app.on('input', '.aaw-range input[type=range]', function () { $(this).siblings('output').text(this.value); });

	// Password toggles.
	$app.on('click', '[data-toggle-pass]', function () {
		const $i = $(this).siblings('input');
		const show = $i.attr('type') === 'password';
		$i.attr('type', show ? 'text' : 'password');
		$(this).html(show ? I.x : I.eye);
	});

	/* =========================================================
	 * Run now
	 * ======================================================= */
	/* ---------- AI revise / new image (review queue) ---------- */
	const aiStates = { revising: ['is-info', 'در حال اصلاح با هوش مصنوعی…'], revised: ['is-ok', 'اصلاح شد – آماده انتشار'], revision_ready: ['is-ok', 'نسخه اصلاح‌شده آماده است'], imaging: ['is-info', 'در حال ساخت تصویر جدید…'], image_ready: ['is-ok', 'تصویر جدید ثبت شد'], error: ['is-bad', 'خطا در آخرین درخواست هوش مصنوعی'], image_error: ['is-bad', 'تصویر ساخته نشد'] };
	function aiStateBadge(p) {
		const st = p.ai_state && p.ai_state.state;
		if (!st || !aiStates[st]) return p.revisions ? '<div class="aaw-ai-state"><span class="aaw-chip">' + fa(p.revisions) + ' اصلاح</span></div>' : '';
		return '<div class="aaw-ai-state"><span class="aaw-chip ' + aiStates[st][0] + '">' + (/ing$/.test(st) ? I.loader : I.sparkles) + ' ' + aiStates[st][1] + '</span>' + ((st === 'error' || st === 'image_error' || st === 'imaging') && p.ai_state.note ? '<small>' + esc(String(p.ai_state.note).split('\n')[0]) + '</small>' : '') + '</div>';
	}
	function aiReviseModal(postId, title, done) {
		Modal.open({
			title: 'اصلاح با هوش مصنوعی',
			body: '<p class="aaw-muted">«' + esc(title || '') + '»</p><label class="aaw-label">چه چیزی تغییر کند؟</label><textarea class="aaw-input" rows="6" data-ai-text placeholder="مثلاً: مقدمه کوتاه‌تر و جذاب‌تر شود، یک جدول مقایسه قیمت کیمچی ۵۰۰ و ۱۰۰۰ گرمی اضافه کن، لحن صمیمی‌تر باشد و در پایان به صفحه محصول لینک بده."></textarea><p class="aaw-help">هوش مصنوعی فقط همین اصلاحات را روی همین نوشته انجام می‌دهد و نتیجه دوباره برای تایید و انتشار به صف بازبینی برمی‌گردد. اگر نوشته منتشر شده باشد، تا وقتی «انتشار اصلاحات» را نزنید تغییری در سایت دیده نمی‌شود.</p>',
			buttons: [{ text: 'ارسال برای هوش مصنوعی', cls: 'aaw-btn-primary', icon: 'send', click: ($b) => withBusy($b, async () => {
				const text = String($('[data-ai-text]').val() || '').trim();
				if (!text) { toast('info', 'دستور اصلاح را بنویسید.'); return; }
				const r = await ajax('revise', { post_id: postId, text });
				Modal.close(); toast('success', r.message, 7000); if (done) done();
			}) }, { text: 'انصراف', click: () => Modal.close() }],
		});
		setTimeout(() => $('[data-ai-text]').trigger('focus'), 50);
	}
	function aiImageModal(postId, title, last, done) {
		Modal.open({
			title: 'فقط تصویر جدید (متن تغییر نمی‌کند)',
			body: '<p class="aaw-muted">«' + esc(title || '') + '»</p><label class="aaw-label">تصویر چطور باشد؟</label><textarea class="aaw-input" rows="5" data-ai-img placeholder="مثلاً: شیشه کیمچی بن‌لی روی میز چوبی کنار کاسه برنج، نور طبیعی صبح، پس‌زمینه آشپزخانه روشن، نمای نزدیک">' + esc(last || '') + '</textarea><label class="aaw-check aaw-mt"><input type="checkbox" data-ai-inline> تصاویر داخل متن را هم دوباره بساز</label><p class="aaw-help">عکس محصولات مرتبط و تم سایت خودکار به‌عنوان مرجع ارسال می‌شود (طبق تنظیمات تب تصاویر).</p>',
			buttons: [{ text: 'ساخت تصویر', cls: 'aaw-btn-primary', icon: 'image', click: ($b) => withBusy($b, async () => {
				const r = await ajax('post_image', { post_id: postId, prompt: $('[data-ai-img]').val(), inline: $('[data-ai-inline]').is(':checked') });
				Modal.close(); toast('success', r.message, 7000); if (done) done();
			}) }, { text: 'انصراف', click: () => Modal.close() }],
		});
	}

	/** Register a browser-driven operation in the Live activity tab. */
	async function trackOp(kind, label, fn) {
		let id = '';
		try { id = (await ajax('act_start', { kind, label })).id; } catch (_) { /* tracking is best-effort */ }
		try {
			const r = await fn();
			if (id) ajax('act_end', { id, ok: 1 }).catch(() => {});
			return r;
		} catch (e) {
			if (id) ajax('act_end', { id, ok: 0, detail: e.message }).catch(() => {});
			throw e;
		}
	}

	/** Poll a Cloudflare background job (short requests only). */
	async function waitBg(id, onStep) {
		const t0 = Date.now();
		let fails = 0;
		for (;;) {
			await new Promise((r) => setTimeout(r, 4000));
			let j;
			try { j = await ajax('bg_status', { id }); fails = 0; } catch (e) { if (++fails >= 5) throw e; continue; }
			if (j.step) { $('.aaw-run-progress b').text(j.step); if (onStep) onStep(j.step); }
			if (j.status === 'done') return j;
			if (j.status === 'error') throw new Error(j.error || 'خطا در کار پس‌زمینه');
			if (Date.now() - t0 > 16 * 60 * 1000) throw new Error('کار پس‌زمینه بیش از ۱۵ دقیقه طول کشید\nعلت: کار روی کلادفلر تمام نشد یا متوقف شد.\nراه‌حل: چند دقیقه بعد صف بازبینی و گزارش‌ها را ببینید.');
		}
	}

	async function runNow(topicId) {
		if (!A.deployed) { toast('error', 'ابتدا ورکر را در تب کلادفلر مستقر کنید.'); return; }
		Modal.open({
			title: 'تولید فوری مقاله',
			body: '<div class="aaw-run-progress"><div class="aaw-orb"></div><b>هوش مصنوعی در حال نوشتن مقاله است…</b><small>این کار بسته به مدل و طول مقاله ۳۰ ثانیه تا چند دقیقه طول می‌کشد. این پنجره را نبندید.</small><small data-elapsed>۰ ثانیه</small></div>',
		});
		const started = Date.now();
		const timer = setInterval(() => $('[data-elapsed]').text(fa(Math.round((Date.now() - started) / 1000)) + ' ثانیه'), 1000);
		try {
			let res;
			if (A.pull) {
				res = await ajax('pull_run', { topic_id: topicId || 0 });
				if (res.bg) {
					const j = await waitBg(res.bg);
					const got = (j.poll && j.poll.drafts) || 0;
					res = { status: got ? 'ok' : 'skip', ms: Date.now() - started, drafts: [], errors: [], reason: got ? '' : 'کار تمام شد ولی پیش‌نویسی ساخته نشد؛ گزارش‌ها را ببینید.', bgDrafts: got, ideas: res.ideas };
				}
			} else if (A.bg) {
				const st = await ajax('run_bg', { topic_id: topicId || 0 });
				const j = await waitBg(st.id);
				res = j.result || {};
			} else {
				const ticket = await ajax('run_ticket', { topic_id: topicId || 0 });
				const r = await trackOp('run', 'تولید فوری مقاله', () => workerFetch(ticket, { kind: 'run', topic_id: topicId || 0 }));
				res = r.result || {};
			}
			let html = '';
			if (res.bgDrafts) {
				html += '<div class="aaw-alert is-ok">' + I['check-circle'] + '<div><b>' + fa(res.bgDrafts) + ' مقاله در پیش‌نویس ذخیره شد.</b><br><a href="admin.php?page=aaw&tab=review">مشاهده در صف بازبینی</a></div></div>';
			}
			if (res.drafts && res.drafts.length) {
				html += '<div class="aaw-alert is-ok">' + I['check-circle'] + '<div><b>' + fa(res.drafts.length) + ' مقاله در پیش‌نویس ذخیره شد.</b></div></div><ul class="aaw-run-log">';
				res.drafts.forEach((d) => { html += '<li><span class="ok">' + I.check + '</span><div><b>' + esc(d.title) + '</b><br><a href="' + esc(d.edit_url) + '" target="_blank">ویرایش و تایید</a></div></li>'; });
				html += '</ul>';
			}
			if (res.errors && res.errors.length) {
				setTimeout(explainPending, 60);
				html += '<ul class="aaw-run-log">';
				res.errors.forEach((e) => { html += '<li><span class="bad">' + I.alert + '</span><div><b>' + esc(e.topic || 'خطا') + '</b><br><small data-explain="' + esc(e.error) + '">' + esc(e.error) + '</small>' + (/WordPress \(|error code: 10/.test(e.error || '') ? '<br><a class="aaw-btn aaw-btn-sm aaw-btn-ghost aaw-mt" href="admin.php?page=aaw&tab=cloudflare">' + I.search + ' عیب‌یابی اتصال ورکر ↔ وردپرس</a>' : '') + '</div></li>'; });
				html += '</ul>';
			}
			if (!html) {
				const reasons = { empty: 'صف موضوعات خالی است و ایده‌پردازی خودکار خاموش است.', skip: res.reason, locked: 'اجرای دیگری در حال انجام است.' };
				html = res.status === 'dispatched'
					? '<div class="aaw-alert is-ok">' + I['check-circle'] + '<div><b>' + esc(res.reason) + '</b>' + (res.url ? '<br><a href="' + esc(res.url) + '" target="_blank" rel="noopener">مشاهده اجرا در GitHub</a>' : '') + '</div></div>'
					: '<div class="aaw-alert is-info">' + I.info + '<div>' + esc(reasons[res.status] || res.reason || 'کاری برای انجام وجود نداشت.') + '</div></div>';
			}
			html += '<small class="aaw-muted">مدت: ' + fa(Math.round((res.ms || 0) / 1000)) + ' ثانیه' + (res.ideas ? ' · ' + fa(res.ideas) + ' ایده جدید اضافه شد' : '') + '</small>';
			Modal.body().html(html);
			Modal.$el.find('.aaw-modal-foot').html('');
			if (typeof refreshCurrent === 'function') refreshCurrent();
		} catch (e) {
			Modal.body().html('<div class="aaw-alert is-error">' + I.alert + '<div>' + fmtErr(e.message) + (/10\d\d|WordPress \(/.test(e.message) ? '<br><a href="admin.php?page=aaw&tab=cloudflare">رفتن به عیب‌یابی اتصال</a>' : '') + '</div></div>');
		} finally {
			clearInterval(timer);
		}
	}
	$app.on('click', '[data-action="run-now"]', () => runNow(0));

	let refreshCurrent = null;

	/* =========================================================
	 * Dashboard
	 * ======================================================= */
	function renderChart($el) {
		const daily = JSON.parse($el.attr('data-daily') || '[]');
		const map = {};
		daily.forEach((d) => { map[d.d] = d; });
		const days = [];
		for (let i = 13; i >= 0; i--) {
			const dt = new Date(Date.now() - i * 86400000);
			const key = dt.toISOString().slice(0, 10);
			days.push({ key, label: dt.toLocaleDateString('fa-IR', { day: 'numeric' }), ok: Number((map[key] || {}).ok || 0), fail: Number((map[key] || {}).fail || 0) });
		}
		const max = Math.max(1, ...days.map((d) => d.ok + d.fail));
		$el.html(days.map((d) => '<div class="aaw-bar" data-tip="' + esc(new Date(d.key).toLocaleDateString('fa-IR')) + ' · ' + fa(d.ok) + ' موفق' + (d.fail ? ' · ' + fa(d.fail) + ' خطا' : '') + '"><i class="ok" style="height:' + (d.ok / max * 100) + '%"></i>' + (d.fail ? '<i class="fail" style="height:' + (d.fail / max * 100) + '%"></i>' : '') + '<span>' + d.label + '</span></div>').join(''));
	}
	$('.aaw-chart').each(function () { renderChart($(this)); });

	if ($('[data-review-mini]').length) {
		ajax('review_list', {}).then((r) => {
			const $w = $('[data-review-mini]');
			if (!r.items.length) { $w.html('<div class="aaw-empty">' + I.inbox + '<p>مقاله‌ای در انتظار بازبینی نیست.</p></div>'); return; }
			$w.html(r.items.slice(0, 6).map((p) => '<a class="row" href="' + esc(p.edit_url) + '"><b>' + esc(p.title) + '</b><small>' + esc(p.date) + ' · ' + fa(p.words) + ' کلمه</small></a>').join('') + '<a class="aaw-btn aaw-btn-ghost aaw-btn-block" href="admin.php?page=aaw&tab=review">مشاهده صف بازبینی</a>');
		}).catch((e) => $('[data-review-mini]').html('<p class="aaw-muted">' + fmtErr(e.message) + '</p>'));
	}

	/* =========================================================
	 * Review queue
	 * ======================================================= */
	const Review = {
		status: '',
		items: [],
		init() {
			if (!$('[data-review-list]').length) return;
			refreshCurrent = () => this.load();
			$('[data-review-filter]').on('click', 'button', (e) => {
				$(e.currentTarget).addClass('is-active').siblings().removeClass('is-active');
				this.status = $(e.currentTarget).data('status');
				this.load();
			});
			$('[data-review-search]').on('input', () => this.render());
			$app.on('click', '[data-action="review-refresh"]', () => this.load());
			$app.on('click', '[data-review-op]', (e) => this.op($(e.currentTarget)));
			this.load();
		},
		async load() {
			try {
				const r = await ajax('review_list', { status: this.status });
				this.items = r.items;
				this.render();
				// While the AI is revising / drawing, keep checking (also delivers finished results).
				clearTimeout(this.t);
				if (this.items.some((p) => p.ai_state && /ing$/.test(p.ai_state.state || ''))) {
					this.t = setTimeout(async () => { try { await ajax('activity', {}); } catch (_) { /* ignore */ } if (!document.hidden) this.load(); }, 12000);
				}
			} catch (e) { toast('error', e.message); }
		},
		render() {
			const q = String($('[data-review-search]').val() || '').trim();
			const items = this.items.filter((p) => !q || p.title.indexOf(q) > -1);
			const $l = $('[data-review-list]');
			if (!items.length) { $l.html('<div class="aaw-card"><div class="aaw-empty">' + I.inbox + '<p>مقاله‌ای برای نمایش وجود ندارد.</p></div></div>'); return; }
			$l.html(items.map((p) => {
				const pending = p.status === 'draft' || p.status === 'pending';
				return '<article class="aaw-review" data-id="' + p.id + '">' +
					'<div class="aaw-review-thumb">' + (p.thumb ? '<img src="' + esc(p.thumb) + '" alt="" loading="lazy">' : I.image) + '</div>' +
					'<div class="aaw-review-body">' +
					'<div class="aaw-review-meta"><span class="aaw-badge b-' + esc(p.status) + '">' + esc(postStatus[p.status] || p.status) + '</span><span>' + I.calendar + esc(p.date) + '</span><span>' + I.content + fa(p.words) + ' کلمه</span>' + (p.keyword ? '<span>' + I.target + esc(p.keyword) + '</span>' : '') + (p.cats ? '<span>' + I.folder + esc(p.cats) + '</span>' : '') + (p.model ? '<span>' + I.cpu + '<code dir="ltr">' + esc(p.model) + '</code></span>' : '') + '</div>' +
					aiStateBadge(p) +
					'<h3><a href="' + esc(p.edit_url) + '">' + esc(p.title) + '</a></h3>' +
					(p.meta_desc ? '<div class="aaw-serp"><b>' + esc(p.title) + '</b><small>' + esc(p.meta_desc) + '</small></div>' : '<p>' + esc(p.excerpt) + '</p>') +
					'<div class="aaw-review-actions">' +
					(pending ? '<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-success" data-review-op="publish">' + I.check + ' تایید و انتشار</button>' +
						'<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-review-op="schedule">' + I.calendar + ' زمان‌بندی انتشار</button>' : '') +
					'<a class="aaw-btn aaw-btn-sm aaw-btn-ghost" href="' + esc(p.preview) + '" target="_blank">' + I.eye + ' پیش‌نمایش</a>' +
					'<a class="aaw-btn aaw-btn-sm aaw-btn-ghost" href="' + esc(p.edit_url) + '">' + I.edit + ' ویرایش</a>' +
					'<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-review-op="ai_revise">' + I.send + ' اصلاح با هوش مصنوعی</button>' +
					'<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-review-op="ai_image">' + I.image + ' فقط تصویر جدید</button>' +
					(p.rev_pending ? '<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-primary" data-review-op="ai_publish_rev">' + I.check + ' انتشار اصلاحات</button>' : '') +
					(pending && p.topic_id ? '<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-review-op="regenerate">' + I.refresh + ' تولید مجدد</button>' : '') +
					(pending ? '<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost is-danger" data-review-op="trash">' + I.trash + ' رد</button>' : '') +
					'</div></div></article>';
			}).join(''));
		},
		async op($btn) {
			const id = $btn.closest('[data-id]').data('id');
			const op = $btn.data('review-op');
			const item = this.items.find((x) => x.id === id) || {};
			if (op === 'ai_revise') { aiReviseModal(id, item.title, () => this.load()); return; }
			if (op === 'ai_image') { aiImageModal(id, item.title, item.img_prompt, () => this.load()); return; }
			if (op === 'ai_publish_rev') {
				if (!(await confirmBox('انتشار اصلاحات', 'نسخه اصلاح‌شده جایگزین متن فعلی نوشته منتشرشده شود؟', 'انتشار'))) return;
				await withBusy($btn, async () => { const r = await ajax('revision_publish', { post_id: id }); toast('success', r.message); this.load(); });
				return;
			}
			if (op === 'trash' && !(await confirmBox('رد مقاله', 'این مقاله به زباله‌دان منتقل شود؟', 'انتقال به زباله‌دان', true))) return;
			if (op === 'regenerate' && !(await confirmBox('تولید مجدد', 'مقاله فعلی حذف و موضوع برای تولید دوباره به ابتدای صف می‌رود.', 'تولید مجدد'))) return;
			if (op === 'schedule') {
				const d = new Date(Date.now() + 86400000);
				const def = d.toISOString().slice(0, 11) + '09:00';
				Modal.open({
					title: 'زمان‌بندی انتشار',
					body: '<label class="aaw-label">تاریخ و ساعت انتشار (به وقت سایت)</label><input type="datetime-local" class="aaw-input" data-sched value="' + def + '" dir="ltr">',
					buttons: [{ text: 'زمان‌بندی', cls: 'aaw-btn-primary', icon: 'calendar', click: ($b) => withBusy($b, async () => {
						const r = await ajax('review_action', { id, op: 'schedule', date: $('[data-sched]').val() });
						Modal.close(); toast('success', r.message); this.load();
					}) }, { text: 'انصراف', click: () => Modal.close() }],
				});
				return;
			}
			await withBusy($btn, async () => {
				const r = await ajax('review_action', { id, op });
				toast('success', r.message);
				$btn.closest('.aaw-review').fadeOut(200, () => this.load());
			});
		},
	};
	Review.init();

	/* =========================================================
	 * Topics
	 * ======================================================= */
	const Topics = {
		status: '',
		items: [],
		selected: new Set(),
		init() {
			if (!$('[data-topics]').length) return;
			refreshCurrent = () => this.load();
			this.tags($('[data-tags]'));
			$('[data-topic-form]').on('submit', (e) => this.add(e));
			$('[data-bulk-form]').on('submit', (e) => this.bulk(e));
			$('[data-bulk-form] textarea').on('input', function () {
				const n = this.value.split('\n').filter((l) => l.trim()).length;
				$('[data-line-count]').text(fa(n) + ' خط');
			});
			$('[data-topic-filter]').on('click', 'button', (e) => {
				$(e.currentTarget).addClass('is-active').siblings().removeClass('is-active');
				this.status = $(e.currentTarget).data('status');
				this.load();
			});
			let t;
			$('[data-topic-search]').on('input', () => { clearTimeout(t); t = setTimeout(() => this.load(), 300); });
			const $list = $('[data-topics]');
			$list.on('click', '[data-t]', (e) => this.action($(e.currentTarget)));
			$list.on('change', '.aaw-topic-sel', (e) => {
				const id = Number($(e.currentTarget).closest('[data-id]').data('id'));
				if (e.currentTarget.checked) this.selected.add(id); else this.selected.delete(id);
				$(e.currentTarget).closest('.aaw-topic').toggleClass('is-selected', e.currentTarget.checked);
				this.bulkbar();
			});
			$list.on('dblclick', '.aaw-topic-title', (e) => this.edit(Number($(e.currentTarget).closest('[data-id]').data('id'))));
			$('[data-select-all]').on('change', (e) => {
				const on = e.currentTarget.checked;
				$list.find('.aaw-topic-sel').prop('checked', on).trigger('change');
			});
			$app.on('click', '[data-bulk]', (e) => this.bulkAction($(e.currentTarget)));
			$list.sortable({
				handle: '.aaw-topic-grip',
				items: '> li.aaw-topic:not(.is-locked)',
				placeholder: 'aaw-sortable-placeholder',
				tolerance: 'pointer',
				axis: 'y',
				update: () => this.saveOrder(),
			});
			$app.on('click', '[data-action="topics-export"]', (e) => withBusy(e.currentTarget, async () => { const r = await ajax('topics_export'); download(r.filename, r.content, 'text/csv;charset=utf-8'); }));
			$app.on('click', '[data-action="topics-import"]', async () => {
				const content = await pickFile($('[data-csv-file]'));
				if (!content) return;
				try { const r = await ajax('topics_import', { content }); toast('success', r.message); this.load(); } catch (e) { toast('error', e.message); }
			});
			$app.on('click', '[data-action="topics-suggest"]', () => this.suggest());
			this.load();
			setInterval(() => { if (this.items.some((i) => i.status === 'processing')) this.load(); }, 15000);
		},
		tags($wrap) {
			$wrap.each(function () {
				const $w = $(this);
				const $in = $w.find('input');
				const add = (v) => {
					v.split(/[,،]/).map((x) => x.trim()).filter(Boolean).forEach((x) => {
						if ($w.find('.aaw-tag').filter((_, el) => $(el).data('v') === x).length) return;
						$('<span class="aaw-tag"></span>').data('v', x).text(x).append($('<button type="button" aria-label="حذف"></button>').html(I.x)).insertBefore($in);
					});
				};
				$in.on('keydown', (e) => {
					if ((e.key === 'Enter' || e.key === ',' || e.key === '،') && $in.val().trim()) { e.preventDefault(); add($in.val()); $in.val(''); }
					if (e.key === 'Backspace' && !$in.val()) $w.find('.aaw-tag').last().remove();
				});
				$in.on('blur', () => { if ($in.val().trim()) { add($in.val()); $in.val(''); } });
				$in.on('paste', () => setTimeout(() => { add($in.val()); $in.val(''); }, 0));
				$w.on('click', '.aaw-tag button', function () { $(this).parent().remove(); });
				$w.data('get', () => $w.find('.aaw-tag').map((_, el) => $(el).data('v')).get());
				$w.data('set', (arr) => { $w.find('.aaw-tag').remove(); add((arr || []).join(',')); });
			});
		},
		async load() {
			try {
				const r = await ajax('topics_list', { status: this.status, search: $('[data-topic-search]').val() || '' });
				this.items = r.items;
				Object.keys(r.counts).forEach((k) => $('[data-c="' + k + '"]').text(fa(r.counts[k])));
				this.render();
			} catch (e) { toast('error', e.message); }
		},
		render() {
			const $l = $('[data-topics]');
			if (!this.items.length) {
				$l.html('<li class="aaw-empty">' + I.inbox + '<p>موضوعی وجود ندارد. از فرم کنار موضوع اضافه کنید یا از «پیشنهاد موضوع با AI» استفاده کنید.</p></li>');
				return;
			}
			let n = 0;
			$l.html(this.items.map((t) => {
				const locked = t.status === 'done' || t.status === 'processing';
				if (t.status === 'pending' || t.status === 'failed') n++;
				const kws = (t.keywords || '').split('،').map((x) => x.trim()).filter(Boolean);
				return '<li class="aaw-topic is-' + t.status + (locked ? ' is-locked' : '') + (this.selected.has(Number(t.id)) ? ' is-selected' : '') + '" data-id="' + t.id + '">' +
					'<span class="aaw-topic-grip" title="جابجایی">' + I.grip + '</span>' +
					'<input type="checkbox" class="aaw-topic-sel" ' + (this.selected.has(Number(t.id)) ? 'checked' : '') + ' aria-label="انتخاب">' +
					'<span class="aaw-topic-state" title="' + esc(statusLabels[t.status]) + '">' + (t.status === 'done' ? I.check : t.status === 'failed' ? I.x : t.status === 'paused' ? I.pause : '') + '</span>' +
					'<div class="aaw-topic-body">' +
					'<span class="aaw-topic-title" title="دوبار کلیک برای ویرایش">' + ((t.status === 'pending' || t.status === 'failed') ? '<span class="aaw-topic-num">' + fa(n) + '. </span>' : '') + esc(t.title) + '</span>' +
					'<div class="aaw-topic-meta">' +
					'<span class="aaw-badge b-' + t.status + '">' + esc(statusLabels[t.status]) + '</span>' +
					(Number(t.priority) ? '<span class="aaw-badge b-p' + t.priority + '">' + (Number(t.priority) === 2 ? 'فوری' : 'اولویت بالا') + '</span>' : '') +
					(t.source === 'ai' ? '<span class="aaw-badge b-ai">' + I.sparkles + ' ایده AI</span>' : '') +
					(kws.length ? '<span>' + I.hash + esc(kws.slice(0, 4).join('، ')) + (kws.length > 4 ? '…' : '') + '</span>' : '') +
					(t.category_name ? '<span>' + I.folder + esc(t.category_name) + '</span>' : '') +
					(Number(t.word_count) ? '<span>' + fa(t.word_count) + ' کلمه</span>' : '') +
					(t.generated_h ? '<span>' + I.clock + esc(t.generated_h) + '</span>' : '') +
					(Number(t.attempts) && t.status !== 'done' ? '<span>تلاش ' + fa(t.attempts) + '</span>' : '') +
					'</div>' +
					(t.error && t.status !== 'done' ? '<div class="aaw-topic-error">' + esc(t.error) + '</div>' : '') +
					'</div>' +
					'<div class="aaw-topic-actions">' +
					(t.edit_url ? '<a class="aaw-icon-btn" href="' + esc(t.edit_url) + '" title="مشاهده مقاله">' + I.external + '</a>' : '') +
					(!locked ? '<button type="button" class="aaw-icon-btn" data-t="run" title="تولید همین حالا">' + I.play + '</button>' : '') +
					(!locked ? '<button type="button" class="aaw-icon-btn" data-t="top" title="انتقال به ابتدای صف">' + I['chevrons-up'] + '</button><button type="button" class="aaw-icon-btn" data-t="bottom" title="انتقال به انتهای صف">' + I['chevrons-down'] + '</button>' : '') +
					(t.status === 'done' || t.status === 'failed' || t.status === 'skipped' ? '<button type="button" class="aaw-icon-btn" data-t="requeue" title="بازگشت به صف">' + I.refresh + '</button>' : '') +
					'<button type="button" class="aaw-icon-btn" data-t="edit" title="ویرایش">' + I.edit + '</button>' +
					'<button type="button" class="aaw-icon-btn" data-t="dup" title="کپی">' + I.copy + '</button>' +
					'<button type="button" class="aaw-icon-btn is-danger" data-t="del" title="حذف">' + I.trash + '</button>' +
					'</div></li>';
			}).join(''));
			$l.sortable('refresh');
			$l.sortable((this.status === '' || this.status === 'pending') && !$('[data-topic-search]').val() ? 'enable' : 'disable');
		},
		async add(e) {
			e.preventDefault();
			const $f = $(e.currentTarget);
			const data = collect($f);
			data.keywords = $f.find('[data-tags="keywords"]').data('get')();
			data.position_top = !!data.position_top;
			await withBusy($f.find('[type=submit]'), async () => {
				const r = await ajax('topic_add', data);
				toast('success', r.message);
				$f[0].reset();
				$f.find('[data-tags]').data('set')([]);
				$f.find('[name=title]').trigger('focus');
				this.load();
			});
		},
		async bulk(e) {
			e.preventDefault();
			const $f = $(e.currentTarget);
			const d = collect($f);
			if (!d.text.trim()) return;
			await withBusy($f.find('[type=submit]'), async () => {
				const r = await ajax('topics_bulk', d);
				toast('success', r.message);
				$f[0].reset();
				$('[data-line-count]').text('۰ خط');
				this.load();
			});
		},
		async saveOrder() {
			const ids = $('[data-topics] > li[data-id]').map((_, el) => $(el).data('id')).get();
			try { await ajax('topics_reorder', { ids }); toast('success', 'ترتیب ذخیره شد.', 1800); this.load(); } catch (e) { toast('error', e.message); }
		},
		bulkbar() {
			$('[data-bulkbar]').prop('hidden', this.selected.size === 0);
			$('[data-selected-count]').text(fa(this.selected.size));
		},
		async bulkAction($b) {
			const ids = [...this.selected];
			const op = $b.data('bulk');
			if (op === 'delete') {
				if (!(await confirmBox('حذف موضوعات', fa(ids.length) + ' موضوع حذف شود؟', 'حذف', true))) return;
				await withBusy($b, async () => { const r = await ajax('topics_delete', { ids }); toast('success', r.message); });
			} else {
				await withBusy($b, async () => { const r = await ajax('topics_status', { ids, status: op }); toast('success', r.message); });
			}
			this.selected.clear();
			this.bulkbar();
			$('[data-select-all]').prop('checked', false);
			this.load();
		},
		async action($b) {
			const id = Number($b.closest('[data-id]').data('id'));
			const op = $b.data('t');
			if (op === 'edit') return this.edit(id);
			if (op === 'run') return runNow(id);
			if (op === 'del') {
				if (!(await confirmBox('حذف موضوع', 'این موضوع حذف شود؟', 'حذف', true))) return;
				await withBusy($b, async () => { await ajax('topics_delete', { ids: [id] }); this.load(); });
				return;
			}
			await withBusy($b, async () => {
				if (op === 'top' || op === 'bottom') await ajax('topic_move', { id, where: op });
				if (op === 'dup') await ajax('topic_duplicate', { id });
				if (op === 'requeue') await ajax('topics_status', { ids: [id], status: 'pending' });
				this.load();
			});
		},
		edit(id) {
			const t = this.items.find((x) => Number(x.id) === id);
			if (!t) return;
			const cats = (A.categories || []).map((c) => '<option value="' + c.id + '"' + (Number(t.category_id) === c.id ? ' selected' : '') + '>' + esc(c.name) + '</option>').join('');
			const tones = Object.keys(A.tones || {}).map((k) => '<option value="' + k + '"' + (t.tone === k ? ' selected' : '') + '>' + esc(A.tones[k]) + '</option>').join('');
			const $b = $('<form class="aaw-topic-form">' +
				'<label class="aaw-label">عنوان</label><input class="aaw-input" name="title" value="' + esc(t.title) + '" dir="auto">' +
				'<label class="aaw-label">کلمات کلیدی</label><div class="aaw-tags-input" data-tags="kw"><input class="aaw-input" placeholder="کلمه + Enter"></div>' +
				'<div class="aaw-grid aaw-grid-3"><div><label class="aaw-label">دسته</label><select class="aaw-input" name="category_id"><option value="0">پیش‌فرض</option>' + cats + '</select></div>' +
				'<div><label class="aaw-label">تعداد کلمات</label><input type="number" class="aaw-input" name="word_count" value="' + (Number(t.word_count) || '') + '"></div>' +
				'<div><label class="aaw-label">لحن</label><select class="aaw-input" name="tone"><option value="">پیش‌فرض</option>' + tones + '</select></div></div>' +
				'<label class="aaw-label">اولویت</label><div class="aaw-seg">' + ['عادی', 'بالا', 'فوری'].map((l, i) => '<label><input type="radio" name="priority" value="' + i + '"' + (Number(t.priority) === i ? ' checked' : '') + '><span>' + l + '</span></label>').join('') + '</div>' +
				'<label class="aaw-label">توضیحات برای AI</label><textarea class="aaw-input" name="notes" rows="3" dir="auto">' + esc(t.notes || '') + '</textarea></form>');
			Modal.open({
				title: 'ویرایش موضوع',
				body: $b,
				buttons: [{ text: 'ذخیره', cls: 'aaw-btn-primary', icon: 'check', click: ($btn) => withBusy($btn, async () => {
					const d = collect($b);
					d.keywords = $b.find('[data-tags]').data('get')();
					d.id = id;
					const r = await ajax('topic_update', d);
					toast('success', r.message);
					Modal.close();
					this.load();
				}) }, { text: 'انصراف', click: () => Modal.close() }],
			});
			this.tags($b.find('[data-tags]'));
			$b.find('[data-tags]').data('set')((t.keywords || '').split('،').map((x) => x.trim()).filter(Boolean));
		},
		suggest() {
			const $b = $('<div><label class="aaw-label">تعداد پیشنهاد</label><input type="number" class="aaw-input" value="10" min="1" max="30" data-n>' +
				'<label class="aaw-label">تمرکز روی (اختیاری)</label><input class="aaw-input" data-hint placeholder="مثلاً: مقالات راهنمای خرید" dir="auto"><div data-ideas class="aaw-mt"></div></div>');
			const run = ($btn) => withBusy($btn, async () => {
				$b.find('[data-ideas]').html('<div class="aaw-run-progress"><div class="aaw-orb"></div><small>در حال تحلیل سایت و پیشنهاد موضوع…</small></div>');
				try {
					const sq = { count: $b.find('[data-n]').val(), hint: $b.find('[data-hint]').val() };
					const ticket = await ajax('suggest_ticket', sq);
					const r = await trackOp('suggest', 'پیشنهاد موضوع با هوش مصنوعی', () => workerFetch(ticket, Object.assign({ kind: 'suggest' }, sq)));
					const list = r.topics || [];
					if (!list.length) { $b.find('[data-ideas]').html('<p class="aaw-muted">پیشنهادی دریافت نشد.</p>'); return; }
					$b.find('[data-ideas]').html(list.map((t, i) => '<label class="aaw-idea"><input type="checkbox" checked data-i="' + i + '"><div><b>' + esc(t.title) + '</b><small>' + esc((t.keywords || []).join('، ')) + '</small></div></label>').join(''));
					$b.data('list', list);
				} catch (e) {
					$b.find('[data-ideas]').html('<div class="aaw-alert is-error">' + I.alert + '<div>' + fmtErr(e.message) + '</div></div>');
				}
			});
			Modal.open({
				title: 'پیشنهاد موضوع با هوش مصنوعی',
				body: $b,
				buttons: [
					{ text: 'دریافت پیشنهادها', cls: 'aaw-btn-dark', icon: 'sparkles', click: run },
					{ text: 'افزودن موارد انتخاب‌شده', cls: 'aaw-btn-primary', icon: 'plus', click: ($btn) => withBusy($btn, async () => {
						const list = $b.data('list') || [];
						const chosen = $b.find('[data-i]:checked').map((_, el) => list[$(el).data('i')]).get();
						if (!chosen.length) { toast('info', 'موردی انتخاب نشده است.'); return; }
						const r = await ajax('suggest_add', { topics: chosen });
						toast('success', r.message);
						Modal.close();
						this.load();
					}) },
				],
			});
		},
	};
	Topics.init();

	/* =========================================================
	 * Prompt
	 * ======================================================= */
	(function () {
		const $p = $('[data-prompt]');
		if (!$p.length) return;
		const count = () => $('[data-prompt-count]').text(fa($p.val().length) + ' کاراکتر');
		count();
		$p.on('input', count);
		$app.on('click', '[data-insert]', function () {
			const el = $p[0];
			const v = $(this).data('insert');
			const s = el.selectionStart || el.value.length;
			el.value = el.value.slice(0, s) + v + el.value.slice(el.selectionEnd || s);
			el.focus();
			el.selectionStart = el.selectionEnd = s + v.length;
			$p.trigger('input');
		});
		$('[data-preset]').on('change', async function () {
			const k = this.value;
			if (!k || !A.presets[k]) return;
			if ($p.val().trim() && !(await confirmBox('جایگزینی پرامپت', 'پرامپت فعلی با قالب «' + A.presets[k].label + '» جایگزین شود؟', 'جایگزینی'))) { this.value = ''; return; }
			$p.val(A.presets[k].prompt).trigger('input');
			$('[name=prompt_preset]').val(k).trigger('change');
			this.value = '';
		});
		$app.on('click', '[data-action="prompt-reset"]', async () => {
			if (!(await confirmBox('بازگشت به پیش‌فرض', 'پرامپت پیش‌فرض حرفه‌ای جایگزین شود؟', 'بازگشت'))) return;
			$p.val(A.presets.pro.prompt).trigger('input');
		});
		$app.on('click', '[data-action="prompt-copy"]', () => { navigator.clipboard.writeText($p.val()).then(() => toast('success', 'کپی شد.')); });
		$app.on('click', '[data-action="prompt-fullscreen"]', () => {
			$p.toggleClass('aaw-prompt-full');
			if ($p.hasClass('aaw-prompt-full')) { $p.trigger('focus'); toast('info', 'برای خروج Esc بزنید.'); }
		});
		$(document).on('keydown', (e) => { if (e.key === 'Escape') $p.removeClass('aaw-prompt-full'); });

		$app.on('click', '[data-action="prompt-preview"]', (e) => withBusy(e.currentTarget, async () => {
			const r = await ajax('prompt_preview', { topic: $('[data-test-topic]').val(), keywords: $('[data-test-keywords]').val(), system_prompt: $p.val() });
			Modal.open({
				title: 'پرامپت نهایی ارسالی به هوش مصنوعی',
				wide: true,
				body: '<label class="aaw-label">System (' + fa(r.chars) + ' کاراکتر)</label><pre class="aaw-pre" dir="auto">' + esc(r.system) + '</pre>' +
					(r.outline ? '<label class="aaw-label">مرحله ۱ – Outline</label><pre class="aaw-pre" dir="auto">' + esc(r.outline) + '</pre>' : '') +
					'<label class="aaw-label">پیام کاربر</label><pre class="aaw-pre" dir="auto">' + esc(r.user) + '</pre>',
			});
		}));

		$app.on('click', '[data-action="prompt-generate"]', async () => {
			const topic = $('[data-test-topic]').val().trim();
			if (!topic) { toast('error', 'موضوع آزمایشی را وارد کنید.'); $('[data-test-topic]').trigger('focus'); return; }
			if ($('form[data-settings].is-dirty').length) toast('info', 'توجه: تغییرات ذخیره‌نشده در تولید آزمایشی اعمال نمی‌شوند.');
			Modal.open({ title: 'تولید مقاله آزمایشی', wide: true, body: '<div class="aaw-run-progress"><div class="aaw-orb"></div><b>در حال نوشتن…</b><small>ممکن است چند دقیقه طول بکشد.</small></div>' });
			try {
				const gq = { topic, keywords: $('[data-test-keywords]').val() };
				const ticket = await ajax('generate_ticket', gq);
				const r = await trackOp('generate', 'تولید مقاله آزمایشی: ' + topic, () => workerFetch(ticket, Object.assign({ kind: 'generate' }, gq)));
				const a = r.article || {};
				const faq = (a.faq || []).map((f) => '<details><summary>' + esc(f.question || f.q) + '</summary><p>' + esc(f.answer || f.a) + '</p></details>').join('');
				Modal.body().html(
					'<div class="aaw-serp aaw-mb"><b>' + esc(a.seo_title || a.title) + '</b><small>' + esc(a.meta_description || '') + '</small></div>' +
					'<div class="aaw-review-meta aaw-mb"><span>' + I.target + esc(a.focus_keyword || '') + '</span><span>' + I.hash + esc((a.tags || []).join('، ')) + '</span><span>' + I.cpu + esc((r.meta || {}).model || '') + '</span><span>توکن: ' + fa(((r.meta || {}).tokens_in || 0) + ((r.meta || {}).tokens_out || 0)) + '</span></div>' +
					'<div class="aaw-article-preview" dir="auto"><h1 style="font-size:22px">' + esc(a.title || '') + '</h1>' + String(a.content_html || '').replace(/<script[\s\S]*?<\/script>/gi, '') + (faq ? '<h2>سؤالات متداول</h2>' + faq : '') + '</div>'
				);
				Modal.$el.find('.aaw-modal-foot').empty().append(
					$('<button type="button" class="aaw-btn aaw-btn-primary">' + I.check + ' ذخیره به‌عنوان پیش‌نویس</button>').on('click', function () {
						withBusy(this, async () => {
							const s = await ajax('save_generated', { article: a, meta: r.meta });
							toast('success', s.message);
							window.location.href = s.edit_url;
						});
					}),
					$('<button type="button" class="aaw-btn aaw-btn-ghost">بستن</button>').on('click', () => Modal.close())
				);
			} catch (e) {
				Modal.body().html('<div class="aaw-alert is-error">' + I.alert + '<div>' + fmtErr(e.message) + '</div></div>');
			}
		});
	})();

	/* =========================================================
	 * AI providers
	 * ======================================================= */
	(function () {
		if (!$('[data-provider-grid]').length) return;
		const P = A.providers || {};
		const $model = $('[data-active-model]');
		const fillModels = (id, list) => {
			const models = list || (P[id] ? P[id].models : []);
			$('#aaw-models').html(models.map((m) => '<option value="' + esc(m) + '"></option>').join(''));
		};
		fillModels(A.active);
		$('[data-active-provider]').on('change', function () {
			const id = this.value;
			fillModels(id);
			$model.val(P[id] ? P[id].model : '');
		});
		$app.on('click', '[data-action="fetch-models"]', (e) => withBusy(e.currentTarget, async () => {
			const id = $('[data-active-provider]').val();
			const r = await ajax('provider_models', { provider: id });
			fillModels(id, r.models);
			toast('success', fa(r.models.length) + ' مدل دریافت شد؛ روی فیلد مدل کلیک کنید.');
			$model.val('').trigger('focus');
		}));
		$app.on('click', '[data-action="test-active"]', (e) => withBusy(e.currentTarget, async () => {
			const r = await ajax('provider_test', { provider: $('[data-active-provider]').val(), model: $model.val() });
			toast('success', r.message, 6000);
		}));
		$('[data-provider-search]').on('input', function () {
			const q = this.value.trim().toLowerCase();
			$('[data-provider]').each(function () { $(this).toggle(!q || String($(this).data('name')).indexOf(q) > -1); });
		});
		const card = ($el) => $el.closest('[data-provider]');
		$app.on('click', '[data-action="key-save"]', (e) => {
			const $c = card($(e.currentTarget));
			const key = $c.find('[data-key-input]').val().trim();
			if (!key) { toast('error', 'کلید را وارد کنید.'); return; }
			withBusy(e.currentTarget, async () => {
				const r = await ajax('key_save', { provider: $c.data('provider'), key });
				toast('success', r.message);
				$c.addClass('has-key').find('[data-key-input]').val('').attr('placeholder', r.mask);
				$c.find('.aaw-provider-state').html(I['check-circle']);
			});
		});
		$app.on('keydown', '[data-key-input]', function (e) { if (e.key === 'Enter') { e.preventDefault(); card($(this)).find('[data-action="key-save"]').trigger('click'); } });
		$app.on('click', '[data-action="key-delete"]', async (e) => {
			const $c = card($(e.currentTarget));
			if (!(await confirmBox('حذف کلید', 'کلید این پرووایدر از Secrets کلادفلر حذف شود؟', 'حذف', true))) return;
			withBusy(e.currentTarget, async () => { const r = await ajax('key_delete', { provider: $c.data('provider') }); toast('success', r.message); setTimeout(() => location.reload(), 700); });
		});
		$app.on('click', '[data-action="provider-test"]', (e) => withBusy(e.currentTarget, async () => {
			const r = await ajax('provider_test', { provider: card($(e.currentTarget)).data('provider') });
			toast('success', r.message, 6000);
		}));
		$app.on('click', '[data-action="provider-use"]', (e) => withBusy(e.currentTarget, async () => {
			const id = card($(e.currentTarget)).data('provider');
			const r = await ajax('priority_save', { kind: 'text', promote: id });
			$('[data-provider]').removeClass('is-active');
			card($(e.currentTarget)).addClass('is-active');
			toast('success', r.message, 6000);
		}));

		const openCustom = (data) => {
			const $f = $($('#aaw-custom-form').html());
			if (data) {
				Object.keys(data).forEach((k) => {
					const $i = $f.find('[name="' + k + '"]');
					if (!$i.length) return;
					if ($i.is(':checkbox')) $i.prop('checked', !!data[k]);
					else if (k === 'headers' && data[k] && typeof data[k] === 'object') $i.val(Object.keys(data[k]).map((h) => h + ': ' + data[k][h]).join('\n'));
					else $i.val(data[k]);
				});
			}
			Modal.open({
				title: data ? 'ویرایش پرووایدر شخصی' : 'پرووایدر شخصی جدید',
				body: $f,
				buttons: [{ text: 'ذخیره', cls: 'aaw-btn-primary', icon: 'check', click: ($b) => withBusy($b, async () => {
					const d = collect($f);
					const r = await ajax('custom_save', d);
					toast('success', r.message);
					Modal.close();
					setTimeout(() => location.reload(), 600);
				}) }, { text: 'انصراف', click: () => Modal.close() }],
			});
		};
		$app.on('click', '[data-action="custom-new"]', () => openCustom(null));
		$app.on('click', '[data-action="custom-edit"]', (e) => { const id = card($(e.currentTarget)).data('provider'); openCustom(P[id] && P[id].raw); });
		$app.on('click', '[data-action="custom-delete"]', async (e) => {
			const id = card($(e.currentTarget)).data('provider');
			if (!(await confirmBox('حذف پرووایدر', 'پرووایدر شخصی و کلید آن حذف شود؟', 'حذف', true))) return;
			try { const r = await ajax('custom_delete', { id }); toast('success', r.message); setTimeout(() => location.reload(), 600); } catch (err) { toast('error', err.message); }
		});
	})();

	/* =========================================================
	 * Cloudflare
	 * ======================================================= */
	(function () {
		const $f = $('[data-cf-form]');
		if (!$f.length) return;
		$f.on('submit', (e) => {
			e.preventDefault();
			withBusy($f.find('[type=submit]'), async () => {
				const r = await ajax('cf_save', collect($f));
				toast('success', r.message, 6000);
				setTimeout(() => location.reload(), 1200);
			});
		});
		$app.on('click', '[data-action="cf-accounts"]', (e) => withBusy(e.currentTarget, async () => {
			const r = await ajax('cf_accounts', { token: $f.find('[name=token]').val() });
			if (!r.accounts.length) { toast('info', 'حسابی یافت نشد.'); return; }
			if (r.accounts.length === 1) { $f.find('[name=account_id]').val(r.accounts[0].id); toast('success', 'حساب «' + r.accounts[0].name + '» انتخاب شد.'); return; }
			$('[data-accounts]').html('<div class="aaw-chips-select aaw-mt">' + r.accounts.map((a) => '<label class="aaw-chip-opt"><input type="radio" name="acc_pick" value="' + esc(a.id) + '"><span>' + esc(a.name) + '</span></label>').join('') + '</div>');
			$('[data-accounts]').on('change', 'input', function () { $f.find('[name=account_id]').val(this.value); });
		}));
		const simple = (sel, action, confirmText, reload) => {
			$app.on('click', '[data-action="' + sel + '"]', async (e) => {
				if (confirmText && !(await confirmBox('تایید', confirmText, 'ادامه', sel === 'cf-delete'))) return;
				withBusy(e.currentTarget, async () => {
					const r = await ajax(action);
					toast('success', r.message, 6000);
					if (reload) setTimeout(() => location.reload(), 1200);
				});
			});
		};
		simple('cf-deploy', 'cf_deploy', null, true);
		simple('cf-sync', 'cf_sync');
		simple('cf-restore', 'cf_restore', 'تنظیمات فعلی با نسخه ذخیره‌شده در KV کلادفلر جایگزین شود؟', true);
		simple('cf-rotate', 'cf_rotate', 'کلید امضای مشترک بین وردپرس و ورکر تعویض شود؟');
		simple('cf-delete', 'cf_delete', 'ورکر و همه Secrets آن از کلادفلر حذف شود؟ این کار قابل بازگشت نیست.', true);
		simple('worker-unlock', 'worker_unlock');
		$app.on('click', '[data-action="cf-status"]', (e) => withBusy(e.currentTarget, async () => {
			const r = await ajax('cf_status');
			const row = (ok, text) => '<li><span class="' + (ok ? 'ok' : 'bad') + '">' + (ok ? I['check-circle'] : I['x-circle']) + '</span>' + text + '</li>';
			const w = r.worker || {};
			let html = '<b>وضعیت زنده</b><ul>';
			html += row(r.configured, 'اتصال API کلادفلر');
			html += row(r.deployed, 'ورکر مستقر');
			if (r.worker) {
				html += row(!w.error, w.error ? 'پاسخ ورکر: ' + esc(w.error) : 'پاسخ‌دهی ورکر (نسخه ' + esc(w.version) + ')');
				html += row(w.kv_binding, 'اتصال KV');
				html += row(w.ai_binding, 'اتصال Workers AI');
				html += row(w.shared_secret, 'کلید امضای مشترک');
			}
			if (r.caps) {
				html += row(r.caps.bg, r.caps.bg ? 'کارهای پس‌زمینه (Durable Object): فعال — کارهای طولانی روی کلادفلر انجام می‌شود' : 'کارهای پس‌زمینه غیرفعال — «استقرار مجدد» بزنید');
				html += row(r.caps.gzip && r.caps.parts, 'ارسال فشرده و تکه‌تکه (برای هاست‌های با اینترنت محدود)');
			}
			html += row((r.schedules || []).length > 0, 'Cron فعال: <code dir="ltr">' + esc((r.schedules || []).join(' | ') || '—') + '</code>');
			html += row((r.secrets || []).length > 0, 'Secrets: ' + ((r.secrets || []).map((s) => '<code dir="ltr">' + esc(s) + '</code>').join(' ') || '—'));
			if (r.outdated) html += row(false, 'نسخه ورکر قدیمی است؛ استقرار مجدد کنید.');
			html += '</ul>';
			if (w.runs && w.runs.length) {
				html += '<b>آخرین اجراهای ورکر</b><ul>';
				w.runs.slice(0, 6).forEach((x) => { html += row(x.status === 'ok' || x.status === 'skip' || x.status === 'empty', new Date(x.at).toLocaleString('fa-IR') + ' · ' + esc(x.trigger) + ' · ' + esc(x.status) + (x.drafts && x.drafts.length ? ' · ' + fa(x.drafts.length) + ' مقاله' : '') + (x.errors && x.errors.length ? ' · ' + esc(x.errors[0].error).slice(0, 120) : '') + (x.reason ? ' · ' + esc(x.reason) : '')); });
				html += '</ul>';
			}
			$('[data-cf-status]').html(html).prop('hidden', false);
		}));
	})();
	$app.on('click', '[data-action="reveal-secret"]', (e) => withBusy(e.currentTarget, async () => {
		const r = await ajax('reveal_secret');
		$('[data-shared-secret]').attr('type', 'text').val(r.secret);
		try { await navigator.clipboard.writeText(r.secret); toast('success', 'کلید کپی شد.'); } catch (_) { toast('info', 'کلید نمایش داده شد.'); }
	}));
	$app.on('click', '[data-action="manual-worker"]', (e) => withBusy(e.currentTarget, async () => {
		const r = await ajax('manual_worker', { worker_url: $('[data-manual-url]').val() });
		toast('success', r.message);
		setTimeout(() => location.reload(), 1000);
	}));
	$('[data-claude-pro-form]').on('submit', function (e) {
		e.preventDefault();
		const $f = $(this);
		withBusy($f.find('[type=submit]'), async () => {
			const d = collect($f);
			const r = await ajax('claude_pro_connect', d);
			toast('success', r.message, 8000);
			setTimeout(() => location.reload(), 1500);
		});
	});
	$app.on('click', '[data-action="claude-pro-test"]', (e) => withBusy(e.currentTarget, async () => {
		toast('info', 'در حال روشن کردن کانتینر و ارسال پیام آزمایشی به Claude…', 6000);
		const r = await ajax('provider_test', { provider: 'claude_pro' });
		toast('success', r.message, 8000);
	}));
	$app.on('click', '[data-action="claude-pro-disconnect"]', async (e) => {
		if (!(await confirmBox('قطع اتصال', 'اتصال Claude Pro قطع شود؟ (توکن در کلادفلر باقی می‌ماند)', 'قطع اتصال', true))) return;
		withBusy(e.currentTarget, async () => { const r = await ajax('claude_pro_disconnect'); toast('success', r.message); setTimeout(() => location.reload(), 1000); });
	});
	/* ---------- Subscription tab ---------- */
	(function () {
		if (!$('[data-engine-pick]').length) return;
		const engine = () => $('[name=sub_engine]:checked').val() || 'claude';
		$('[data-engine-pick]').on('change', 'input', function () {
			$('.aaw-sub-account').removeClass('is-picked');
			$(this).closest('.aaw-sub-account').addClass('is-picked');
			$('[data-engine-panel]').prop('hidden', true).filter('[data-engine-panel="' + this.value + '"]').prop('hidden', false);
		});
		$('[data-gh-form]').on('submit', function (e) {
			e.preventDefault();
			const $f = $(this);
			withBusy($f.find('[type=submit]'), async () => {
				const r = await ajax('gh_connect', collect($f));
				toast('success', r.message, 8000);
				setTimeout(() => location.reload(), 1600);
			});
		});
		$('[data-sub-form]').on('submit', function (e) {
			e.preventDefault();
			const $f = $(this);
			const d = collect($f);
			d.engine = $f.data('sub-form');
			if (!String(d.value || '').trim()) { toast('error', 'مقدار توکن را وارد کنید.'); return; }
			withBusy($f.find('[type=submit]'), async () => {
				const r = await ajax('gh_sub_save', d);
				toast('success', r.message, 9000);
				setTimeout(() => location.reload(), 2200);
			});
		});
		let pollTimer = null;
		const statusLabel = (r) => {
			if (r.status !== 'completed') return '<span class="aaw-badge b-processing">' + (r.status === 'queued' ? 'در صف' : 'در حال اجرا') + '</span>';
			return r.conclusion === 'success' ? '<span class="aaw-badge b-done">موفق</span>' : '<span class="aaw-badge b-failed">' + esc(r.conclusion === 'cancelled' ? 'لغو شد' : 'ناموفق') + '</span>';
		};
		const loadRuns = async () => {
			try {
				const r = await ajax('gh_runs');
				const $b = $('[data-gh-runs]');
				if (!r.runs.length) $b.html('<tr><td colspan="5" class="aaw-muted">هنوز اجرایی ثبت نشده است.</td></tr>');
				else $b.html(r.runs.map((x) => '<tr><td class="nowrap">' + esc(x.created) + '</td><td>' + statusLabel(x) + '</td><td class="nowrap">' + esc(x.event === 'workflow_dispatch' ? 'اجرای افزونه' : x.event) + '</td><td class="nowrap">' + (x.duration ? fa(Math.round(x.duration / 60 * 10) / 10) + ' دقیقه' : '—') + '</td><td><a href="' + esc(x.url) + '" target="_blank" rel="noopener">' + I.external + ' جزئیات</a></td></tr>').join(''));
				$('[data-gh-secrets]').text(r.secrets.length ? 'Secrets مخزن: ' + r.secrets.join('، ') : '');
				if (r.outdated) toast('info', 'فایل‌های Runner در GitHub قدیمی هستند؛ «به‌روزرسانی فایل‌های Runner» را بزنید.', 7000);
				clearTimeout(pollTimer);
				if (r.runs.some((x) => x.status !== 'completed')) pollTimer = setTimeout(loadRuns, 12000);
			} catch (e) {
				$('[data-gh-runs]').html('<tr><td colspan="5" class="aaw-muted">' + fmtErr(e.message) + '</td></tr>');
			}
		};
		if (!$('[data-action="gh-sync"]').prop('disabled')) loadRuns();
		$app.on('click', '[data-action="gh-test"]', (e) => withBusy(e.currentTarget, async () => {
			const r = await ajax('gh_test', { engine: engine() });
			toast('success', r.message, 8000);
			setTimeout(loadRuns, 4000);
		}));
		$app.on('click', '[data-action="gh-activate"]', (e) => withBusy(e.currentTarget, async () => {
			const r = await ajax('gh_activate', { provider: engine() === 'codex' ? 'sub_codex' : 'sub_claude', fallback_free: true });
			toast('success', r.message);
			setTimeout(() => location.reload(), 1200);
		}));
		$app.on('click', '[data-action="gh-sync"]', (e) => withBusy(e.currentTarget, async () => { const r = await ajax('gh_sync'); toast('success', r.message); loadRuns(); }));
		$app.on('click', '[data-action="gh-disconnect"]', async (e) => {
			if (!(await confirmBox('قطع اتصال GitHub', 'اتصال GitHub و اکانت اشتراکی از افزونه حذف شود؟', 'قطع اتصال', true))) return;
			withBusy(e.currentTarget, async () => { const r = await ajax('gh_disconnect'); toast('success', r.message, 8000); setTimeout(() => location.reload(), 1500); });
		});
	})();
	$app.on('click', '[data-copy]', function () {
		const t = $(this).attr('data-copy');
		navigator.clipboard.writeText(t).then(() => toast('success', 'کپی شد.', 1500)).catch(() => toast('error', 'کپی انجام نشد.'));
	});

	// Local/Pull mode: collect finished results whenever the admin is open.
	const pullPoll = async (manual, btn) => {
		try {
			const r = await ajax('pull_poll');
			if (manual || r.drafts || r.errors) toast(r.drafts ? 'success' : 'info', r.message, 6000);
			if ((r.drafts || r.errors) && typeof refreshCurrent === 'function') refreshCurrent();
		} catch (e) { if (manual) toast('error', e.message); }
	};
	// Poll Cloudflare only while results are actually expected (keeps admin light).
	if (A.deployed && A.pendingJobs > 0) { setTimeout(() => pullPoll(false), 1500); setInterval(() => pullPoll(false), 60000); }
	$app.on('click', '[data-action="pull-poll"]', (e) => withBusy(e.currentTarget, () => pullPoll(true)));

	$app.on('click', '[data-action="diagnose"]', (e) => withBusy(e.currentTarget, async () => {
		const r = await ajax('diagnose');
		let html = '<b>نتیجه عیب‌یابی</b><ul>';
		r.checks.forEach((c) => { html += '<li><span class="' + (c.ok ? 'ok' : 'bad') + '">' + (c.ok ? I['check-circle'] : I['x-circle']) + '</span><div><b>' + esc(c.title) + '</b>' + (c.detail ? '<br><small dir="auto">' + esc(c.detail) + '</small>' : '') + '</div></li>'; });
		html += '</ul>';
		if (r.diag) html += '<details class="aaw-more"><summary>جزئیات فنی</summary><pre class="aaw-pre" dir="ltr">' + esc(JSON.stringify(r.diag, null, 2)) + '</pre></details>';
		$('[data-diagnose]').html(html).prop('hidden', false);
		const bad = r.checks.filter((c) => !c.ok).length;
		toast(bad ? 'error' : 'success', bad ? fa(bad) + ' مشکل پیدا شد؛ جزئیات را ببینید.' : 'اتصال سالم است.');
	}));

	$app.on('click', '[data-action="cf-schedule"]', (e) => withBusy(e.currentTarget, async () => { const r = await ajax('cf_schedule'); toast('success', r.message); }));

	/* =========================================================
	 * Logs
	 * ======================================================= */
	(function () {
		if (!$('[data-logs]').length) return;
		const st = { level: '', event: '', search: '', page: 1 };
		const lvl = { success: 'موفق', info: 'اطلاعات', warning: 'هشدار', error: 'خطا', debug: 'دیباگ' };
		const load = async () => {
			try {
				const r = await ajax('logs_list', st);
				const $b = $('[data-logs]');
				if (!r.items.length) { $b.html('<tr><td colspan="7"><div class="aaw-empty">' + I.inbox + '<p>گزارشی ثبت نشده است.</p></div></td></tr>'); $('[data-log-pager]').empty(); return; }
				$b.html(r.items.map((x) => '<tr><td class="nowrap">' + esc(x.time_h) + '</td><td><span class="aaw-badge b-' + esc(x.level) + '">' + esc(lvl[x.level] || x.level) + '</span></td><td class="nowrap">' + esc(x.event) + '</td><td class="msg">' + esc(x.message) + (x.edit ? ' <a href="' + esc(x.edit) + '">' + I.external + '</a>' : '') + '</td><td class="nowrap"><code dir="ltr">' + esc(x.model || '—') + '</code></td><td class="nowrap">' + (Number(x.duration_ms) ? fa(Math.round(x.duration_ms / 100) / 10) + 's' : '—') + '</td><td class="nowrap">' + (Number(x.tokens_in) + Number(x.tokens_out) ? fa(Number(x.tokens_in) + Number(x.tokens_out)) : '—') + '</td></tr>').join(''));
				const pages = Math.ceil(r.total / 50);
				let p = '';
				for (let i = 1; i <= Math.min(pages, 20); i++) p += '<button type="button" class="' + (i === st.page ? 'is-active' : '') + '" data-p="' + i + '">' + fa(i) + '</button>';
				$('[data-log-pager]').html(pages > 1 ? p : '');
			} catch (e) { toast('error', e.message); }
		};
		refreshCurrent = load;
		$('[data-log-level]').on('click', 'button', function () { $(this).addClass('is-active').siblings().removeClass('is-active'); st.level = $(this).data('level'); st.page = 1; load(); });
		$('[data-log-event]').on('change', function () { st.event = this.value; st.page = 1; load(); });
		let t; $('[data-log-search]').on('input', function () { clearTimeout(t); t = setTimeout(() => { st.search = this.value; st.page = 1; load(); }, 300); });
		$('[data-log-pager]').on('click', 'button', function () { st.page = Number($(this).data('p')); load(); });
		$app.on('click', '[data-action="logs-export"]', (e) => withBusy(e.currentTarget, async () => { const r = await ajax('logs_export'); download(r.filename, r.content, 'text/csv;charset=utf-8'); }));
		$app.on('click', '[data-action="logs-clear"]', async (e) => {
			if (!(await confirmBox('پاک کردن گزارش‌ها', 'همه گزارش‌ها حذف شوند؟', 'حذف همه', true))) return;
			withBusy(e.currentTarget, async () => { const r = await ajax('logs_clear'); toast('success', r.message); load(); });
		});
		load();
	})();

	/* =========================================================
	 * Tools / notify / features
	 * ======================================================= */
	$app.on('click', '[data-action="settings-export"]', (e) => withBusy(e.currentTarget, async () => { const r = await ajax('settings_export'); download(r.filename, r.content, 'application/json'); }));
	$app.on('click', '[data-action="settings-import"]', async () => {
		const content = await pickFile($('[data-json-file]'));
		if (!content) return;
		try { const r = await ajax('settings_import', { content }); toast('success', r.message); setTimeout(() => location.reload(), 900); } catch (e) { toast('error', e.message); }
	});
	$app.on('click', '[data-action="settings-reset"]', async (e) => {
		if (!(await confirmBox('بازنشانی', 'همه تنظیمات (به جز اتصال کلادفلر) به پیش‌فرض برگردد؟', 'بازنشانی', true))) return;
		withBusy(e.currentTarget, async () => { const r = await ajax('settings_reset'); toast('success', r.message); setTimeout(() => location.reload(), 900); });
	});
	$app.on('click', '[data-action="copy-info"]', () => {
		const txt = $('.aaw-info tr').map((_, tr) => $(tr).find('th').text() + ': ' + $(tr).find('td').text()).get().join('\n');
		navigator.clipboard.writeText(txt).then(() => toast('success', 'کپی شد.'));
	});
	$app.on('click', '[data-action="test-notify"]', (e) => withBusy(e.currentTarget, async () => { const r = await ajax('test_notify'); toast('success', r.message); }));

	$('[data-feature-search]').on('input', function () {
		const q = this.value.trim();
		let n = 0;
		$('.aaw-feature-group').each(function () {
			let vis = 0;
			$(this).find('li').each(function () {
				const show = !q || $(this).text().indexOf(q) > -1;
				$(this).toggleClass('is-hidden', !show);
				if (show) vis++;
			});
			$(this).toggleClass('is-hidden', vis === 0);
			n += vis;
		});
		$('[data-feature-count]').text(fa(n) + ' مورد');
	});

	/* =========================================================
	 * Dates, "now" status, timeline
	 * ======================================================= */
	const fdate = (ts, opts) => new Date(ts * 1000).toLocaleString('fa-IR', opts || { weekday: 'long', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' });
	const fday = (ts) => new Date(ts * 1000).toLocaleDateString('fa-IR', { weekday: 'long', day: 'numeric', month: 'long' });
	const rel = (ts) => {
		const d = ts - Math.floor(Date.now() / 1000);
		const a = Math.abs(d);
		let t;
		if (a < 60) t = 'چند لحظه';
		else if (a < 3600) t = fa(Math.round(a / 60)) + ' دقیقه';
		else if (a < 86400) t = fa(Math.round(a / 3600)) + ' ساعت';
		else t = fa(Math.round(a / 86400)) + ' روز';
		return d >= 0 ? t + ' دیگر' : t + ' پیش';
	};
	const postStatusBadge = (st) => {
		const map = { publish: ['b-done', 'منتشرشده'], draft: ['b-draft', 'پیش‌نویس · منتظر تایید'], pending: ['b-pending', 'در انتظار بررسی'], future: ['b-warning', 'زمان‌بندی‌شده'], failed: ['b-failed', 'خطا'], private: ['b-draft', 'خصوصی'] };
		const m = map[st] || ['', st];
		return '<span class="aaw-badge ' + m[0] + '">' + esc(m[1]) + '</span>';
	};

	function renderNow(n) {
		const $n = $('[data-now]');
		if (!$n.length) return;
		const next = n.next;
		const compact = $n.hasClass('aaw-now-compact');
		let html = '<div class="aaw-now-row"><span class="aaw-now-dot is-' + esc(n.state) + '"></span><div class="aaw-now-main"><small>الان</small><b>' + esc(n.text) + '</b></div>';
		if (next) {
			const first = next.items[0] || {};
			html += '<div class="aaw-now-next"><small>نوبت بعدی · ' + esc(rel(next.ts)) + '</small><b>' + esc(fdate(next.ts)) + '</b><span>' + (first.idea ? I.sparkles + ' ' : '') + esc(first.title || '') + (next.items.length > 1 ? ' + ' + fa(next.items.length - 1) + ' مورد' : '') + '</span></div>';
		} else {
			html += '<div class="aaw-now-next"><small>نوبت بعدی</small><b>—</b><span>زمان‌بندی فعالی وجود ندارد</span></div>';
		}
		html += '</div>';
		if (!compact) {
			html += '<div class="aaw-now-meta"><span class="aaw-chip is-info">' + I.cpu + ' ' + esc(n.engine) + '</span><span class="aaw-chip">' + I.server + ' ' + (n.mode === 'local' ? 'اتصال معکوس' : 'اتصال مستقیم') + '</span>' + (n.last ? '<span class="aaw-muted">آخرین رویداد: ' + esc(n.last.message).slice(0, 120) + '</span>' : '') + '</div>';
		}
		$n.find('.aaw-card-body').html(html);
	}
	const loadNow = () => ajax('now').then(renderNow).catch(() => {});
	if ($('[data-now]').length && !$('[data-timeline]').length) { loadNow(); setInterval(() => { if (!document.hidden) loadNow(); }, 30000); }

	function futureItemHtml(run, isNext) {
		return '<div class="aaw-tl-item is-future' + (isNext ? ' is-next' : '') + '"><div class="aaw-tl-time"><b>' + esc(fdate(run.ts, { hour: '2-digit', minute: '2-digit' })) + '</b><small>' + esc(rel(run.ts)) + '</small></div><span class="aaw-tl-node">' + I.clock + '</span><div class="aaw-tl-card">' +
			run.items.map((it) => '<div class="aaw-tl-topic">' + (it.idea ? '<span class="aaw-badge b-ai">' + I.sparkles + ' ایده خودکار</span> ' : '') + '<b>' + esc(it.title) + '</b>' +
				'<div class="aaw-topic-meta">' + (it.priority === 2 ? '<span class="aaw-badge b-p2">فوری</span>' : it.priority === 1 ? '<span class="aaw-badge b-p1">اولویت بالا</span>' : '') + (it.retry ? '<span class="aaw-badge b-failed">تلاش مجدد</span>' : '') + (it.ai ? '<span class="aaw-badge b-ai">پیشنهاد AI</span>' : '') + (it.keywords ? '<span>' + I.hash + esc(String(it.keywords).split('،').slice(0, 3).join('، ')) + '</span>' : '') + (it.category ? '<span>' + I.folder + esc(it.category) + '</span>' : '') + '</div></div>').join('') +
			'</div></div>';
	}
	function pastItemHtml(p) {
		return '<div class="aaw-tl-item is-past' + (p.status === 'failed' ? ' is-failed' : '') + '"><div class="aaw-tl-time"><b>' + esc(fdate(p.ts, { hour: '2-digit', minute: '2-digit' })) + '</b><small>' + esc(rel(p.ts)) + '</small></div><span class="aaw-tl-node">' + (p.status === 'failed' ? I.x : I.check) + '</span><div class="aaw-tl-card">' +
			(p.thumb ? '<img class="aaw-tl-thumb" src="' + esc(p.thumb) + '" alt="" loading="lazy">' : '') +
			'<div><b>' + (p.edit ? '<a href="' + esc(p.edit) + '">' + esc(p.title) + '</a>' : esc(p.title)) + '</b><div class="aaw-topic-meta">' + postStatusBadge(p.status) + (p.words ? '<span>' + fa(p.words) + ' کلمه</span>' : '') + (p.keyword ? '<span>' + I.target + esc(p.keyword) + '</span>' : '') + (p.model ? '<span><code dir="ltr">' + esc(p.model) + '</code></span>' : '') + (p.view ? '<a href="' + esc(p.view) + '" target="_blank">' + I.eye + ' نمایش</a>' : '') + '</div></div></div></div>';
	}
	function groupByDay(list, key, render) {
		let html = '';
		let day = '';
		list.forEach((x, i) => {
			const d = fday(x[key]);
			if (d !== day) { day = d; html += '<div class="aaw-tl-day">' + esc(d) + '</div>'; }
			html += render(x, i);
		});
		return html;
	}

	const Timeline = {
		filter: 'all',
		data: null,
		init() {
			if (!$('[data-timeline]').length) return;
			refreshCurrent = () => this.load();
			$('[data-tl-filter]').on('click', 'button', (e) => { $(e.currentTarget).addClass('is-active').siblings().removeClass('is-active'); this.filter = $(e.currentTarget).data('f'); this.render(); });
			$app.on('click', '[data-action="timeline-refresh"]', (e) => withBusy(e.currentTarget, () => this.load()));
			this.load();
			setInterval(() => { if (!document.hidden) this.load(); }, 60000);
		},
		async load() {
			try { this.data = await ajax('timeline', { runs: 20 }); renderNow(this.data.now); this.render(); } catch (e) { toast('error', e.message); }
		},
		render() {
			const d = this.data;
			if (!d) return;
			let html = '';
			if (this.filter !== 'past') {
				html += '<h3 class="aaw-tl-section">' + I.calendar + ' برنامه آینده</h3>';
				if (d.future.paused) html += '<div class="aaw-alert is-warn">' + I.pause + '<div>زمان‌بندی متوقف یا خاموش است؛ برنامه آینده اجرا نمی‌شود.</div></div>';
				if (!d.future.runs.length) html += '<div class="aaw-empty">' + I.inbox + '<p>' + (d.future.empty ? 'صف موضوعات خالی است. از «تحلیل هوشمند سایت» یا تب موضوعات، موضوع اضافه کنید.' : 'برنامه‌ای برای نمایش وجود ندارد.') + '</p></div>';
				html += groupByDay(d.future.runs, 'ts', (r, i) => futureItemHtml(r, i === 0));
				if (d.future.remaining) html += '<p class="aaw-muted aaw-tl-more">و ' + fa(d.future.remaining) + ' موضوع دیگر در صف بعد از این‌ها…</p>';
			}
			if (this.filter === 'all') html += '<div class="aaw-tl-nowline"><span>' + I.zap + ' اکنون</span></div>';
			if (this.filter !== 'future') {
				html += '<h3 class="aaw-tl-section">' + I.check + ' تاریخچه تولید</h3>';
				if (!d.past.length) html += '<div class="aaw-empty">' + I.inbox + '<p>هنوز مقاله‌ای تولید نشده است.</p></div>';
				html += groupByDay(d.past, 'ts', (p) => pastItemHtml(p));
			}
			$('[data-timeline]').html(html);
		},
	};
	Timeline.init();

	if ($('[data-timeline-mini]').length) {
		const loadMini = () => ajax('timeline', { runs: 3 }).then((d) => {
			renderNow(d.now);
			let html = '<div class="aaw-tl-mini-col"><h4>' + I.calendar + ' پیش‌رو</h4>';
			html += d.future.runs.length ? d.future.runs.slice(0, 3).map((r) => '<div class="aaw-tl-mini-item"><span class="aaw-tl-mini-time">' + esc(fdate(r.ts, { weekday: 'short', hour: '2-digit', minute: '2-digit' })) + '</span><b>' + (r.items[0].idea ? I.sparkles + ' ' : '') + esc(r.items[0].title) + '</b></div>').join('') : '<p class="aaw-muted">برنامه‌ای نیست.</p>';
			html += '</div><div class="aaw-tl-mini-col"><h4>' + I.check + ' اخیر</h4>';
			const past = d.past.filter((p) => p.status !== 'failed').slice(0, 3);
			html += past.length ? past.map((p) => '<div class="aaw-tl-mini-item"><span class="aaw-tl-mini-time">' + esc(rel(p.ts)) + '</span><b>' + (p.edit ? '<a href="' + esc(p.edit) + '">' + esc(p.title) + '</a>' : esc(p.title)) + '</b>' + postStatusBadge(p.status) + '</div>').join('') : '<p class="aaw-muted">هنوز مقاله‌ای ساخته نشده.</p>';
			html += '</div>';
			$('[data-timeline-mini]').html(html);
		}).catch((e) => $('[data-timeline-mini]').html('<p class="aaw-muted">' + fmtErr(e.message) + '</p>'));
		loadMini();
		setInterval(() => { if (!document.hidden) loadMini(); }, 60000);
	}

	/* =========================================================
	 * Smart analysis (strategy tab)
	 * ======================================================= */
	(function () {
		const $root = $('[data-strategy]');
		if (!$root.length) return;
		let record = null;
		try { record = JSON.parse($root.attr('data-record') || 'null'); } catch (_) { record = null; }
		const $form = $('[data-analysis-form]');
		const $prog = $('[data-analysis-progress]');
		let timer = null;
		const step = (name, state, note) => {
			const $li = $prog.find('[data-step="' + name + '"]');
			$li.removeClass('is-active is-done is-error').addClass(state ? 'is-' + state : '');
			if (note !== undefined) $li.find('[data-step-note]').text(note);
		};
		const startProgress = () => {
			$prog.prop('hidden', false);
			$prog.find('[data-analysis-title]').html((I.loader || '') + ' در حال انجام…');
			$prog.find('[data-action="analysis-cancel"]').prop('hidden', false);
			['collect', 'competitors', 'ai', 'done'].forEach((s) => step(s, '', ''));
			const t0 = Date.now();
			clearInterval(timer);
			timer = setInterval(() => $('[data-elapsed-a]').text(fa(Math.round((Date.now() - t0) / 1000)) + ' ثانیه'), 1000);
		};
		const stopProgress = () => clearInterval(timer);

		const priorityLabel = { high: ['b-p2', 'اولویت بالا'], medium: ['b-p1', 'متوسط'], low: ['', 'کم'] };
		const intentLabel = { informational: 'آموزشی', commercial: 'تجاری / مقایسه', transactional: 'خرید', navigational: 'ناوبری' };

		function renderReport(rec) {
			const $r = $('[data-analysis-report]');
			if (!rec || !rec.result) return;
			const a = rec.result;
			const m = rec.meta || {};
			const st = m.stats || {};
			const pillars = [...new Set(a.topics.map((t) => t.pillar).filter(Boolean))];
			let html = '<section class="aaw-card"><div class="aaw-card-body">';
			html += '<div class="aaw-row-between"><h3 class="aaw-h3">' + I.check + ' نتیجه تحلیل</h3><span class="aaw-muted">' + esc(fdate(rec.time)) + '</span></div>';
			html += '<div class="aaw-review-meta aaw-mb"><span class="aaw-chip is-info">' + I.cpu + ' ' + esc(((A.providers || {})[m.provider] || {}).name || m.provider || '') + (m.model ? ' · ' + esc(m.model) : '') + '</span><span class="aaw-chip ' + (m.web ? 'is-ok' : '') + '">' + I.globe + ' ' + (m.web ? 'با جستجوی زنده وب' : 'بر اساس دانش مدل') + '</span>' + (m.competitors ? '<span class="aaw-chip is-ok">' + I.target + ' ' + fa(m.competitors) + ' رقیب بررسی شد</span>' : '') + '<span class="aaw-muted">' + fa(st.posts || 0) + ' مقاله · ' + fa(st.products || 0) + ' محصول · ' + fa((st.categories || 0) + (st.product_categories || 0)) + ' دسته بررسی شد</span></div>';
			if (a.summary) html += '<div class="aaw-analysis-summary"><div><small>کسب‌وکار شما</small><p>' + esc(a.summary) + '</p></div>' + (a.audience ? '<div><small>مخاطب هدف</small><p>' + esc(a.audience) + '</p></div>' : '') + '</div>';
			if (a.pillars.length) html += '<h4 class="aaw-h4">' + I.layers + ' ستون‌های محتوایی</h4><div class="aaw-pillars">' + a.pillars.map((p) => '<div class="aaw-pillar"><b>' + esc(p.name) + '</b><small>' + esc(p.description) + '</small></div>').join('') + '</div>';
			const lists = [['gaps', 'شکاف‌های محتوایی', 'search'], ['trends', 'روندهای روز و فصلی', 'trending'], ['seo_notes', 'توصیه‌های سئو', 'seo']];
			html += '<div class="aaw-grid aaw-grid-3 aaw-mt">' + lists.map(([k, t, ic]) => (a[k] && a[k].length ? '<div class="aaw-insight"><h4 class="aaw-h4">' + (I[ic] || I.info) + ' ' + t + '</h4><ul>' + a[k].slice(0, 8).map((x) => '<li>' + esc(x) + '</li>').join('') + '</ul></div>' : '')).join('') + '</div>';
			if (a.competitors.length) html += '<h4 class="aaw-h4 aaw-mt">' + I.target + ' رقبا</h4><div class="aaw-table-wrap"><table class="aaw-table"><thead><tr><th>رقیب</th><th>نقاط قوت</th><th>نقاط ضعف / فرصت شما</th></tr></thead><tbody>' + a.competitors.map((c) => '<tr><td><b>' + esc(c.name) + '</b>' + (c.url ? '<br><a href="' + esc(c.url) + '" target="_blank" rel="noopener" dir="ltr">' + esc(c.url.replace(/^https?:\/\//, '')) + '</a>' : '') + '</td><td>' + esc(c.strengths) + '</td><td>' + esc(c.weaknesses) + '</td></tr>').join('') + '</tbody></table></div>';
			html += '</div></section>';

			html += '<section class="aaw-card aaw-card-flush"><div class="aaw-topics-toolbar"><div><b>' + I.list + ' ' + fa(a.topics.length) + ' موضوع پیشنهادی</b> <small class="aaw-muted">به ترتیب اولویت</small></div>';
			html += '<div class="aaw-btn-row"><div class="aaw-tabs-pill" data-ta-filter><button type="button" class="is-active" data-p="">همه</button><button type="button" data-p="high">اولویت بالا</button>' + pillars.slice(0, 5).map((p) => '<button type="button" data-pillar="' + esc(p) + '">' + esc(p) + '</button>').join('') + '</div></div></div>';
			html += '<div class="aaw-bulkbar"><label class="aaw-check"><input type="checkbox" data-ta-all checked> انتخاب همه</label><label class="aaw-check"><input type="checkbox" data-ta-newcats> ساخت دسته‌های جدید پیشنهادی</label><button type="button" class="aaw-btn aaw-btn-primary aaw-btn-sm" data-action="analysis-add">' + I.plus + ' افزودن انتخاب‌شده‌ها به صف تولید</button></div>';
			html += '<div class="aaw-topic-cards">' + a.topics.map((t, i) => {
				const pl = priorityLabel[t.priority] || priorityLabel.medium;
				return '<label class="aaw-topic-card" data-i="' + i + '" data-prio="' + esc(t.priority) + '" data-pillar="' + esc(t.pillar) + '"><input type="checkbox" checked data-ta-pick="' + i + '"><div>' +
					'<div class="aaw-topic-card-head"><span class="aaw-fnum">' + fa(i + 1) + '</span><b>' + esc(t.title) + '</b></div>' +
					'<div class="aaw-topic-meta"><span class="aaw-badge ' + pl[0] + '">' + pl[1] + '</span>' + (t.intent ? '<span class="aaw-badge">' + esc(intentLabel[t.intent] || t.intent) + '</span>' : '') + (t.pillar ? '<span>' + I.layers + esc(t.pillar) + '</span>' : '') + (t.category ? '<span>' + I.folder + esc(t.category) + '</span>' : '') + (t.word_count ? '<span>' + fa(t.word_count) + ' کلمه</span>' : '') + '</div>' +
					'<div class="aaw-kw-chips">' + (t.focus_keyword ? '<span class="aaw-kw is-focus">' + esc(t.focus_keyword) + '</span>' : '') + t.keywords.filter((k) => k !== t.focus_keyword).slice(0, 6).map((k) => '<span class="aaw-kw">' + esc(k) + '</span>').join('') + '</div>' +
					(t.reason ? '<p><b>چرا:</b> ' + esc(t.reason) + '</p>' : '') + (t.angle ? '<p><b>زاویه برتری:</b> ' + esc(t.angle) + '</p>' : '') + (t.internal_links && t.internal_links.length ? '<p class="aaw-muted">' + I.link + ' لینک داخلی: ' + esc(t.internal_links.join('، ')) + '</p>' : '') +
					'</div></label>';
			}).join('') + '</div></section>';
			$r.html(html);
			record = rec;
		}

		$app.on('click', '[data-ta-filter] button', function () {
			$(this).addClass('is-active').siblings().removeClass('is-active');
			const p = $(this).data('p');
			const pil = $(this).data('pillar');
			$('.aaw-topic-card').each(function () {
				const show = (!p && !pil) || (p && $(this).data('prio') === p) || (pil && $(this).data('pillar') === pil);
				$(this).toggle(!!show);
			});
		});
		$app.on('change', '[data-ta-all]', function () { $('[data-ta-pick]:visible').prop('checked', this.checked); });
		$app.on('click', '[data-action="analysis-add"]', (e) => {
			if (!record) return;
			const picked = $('[data-ta-pick]:checked').map((_, el) => record.result.topics[$(el).data('ta-pick')]).get();
			if (!picked.length) { toast('info', 'موضوعی انتخاب نشده است.'); return; }
			withBusy(e.currentTarget, async () => {
				const r = await ajax('analysis_add', { topics: picked, create_categories: $('[data-ta-newcats]').is(':checked') });
				Modal.open({
					title: 'به صف اضافه شد',
					body: '<div class="aaw-alert is-ok">' + I['check-circle'] + '<div><b>' + esc(r.message) + '</b><br>هر موضوع همراه کلمات کلیدی، زاویه برتری و لینک‌های داخلی ذخیره شد تا هوش مصنوعی دقیقاً طبق این استراتژی بنویسد.</div></div>',
					buttons: [
						{ text: 'مشاهده خط زمانی', cls: 'aaw-btn-primary', icon: 'calendar', click: () => { location.href = 'admin.php?page=aaw&tab=timeline'; } },
						{ text: 'مدیریت موضوعات', click: () => { location.href = 'admin.php?page=aaw&tab=topics'; } },
					],
				});
			});
		});

		/** One answer for every outcome: result, error, cancelled — never "in progress" forever. */
		const finished = (s, startedAt) => {
			const $btn = $form.find('[type=submit]');
			if (s.error && !s.pending) { step('ai', 'error', ''); $prog.find('[data-step="ai"] [data-step-note]').html(fmtErr(s.error)); $prog.find('[data-analysis-title]').html(I.alert + ' تحلیل انجام نشد'); stopProgress(); busy($btn, false); $prog.find('[data-action="analysis-cancel"]').prop('hidden', true); return true; }
			if (!s.pending && s.record && s.record.time >= startedAt - 5) {
				step('ai', 'done', ''); step('done', 'done', fa(s.record.result.topics.length) + ' موضوع آماده شد');
				$prog.find('[data-analysis-title]').html(I['check-circle'] + ' انجام شد'); $prog.find('[data-action="analysis-cancel"]').prop('hidden', true);
				stopProgress(); busy($btn, false); renderReport(s.record);
				toast('success', 'تحلیل هوشمند آماده شد.');
				return true;
			}
			if (!s.pending) { $prog.prop('hidden', true); stopProgress(); busy($btn, false); return true; } // Cancelled or cleared elsewhere.
			return false;
		};

		const waitGithub = (startedAt, url) => {
			step('ai', 'active', 'در حال اجرا در GitHub با اکانت اشتراکی شما… (می‌توانید صفحه را ترک کنید)');
			if (url) $prog.find('[data-step="ai"] [data-step-note]').append(' ').append($('<a target="_blank" rel="noopener">مشاهده اجرا</a>').attr('href', url));
			const tick = async () => {
				try {
					const s = await ajax('analysis_status');
					if (finished(s, startedAt)) return;
				} catch (e) { /* keep waiting */ }
				setTimeout(tick, 10000);
			};
			setTimeout(tick, 15000);
		};

		const waitAsync = (startedAt, local) => {
			step('ai', 'active', local ? 'هوش مصنوعی مستقیم روی همین سرور در حال تحلیل است… (می‌توانید صفحه را ترک کنید؛ نتیجه ذخیره می‌شود)' : 'هوش مصنوعی روی کلادفلر در حال تحلیل است… (می‌توانید صفحه را ترک کنید؛ نتیجه ذخیره می‌شود)');
			const tick = async () => {
				try {
					const s = await ajax('analysis_status');
					if (s.step && s.pending) step('ai', 'active', s.step);
					if (finished(s, startedAt)) return;
				} catch (e) { /* keep waiting */ }
				setTimeout(tick, 5000);
			};
			setTimeout(tick, 6000);
		};

		$form.on('submit', async (e) => {
			e.preventDefault();
			const d = collect($form);
			const $btn = $form.find('[type=submit]');
			busy($btn, true);
			startProgress();
			step('collect', 'active', 'در حال خواندن مقالات، محصولات و دسته‌ها…');
			try {
				const r = await ajax('analysis_start', d);
				const st = r.stats || {};
				if (r.crawl) step('collect', 'done', 'GitHub کل سایت را می‌خواند و نسخه پشتیبان کامل می‌سازد (نسخه قبلی جایگزین می‌شود)' + (st.drafts ? ' · ' + fa(st.drafts) + ' پیش‌نویس از هاست' : ''));
				else step('collect', 'done', fa(st.posts) + ' مقاله، ' + fa(st.products) + ' محصول، ' + fa((st.categories || 0) + (st.product_categories || 0)) + ' دسته، ' + fa(st.pages) + ' برگه');
				const comps = String(d.competitors || '').split(/\s+/).filter(Boolean).length;
				step('competitors', comps ? 'active' : 'done', comps ? 'در حال بررسی ' + fa(comps) + ' سایت رقیب…' : 'آدرسی وارد نشده؛ تحلیل رقبا از دانش مدل' + (r.web ? ' و جستجوی وب' : ''));
				if (r.mode === 'github') { if (comps) step('competitors', 'done', 'در GitHub بررسی می‌شود'); waitGithub(r.started, r.url); return; }
				if (r.mode === 'async') { if (comps) step('competitors', 'done', 'روی کلادفلر بررسی می‌شود'); waitAsync(r.started); return; }
				if (r.mode === 'local') { if (comps) step('competitors', 'done', 'همراه تحلیل روی سرور بررسی می‌شود'); waitAsync(r.started, true); return; }
				step('ai', 'active', 'هوش مصنوعی در حال تحلیل و برنامه‌ریزی…' + (r.web ? ' (با جستجوی وب)' : ''));
				let rec;
				if (r.mode === 'done') {
					rec = r.record;
				} else {
					const out = await workerFetch(r.ticket, Object.assign({ kind: 'analyze' }, d));
					const saved = await ajax('analysis_save', { analysis: out.analysis, meta: out.meta, stats: st });
					rec = saved.record;
					if (comps) step('competitors', 'done', fa((out.meta && out.meta.competitors_fetched) || 0) + ' رقیب با موفقیت بررسی شد');
				}
				if (comps && r.mode === 'done') step('competitors', 'done', fa(rec.meta.competitors || 0) + ' رقیب با موفقیت بررسی شد');
				step('ai', 'done', '');
				step('done', 'done', fa(rec.result.topics.length) + ' موضوع آماده شد');
				renderReport(rec);
				toast('success', 'تحلیل هوشمند آماده شد.');
				stopProgress();
				busy($btn, false);
			} catch (err) {
				$prog.find('li.is-active').removeClass('is-active').addClass('is-error').find('[data-step-note]').html(fmtErr(err.message));
				toast('error', err.message);
				stopProgress();
				busy($btn, false);
			}
		});

		if (record) renderReport(record);
		if ($root.attr('data-pending') === '1') {
			const started = Number($root.attr('data-started')) || Math.floor(Date.now() / 1000) - 3600;
			startProgress(); step('collect', 'done', ''); step('competitors', 'done', ''); busy($form.find('[type=submit]'), true);
			if ($root.attr('data-mode') === 'github' || !$root.attr('data-mode') || $root.attr('data-mode') === 'legacy') waitGithub(started, ''); else waitAsync(started, $root.attr('data-mode') === 'local');
		} else if ($root.attr('data-error')) {
			startProgress(); stopProgress(); step('collect', 'done', ''); step('competitors', 'done', '');
			step('ai', 'error', ''); $prog.find('[data-step="ai"] [data-step-note]').html(fmtErr($root.attr('data-error')));
			$prog.find('[data-analysis-title]').html(I.alert + ' آخرین تحلیل انجام نشد'); $prog.find('[data-action="analysis-cancel"]').prop('hidden', true);
		}
		$app.on('click', '[data-action="analysis-cancel"]', async (ev) => {
			if (!(await confirmBox('لغو تحلیل', 'تحلیل در حال انجام لغو شود؟ می‌توانید بلافاصله دوباره شروع کنید.', 'لغو تحلیل', true))) return;
			try { const r = await ajax('analysis_cancel'); toast('success', r.message); $prog.prop('hidden', true); stopProgress(); busy($form.find('[type=submit]'), false); } catch (e) { toast('error', e.message); }
		});
		if ($root.attr('data-autostart') === '1' && !record) $form[0].scrollIntoView({ behavior: 'smooth' });
	})();

	/* =========================================================
	 * License
	 * ======================================================= */
	$app.on('submit', '[data-license-form]', function (e) {
		e.preventDefault();
		const $f = $(this);
		const key = String($f.find('[name=key]').val() || '').trim();
		if (!key) return;
		withBusy($f.find('[type=submit]'), async () => {
			const r = await ajax('license_activate', { key });
			toast('success', r.message || 'لایسنس فعال شد.', 6000);
			setTimeout(() => location.reload(), 1200);
		});
	});
	$app.on('click', '[data-action="license-check"]', (e) => withBusy(e.currentTarget, async () => {
		const r = await ajax('license_check');
		toast(r.state && r.state.status === 'active' ? 'success' : 'info', r.message, 6000);
		setTimeout(() => location.reload(), 1200);
	}));
	$app.on('click', '[data-action="license-deactivate"]', async (e) => {
		if (!(await confirmBox('غیرفعال‌سازی لایسنس', 'لایسنس از این سایت آزاد می‌شود و می‌توانید آن را روی سایت دیگری فعال کنید. تولید خودکار روی این سایت متوقف می‌شود.', 'غیرفعال‌سازی', true))) return;
		withBusy(e.currentTarget, async () => {
			const r = await ajax('license_deactivate');
			toast('success', r.message, 5000);
			setTimeout(() => location.reload(), 1200);
		});
	});

	/* =========================================================
	 * Images & SEO knowledge (background jobs on Cloudflare)
	 * ======================================================= */
	$app.on('change', '.aaw-engine input', function () {
		$('.aaw-engine').removeClass('is-active');
		$(this).closest('.aaw-engine').addClass('is-active');
	});
	$app.on('click', '[data-action="pick-style-media"]', () => {
		if (!window.wp || !wp.media) { toast('error', 'کتابخانه رسانه وردپرس بارگذاری نشد؛ صفحه را تازه کنید.'); return; }
		const frame = wp.media({ title: 'تصاویر نمونه تم سایت (۲ تا ۶ تصویر)', button: { text: 'استفاده به‌عنوان تم' }, library: { type: 'image' }, multiple: 'add' });
		frame.on('open', () => {
			const sel = frame.state().get('selection');
			String($('[name="image_style_ids"]').val() || '').split(/[\s,]+/).filter(Boolean).forEach((id) => { const a = wp.media.attachment(id); a.fetch(); sel.add(a); });
		});
		frame.on('select', () => {
			const items = frame.state().get('selection').toJSON().slice(0, 8);
			$('[name="image_style_ids"]').val(items.map((a) => a.id).join(', ')).trigger('input').trigger('change');
			$('[data-style-thumbs]').html(items.map((a) => '<img src="' + esc((a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail.url : a.url)) + '" alt="">').join(''));
			toast('info', fa(items.length) + ' تصویر انتخاب شد؛ «ذخیره تنظیمات» را بزنید و بعد «یادگیری تم» را اجرا کنید.');
		});
		frame.open();
	});
	$app.on('click', '[data-action="pick-product-media"]', () => {
		if (!window.wp || !wp.media) { toast('error', 'کتابخانه رسانه وردپرس بارگذاری نشد؛ صفحه را تازه کنید.'); return; }
		const frame = wp.media({ title: 'عکس‌های مرجع محصولات (تا ۱۲ تصویر)', button: { text: 'استفاده به‌عنوان مرجع محصول' }, library: { type: 'image' }, multiple: 'add' });
		frame.on('open', () => {
			const sel = frame.state().get('selection');
			String($('[name="image_product_ids"]').val() || '').split(/[\s,]+/).filter(Boolean).forEach((id) => { const a = wp.media.attachment(id); a.fetch(); sel.add(a); });
		});
		frame.on('select', () => {
			const items = frame.state().get('selection').toJSON().slice(0, 12);
			$('[name="image_product_ids"]').val(items.map((a) => a.id).join(', ')).trigger('input').trigger('change');
			$('[data-product-thumbs]').html(items.map((a) => '<img src="' + esc((a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail.url : a.url)) + '" alt="">').join(''));
			toast('info', fa(items.length) + ' عکس محصول انتخاب شد؛ «ذخیره تنظیمات» را بزنید.');
		});
		frame.open();
	});
	$app.on('click', '[data-action="clear-product-media"]', () => {
		$('[name="image_product_ids"]').val('').trigger('input').trigger('change');
		$('[data-product-thumbs]').empty();
	});
	$app.on('click', '[data-action="image-prompt-default"]', () => {
		const $t = $('[name="image_chat_prompt"]');
		$t.val($t.attr('placeholder') || '').trigger('input').trigger('change');
	});
	$app.on('click', '[data-action="clear-style-media"]', () => {
		$('[name="image_style_ids"]').val('').trigger('input').trigger('change');
		$('[data-style-thumbs]').html('<small class="aaw-muted">خودکار: تصاویر شاخص آخرین مقالات</small>');
	});
	$app.on('click', '[data-action="img-key-save"]', (e) => {
		const engine = $(e.currentTarget).data('engine');
		const $in = $('[data-img-key="' + engine + '"]');
		const key = String($in.val() || '').trim();
		if (!key) { toast('info', 'کلید را وارد کنید.'); return; }
		withBusy(e.currentTarget, async () => {
			const r = await ajax('image_key_save', { engine, key });
			$in.val('').attr('placeholder', r.mask);
			$('.aaw-engine[data-engine="' + engine + '"] .aaw-chip.is-warn').removeClass('is-warn').addClass('is-ok').text('کلید ثبت شده');
			toast('success', r.message);
		});
	});
	const bgButton = (sel, action, doneText, onDone) => {
		$app.on('click', '[data-action="' + sel + '"]', (e) => {
			const btn = e.currentTarget;
			withBusy(btn, async () => {
				const r = await ajax(action, {});
				toast('info', 'کار روی کلادفلر شروع شد؛ می‌توانید در صفحه بمانید یا آن را ترک کنید.');
				const j = await waitBg(r.id, (step) => $(btn).attr('title', step));
				toast('success', doneText);
				if (onDone) onDone(j);
			});
		});
	};
	bgButton('style-learn', 'style_learn', 'تم تصویری سایت یاد گرفته شد.', async () => {
		const k = await ajax('knowledge');
		if (k.theme && k.theme.theme) $('[data-theme-box]').html('<b>تم فعلی:</b> ' + esc(k.theme.theme));
	});
	/** Wait for a GitHub job: collect results every 15 s until check() is true (max ~15 min). */
	async function waitGh(check) {
		const t0 = Date.now();
		while (Date.now() - t0 < 15 * 60 * 1000) {
			await new Promise((r) => setTimeout(r, 15000));
			try { await ajax('pull_poll'); } catch (e) { /* keep waiting */ }
			const r = await check();
			if (r) return r;
		}
		throw new Error('کار GitHub بیش از ۱۵ دقیقه طول کشید\nعلت: اجرای Actions تمام نشد یا هنوز در صف است.\nراه‌حل: در تب «فعالیت زنده» یا صفحه Actions مخزن وضعیت را ببینید.');
	}
	$app.on('click', '[data-action="seo-learn"]', (e) => {
		const btn = e.currentTarget;
		withBusy(btn, async () => {
			const r = await ajax('seo_learn', {});
			if (r.github) {
				toast('info', 'GitHub شروع به ساخت دیتابیس دانش سئو کرد (۲ تا ۶ دقیقه). می‌توانید صفحه را ترک کنید.', 9000);
				await waitGh(async () => { const k = await ajax('knowledge'); return k.seo && Number(k.seo.at || 0) >= r.since ? k : null; });
			} else {
				toast('info', 'کار روی کلادفلر شروع شد؛ می‌توانید در صفحه بمانید یا آن را ترک کنید.');
				await waitBg(r.id, (step) => $(btn).attr('title', step));
			}
			toast('success', 'دانش به‌روز سئو یاد گرفته شد.');
			setTimeout(() => location.reload(), 900);
		});
	});
	$app.on('click', '[data-action="site-crawl"]', (e) => withBusy(e.currentTarget, async () => {
		const r = await ajax('site_crawl', {});
		toast('success', r.message, 9000);
		const t0 = Math.floor(Date.now() / 1000);
		waitGh(async () => { const st = await ajax('site_status'); return st.data && Number(st.data.at || 0) >= t0 ? st : (st.error && !st.crawling ? Promise.reject(new Error(st.error)) : null); })
			.then(() => { toast('success', 'نسخه پشتیبان سایت در GitHub به‌روز شد.'); setTimeout(() => location.reload(), 900); })
			.catch((err) => toast('error', fmtErr(err.message), 12000));
	}));

	/* =========================================================
	 * Main AI tabs: priority lists (content / image)
	 * ======================================================= */
	(function Priority() {
		const $lists = $('[data-prio]');
		if (!$lists.length) return;
		const renumber = ($l) => {
			let n = 0;
			$l.children('.aaw-prio-item').each(function () {
				const on = $(this).find('[data-prio-on]').prop('checked');
				$(this).toggleClass('is-on', on).toggleClass('is-off', !on).find('.aaw-prio-rank').text(on ? fa(++n) : '–');
			});
		};
		$lists.each(function () {
			const $l = $(this);
			$l.sortable({ handle: '.aaw-prio-grip', axis: 'y', items: '> .aaw-prio-item', update: () => { renumber($l); $l.closest('.aaw-card').addClass('is-dirty'); } });
		});
		$app.on('change', '[data-prio-on]', function () {
			const $it = $(this).closest('.aaw-prio-item');
			const $l = $it.closest('[data-prio]');
			if (this.checked && String($it.data('ready')) !== '1') {
				this.checked = false;
				toast('error', '«' + $it.data('name') + '» هنوز وصل نیست: ' + $it.find('.aaw-prio-main small').text().trim() + '. ابتدا از دکمه «اتصال» آن را وصل کنید.', 8000);
				return;
			}
			if (this.checked) {
				// Newly switched on → place right after the last active one.
				const $last = $l.children('.aaw-prio-item.is-on').not($it).last();
				if ($last.length) $it.insertAfter($last); else $it.prependTo($l);
			} else {
				$it.appendTo($l);
			}
			renumber($l);
			$l.closest('.aaw-card').addClass('is-dirty');
		});
		$app.on('change', '[data-prio-enabled]', function () {
			$('[data-prio-wrap]').toggleClass('is-disabled', !this.checked);
			$(this).closest('.aaw-card').addClass('is-dirty');
		});
		$app.on('click', '[data-action="prio-save"]', (e) => {
			const kind = $(e.currentTarget).data('kind');
			const $l = $('[data-prio="' + kind + '"]');
			const order = []; const models = {};
			$l.children('.aaw-prio-item').each(function () {
				const id = $(this).data('id');
				const m = $(this).find('[data-prio-model]');
				if (m.length) models[id] = m.val();
				if ($(this).find('[data-prio-on]').prop('checked')) order.push(id);
			});
			const d = { kind, order, models };
			if (kind === 'image') d.enabled = $('[data-prio-enabled]').prop('checked') ? 1 : 0;
			withBusy(e.currentTarget, async () => {
				const r = await ajax('priority_save', d);
				toast('success', r.message, 7000);
				$l.closest('.aaw-card').removeClass('is-dirty');
				if (r.label) $('[data-prio-label="' + kind + '"]').text(r.label);
			});
		});
		$app.on('click', '[data-action="prio-test"]', (e) => {
			const $it = $(e.currentTarget).closest('.aaw-prio-item');
			const kind = $it.closest('[data-prio]').data('prio');
			const id = $it.data('id');
			const model = $it.find('[data-prio-model]').val() || '';
			withBusy(e.currentTarget, async () => {
				if (kind === 'text') {
					const r = await ajax('provider_test', { provider: id, model });
					toast('success', r.message, 7000);
					return;
				}
				const $out = $('[data-img-test-out]');
				const r = await ajax('image_test', { engine: id });
				$out.html('<div class="aaw-run-progress"><div class="aaw-orb"></div><b>در حال ساخت تصویر آزمایشی با ' + esc($it.data('name')) + '…</b><small>' + fa(r.refs) + ' تصویر مرجع</small></div>');
				try {
					const j = await waitBg(r.id);
					$out.html(j.preview ? '<img src="' + j.preview + '" alt=""><small class="aaw-muted">موتور: ' + esc((j.result && j.result.engine) || id) + ' · مرجع استفاده‌شده: ' + fa((j.result && j.result.refs_used) || 0) + '</small>' : '<div class="aaw-alert is-warn">' + I.alert + '<div>تصویری برنگشت.</div></div>');
				} catch (err) {
					$out.html('<div class="aaw-alert is-error">' + I.alert + '<div>' + fmtErr(err.message) + '</div></div>');
				}
			});
		});
	})();

	/* =========================================================
	 * Search Console + merging duplicate articles
	 * ======================================================= */
	(function GSC() {
		const $root = $('[data-gsc]');
		if (!$root.length) return;
		const num = (n) => fa(Number(n || 0).toLocaleString('en-US'));
		const renderReport = (r) => {
			if (!r) return;
			$('[data-gsc-at]').text('آخرین دریافت: همین حالا · ' + num(r.totals.c) + ' کلیک، ' + num(r.totals.i) + ' نمایش در ' + fa(r.days) + ' روز');
			const row = (s, pick) => '<tr>' + (pick ? '<td>' + (s.post ? '' : '<input type="checkbox" data-gsc-q value="' + esc(s.q) + '">') + '</td>' : '') + '<td><b>' + esc(s.q) + '</b>' + (s.post ? '<br><small class="aaw-muted">مقاله دارد: ' + esc(s.post.title) + ' → تقویت/بازنویسی</small>' : '') + '</td><td>' + num(s.i) + '</td><td>' + num(s.c) + '</td><td>' + fa(s.ctr) + '٪</td><td>' + fa(s.p) + '</td></tr>';
			const head = (pick) => '<thead><tr>' + (pick ? '<th></th>' : '') + '<th>جستجو</th><th>نمایش</th><th>کلیک</th><th>CTR</th><th>جایگاه</th></tr></thead>';
			let h = '';
			h += '<h3 class="aaw-h3">' + I.target + ' نزدیک صفحه اول (جایگاه ۵ تا ۲۰) — بهترین موضوع‌ها برای مقاله جدید</h3>';
			h += r.striking.length ? '<div class="aaw-table-wrap"><table class="aaw-table">' + head(true) + '<tbody>' + r.striking.map((s) => row(s, true)).join('') + '</tbody></table></div><button type="button" class="aaw-btn aaw-btn-sm aaw-btn-primary aaw-mt" data-action="gsc-add">' + I.plus + ' افزودن انتخاب‌شده‌ها به صف موضوعات</button>' : '<p class="aaw-muted">فرصتی پیدا نشد.</p>';
			h += '<h3 class="aaw-h3 aaw-mt">' + I.alert + ' جایگاه خوب ولی کلیک کم (CTR پایین) — عنوان و توضیحات متا را جذاب‌تر کنید</h3>';
			h += r.low_ctr.length ? '<div class="aaw-table-wrap"><table class="aaw-table">' + head(false) + '<tbody>' + r.low_ctr.map((s) => row(s, false)).join('') + '</tbody></table></div>' : '<p class="aaw-muted">موردی نیست.</p>';
			h += '<details class="aaw-mt"><summary><b>پرکلیک‌ترین جستجوها</b></summary><div class="aaw-table-wrap"><table class="aaw-table">' + head(false) + '<tbody>' + r.top.map((s) => row(s, false)).join('') + '</tbody></table></div></details>';
			$('[data-gsc-report]').html(h);
		};
		const loadMerge = async (force) => {
			const r = await ajax('merge_list', { force: force ? 1 : 0 });
			const side = (s, pairIdx, key, checked) => '<label class="aaw-merge-side' + (checked ? ' is-keep' : '') + '"><input type="radio" name="keep-' + pairIdx + '" value="' + key + '"' + (checked ? ' checked' : '') + '><div><b><a href="' + esc(s.url) + '" target="_blank" rel="noopener">' + esc(s.title) + '</a></b><small>' + num(s.words) + ' کلمه · ' + esc(s.date) + (r.gsc ? ' · ' + num(s.clicks) + ' کلیک / ' + num(s.impr) + ' نمایش' + (s.pos ? ' · جایگاه ' + fa(s.pos) : '') : '') + '</small><em class="aaw-keep-tag">می‌ماند</em><em class="aaw-drop-tag">ادغام و ریدایرکت می‌شود</em></div></label>';
			$('[data-merge-list]').html(r.pairs.length ? r.pairs.map((p, i) => '<div class="aaw-merge-pair" data-pair data-a="' + p.a.id + '" data-b="' + p.b.id + '">' +
				'<div class="aaw-merge-why">' + p.why.map((w) => w === 'gsc' ? '<span class="aaw-chip is-bad">رقابت در گوگل' + (p.queries.length ? ': ' + esc(p.queries.join('، ')) : '') + '</span>' : '<span class="aaw-chip is-warn">موضوع مشابه (' + fa(Math.round(p.score * 100)) + '٪)</span>').join(' ') + '</div>' +
				'<div class="aaw-merge-sides">' + side(p.a, i, 'a', p.keep === 'a') + side(p.b, i, 'b', p.keep === 'b') + '</div>' +
				'<div class="aaw-row-between"><label class="aaw-check"><input type="checkbox" data-merge-links checked> لینک‌های داخلی سایت هم به مقاله باقی‌مانده اصلاح شود</label><button type="button" class="aaw-btn aaw-btn-sm aaw-btn-primary" data-action="merge-go">' + I.layers + ' ادغام این دو مقاله</button></div></div>').join('')
				: '<div class="aaw-empty">' + I['check-circle'] + '<p>مقاله تکراری یا رقیبی پیدا نشد.' + (r.gsc ? '' : ' (با اتصال سرچ کنسول، رقابت واقعی مقاله‌ها در گوگل هم بررسی می‌شود.)') + '</p></div>');
			$('[data-merge-history]').html((r.history.length ? '<ul class="aaw-merge-hist">' + r.history.map((m) => '<li><b>' + esc(m.drop_title) + '</b> ← در «' + esc(m.keep_title) + '» ادغام شد · ' + esc(m.when) + (m.links ? ' · ' + fa(m.links) + ' لینک اصلاح شد' : '') + (m.undone ? ' <em class="aaw-chip">بازگردانی شد</em>' : ' <button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="merge-undo" data-drop="' + m.drop + '">' + I.undo + ' بازگردانی</button>') + '<br><small class="aaw-muted" dir="ltr">301: ' + esc(m.from) + '</small></li>').join('') + '</ul>' : '<small class="aaw-muted">هنوز ادغامی انجام نشده است.</small>'));
		};
		$root.on('change', '.aaw-merge-side input', function () {
			$(this).closest('.aaw-merge-sides').find('.aaw-merge-side').removeClass('is-keep');
			$(this).closest('.aaw-merge-side').addClass('is-keep');
		});
		$app.on('click', '[data-action="merge-scan"]', (e) => withBusy(e.currentTarget, () => loadMerge(true)));
		$app.on('click', '[data-action="merge-go"]', async (e) => {
			const $p = $(e.currentTarget).closest('[data-pair]');
			const keepKey = $p.find('.aaw-merge-side input:checked').val();
			const keep = keepKey === 'a' ? $p.data('a') : $p.data('b');
			const drop = keepKey === 'a' ? $p.data('b') : $p.data('a');
			const keepTitle = $p.find('.aaw-merge-side.is-keep b').text();
			const dropTitle = $p.find('.aaw-merge-side').not('.is-keep').find('b').text();
			if (!(await confirmBox('ادغام دو مقاله', 'مطالب «' + dropTitle + '» با هوش مصنوعی در «' + keepTitle + '» ادغام می‌شود، «' + dropTitle + '» با ریدایرکت ۳۰۱ به آن منتقل و پیش‌نویس می‌شود. نسخه قبلی ذخیره می‌شود و از بخش «ادغام‌های انجام‌شده» قابل بازگردانی است. ادامه؟', 'ادغام کن'))) return;
			withBusy(e.currentTarget, async () => {
				const r = await ajax('merge_start', { keep, drop, links: $p.find('[data-merge-links]').prop('checked') ? 1 : 0 });
				toast('success', r.message, 9000);
				$p.addClass('is-working').find('[data-action="merge-go"]').prop('disabled', true).text('در حال ادغام…');
			});
		});
		$app.on('click', '[data-action="merge-undo"]', async (e) => {
			if (!(await confirmBox('بازگردانی ادغام', 'ریدایرکت حذف و هر دو مقاله به حالت قبل از ادغام برمی‌گردند. ادامه؟', 'بازگردانی'))) return;
			withBusy(e.currentTarget, async () => { const r = await ajax('merge_undo', { drop: $(e.currentTarget).data('drop') }); toast('success', r.message); loadMerge(true); });
		});
		$app.on('click', '[data-action="gsc-key-save"]', (e) => withBusy(e.currentTarget, async () => {
			const json = String($('[data-gsc-json]').val() || '').trim();
			if (!json) { toast('error', 'محتوای فایل JSON را جای‌گذاری کنید.'); return; }
			const r = await ajax('gsc_key_save', { json });
			$('[data-gsc-json]').val('');
			fillSites(r);
			toast('success', r.sites.length ? 'وصل شد. property مربوط به سایت را انتخاب و ذخیره کنید.' : 'کلید ذخیره شد ولی این Service Account به هیچ property دسترسی ندارد؛ ایمیلش را در Search Console → Users and permissions اضافه کنید و دکمه تازه‌سازی را بزنید.', 10000);
			if (r.selected) setTimeout(() => location.reload(), 1800);
		}));
		$app.on('click', '[data-action="gsc-client-save"]', (e) => withBusy(e.currentTarget, async () => {
			const id = String($('[data-gsc-client-id]').val() || '').trim();
			const secret = String($('[data-gsc-client-secret]').val() || '').trim();
			if (!id || !secret) { toast('error', 'Client ID و Client secret هر دو لازم است.'); return; }
			const r = await ajax('gsc_client_save', { client_id: id, client_secret: secret });
			$('[data-gsc-client-secret]').val('');
			$('[data-action="gsc-google-login"]').prop('disabled', false);
			toast('success', r.message, 8000);
		}));
		$app.on('click', '[data-action="gsc-google-login"]', (e) => withBusy(e.currentTarget, async () => {
			const r = await ajax('gsc_auth_url');
			window.location.href = r.url;
		}));
		$app.on('click', '[data-action="gsc-disconnect"]', (e) => withBusy(e.currentTarget, async () => {
			if (!window.confirm('اتصال سرچ کنسول قطع شود؟')) return;
			const r = await ajax('gsc_disconnect');
			toast('success', r.message);
			setTimeout(() => location.reload(), 900);
		}));
		const fillSites = (r) => {
			$('[data-gsc-sites]').prop('hidden', false);
			$('[data-gsc-site]').html(r.sites.map((s) => '<option value="' + esc(s.url) + '"' + (s.url === r.selected ? ' selected' : '') + '>' + esc(s.url) + '</option>').join(''));
		};
		$app.on('click', '[data-action="gsc-sites"]', (e) => withBusy(e.currentTarget, async () => { fillSites(await ajax('gsc_sites')); }));
		$app.on('click', '[data-action="gsc-site-save"]', (e) => withBusy(e.currentTarget, async () => { const r = await ajax('gsc_site_save', { site: $('[data-gsc-site]').val() }); toast('success', r.message); setTimeout(() => location.reload(), 900); }));
		$app.on('click', '[data-action="gsc-refresh"]', (e) => withBusy(e.currentTarget, async () => {
			let r = await ajax('gsc_refresh', { days: $('[data-gsc-days]').val() });
			let guard = 0;
			while (!r.done && guard++ < 60) {
				$('[data-gsc-report]').html('<div class="aaw-run-progress"><div class="aaw-orb"></div><b>در حال دریافت داده‌ها (تکه‌تکه)… ' + fa(r.progress || 0) + '٪</b></div>');
				r = await ajax('gsc_refresh', { continue: 1 });
			}
			renderReport(r.report);
			toast('success', 'داده‌های سرچ کنسول به‌روز شد.');
			loadMerge(true);
		}));
		$app.on('click', '[data-action="gsc-add"]', (e) => {
			const queries = $('[data-gsc-q]:checked').map(function () { return this.value; }).get();
			if (!queries.length) { toast('info', 'چند جستجو را تیک بزنید.'); return; }
			withBusy(e.currentTarget, async () => { const r = await ajax('gsc_add_topics', { queries }); toast('success', r.message, 7000); });
		});
		if ($root.data('connected') === 1 || $root.attr('data-connected') === '1') ajax('gsc_report').then((r) => renderReport(r.report)).catch(() => {});
		loadMerge(false).catch((err) => $('[data-merge-list]').html('<div class="aaw-alert is-error">' + I.alert + '<div>' + fmtErr(err.message) + '</div></div>'));
	})();

	/* ChatGPT sign-in with a one-time code (device code on GitHub; nothing to install). */
	$app.on('click', '[data-action="codex-login"]', function () {
		const $box = $(this).closest('[data-codex-login]');
		const $out = $box.find('[data-cx-out]');
		const btn = this;
		const show = (html) => $out.prop('hidden', false).html(html);
		withBusy(btn, async () => {
			const r = await ajax('codex_login_start', { image: $box.find('[data-cx-image]').prop('checked') ? 1 : 0, text: $box.find('[data-cx-text]').prop('checked') ? 1 : 0 });
			show('<div class="aaw-run-progress"><div class="aaw-orb"></div><b>در حال آماده‌سازی ورود در GitHub…</b><small>حدود ۱ تا ۲ دقیقه؛ این صفحه را نبندید.</small></div>');
			const t0 = Date.now();
			let shown = '';
			for (;;) {
				await new Promise((res) => setTimeout(res, 4000));
				let st;
				try { st = await ajax('codex_login_status', { id: r.id }); } catch (e) { continue; }
				if (st.state === 'code' && st.code && shown !== st.code) {
					shown = st.code;
					show('<div class="aaw-cx-code"><small>این کد را در صفحه ورود ChatGPT وارد کنید:</small><b dir="ltr" data-cx-code>' + esc(st.code) + '</b>' +
						'<div class="aaw-btn-row"><button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-cx-copy>' + I.copy + ' کپی کد</button>' +
						'<a class="aaw-btn aaw-btn-primary" href="' + esc(st.url) + '" target="_blank" rel="noopener">' + I.external + ' باز کردن صفحه ورود ChatGPT</a></div>' +
						'<small class="aaw-muted">بعد از ورود با اکانت ChatGPT و وارد کردن کد، این‌جا خودکار «وصل شد» نمایش داده می‌شود.</small></div>');
				}
				if (st.state === 'done') {
					show('<div class="aaw-alert is-ok">' + I['check-circle'] + '<div><b>اکانت ChatGPT وصل شد.</b> ' + (st.roles && st.roles.image ? 'از این پس تصاویر با اکانت ChatGPT ساخته می‌شوند (اولویت ' + fa(st.roles.image) + ' در لیست تصویر).' : 'در تب «هوش مصنوعی تولید تصویر» روشنش کنید.') + '</div></div>');
					toast('success', 'اکانت ChatGPT وصل شد.', 7000);
					setTimeout(() => location.reload(), 2500);
					return;
				}
				if (st.state === 'error') {
					show('<div class="aaw-alert is-error">' + I.alert + '<div><b>' + esc(st.error || 'ورود ناموفق بود.') + '</b>' + (st.detail ? '<br><small dir="ltr">' + esc(st.detail) + '</small>' : '') + '</div></div>');
					return;
				}
				if (!shown && Date.now() - t0 > 6 * 60 * 1000) {
					show('<div class="aaw-alert is-warn">' + I.alert + '<div>کد هنوز آماده نشده. وضعیت اجرا را در <a href="' + esc(r.url) + '" target="_blank" rel="noopener">GitHub Actions</a> ببینید؛ اگر اجرا شروع نشده، در تب اکانت اشتراکی «به‌روزرسانی فایل‌های Runner» را بزنید و دوباره امتحان کنید.</div></div>');
					return;
				}
				if (Date.now() - t0 > 20 * 60 * 1000) {
					show('<div class="aaw-alert is-warn">' + I.alert + '<div>مهلت ورود تمام شد. دوباره «ورود با اکانت ChatGPT» را بزنید.</div></div>');
					return;
				}
			}
		});
	});
	$app.on('click', '[data-cx-copy]', function () {
		const code = $(this).closest('.aaw-cx-code').find('[data-cx-code]').text();
		if (navigator.clipboard) navigator.clipboard.writeText(code).then(() => toast('success', 'کد کپی شد.'));
	});

	/* Subscription tab: which job each account does. */
	$app.on('change', '[data-sub-role] input[data-role]', function () {
		const $row = $(this).closest('[data-sub-role]');
		const d = { provider: $row.data('sub-role'), text: $row.find('[data-role="text"]').prop('checked') ? 1 : 0, image: $row.find('[data-role="image"]').prop('checked') ? 1 : 0 };
		const $inputs = $row.find('input').prop('disabled', true);
		ajax('sub_role', d)
			.then((r) => { toast('success', r.message, 6000); setTimeout(() => location.reload(), 1200); })
			.catch((err) => { toast('error', fmtErr(err.message), 9000); $inputs.prop('disabled', false); this.checked = !this.checked; });
	});
	$app.on('click', '[data-action="img-test"]', (e) => {
		const $out = $('[data-img-test-out]');
		withBusy(e.currentTarget, async () => {
			const r = await ajax('image_test', { title: $('[data-img-test-title]').val() });
			$out.html('<div class="aaw-run-progress"><div class="aaw-orb"></div><b>در حال ساخت تصویر…</b><small>' + (r.products && r.products.length ? 'محصولات مرجع: ' + esc(r.products.join('، ')) : 'محصول مرتبطی پیدا نشد') + ' · ' + fa(r.refs) + ' تصویر مرجع</small></div>');
			try {
				const j = await waitBg(r.id);
				$out.html(j.preview ? '<img src="' + j.preview + '" alt=""><small class="aaw-muted">موتور: ' + esc((j.result && j.result.engine) || '') + ' · مرجع استفاده‌شده: ' + fa((j.result && j.result.refs_used) || 0) + '</small>' : '<div class="aaw-alert is-warn">' + I.alert + '<div>تصویری برنگشت.</div></div>');
			} catch (err) {
				$out.html('<div class="aaw-alert is-error">' + I.alert + '<div>' + fmtErr(err.message) + '</div></div>');
			}
		});
	});

	/* =========================================================
	 * Live activity tab
	 * ======================================================= */
	(function Live() {
		if (!$('[data-ops]').length) return;
		const kindIcon = { test: 'zap', run: 'play', generate: 'content', suggest: 'sparkles', analyze: 'wand', image: 'image', post_image: 'image', revise: 'send', seo_learn: 'book', seo: 'book', style_learn: 'wand', models: 'list', fetch: 'download' };
		const dur = (s) => (s >= 60 ? fa(Math.floor(s / 60)) + ' دقیقه و ' : '') + fa(s % 60) + ' ثانیه';
		let since = 0;
		const seen = new Set();
		const render = (r) => {
			const ops = r.ops || [];
			const running = ops.filter((o) => o.status === 'running');
			$('[data-live-summary]').text(running.length ? fa(running.length) + ' عملیات در حال انجام است' : 'در حال حاضر کاری در حال انجام نیست');
			$('.aaw-live-dot').toggleClass('is-on', running.length > 0);
			$('[data-live-count]').text(running.length ? fa(running.length) + ' در حال انجام' : 'فعالیت زنده');
			$('#aaw-live-chip').toggleClass('is-info aaw-live', running.length > 0);
			$('[data-live-updated]').text('به‌روزرسانی: ' + new Date().toLocaleTimeString('fa-IR'));
			let html = (r.processing || []).map((t) => '<div class="aaw-op is-running"><span class="aaw-op-ic">' + I.loader + '</span><div class="aaw-op-main"><b>در حال نوشتن: ' + esc(t.title) + '</b><small>موضوع در وضعیت «در حال پردازش» است</small></div></div>').join('');
			html += ops.map((o) => {
				const ic = o.status === 'running' ? I.loader : (o.status === 'done' ? I['check-circle'] : I['x-circle']);
				return '<div class="aaw-op is-' + esc(o.status) + '"><span class="aaw-op-ic">' + ic + '</span><div class="aaw-op-main"><b>' + (I[kindIcon[o.kind]] || '') + ' ' + esc(o.label || o.kind) + '</b>' +
					'<small>' + esc(o.step || '') + ' · ' + esc(o.time) + ' · ' + dur(Number(o.elapsed) || 0) + '</small>' +
					(o.detail ? '<div class="aaw-op-detail">' + fmtErr(o.detail) + '</div>' : '') +
					(o.url ? '<a href="' + esc(o.url) + '" target="_blank" rel="noopener">مشاهده اجرا</a>' : '') +
					(o.post_id ? ' <a href="post.php?post=' + Number(o.post_id) + '&action=edit">مشاهده نوشته</a>' : '') +
					'</div></div>';
			}).join('');
			$('[data-ops]').html(html || '<div class="aaw-empty">' + I.inbox + '<p>هنوز عملیاتی ثبت نشده است. تست هوش مصنوعی، تولید مقاله یا ساخت تصویر را اجرا کنید تا اینجا لحظه‌به‌لحظه ببینید.</p></div>');
			const logs = (r.logs || []).filter((l) => !seen.has(l.id)).reverse();
			logs.forEach((l) => { seen.add(l.id); since = Math.max(since, Number(l.id)); $('[data-live-log]').prepend('<li class="lv-' + esc(l.level) + '"><time>' + esc(l.time) + '</time><span>' + fmtErr(String(l.message).split('\n')[0]) + '</span></li>'); });
			$('[data-live-log] li').slice(60).remove();
			if (r.now) $('[data-live-now]').html('<div class="aaw-now-row"><span class="aaw-now-dot is-' + esc(r.now.state) + '"></span><div class="aaw-now-main"><small>الان</small><b>' + esc(r.now.text) + '</b></div>' + (r.now.next ? '<div class="aaw-now-next"><small>نوبت بعدی · ' + esc(rel(r.now.next.ts)) + '</small><b>' + esc(fdate(r.now.next.ts)) + '</b></div>' : '') + '</div>');
			return running.length;
		};
		const tick = async () => {
			let delay = 8000;
			if (!document.hidden) {
				try { const r = await ajax('activity', { since }); delay = render(r) ? 3000 : 8000; } catch (e) { $('[data-live-summary]').text('خطا در دریافت وضعیت'); }
			}
			setTimeout(tick, delay);
		};
		tick();
		$app.on('click', '[data-action="activity-clear"]', (e) => withBusy(e.currentTarget, async () => { const r = await ajax('activity_clear'); toast('success', r.message); }));
	})();

	/* =========================================================
	 * AI engines on this server (direct, no GitHub / Cloudflare)
	 * ======================================================= */
	(function () {
		const $root = $('[data-engines]');
		if (!$root.length) return;
		const GROUP = {
			ready: ['is-ok', 'check-circle', 'آماده'],
			needs_test: ['is-info', 'zap', 'نیاز به تست'],
			auth_required: ['is-warn', 'key', 'نیاز به ورود'],
			not_installed: ['', 'download', 'نصب نشده'],
			installing: ['is-info', 'loader', 'در حال نصب'],
			error: ['is-error', 'alert', 'خطا'],
			unsupported: ['is-error', 'x-circle', 'هاست پشتیبانی نمی‌کند'],
		};
		const STEPS = ['بررسی سرور', 'نصب', 'ورود', 'تست', 'آماده'];
		const stepOf = (e) => ({ ready: 4, needs_test: 3, error: 3, auth_required: 2, not_installed: 1, installing: 1 }[e.status] || 0);
		let timer = null;
		let doc = null;

		const kv = (label, val, tone) => '<div><small>' + esc(label) + '</small><code class="' + (tone || '') + '" dir="auto">' + esc(val) + '</code></div>';

		function card(e) {
			const g = GROUP[e.status] || GROUP.error;
			const at = stepOf(e);
			const st = e.state || {};
			const inst = e.install || {};
			const test = st.test;
			let h = '<article class="aaw-card aaw-eng" data-eng="' + e.engine + '"><div class="aaw-card-body">';
			h += '<div class="aaw-row-between"><div><b class="aaw-eng-name">' + esc(e.name) + '</b><br><small class="aaw-muted" dir="ltr">' + esc(e.package) + '</small></div><span class="aaw-chip ' + g[0] + '">' + (I[g[1]] || '') + ' ' + g[2] + '</span></div>';
			h += '<ol class="aaw-eng-steps">' + STEPS.map((s, i) => '<li class="' + (i < at ? 'is-done' : (i === at ? 'is-now' : '')) + '"><span>' + fa(i + 1) + '</span>' + s + '</li>').join('') + '</ol>';
			h += '<div class="aaw-eng-route"><b>روش اجرای این اکانت:</b><div class="aaw-seg">'
				+ '<label><input type="radio" name="route-' + e.engine + '" value="local"' + (e.route === 'local' ? ' checked' : '') + ' data-eng-route="' + e.engine + '"><span>مستقیم از همین سرور</span></label>'
				+ '<label><input type="radio" name="route-' + e.engine + '" value="github"' + (e.route !== 'local' ? ' checked' : '') + ' data-eng-route="' + e.engine + '"><span>از طریق GitHub</span></label></div>'
				+ '<small class="aaw-muted">' + (e.route === 'local' ? 'مقاله، اصلاح، تحلیل' + (e.engine === 'codex' ? ' و تصویر' : '') + ' با این اکانت فقط روی همین سرور انجام می‌شود.' : 'این اکانت روی GitHub Actions اجرا می‌شود (تب اکانت اشتراکی).') + '</small></div>';
			if (st.msg && e.status !== 'ready') h += '<div class="aaw-alert is-error">' + I.alert + '<div>' + fmtErr(st.msg) + '</div></div>';
			if (e.ver_err) h += '<div class="aaw-alert is-warn">' + I.alert + '<div><b>برنامه نصب است ولی اجرا نشد:</b><div class="aaw-err-tech" dir="ltr">' + esc(e.ver_err) + '</div></div></div>';
			if (inst.status === 'running') h += '<div class="aaw-alert is-info">' + I.loader + '<div>در حال نصب با npm… (' + fa(Math.round((inst.elapsed || 0) / 60)) + ' دقیقه — معمولاً ۱ تا ۵ دقیقه؛ این صفحه خودش به‌روز می‌شود)</div></div>';
			if (inst.status === 'failed') h += '<div class="aaw-alert is-error">' + I.alert + '<div><b>نصب ناموفق بود:</b> ' + fmtErr(inst.message || '') + (inst.log ? '<details><summary>گزارش نصب</summary><pre class="aaw-pre" dir="ltr">' + esc(inst.log) + '</pre></details>' : '') + '<div class="aaw-mt-sm">نصب دستی با SSH / ترمینال cPanel:<code class="aaw-cmd" dir="ltr">' + esc(e.ssh) + '</code></div></div></div>';
			h += '<div class="aaw-kv aaw-eng-kv">'
				+ kv('نسخه برنامه', e.version || '—', e.version ? 'is-good' : '')
				+ kv('ورود', e.login ? 'ثبت شده' : 'ثبت نشده', e.login ? 'is-good' : 'is-warn')
				+ kv('آخرین اتصال موفق', st.last_ok ? new Date(st.last_ok * 1000).toLocaleString('fa-IR') : '—')
				+ kv('مدل', e.model || (e.engine === 'codex' ? 'پیش‌فرض پلن ChatGPT' : 'sonnet'))
				+ '</div>';
			if (test) h += '<div class="aaw-alert ' + (test.ok ? 'is-ok' : 'is-error') + '">' + (test.ok ? I['check-circle'] : I.alert) + '<div>' + (test.ok ? '<b>کار می‌کند</b> — پاسخ «' + esc(test.text) + '» در ' + fa(test.sec) + ' ثانیه' : fmtErr(test.text)) + '</div></div>';
			h += '<div data-eng-out></div>';
			h += '<details class="aaw-eng-paths"><summary>مسیرهای پیدا‌شده</summary><div dir="ltr" class="aaw-small">CLI: ' + esc(e.path || '—') + '<br>Node.js: ' + esc(e.node || '—') + '</div></details>';
			const noRun = ['not_installed', 'unsupported', 'installing'].indexOf(e.status) >= 0;
			h += '<div class="aaw-btn-row aaw-mt-sm">'
				+ '<button type="button" class="aaw-btn aaw-btn-primary" data-action="eng-test" data-engine="' + e.engine + '"' + (noRun || !e.login ? ' disabled' : '') + '>' + I.zap + ' تست اتصال</button>'
				+ '<button type="button" class="aaw-btn aaw-btn-ghost" data-action="eng-install" data-engine="' + e.engine + '"' + (e.status === 'unsupported' || e.status === 'installing' ? ' disabled' : '') + '>' + I.download + ' ' + (e.version ? 'نصب / تعمیر' : 'نصب') + '</button>'
				+ '<button type="button" class="aaw-btn aaw-btn-ghost" data-action="eng-login" data-engine="' + e.engine + '"' + (e.status === 'unsupported' ? ' disabled' : '') + '>' + I.key + ' ' + (e.login ? 'ورود دوباره' : 'ورود') + '</button>'
				+ (e.login ? '<button type="button" class="aaw-btn aaw-btn-ghost" data-action="eng-signout" data-engine="' + e.engine + '">' + I.x + ' خروج</button>' : '')
				+ '</div>';
			return h + '</div></article>';
		}

		function render(r) {
			doc = r;
			$root.html('<div class="aaw-eng-grid">' + ['codex', 'claude'].map((id) => card(r.engines[id])).join('') + '</div>');
			$('[data-eng-env]').html('<ul class="aaw-checks">' + r.env.map((c) => '<li class="' + (c.ok ? 'is-ok' : 'is-warn') + '">' + (c.ok ? I['check-circle'] : I.alert) + '<div><b>' + esc(c.label) + '</b><small dir="auto">' + esc(c.detail) + '</small></div></li>').join('') + '</ul>'
				+ (r.nodes.length ? '<table class="aaw-table aaw-mt-sm"><thead><tr><th>Node.js پیدا‌شده</th><th>نسخه</th><th>npm</th></tr></thead><tbody>' + r.nodes.map((n) => '<tr><td dir="ltr"><code>' + esc(n.path) + '</code></td><td>' + esc(n.version) + '</td><td>' + (n.npm ? '✓' : '—') + '</td></tr>').join('') + '</tbody></table>' : '<p class="aaw-muted">Node.js روی این سرور پیدا نشد.</p>'));
			renderJobs(r.jobs || []);
			const busy = ['codex', 'claude'].some((id) => r.engines[id].status === 'installing') || (r.jobs || []).some((j) => j.status === 'queued' || j.status === 'running');
			clearTimeout(timer);
			if (busy) timer = setTimeout(() => load(false), 6000);
		}

		function renderJobs(jobs) {
			const LBL = { queued: ['', 'در صف'], running: ['is-info', 'در حال اجرا'], done: ['is-ok', 'انجام شد'], error: ['is-error', 'خطا'] };
			$('[data-eng-jobs]').html(jobs.length ? '<ul class="aaw-eng-jobs">' + jobs.map((j) => {
				const l = LBL[j.status] || LBL.queued;
				return '<li><span class="aaw-chip ' + l[0] + '">' + l[1] + '</span> <b>' + esc(j.label) + '</b> <small class="aaw-muted">' + (j.engine === 'codex' ? 'ChatGPT' : 'Claude') + ' · ' + new Date(j.created * 1000).toLocaleString('fa-IR') + '</small>'
					+ '<div class="aaw-muted aaw-small">' + (j.status === 'error' ? fmtErr(j.error) : esc(j.step)) + '</div>'
					+ ((j.status === 'running' || j.status === 'queued') ? '<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost" data-action="eng-cancel" data-id="' + esc(j.id) + '">' + I.x + ' لغو</button>' : '') + '</li>';
			}).join('') + '</ul>' : '<small class="aaw-muted">هنوز کاری مستقیم روی سرور اجرا نشده است.</small>');
		}

		function load(fresh) {
			return ajax('local_doctor', fresh ? { fresh: 1 } : {}).then(render).catch((e) => $root.html('<div class="aaw-alert is-error">' + I.alert + '<div>' + fmtErr(e.message) + '</div></div>'));
		}

		/* ---- login dialog: like a real user (official page in your window) or paste ---- */
		function loginDialog(engine) {
			const e = doc.engines[engine];
			let poll = null;
			const $b = $('<div class="aaw-eng-login"></div>');
			if (engine === 'codex') {
				$b.append('<h4>روش ۱ — ورود مثل کاربر واقعی (پیشنهادی)</h4><p class="aaw-muted">برنامه رسمی Codex روی همین سرور یک لینک و کد یک‌بارمصرف می‌سازد. صفحه رسمی OpenAI در پنجره شما باز می‌شود؛ ایمیل و رمز و تأیید دومرحله‌ای را همان‌جا (نه در افزونه) وارد می‌کنید و کد را تأیید می‌کنید. پیش‌نیاز: در chatgpt.com → Settings → Security گزینه «Allow device code login» روشن باشد.</p>');
				const $go = $('<button type="button" class="aaw-btn aaw-btn-primary">' + I.key + ' ورود با اکانت ChatGPT روی همین سرور</button>');
				const $dev = $('<div class="aaw-mt-sm"></div>');
				$b.append($go).append($dev);
				const show = (s) => {
					if (s.status === 'waiting') $dev.html('<div class="aaw-eng-device"><p>۱. روی دکمه بزنید و با اکانت ChatGPT وارد شوید. ۲. این کد را وارد کنید:</p><div class="aaw-eng-code" dir="ltr">' + esc(s.code) + '</div><a class="aaw-btn aaw-btn-primary" target="_blank" rel="noopener" href="' + esc(s.url) + '">' + I.external + ' باز کردن صفحه ورود OpenAI</a><p class="aaw-muted aaw-small">کد ۱۵ دقیقه اعتبار دارد. این پنجره خودش به‌روز می‌شود.</p></div>');
					else if (s.status === 'done') { $dev.html('<div class="aaw-alert is-ok">' + I['check-circle'] + '<div>وارد شدید. حالا «تست اتصال» را بزنید.</div></div>'); clearInterval(poll); load(false); }
					else if (s.status === 'failed') { $dev.html('<div class="aaw-alert is-error">' + I.alert + '<div>' + fmtErr(s.message || 'ورود ناموفق بود.') + '</div></div>'); clearInterval(poll); }
					else $dev.html('<div class="aaw-row">' + I.loader + ' در حال آماده‌سازی ورود روی سرور…</div>');
				};
				$go.on('click', () => withBusy($go, async () => {
					show(await ajax('local_login_start'));
					clearInterval(poll);
					poll = setInterval(async () => { if (Modal.$el.prop('hidden')) { clearInterval(poll); return; } try { show(await ajax('local_login_status')); } catch (_) { /* retry */ } }, 3000);
				}));
				$b.append('<h4 class="aaw-mt">روش ۲ — جای‌گذاری ورود از کامپیوتر خودتان</h4><p class="aaw-muted">روی کامپیوترتان «codex login» را بزنید و با ChatGPT وارد شوید؛ سپس کل محتوای فایل <code dir="ltr">~/.codex/auth.json</code> (ویندوز: <code dir="ltr">%USERPROFILE%\\.codex\\auth.json</code>) را این‌جا بگذارید.</p>');
				const $imp = $('<button type="button" class="aaw-btn aaw-btn-sm aaw-btn-ghost">' + I.download + ' استفاده از همان ورود ChatGPT که GitHub دارد</button>');
				$imp.on('click', () => withBusy($imp, async () => { const r = await ajax('local_login_import'); toast('success', r.message); Modal.close(); load(false); }));
				$b.append($imp);
			} else {
				$b.append('<h4>ورود اکانت Claude Pro/Max</h4><p class="aaw-muted">Anthropic ورود برنامه‌ها را فقط با توکن رسمی اشتراک مجاز می‌داند. روی کامپیوتر خودتان (یک‌بار) دستور زیر را بزنید؛ مرورگر باز می‌شود و مثل همیشه با ایمیل/گوگل و تأیید وارد اکانت Claude می‌شوید؛ توکنی که نمایش داده می‌شود (sk-ant-oat01-…) را این‌جا بگذارید. توکن یک سال اعتبار دارد.</p><code class="aaw-cmd" dir="ltr">npm install -g @anthropic-ai/claude-code &amp;&amp; claude setup-token</code>');
			}
			const $ta = $('<textarea class="aaw-input aaw-mono aaw-mt-sm" dir="ltr" rows="' + (engine === 'codex' ? 6 : 2) + '" spellcheck="false" autocomplete="off" placeholder="' + (engine === 'codex' ? '{&quot;tokens&quot;: {…}, &quot;last_refresh&quot;: …}' : 'sk-ant-oat01-…') + '"></textarea>');
			$b.append($ta);
			Modal.open({
				title: 'ورود ' + e.name + ' روی همین سرور',
				body: $b,
				wide: true,
				buttons: [
					{ text: 'ذخیره ورود', cls: 'aaw-btn-primary', icon: 'check', click: ($btn) => withBusy($btn, async () => {
						if (!$ta.val().trim()) { toast('error', engine === 'codex' ? 'محتوای auth.json را جای‌گذاری کنید.' : 'توکن را جای‌گذاری کنید.'); return; }
						const r = await ajax('local_login_save', { engine, value: $ta.val() });
						$ta.val(''); toast('success', r.message); Modal.close(); load(false);
					}) },
					{ text: 'بستن', click: () => { clearInterval(poll); Modal.close(); } },
				],
			});
		}

		/* ---- actions ---- */
		$app.on('click', '[data-action="eng-refresh"]', (ev) => withBusy(ev.currentTarget, () => load(true)));
		$app.on('click', '[data-action="eng-install"]', (ev) => withBusy(ev.currentTarget, async () => {
			const en = $(ev.currentTarget).data('engine');
			await ajax('local_install', { engine: en });
			toast('info', 'نصب شروع شد؛ چند دقیقه طول می‌کشد. این صفحه خودش به‌روز می‌شود.');
			await load(false);
		}));
		$app.on('click', '[data-action="eng-login"]', (ev) => loginDialog($(ev.currentTarget).data('engine')));
		$app.on('click', '[data-action="eng-signout"]', async (ev) => {
			const en = $(ev.currentTarget).data('engine');
			if (!(await confirmBox('خروج', 'ورود ذخیره‌شده این اکانت از روی سرور حذف شود؟', 'حذف ورود', true))) return;
			try { const r = await ajax('local_signout', { engine: en }); toast('success', r.message); load(false); } catch (e) { toast('error', e.message); }
		});
		$app.on('change', '[data-eng-route]', async function () {
			const en = $(this).data('eng-route');
			try {
				const r = await ajax('local_route', { engine: en, route: this.value });
				toast(r.warning ? 'error' : 'success', r.message + (r.warning ? '\nتوجه: ' + r.warning : ''), r.warning ? 15000 : 5000);
				load(false);
			} catch (e) { toast('error', e.message); load(false); }
		});
		$app.on('click', '[data-action="eng-test"]', (ev) => withBusy(ev.currentTarget, async () => {
			const $btn = $(ev.currentTarget);
			const en = $btn.data('engine');
			const $out = $btn.closest('[data-eng]').find('[data-eng-out]');
			const r = await ajax('local_test', { engine: en });
			const t0 = Date.now();
			for (let i = 0; i < 120; i++) {
				$out.html('<div class="aaw-alert is-info">' + I.loader + '<div>پیام آزمایشی روی سرور ارسال شد… ' + fa(Math.round((Date.now() - t0) / 1000)) + ' ثانیه</div></div>');
				await new Promise((res) => setTimeout(res, 3000));
				let s;
				try { s = await ajax('local_jobs', { id: r.id }); } catch (_) { continue; }
				if (s.job.status === 'done' || s.job.status === 'error') {
					$out.empty();
					toast(s.job.status === 'done' ? 'success' : 'error', s.job.status === 'done' ? 'اتصال مستقیم کار می‌کند. ' + s.job.step : s.job.error, s.job.status === 'done' ? 6000 : 30000);
					return load(false);
				}
			}
			$out.html('<div class="aaw-alert is-warn">' + I.alert + '<div>پاسخ تست هنوز نرسیده است؛ نتیجه در «آخرین کارها» نمایش داده می‌شود.</div></div>');
		}));
		$app.on('click', '[data-action="eng-cancel"]', (ev) => withBusy(ev.currentTarget, async () => { const r = await ajax('local_cancel', { id: $(ev.currentTarget).data('id') }); toast('success', r.message); load(false); }));
		$app.on('click', '[data-action="eng-settings-save"]', (ev) => withBusy(ev.currentTarget, async () => {
			const d = {}; $('[data-eng-settings]').serializeArray().forEach((f) => { d[f.name] = f.value; });
			const r = await ajax('local_settings', d); toast('success', r.message); load(true);
		}));
		load(false);
	})();

	/* =========================================================
	 * Keyboard shortcuts
	 * ======================================================= */
	$(document).on('keydown', (e) => {
		const tag = (e.target.tagName || '').toLowerCase();
		const typing = tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable;
		if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
			const $f = $('form[data-settings]').first();
			if ($f.length) { e.preventDefault(); $f.trigger('submit'); }
		}
		if (e.altKey && e.key.toLowerCase() === 'r') { e.preventDefault(); runNow(0); }
		if (e.altKey && e.key.toLowerCase() === 'n') { const $t = $('[data-topic-form] [name=title]'); if ($t.length) { e.preventDefault(); $t.trigger('focus'); } }
		if (e.key === '/' && !typing) { const $s = $('.aaw-search input').first(); if ($s.length) { e.preventDefault(); $s.trigger('focus'); } }
		if (e.key === 'Escape' && !Modal.$el.prop('hidden')) Modal.close();
	});
})(jQuery);
