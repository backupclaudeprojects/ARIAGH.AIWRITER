<?php
/**
 * ARIAGH.AIWRITER – licensing & store configuration.
 *
 * OWNER EDITION – unlimited, for the product owner only. Do not distribute.
 *
 * This file is written automatically by the "ARIAGH License Server" plugin when it
 * builds the distributable ZIP for your customers (server URL + public signing key).
 * Every value can also be overridden from wp-config.php with the matching constant,
 * e.g. define( 'AAW_LICENSE_API', 'https://your-store.com/wp-json/ariagh/v1' );
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'product'        => 'ariagh-aiwriter',
	'product_name'   => 'ARIAGH.AIWRITER',
	'api'            => '',
	'public_key'     => '',
	'store_url'      => '',
	'buy_url'        => '',
	'account_url'    => '',
	'support_url'    => '',
	'docs_url'       => '',
	'trial_days'     => 7,
	'trial_articles' => 5,
	'edition'        => 'owner',
);
