<?php
putenv( 'HOME=/tmp/aaw-wp/home' );
require __DIR__ . '/stub.php';
require AAW_DIR . 'includes/class-aaw-icons.php';
class AAW_Admin { static function head( $t, $d, $i, $a = '' ) { echo "<h1>$t</h1>$a"; } static function card_open( $t, $s = '', $i = '' ) { echo "<section><h2>$t</h2>"; } static function card_close() { echo '</section>'; }
	static function text( $k, $l, $h = '', $p = '', $t = 'text' ) { echo "<input name='$k' value='" . esc_attr( AAW_Settings::get( $k ) ) . "'>"; } static function number( $k, $l, $h = '', $a = 0, $b = 0 ) { echo "<input name='$k'>"; }
	static function textarea( $k, $l, $h = '', $p = '', $r = 3 ) { echo "<textarea name='$k' placeholder='" . esc_attr( $p ) . "'>" . esc_html( AAW_Settings::get( $k ) ) . '</textarea>'; } static function toggle( $k, $l, $h = '' ) { echo "<input type=checkbox name='$k'>"; }
	static function select( $k, $l, $o, $h = '' ) { echo "<select name='$k'></select>"; } static function save_bar( $t = '' ) {} }
class AAW_Images2 {}
function wp_get_attachment_image() { return '<img>'; } function disabled() {} function checked() {} function selected() {}
echo "engines.php\n"; ob_start(); include AAW_DIR . 'admin/views/engines.php'; $h = ob_get_clean();
echo ( false !== strpos( $h, 'data-engines' ) && false !== strpos( $h, 'data-eng-settings' ) && false !== strpos( $h, '--ephemeral' ) ) ? "  PASS engines view\n" : "  FAIL engines view\n";
echo "local doctor JSON\n"; $d = AAW_Local::doctor(); echo ( json_encode( $d ) ? "  PASS doctor encodes (" . strlen( json_encode( $d ) ) . " bytes)\n" : "  FAIL\n" );
