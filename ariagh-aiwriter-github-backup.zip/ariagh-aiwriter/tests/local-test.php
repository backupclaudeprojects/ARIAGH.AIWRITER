<?php
// v1.9: AI engines directly on this server — real detached processes with fake Codex / Claude CLIs.
putenv( 'HOME=/tmp/aaw-wp/home' );
exec( 'rm -rf /tmp/aaw-wp; mkdir -p /tmp/aaw-wp/home' );
@unlink( '/tmp/fake-cli.log' ); @unlink( '/tmp/fake-flags.json' );
require __DIR__ . '/stub.php';
$f = 0; function ok( $c, $m ) { global $f; echo ( $c ? '  PASS ' : '  FAIL ' ) . $m . "\n"; if ( ! $c ) { $f++; } }
function calls( $bin = null ) { $o = array(); foreach ( file_exists( '/tmp/fake-cli.log' ) ? file( '/tmp/fake-cli.log' ) : array() as $l ) { $j = json_decode( $l, true ); if ( ! $bin || $j['bin'] === $bin ) { $o[] = $j; } } return $o; }
function lastcall( $bin ) { $c = calls( $bin ); return end( $c ); }
function job( $id ) { foreach ( AAW_Local::jobs_summary() as $j ) { if ( $j['id'] === $id ) { return $j; } } return null; }
function wait_job( $id, $max = 60 ) { for ( $i = 0; $i < $max * 4; $i++ ) { AAW_Local::tick( 5 ); $j = job( $id ); if ( $j && in_array( $j['status'], array( 'done', 'error' ), true ) ) { return $j; } usleep( 250000 ); } return job( $id ); }
$BIN = __DIR__ . '/bin';
AAW_Settings::update( array( 'local_bin_codex' => $BIN . '/codex', 'local_bin_claude' => $BIN . '/claude', 'provider' => 'sub_codex' ) );

echo "Server checks\n";
ok( AAW_Proc::can_exec(), 'proc_open available' );
$d = AAW_Local::doctor( true );
ok( false === strpos( AAW_Proc::base_dir(), ABSPATH ) && '0700' === substr( sprintf( '%o', fileperms( AAW_Proc::base_dir() ) ), -4 ), 'private folder outside the web root, mode 0700' );
ok( 'codex-cli 0.98.0' === $d['engines']['codex']['version'] && '2.1.30 (Claude Code)' === $d['engines']['claude']['version'], 'installed CLIs detected with their versions' );
ok( 'auth_required' === $d['engines']['codex']['status'] && 'github' === $d['engines']['codex']['route'], 'not signed in yet → "sign in"; route stays GitHub by default' );
ok( $d['nodes'] && $d['nodes'][0]['major'] >= 18 && '' !== AAW_Local::node( 18 ), 'Node.js found (' . $d['nodes'][0]['version'] . ')' );

echo "Logins (official ways only)\n";
ok( is_wp_error( AAW_Local::save_login( 'codex', '{"x":1}' ) ), 'invalid auth.json refused' );
ok( is_wp_error( AAW_Local::save_login( 'codex', '{"OPENAI_API_KEY":"sk-x"}' ) ), 'API-key auth.json refused (must be the ChatGPT account)' );
ok( is_wp_error( AAW_Local::save_login( 'claude', 'sk-ant-api03-abcdefghijklmnopqrstuvwxyz' ) ), 'Claude API key refused (subscription token needed)' );
ok( ! is_wp_error( AAW_Local::save_login( 'claude', 'sk-ant-oat01-' . str_repeat( 'a', 40 ) ) ) && AAW_Local::has_login( 'claude' ), 'Claude setup-token saved' );
ok( false === strpos( wp_json_encode( $GLOBALS['__o'] ), 'sk-ant-oat01-aaaa' ), 'token stored encrypted (not readable in options)' );

file_put_contents( '/tmp/fake-flags.json', '{"login_fail":true,"login_wait":1}' );
AAW_Local::login_start();
for ( $i = 0; $i < 40; $i++ ) { $s = AAW_Local::login_status(); if ( 'failed' === $s['status'] ) { break; } usleep( 250000 ); }
ok( 'failed' === $s['status'] && false !== strpos( $s['message'], 'Allow device code login' ), 'device login not allowed → exact setting to turn on' );
file_put_contents( '/tmp/fake-flags.json', '{"login_wait":3}' );
$s = AAW_Local::login_start();
$seen = null;
for ( $i = 0; $i < 60; $i++ ) { $s = AAW_Local::login_status(); if ( 'waiting' === $s['status'] ) { $seen = $s; } if ( 'done' === $s['status'] ) { break; } usleep( 250000 ); }
ok( $seen && 'https://auth.openai.com/codex/device' === $seen['url'] && 'K7QX-9F2MZ' === $seen['code'], 'sign-in like a real user: official OpenAI link + one-time code shown (approved in the user\'s own window)' );
ok( 'done' === $s['status'] && AAW_Local::has_login( 'codex' ) && file_exists( AAW_Local::codex_home() . '/auth.json' ) && '0600' === substr( sprintf( '%o', fileperms( AAW_Local::codex_home() . '/auth.json' ) ), -4 ), 'login saved on the server (auth.json 0600 + encrypted copy)' );

echo "Route: direct from this server\n";
AAW_Settings::update( array( 'local_route_codex' => 'local', 'local_route_claude' => 'local' ) );
ok( AAW_Local::is_local( 'sub_codex' ) && true === AAW_Local::ready( 'codex' ), 'ChatGPT set to direct and ready' );
AAW_Settings::set_key_meta( 'sub_codex', 'x' ); // GitHub also has this login → refreshed tokens must reach it.
$id = AAW_Local::start( 'test', 'codex', array( 'status' => 'test' ) );
$j  = wait_job( $id );
$c  = lastcall( 'codex' );
ok( 'done' === $j['status'] && false !== strpos( $j['step'], 'OK' ), 'test message answered on this server: ' . $j['step'] );
ok( in_array( '--ephemeral', $c['argv'], true ) && in_array( 'read-only', $c['argv'], true ) && ! $c['has_openai_key'] && $c['codex_home'] === AAW_Local::codex_home(), 'Codex ran with --ephemeral (not in chat history), read-only sandbox, own CODEX_HOME, no API key' );
$st = AAW_Local::state( 'codex' );
ok( 'ok' === $st['state'] && $st['test']['ok'] && 'ready' === AAW_Local::doctor()['engines']['codex']['status'], 'engine shows "ready" after the test' );
$saved = json_decode( AAW_Settings::secure_get( 'local_codex_auth' ), true );
ok( 0 === strpos( $saved['tokens']['refresh_token'], 'rt_1' ) && false !== strpos( AAW_Cloudflare::$kv, $saved['tokens']['refresh_token'] ), 'rotated refresh token kept on the server AND copied for the GitHub runner' );

echo "Articles (same prompts, rules, site data)\n";
$GLOBALS['__img_engine'] = 'workers_ai';
$jobs = array(
	array( 'topic' => array( 'id' => 31, 'title' => 'طرز تهیه کیمچی', 'keywords' => 'کیمچی' ), 'prompts' => array( 'system' => "قوانین سایت: لحن صمیمی. دانش سئو: E-E-A-T.\n## لینک‌سازی داخلی\n- x", 'user' => 'مقاله «طرز تهیه کیمچی» را بنویس.', 'outline' => 'OUTLINE طرح کلی' ) ),
	array( 'topic' => array( 'id' => 32, 'title' => 'BADJSON ترشی', 'keywords' => 'ترشی' ), 'prompts' => array( 'system' => 'قوانین سایت', 'user' => 'BADJSON بنویس', 'outline' => 'OUTLINE' ) ),
);
$calls_rest = 0;
AAW_REST::$job = function ( $b ) use ( $jobs, &$calls_rest ) { $calls_rest++; if ( 1 === $calls_rest ) { return array( 'status' => 'need_topics', 'ideas' => array( 'prompt' => 'IDEAS بده' ), 'runtime' => array() ); } return array( 'status' => 'ok', 'jobs' => $jobs, 'runtime' => array( 'params' => array( 'two_pass' => true ), 'image' => array( 'enabled' => true ) ) ); };
AAW_Settings::update( array( 'featured_image' => true ) );
$r = AAW_Local::start_generate( 'manual', 0, 'codex' );
ok( 'dispatched' === $r['status'] && ! empty( $r['local'] ), 'article job started directly' );
$j = wait_job( $r['id'], 90 );
ok( 'done' === $j['status'] && 2 === count( AAW_REST::$drafts ), 'two drafts created: ' . $j['step'] );
ok( array( 'ایده جدید ۱', 'ایده جدید ۲' ) === array_column( array_map( function ( $t ) { return is_array( $t ) ? $t : array( 'title' => $t ); }, AAW_REST::$topics[0] ), 'title' ), 'empty queue → ideas asked and added first' );
$inputs = array_column( calls( 'codex' ), 'input' );
$write  = '';
foreach ( $inputs as $in ) { if ( false !== strpos( $in, 'مقاله «طرز تهیه کیمچی» را بنویس' ) ) { $write = $in; } }
ok( false !== strpos( $write, 'قوانین سایت: لحن صمیمی' ) && false !== strpos( $write, 'دانش سئو' ) && false !== strpos( $write, 'طرح کلی (Outline) مصوب' ), 'the message carries the site rules, SEO knowledge and the approved outline' );
ok( false !== strpos( $write, '## داده‌های واقعی سایت' ) && false !== strpos( $write, 'طرز تهیه کیمچی خانگی => https://example.com/?p=11' ) && false !== strpos( $write, 'هشدار تکرار' ) && false !== strpos( $write, 'دسته‌بندی‌های مرتبط' ), 'real site data added (duplicate warning, links, categories) like the GitHub runner' );
ok( 'مقاله تست' === AAW_REST::$drafts[0]['article']['title'] && 'local' === AAW_REST::$drafts[0]['meta']['runner'] && ! empty( AAW_REST::$drafts[0]['meta']['outline'] ), 'loose JSON from the model repaired; meta says runner=local' );
ok( 'تبدیل‌شده' === AAW_REST::$drafts[1]['article']['title'], 'non-JSON answer converted with a second message' );
ok( 2 === count( AAW_Revise::$req ), 'article image requested for each draft (API image engine)' );
ok( ! AAW_GitHub::$dispatched, 'nothing was sent to GitHub' );

echo "Revise with Claude (direct)\n";
mkpost( 77, 'مقاله قدیمی', '<p>متن قدیمی</p>' );
$id = AAW_Local::start( 'revise', 'claude', array( 'post_id' => 77, 'system' => 'قوانین اصلاح', 'prompt' => 'REVISE پاراگراف دوم کوتاه شود', 'request_id' => 'rq1' ), array( 'post_id' => 77 ) );
$j  = wait_job( $id );
$c  = lastcall( 'claude' );
ok( 'done' === $j['status'] && 'rq1' === AAW_Revise::$rev[0][2] && 'اصلاح‌شده' === AAW_Revise::$rev[0][1]['title'], 'revision applied through the normal path' );
ok( 0 === strpos( $c['token'], 'sk-ant-oat01-' ) && in_array( '--no-session-persistence', $c['argv'], true ) && 'قوانین اصلاح' === $c['system'] && ! $c['has_api_key'] && false !== strpos( $c['home'], 'claude-home' ), 'Claude ran with the subscription token, no session saved, system prompt file, private HOME' );

echo "Image with ChatGPT: product photos + previous-article samples + editable message\n";
@mkdir( '/tmp/aaw-wp/img' );
file_put_contents( '/tmp/aaw-wp/img/prod.jpg', str_repeat( 'J', 500 ) ); file_put_contents( '/tmp/aaw-wp/img/style.jpg', str_repeat( 'S', 500 ) );
$GLOBALS['__files'] = array( 901 => '/tmp/aaw-wp/img/prod.jpg', 902 => '/tmp/aaw-wp/img/style.jpg' );
mkpost( 88, 'کیمچی را چطور سرو کنیم', '<p>کیمچی را با برنج سرو کنید. ' . str_repeat( 'متن ', 50 ) . '</p>' );
update_post_meta( 88, '_aaw_focus_keyword', 'سرو کیمچی' );
AAW_Settings::update( array( 'image_chat_prompt' => "سلام، برای مقاله «{title}» ({keyword}) مثل نمونه‌ها با محصولات {products} بساز.\nتوضیح: {description}\nمتن: {article}", 'image_max_refs' => 6 ) );
$payload = array( 'post_id' => 88, 'prompt' => 'jar of kimchi on rice', 'refs' => array( 'products' => array( array( 'id' => 901 ) ), 'styles' => array( array( 'id' => 902 ), array( 'b64' => base64_encode( str_repeat( 'B', 300 ) ) ) ), 'product_names' => array( 'کیمچی ۵۰۰ گرمی' ) ), 'inline' => array( array( 'prompt' => 'kimchi close-up', 'alt' => 'نما', 'after_h2' => 0 ) ), 'replace_inline' => true );
$id = AAW_Local::start( 'image', 'codex', $payload, array( 'post_id' => 88 ) );
$j  = wait_job( $id );
$ic = array_values( array_filter( calls( 'codex' ), function ( $c ) { return ! empty( $c['images'] ); } ) );
ok( 'done' === $j['status'] && 1 === count( AAW_Revise::$img ) && 'image/png' === AAW_Revise::$img[0][1]['mime'] && 1 === count( AAW_Revise::$img[0][2] ) && AAW_Revise::$img[0][3], 'featured + inline image made on the server and applied' );
ok( 2 === count( $ic ) && 3 === count( $ic[0]['images'] ) && ! in_array( false, $ic[0]['refs_exist'], true ) && in_array( 'workspace-write', $ic[0]['argv'], true ), 'reference photos attached to the message (product first, then samples)' );
ok( false !== strpos( $ic[0]['input'], 'سلام، برای مقاله «کیمچی را چطور سرو کنیم» (سرو کیمچی) مثل نمونه‌ها با محصولات کیمچی ۵۰۰ گرمی بساز' ) && false !== strpos( $ic[0]['input'], 'کیمچی را با برنج سرو کنید' ) && false !== strpos( $ic[0]['input'], 'jar of kimchi on rice' ), 'the editable message is filled with title, keyword, products, description and article text' );
ok( ! is_dir( AAW_Proc::private_dir( 'runs' ) . '/refs-' . $id ), 'temporary reference files removed' );

echo "Smart analysis (direct) + never stuck\n";
AAW_Settings::update( array( 'provider' => 'sub_claude' ) );
$id = AAW_Local::start( 'analyze', 'claude', array( 'system' => 'تحلیلگر', 'prompt' => 'ANALYZE سایت', 'competitors' => array( 'https://digikala.com' ), 'gsc' => 'sc-domain:example.com', 'stats' => array( 'posts' => 3 ) ), array( 'kind' => 'analyze' ) );
AAW_Analyzer::track( $id, 'local' );
$j = wait_job( $id );
$c = lastcall( 'claude' );
$rec = AAW_Analyzer::get();
ok( 'done' === $j['status'] && 'موضوع تحلیل' === $rec['result']['topics'][0]['title'] && 'local' === $rec['meta']['runner'] && '' === AAW_Analyzer::pending_id(), 'analysis saved and the "in progress" state cleared' );
ok( false !== strpos( $c['input'], 'سرچ کنسول' ) && false !== strpos( $c['input'], 'digikala' ) && in_array( 'WebSearch,WebFetch', $c['argv'], true ), 'Search Console data + competitors included; Claude may search the web' );

$id = AAW_Local::start( 'analyze', 'claude', array( 'system' => 's', 'prompt' => 'FAILQUOTA' ), array( 'kind' => 'analyze' ) );
AAW_Analyzer::track( $id, 'local' );
wait_job( $id );
AAW_Analyzer::check_stale();
ok( '' === AAW_Analyzer::pending_id() && false !== mb_strpos( get_option( 'aaw_analysis_error' ), 'سهمیه' ), 'failed analysis ends with a clear message (quota), not "in progress"' );

AAW_Analyzer::track( 'gh1', 'github' ); $GLOBALS['__o'][ AAW_Analyzer::JOB ]['t'] = time() - 600;
$GLOBALS['__runs'] = array( array( 'title' => 'ARIAGH crawl claude gh1', 'status' => 'completed', 'conclusion' => 'failure', 'url' => 'https://github.com/a/b/actions/runs/9' ) );
AAW_Analyzer::check_stale();
ok( '' === AAW_Analyzer::pending_id() && false !== strpos( get_option( 'aaw_analysis_error' ), 'actions/runs/9' ), 'GitHub run failed → analysis ends with the run link' );
update_option( 'aaw_analysis_pending', 'old123' ); delete_option( AAW_Analyzer::JOB ); $GLOBALS['__runs'] = array();
AAW_Analyzer::check_stale();
ok( '' === AAW_Analyzer::pending_id() && false !== mb_strpos( get_option( 'aaw_analysis_error' ), 'هیچ‌وقت نتیجه' ), 'old stuck analysis from a previous version is resolved automatically' );
AAW_Analyzer::track( 'gh2', 'github' ); $GLOBALS['__o'][ AAW_Analyzer::JOB ]['t'] = time() - 20 * 60; $GLOBALS['__runs'] = array();
AAW_Analyzer::check_stale();
ok( '' === AAW_Analyzer::pending_id(), 'no GitHub run after 15 minutes → stopped with explanation' );
AAW_Analyzer::track( 'gh3', 'github' ); $GLOBALS['__o'][ AAW_Analyzer::JOB ]['t'] = time() - 6 * 60; $GLOBALS['__runs'] = array( array( 'title' => 'ARIAGH crawl claude gh3', 'status' => 'in_progress', 'conclusion' => null, 'url' => 'u' ) );
AAW_Analyzer::check_stale();
ok( 'gh3' === AAW_Analyzer::pending_id(), 'still running on GitHub → keeps waiting' );
AAW_Analyzer::cancel();
ok( '' === AAW_Analyzer::pending_id(), '«لغو» clears a running analysis' );
AAW_Analyzer::track( 'b1', 'async' ); $GLOBALS['__o'][ AAW_Analyzer::JOB ]['t'] = time() - 26 * 60;
AAW_Analyzer::check_stale();
ok( '' === AAW_Analyzer::pending_id(), 'Cloudflare analysis older than 25 minutes → stopped' );

echo "Errors are explained, never silent\n";
$id = AAW_Local::start( 'revise', 'codex', array( 'post_id' => 77, 'system' => 's', 'prompt' => 'FAILAUTH' ) );
$j  = wait_job( $id );
ok( 'error' === $j['status'] && false !== mb_strpos( $j['error'], 'ورود' ) && 'auth' === AAW_Local::state( 'codex' )['state'] && 'auth_required' === AAW_Local::doctor()['engines']['codex']['status'], 'expired ChatGPT login → "sign in again"' );
$id = AAW_Local::start( 'revise', 'codex', array( 'post_id' => 77, 'system' => 's', 'prompt' => 'FAILNET' ) );
$j  = wait_job( $id );
ok( 'error' === $j['status'] && false !== mb_strpos( $j['error'], 'اینترنت بین‌المللی هاست' ), 'blocked network (Iranian host) → explains and suggests GitHub' );
$id = AAW_Local::start( 'revise', 'claude', array( 'post_id' => 77, 'system' => 's', 'prompt' => 'CRASH' ) );
$j  = wait_job( $id );
ok( 'error' === $j['status'] && false !== mb_strpos( $j['error'], 'حافظه' ), 'process killed by the host → memory explanation' );
$jobs2 = array( array( 'topic' => array( 'id' => 41, 'title' => 'FAILAUTH a', 'keywords' => '' ), 'prompts' => array( 'system' => 's', 'user' => 'FAILAUTH' ) ), array( 'topic' => array( 'id' => 42, 'title' => 'b', 'keywords' => '' ), 'prompts' => array( 'system' => 's', 'user' => 'b' ) ) );
AAW_REST::$job = function ( $b ) use ( $jobs2 ) { return array( 'status' => 'ok', 'jobs' => $jobs2, 'runtime' => array() ); };
AAW_Topics::$upd = array();
$r = AAW_Local::start_generate( 'manual', 0, 'codex' );
$j = wait_job( $r['id'] );
ok( 'error' === $j['status'] && 41 === (int) end( AAW_REST::$fails )['topic_id'] && in_array( array( 42, array( 'status' => 'pending', 'locked_at' => null ) ), AAW_Topics::$upd, true ), 'engine cannot work → topic failed, the rest go back to the queue' );

echo "Memory: native Codex, raised limits, clear explanation\n";
AAW_Settings::update( array( 'local_route_codex' => 'local' ) );
AAW_Local::save_login( 'codex', json_encode( array( 'tokens' => array( 'refresh_token' => 'r', 'account_id' => 'a' ), 'last_refresh' => gmdate( 'c' ) ) ) );
$id = AAW_Local::start( 'revise', 'codex', array( 'post_id' => 77, 'system' => 's', 'prompt' => 'MEMFAIL' ) );
$j  = wait_job( $id );
$c  = lastcall( 'codex' );
ok( 'error' === $j['status'] && false !== mb_strpos( $j['error'], 'VMEM' ) && false !== mb_strpos( $j['error'], 'سقف حافظه مجازی برنامه روی هاست' ), 'Rust "memory allocation failed" + core dump → exact host settings to ask for, with the real limits' );
ok( '2' === $c['env_arena'] && '2' === $c['env_tokio'], 'Codex started with small memory footprint (MALLOC_ARENA_MAX, TOKIO_WORKER_THREADS)' );
$pre = AAW_Local::prefix() . '/node_modules';
@mkdir( $pre . '/@openai/codex/bin', 0777, true ); @mkdir( $pre . '/@openai/codex-linux-x64/vendor/x86_64-unknown-linux-musl/codex', 0777, true ); @mkdir( $pre . '/.bin', 0777, true );
file_put_contents( $pre . '/@openai/codex/bin/codex.js', "#!/usr/bin/env node\n" ); chmod( $pre . '/@openai/codex/bin/codex.js', 0755 );
copy( $BIN . '/codex', $pre . '/@openai/codex-linux-x64/vendor/x86_64-unknown-linux-musl/codex/codex' );
@symlink( $pre . '/@openai/codex/bin/codex.js', $pre . '/.bin/codex' );
AAW_Settings::update( array( 'local_bin_codex' => '' ) );
ok( false !== strpos( AAW_Local::binary( 'codex' ), 'vendor/x86_64-unknown-linux-musl/codex/codex' ), 'npm launcher skipped: the native Codex program is run directly (no Node.js process)' );
AAW_Settings::update( array( 'local_bin_codex' => $BIN . '/codex' ) );

echo "Cancel / lost process / not installed\n";
AAW_Local::save_login( 'claude', 'sk-ant-oat01-' . str_repeat( 'b', 40 ) );
$id = AAW_Local::start( 'revise', 'claude', array( 'post_id' => 77, 'system' => 's', 'prompt' => 'SLOW REVISE' ) );
usleep( 800000 ); AAW_Local::tick( 2 );
ok( 'running' === job( $id )['status'], 'long request keeps running after the PHP request (detached)' );
AAW_Local::cancel( $id );
ok( 'error' === job( $id )['status'], 'cancel stops it' );
$idx = get_option( AAW_Local::JOBS );
$lost = 'llost1';
$dir  = AAW_Proc::private_dir( 'runs' ) . '/run-lost';
wp_mkdir_p( $dir ); file_put_contents( $dir . '/started', time() - 300 );
$jl = array( 'id' => $lost, 'trigger' => 'revise', 'engine' => 'claude', 'model' => '', 'label' => 'x', 'payload' => array(), 'post_id' => 0, 'kind' => 'revise', 'status' => 'running', 'step' => 's', 'ctx' => array( 'await' => 'write' ), 'run' => $dir, 'error' => '', 'created' => time(), 'updated' => time(), 'op' => '' );
file_put_contents( AAW_Proc::private_dir( 'jobs' ) . '/' . $lost . '.json', json_encode( $jl ) );
$idx[ $lost ] = array( 'id' => $lost, 'trigger' => 'revise', 'engine' => 'claude', 'label' => 'x', 'status' => 'running', 'step' => 's', 'created' => time(), 'updated' => time(), 'error' => '' );
update_option( AAW_Local::JOBS, $idx );
AAW_Local::tick( 3 );
ok( 'error' === job( $lost )['status'] && false !== mb_strpos( job( $lost )['error'], 'متوقف' ), 'process killed without exit code → job ends with explanation' );
AAW_Settings::update( array( 'local_bin_claude' => '/nonexistent/claude' ) );
putenv( 'PATH=/usr/bin:/bin' );
$e = AAW_Local::start( 'revise', 'claude', array() );
ok( is_wp_error( $e ) && false !== mb_strpos( $e->get_error_message(), 'نصب نیست' ) && ! AAW_GitHub::$dispatched, 'direct but not installed → clear error, nothing silently sent to GitHub' );

echo "Install with one click (npm, detached)\n";
@mkdir( '/tmp/aaw-wp/node/bin', 0777, true );
@symlink( trim( shell_exec( 'command -v node || echo /opt/node22/bin/node' ) ), '/tmp/aaw-wp/node/bin/node' );
file_put_contents( '/tmp/aaw-wp/node/bin/npm', "// fake npm\nconst fs=require('fs'),p=require('path');const a=process.argv.slice(2);const pre=a[a.indexOf('--prefix')+1];fs.mkdirSync(p.join(pre,'node_modules/.bin'),{recursive:true});fs.copyFileSync('" . $BIN . "/claude',p.join(pre,'node_modules/.bin/claude'));fs.chmodSync(p.join(pre,'node_modules/.bin/claude'),0o755);fs.writeFileSync('/tmp/aaw-wp/npm-args.json',JSON.stringify(a));setTimeout(()=>console.log('added 3 packages'),500);\n" );
AAW_Settings::update( array( 'local_node_path' => '/tmp/aaw-wp/node/bin/node', 'local_bin_claude' => '' ) );
delete_transient( 'aaw_local_nodes' );
$s = AAW_Local::install( 'claude' );
for ( $i = 0; $i < 40 && 'running' === $s['status']; $i++ ) { usleep( 250000 ); $s = AAW_Local::install_status( 'claude' ); }
$args = json_decode( (string) @file_get_contents( '/tmp/aaw-wp/npm-args.json' ), true );
ok( 'done' === $s['status'] && false !== strpos( AAW_Local::binary( 'claude' ), '/cli/node_modules/.bin/claude' ) && in_array( '@anthropic-ai/claude-code@latest', (array) $args, true ), 'npm install into the private prefix, CLI found afterwards (' . ( $s['version'] ?? ( $s['message'] ?? '' ) ) . ')' );

echo "JSON repair\n";
ok( 'a' === AAW_Local::parse_json( "خروجی:\n```json\n{\"t\":\"a\",}\n```" )['t'] && "x\ny" === AAW_Local::parse_json( "{\"t\":\"x\ny\"}" )['t'], 'fenced, trailing comma and raw newline handled' );

echo $f ? "\n$f FAILED\n" : "\nALL LOCAL ENGINE TESTS PASSED\n";
exit( $f ? 1 : 0 );
