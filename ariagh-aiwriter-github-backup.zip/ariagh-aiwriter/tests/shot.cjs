const { chromium } = require('/opt/npm-tools/node_modules/playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1320, height: 900 } });
  const errs = []; p.on('pageerror', (e) => errs.push(e.message)); p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
  await p.goto('file:///tmp/claude-0/eng.html'); await p.waitForTimeout(800);
  await p.screenshot({ path: '/tmp/claude-0/eng1.png', fullPage: true });
  await p.click('[data-action="eng-login"][data-engine="codex"]'); await p.waitForTimeout(300);
  await p.click('.aaw-eng-login .aaw-btn-primary'); await p.waitForTimeout(500);
  await p.screenshot({ path: '/tmp/claude-0/eng2.png' });
  console.log('errors:', JSON.stringify(errs));
  await b.close();
})();
