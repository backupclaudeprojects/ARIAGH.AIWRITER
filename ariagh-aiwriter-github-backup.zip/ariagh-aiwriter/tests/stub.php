<?php
// Minimal WordPress stubs + fakes for the classes around AAW_Local (direct engines on this server).
define( 'ABSPATH', '/tmp/aaw-wp/public_html/' );
define( 'AUTH_KEY', 'k' ); define( 'SECURE_AUTH_SALT', 's' ); define( 'LOGGED_IN_KEY', 'l' ); define( 'NONCE_KEY', 'n' );
define( 'HOUR_IN_SECONDS', 3600 ); define( 'MINUTE_IN_SECONDS', 60 ); define( 'DAY_IN_SECONDS', 86400 ); define( 'ARRAY_A', 'ARRAY_A' );
define( 'AAW_VERSION', '1.9.0' ); define( 'AAW_DIR', is_dir( dirname( __DIR__ ) . '/plugin/aria-ai-writer' ) ? dirname( __DIR__ ) . '/plugin/aria-ai-writer/' : dirname( __DIR__ ) . '/aria-ai-writer/' ); define( 'AAW_CAP', 'aaw_manage' );
@mkdir( ABSPATH, 0777, true );
$GLOBALS['__o'] = array(); $GLOBALS['__t'] = array(); $GLOBALS['__meta'] = array(); $GLOBALS['__posts'] = array(); $GLOBALS['__cron'] = array();
class WP_Error { public $c, $m, $d; function __construct( $c = '', $m = '', $d = null ) { $this->c = $c; $this->m = $m; $this->d = $d; } function get_error_message() { return $this->m; } function get_error_code() { return $this->c; } function get_error_data() { return $this->d; } }
function is_wp_error( $x ) { return $x instanceof WP_Error; }
function get_option( $k, $d = false ) { return array_key_exists( $k, $GLOBALS['__o'] ) ? $GLOBALS['__o'][ $k ] : $d; }
function update_option( $k, $v, $a = null ) { $GLOBALS['__o'][ $k ] = $v; return true; }
function add_option( $k, $v, $x = '', $a = null ) { $GLOBALS['__o'][ $k ] = $v; return true; }
function delete_option( $k ) { unset( $GLOBALS['__o'][ $k ] ); return true; }
function get_transient( $k ) { return $GLOBALS['__t'][ $k ] ?? false; }
function set_transient( $k, $v, $e = 0 ) { $GLOBALS['__t'][ $k ] = $v; return true; }
function delete_transient( $k ) { unset( $GLOBALS['__t'][ $k ] ); return true; }
function wp_parse_args( $a, $d ) { return array_merge( $d, (array) $a ); }
function sanitize_text_field( $s ) { return trim( preg_replace( '/[\r\n\t ]+/', ' ', strip_tags( (string) $s ) ) ); }
function sanitize_textarea_field( $s ) { return trim( strip_tags( (string) $s ) ); }
function sanitize_key( $s ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $s ) ); }
function sanitize_title( $s ) { return strtolower( preg_replace( '/\W+/u', '-', (string) $s ) ); }
function sanitize_email( $e ) { return filter_var( $e, FILTER_SANITIZE_EMAIL ); }
function sanitize_hex_color( $c ) { return $c; }
function esc_url_raw( $u ) { return filter_var( $u, FILTER_VALIDATE_URL ) ? $u : ''; }
function esc_html( $s ) { return htmlspecialchars( (string) $s ); } function esc_attr( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES ); }
function wp_unslash( $s ) { return $s; }
function untrailingslashit( $s ) { return rtrim( $s, '/\\' ); } function trailingslashit( $s ) { return untrailingslashit( $s ) . '/'; }
function wp_json_encode( $d, $f = 0 ) { return json_encode( $d, $f | JSON_UNESCAPED_UNICODE ); }
function wp_strip_all_tags( $s ) { return trim( strip_tags( (string) $s ) ); }
function wp_kses_post( $s ) { return $s; }
function home_url( $p = '' ) { return 'https://example.com' . $p; }
function admin_url( $p = '' ) { return 'https://example.com/wp-admin/' . $p; }
function wp_parse_url( $u, $c = -1 ) { return parse_url( $u, $c ); }
function wp_date( $f, $t = null ) { return gmdate( $f, $t ?? time() ); }
function current_time( $t, $g = 0 ) { return gmdate( 'Y-m-d H:i:s' ); }
function wp_generate_password( $n = 12, $s = true, $e = false ) { return substr( bin2hex( random_bytes( $n ) ), 0, $n ); }
function wp_salt( $s = '' ) { return 'salt-' . $s; }
function do_action() {} function add_action() {} function add_filter() {} function apply_filters( $t, $v ) { return $v; }
function get_current_user_id() { return 1; }
function current_user_can() { return true; }
function absint( $v ) { return abs( (int) $v ); }
function wp_mkdir_p( $d ) { return is_dir( $d ) || @mkdir( $d, 0777, true ); }
function wp_upload_dir( $t = null, $c = true ) { @mkdir( '/tmp/aaw-wp/public_html/wp-content/uploads', 0777, true ); return array( 'basedir' => '/tmp/aaw-wp/public_html/wp-content/uploads', 'baseurl' => 'https://example.com/wp-content/uploads' ); }
function wp_list_pluck( $l, $f ) { return array_map( function ( $x ) use ( $f ) { return is_array( $x ) ? $x[ $f ] : $x->$f; }, (array) $l ); }
function wp_next_scheduled( $h ) { return $GLOBALS['__cron'][ $h ] ?? false; }
function wp_schedule_single_event( $t, $h, $a = array() ) { $GLOBALS['__cron'][ $h ] = $t; return true; }
function wp_schedule_event() { return true; } function wp_clear_scheduled_hook() {}
function wp_remote_get( $u, $a = array() ) { return $GLOBALS['__http'] ? ( $GLOBALS['__http'] )( $u, $a ) : new WP_Error( 'http', 'offline' ); }
function wp_remote_retrieve_response_code( $r ) { return $r['code']; } function wp_remote_retrieve_body( $r ) { return $r['body']; }
$GLOBALS['__http'] = null;
class Fake_Post { public $ID, $post_title, $post_content = '', $post_excerpt = '', $post_status = 'publish', $post_type = 'post', $post_parent = 0; }
function mkpost( $id, $title, $content = '', $type = 'post', $parent = 0 ) { $p = new Fake_Post(); $p->ID = $id; $p->post_title = $title; $p->post_content = $content; $p->post_type = $type; $p->post_parent = $parent; $GLOBALS['__posts'][ $id ] = $p; return $p; }
function get_post( $id ) { return $GLOBALS['__posts'][ (int) $id ] ?? null; }
function get_the_title( $id ) { return isset( $GLOBALS['__posts'][ (int) $id ] ) ? $GLOBALS['__posts'][ (int) $id ]->post_title : ''; }
function get_post_field( $f, $id ) { return $GLOBALS['__posts'][ (int) $id ]->$f ?? ''; }
function get_post_type( $id ) { return $GLOBALS['__posts'][ (int) $id ]->post_type ?? false; }
function wp_get_post_parent_id( $id ) { return $GLOBALS['__posts'][ (int) $id ]->post_parent ?? 0; }
function get_post_meta( $id, $k = '', $s = false ) { return $GLOBALS['__meta'][ $id ][ $k ] ?? ''; }
function update_post_meta( $id, $k, $v ) { $GLOBALS['__meta'][ $id ][ $k ] = $v; return true; }
function has_post_thumbnail( $id ) { return ! empty( $GLOBALS['__meta'][ $id ]['_thumbnail_id'] ); }
function get_permalink( $id ) { return 'https://example.com/?p=' . ( is_object( $id ) ? $id->ID : $id ); }
function get_attached_file( $id ) { return $GLOBALS['__files'][ $id ] ?? ''; }
function get_categories( $a = array() ) { $c = new stdClass(); $c->name = 'کیمچی و ترشی'; $c->term_id = 7; return array( $c ); }
function get_category_link( $id ) { return 'https://example.com/category/' . $id; }
function get_bloginfo( $k = '' ) { return 'سایت'; }
function number_format_i18n( $n ) { return (string) $n; }
function human_time_diff( $t ) { return '۱ دقیقه'; }

require AAW_DIR . 'includes/class-aaw-crypto.php';
require AAW_DIR . 'includes/class-aaw-settings.php';
require AAW_DIR . 'includes/class-aaw-errors.php';
require AAW_DIR . 'includes/class-aaw-activity.php';
require AAW_DIR . 'includes/class-aaw-proc.php';
require AAW_DIR . 'includes/class-aaw-local.php';
require AAW_DIR . 'includes/class-aaw-analyzer.php';
require AAW_DIR . 'includes/class-aaw-pull.php';

/* ---------------- fakes of the surrounding plugin ---------------- */
class AAW_Prompt { public static function default_prompt() { return 'p'; } public static function is_legacy_default() { return false; } }
class AAW_Logs { public static $rows = array(); public static function add( $l, $e, $m, $c = array() ) { self::$rows[] = array( $l, $e, $m ); } public static function last() { return null; } }
class AAW_BG { public static function new_id( $p = 'b' ) { return $p . time() . substr( bin2hex( random_bytes( 3 ) ), 0, 6 ); } public static function available() { return true; } }
class AAW_Providers {
	public static function get( $id ) { $m = array( 'sub_claude' => array( 'name' => 'Claude', 'format' => 'github_runner', 'engine' => 'claude' ), 'sub_codex' => array( 'name' => 'ChatGPT', 'format' => 'github_runner', 'engine' => 'codex' ) ); return $m[ $id ] ?? null; }
	public static function model_for( $id ) { return ''; }
}
class AAW_Cloudflare { public static $calls = array(); public static $kv = ''; public static function is_deployed() { return true; }
	public static function call_worker( $route, $p, $t = 30 ) { self::$calls[] = array( $route, $p ); if ( 'codex_auth' === $route ) { if ( 'put' === ( $p['action'] ?? '' ) ) { self::$kv = $p['data']; return array( 'ok' => true ); } return array( 'ok' => true, 'data' => self::$kv ); } if ( 'gsc' === $route ) { return array( 'ok' => true, 'text' => "\n# سرچ کنسول: «کیمچی» ۹۰۰ نمایش" ); } if ( 'competitors' === $route ) { return array( 'ok' => true, 'fetched' => 1, 'text' => "\n- رقیب: digikala" ); } return array( 'ok' => true ); } }
class AAW_GitHub { public static $dispatched = array(); public static function is_connected() { return true; } public static function repo_url() { return 'https://github.com/a/b'; } public static function runs( $n = 10 ) { return $GLOBALS['__runs'] ?? array(); } public static function dispatch( $t, $topic = 0, $e = '', $id = '' ) { self::$dispatched[] = array( $t, $e, $id ); return array( 'inputs' => array( 'engine' => $e ) ); } }
class AAW_Dedupe {
	public static function tokens( $t ) { return array_values( array_filter( preg_split( '/\s+/u', mb_strtolower( (string) $t ) ) ) ); }
	public static function score( array $a, array $b ) { if ( ! $a || ! $b ) { return 0; } return count( array_intersect( $a, $b ) ) / sqrt( count( $a ) * count( $b ) ); }
	public static function nearest( $title, $kw = '', $n = 8, $types = array( 'post' ) ) { return array( array( 'id' => 11, 'title' => 'طرز تهیه کیمچی خانگی', 'score' => 0.8, 'type' => 'post', 'status' => 'publish' ), array( 'id' => 12, 'title' => 'فواید کیمچی', 'score' => 0.3, 'type' => 'post', 'status' => 'publish' ) ); }
}
class AAW_Topics { public static $upd = array(); public static $failed = array(); public static function update( $id, $d ) { self::$upd[] = array( $id, $d ); } public static function bulk_status( $ids, $s ) { foreach ( $ids as $i ) { self::$upd[] = array( $i, array( 'status' => $s ) ); } } public static function mark_failed( $id, $e ) { self::$failed[] = array( $id, $e ); } }
class AAW_REST {
	public static $drafts = array(); public static $fails = array(); public static $topics = array(); public static $job = null;
	public static function job_data( $b ) { return self::$job ? ( self::$job )( $b ) : array( 'status' => 'skip', 'reason' => 'none' ); }
	public static function apply_draft( $b ) { self::$drafts[] = $b; $id = 500 + count( self::$drafts ); mkpost( $id, $b['article']['title'] ?? 't', $b['article']['content_html'] ?? '' ); return array( 'ok' => true, 'post_id' => $id ); }
	public static function apply_fail( $b ) { self::$fails[] = $b; return array( 'ok' => true ); }
	public static function apply_topics( $b ) { self::$topics[] = $b['topics']; return array( 'added' => count( $b['topics'] ) ); }
}
class AAW_Revise { const META_STATE = '_aaw_revise_state'; public static $rev = array(); public static $img = array(); public static $req = array();
	public static function apply_revision( $pid, $a, $rid = '' ) { self::$rev[] = array( $pid, $a, $rid ); return true; }
	public static function apply_image( $pid, $img, $inl = array(), $rep = false ) { self::$img[] = array( $pid, $img, $inl, $rep ); return 1; }
	public static function request_image( $pid, $prompt = '', $inline = false, $engine = '' ) { self::$req[] = array( $pid, $prompt ); return 'x'; }
	public static function resolve() {} }
class AAW_Images { public static function engine() { return $GLOBALS['__img_engine'] ?? 'workers_ai'; } public static function engines() { return array(); } public static function save_theme( $r ) {}
	public static function ref_from_attachment( $id ) { $f = get_attached_file( $id ); return $f ? array( 'b64' => base64_encode( file_get_contents( $f ) ), 'mime' => 'image/jpeg', 'id' => $id ) : null; } }
class AAW_Knowledge { public static $saved = null; public static function save( $k ) { self::$saved = $k; } }
class AAW_SiteData { public static function save( $d ) {} }
class AAW_Priority { public static function image_chain() { return array(); } }
class AAW_Notifier { public static function failure() {} }
class AAW_Transfer { const PIECE_TO = 13; public static function record() {} public static function release() {} public static function down_chunk() { return 32000; } }
