#!/usr/bin/env bash
# Build both release ZIPs of ARIAGH.AIWRITER from plugin/aria-ai-writer.
#   dist/ARIAGH-AIWRITER-<ver>.zip                 → for customers (no owner edition)
#   dist/ARIAGH-AIWRITER-<ver>-OWNER-Unlimited.zip → owner only, never distribute
# Usage: bash tools/build.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/plugin/aria-ai-writer"
VER="$(grep -oE "AAW_VERSION', '[0-9.]+" "$SRC/aria-ai-writer.php" | grep -oE '[0-9.]+$')"
DIST="$ROOT/dist"; TMP="$(mktemp -d)"
mkdir -p "$DIST"
# Version must be identical everywhere.
for f in "$SRC/README.md" "$SRC/worker/worker.js" "$SRC/worker/wrangler.toml" "$SRC/readme.txt"; do
  grep -q "$VER" "$f" || { echo "Version $VER missing in $f"; exit 1; }
done
# Customer edition must NOT contain the owner flag.
if grep -q "'edition'" "$SRC/license-config.php"; then echo "license-config.php contains 'edition' – remove it"; exit 1; fi
find "$SRC" -name '*.php' -print0 | xargs -0 -n1 php -l >/dev/null
node --check "$SRC/assets/js/admin.js" && node --check "$SRC/worker/worker.js" && node --check "$SRC/github-runner/runner.mjs"
( cd "$ROOT/plugin" && rm -f "$DIST/ARIAGH-AIWRITER-$VER.zip" && zip -qr "$DIST/ARIAGH-AIWRITER-$VER.zip" aria-ai-writer )
cp -r "$SRC" "$TMP/aria-ai-writer"
python3 - "$TMP/aria-ai-writer/license-config.php" <<'PY'
import sys
p=sys.argv[1]; s=open(p,encoding='utf-8').read()
s=s.replace(" * ARIAGH.AIWRITER – licensing & store configuration.\n *\n"," * ARIAGH.AIWRITER – licensing & store configuration.\n *\n * OWNER EDITION – unlimited, for the product owner only. Do not distribute.\n *\n",1)
i=s.rindex(");")
s=s[:i]+"\t'edition'        => 'owner',\n"+s[i:]
open(p,'w',encoding='utf-8').write(s)
PY
php -l "$TMP/aria-ai-writer/license-config.php" >/dev/null
( cd "$TMP" && rm -f "$DIST/ARIAGH-AIWRITER-$VER-OWNER-Unlimited.zip" && zip -qr "$DIST/ARIAGH-AIWRITER-$VER-OWNER-Unlimited.zip" aria-ai-writer )
rm -rf "$TMP"
unzip -p "$DIST/ARIAGH-AIWRITER-$VER.zip" aria-ai-writer/license-config.php | grep -q "'edition'" && { echo "LEAK: owner flag in customer zip"; exit 1; }
unzip -p "$DIST/ARIAGH-AIWRITER-$VER-OWNER-Unlimited.zip" aria-ai-writer/license-config.php | grep -q "'edition'        => 'owner'"
echo "OK → $DIST/ARIAGH-AIWRITER-$VER.zip and -OWNER-Unlimited.zip"
