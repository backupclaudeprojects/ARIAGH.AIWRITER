# ARIAGH.AIWRITER — مخزن پشتیبان کامل پروژه

افزونه تجاری وردپرس برای نوشتن خودکار مقاله سئو، تصویر، تحلیل سایت و برنامه محتوا با هوش مصنوعی، به‌همراه سرور فروش لایسنس، تست‌ها و مستندات کامل. آخرین نسخه: **1.9.1**.

> ⚠️ این مخزن را **Private** نگه دارید. سورس کامل محصول تجاری است.
> نسخه مالک (نامحدود) داخل مخزن نیست. فقط با `tools/build.sh` ساخته می‌شود و نباید به کسی داده شود.

## از کجا شروع کنم؟

| می‌خواهید… | بخوانید |
|---|---|
| یک چت جدید Claude پروژه را ادامه دهد | [`CLAUDE.md`](CLAUDE.md)، سپس [`docs/PROJECT_MAP.md`](docs/PROJECT_MAP.md) |
| بفهمید اجزا چطور به هم وصل‌اند (نمودارها) | [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) |
| بدانید هر قابلیت در کدام فایل و تابع است | [`docs/CODE_GUIDE.md`](docs/CODE_GUIDE.md) |
| اشتباهاتی که نباید تکرار شود و باگ‌های رفع‌شده | [`docs/LESSONS.md`](docs/LESSONS.md) |
| تاریخچه نسخه‌ها و درخواست‌های داخل چت‌ها | [`docs/HISTORY.md`](docs/HISTORY.md) |
| ساخت ZIP، تست و انتشار | [`docs/RELEASE.md`](docs/RELEASE.md) |

## ساختار مخزن

```
.
├── CLAUDE.md                     ← دستور کار چت جدید Claude (اول این)
├── README.md                     ← همین فایل
├── docs/
│   ├── PROJECT_MAP.md            ← نقشه فشرده: وضعیت، فایل‌ها، تصمیم‌ها، قدم بعد
│   ├── ARCHITECTURE.md           ← نمودارهای Mermaid (کل سیستم، ۳ مسیر اجرا، موتور سرور، تحلیل، سرچ کنسول)
│   ├── CODE_GUIDE.md             ← قابلیت → فایل/تابع/خط؛ اکشن‌های AJAX؛ تنظیمات؛ مسیرهای ورکر
│   ├── LESSONS.md                ← اشتباه‌های تکرارنشدنی، راه‌های شکست‌خورده، باگ‌های مهم، قوانین کاربر
│   ├── HISTORY.md                ← نسخه‌به‌نسخه: درخواست کاربر → تغییر → نتیجه
│   └── RELEASE.md                ← چک‌لیست نسخه جدید، ساخت، تست، تحویل
├── plugin/aria-ai-writer/        ← سورس افزونه (همان محتوای ZIP فروش 1.9.1)
├── license-server/ariagh-license-server/ ← سورس افزونه سرور لایسنس 1.0.0 (روی سایت فروش)
├── tests/                        ← stub وردپرس + تست موتور سرور + CLIهای جعلی Codex/Claude
└── tools/build.sh                ← ساخت دو ZIP (فروش + مالک) با بررسی‌های ایمنی
```

## بازسازی فایل‌های نصب

```bash
bash tools/build.sh          # → dist/ARIAGH-AIWRITER-1.9.1.zip  و  dist/ARIAGH-AIWRITER-1.9.1-OWNER-Unlimited.zip
php tests/local-test.php     # تست موتور هوش مصنوعی روی سرور (با Codex/Claude جعلی)
```

خروجی `build.sh` بایت‌به‌بایت با ZIP فروش منتشرشده 1.9.1 یکی است (بررسی شده).

## بالا بردن روی GitHub (یک‌بار)

۱. در github.com یک مخزن **Private** خالی بسازید (مثلاً `ariagh-aiwriter`)، بدون README.
۲. ZIP این پشتیبان را باز کنید و در پوشه آن:

```bash
git init
git add .
git commit -m "ARIAGH.AIWRITER 1.9.1 – full backup"
git branch -M main
git remote add origin https://github.com/<USER>/ariagh-aiwriter.git
git push -u origin main
```

یا با GitHub Desktop: File → Add local repository → این پوشه → Publish repository (تیک Keep this code private).
