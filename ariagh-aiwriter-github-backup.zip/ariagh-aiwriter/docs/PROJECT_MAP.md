# PROJECT_MAP — ARIAGH.AIWRITER (افزونه وردپرس نویسنده هوش مصنوعی)

## ۱. هدف پروژه
- افزونه تجاری وردپرس **ARIAGH.AIWRITER** (پوشه/اسلاگ `aria-ai-writer`، پیشوند کلاس `AAW_`) که مقالات سئو، تصویر، تحلیل سایت و برنامه محتوا را با هوش مصنوعی می‌سازد و به‌صورت پیش‌نویس ذخیره می‌کند.
- صاحب: احسان (کارشناس سئو/محتوا)؛ سایت اصلی تست: benlifood.ir (فروشگاه ووکامرس، هاست ایرانی).
- پشته: PHP 7.4+ (وردپرس)، ورکر کلادفلر (ESM + KV + Durable Object)، GitHub Actions runner (Node 22 + CLIهای رسمی Claude Code / Codex)، JS ادمین با jQuery، UI فارسی RTL.
- فروش: سرور لایسنس «ARIAGH License Server 1.0.0» (افزونه ووکامرس جدا).

## ۲. وضعیت فعلی
- آخرین نسخه: **1.9.1** (۱۴۰۵/۸/۱۶). فایل‌ها در همین پوشه: `ARIAGH-AIWRITER-1.9.1.zip` (فروش) و `ARIAGH-AIWRITER-1.9.1-OWNER-Unlimited.zip` (مالک، توزیع نشود). نسخه‌های قدیمی‌تر (1.5.0 تا 1.9.0) = آرشیو.
- **مخزن پشتیبان GitHub (این مخزن):** `plugin/aria-ai-writer/` (سورس 1.9.1)، `license-server/`، `tests/`، `tools/build.sh`، `docs/` (ARCHITECTURE، CODE_GUIDE، SYMBOLS، LESSONS، HISTORY، RELEASE).
- تست‌ها: `tests/` (stub.php + local-test.php + CLIهای جعلی bin/codex, bin/claude). ۵۰+ تست پاس. تست‌های قدیمی‌تر (v18…v186) با پاک شدن محیط ابری از بین رفت.
- کار می‌کند: تولید مقاله با API (کلادفلر) یا اکانت اشتراکی (GitHub)، تصاویر، اصلاح، تحلیل هوشمند، دانش سئو، سرچ کنسول + ادغام مقالات، اجرای مستقیم روی سرور (1.9).
- نیمه‌کاره/تأییدنشده: اجرای مستقیم روی هاست واقعی هنوز با CLI واقعی تأیید نشده؛ آخرین گزارش کاربر خطای حافظه Codex بود ← 1.9.1 برای آن ساخته شد (منتظر نتیجه تست کاربر).

## ۳. نقشه فایل‌ها (مسیرها نسبت به `plugin/aria-ai-writer/`؛ فهرست کامل نمادها: `docs/SYMBOLS.md`)
| مسیر | کار | نمادهای کلیدی (خط) | آخرین تغییر |
|---|---|---|---|
| `aria-ai-writer.php` | **ورودی**، ثابت‌ها، require همه کلاس‌ها | `AAW_VERSION` (20) | 1.9.1 |
| `license-config.php` | سرور لایسنس، کلید عمومی؛ در نسخه مالک `'edition' => 'owner'` | — | 1.9.0 |
| `includes/class-aaw-local.php` (1547) | موتور هوش مصنوعی روی همین سرور | ready 65، start_generate 87، native_codex 147، codex_env 262، save_login 308، login_start 408، install 470، doctor 544، classify 606، start 707، tick 771، advance 825، ask 869، collect 923، task_* 1021–1279، image_task 1108، image_message 1117، site_context 1419، finish 1460، parse_json 1481 | 1.9.1 |
| `includes/class-aaw-proc.php` (326) | اجرای برنامه: proc_open آرایه‌ای، اجرای جدا (setsid -f / nohup)، پوشه خصوصی | base_dir 49، private_dir 76، env 126، run 160، spawn 207، status 256، kill 277، limits 306، limits_text 318 | 1.9.1 |
| `includes/class-aaw-analyzer.php` (482) | تحلیل هوشمند + جلوگیری از «در حال انجام» ابدی | track 19، fail 30، done 37، cancel 42، check_stale 62، save 389 | 1.9.0 |
| `includes/class-aaw-pull.php` (547) | دریافت نتایج از KV، اتصال معکوس | run_cycle 59، dispatch_subscription 164، poll 222، **ingest 320** (مشترک GitHub/لوکال)، tick 511 | 1.9.0 |
| `includes/class-aaw-ajax.php` (1845) | همه اکشن‌های `aaw_*` (nonce `aaw_admin`) | analysis_payload 391، a_analysis_start 418، a_analysis_status 533، a_local_* 588–680 | 1.9.0 |
| `includes/class-aaw-revise.php` | اصلاح مقاله، تصویر | github_task 80 (رهگیری لوکال)، dispatch_rewrite 136، apply_revision 150، request_image 213، apply_image 277، after_draft 319 | 1.9.0 |
| `includes/class-aaw-rest.php` | REST برای runner/ورکر | runtime 54، job_data 111 (رهگیری لوکال)، apply_draft 244 | 1.9.0 |
| `includes/class-aaw-priority.php` | لیست اولویت موتورها | text_ready 29، image_ready 141، text_failover 336 | 1.9.0 |
| `includes/class-aaw-images.php` | مرجع‌های تصویر | ref_from_attachment 196، references_for 282 (اول `image_product_ids`) | 1.9.0 |
| `includes/class-aaw-sitedata.php` | بک‌آپ سایت روی GitHub، دانش سئو | local_engine، available، start_crawl، start_seo | 1.9.0 |
| `includes/class-aaw-gsc.php` | سرچ کنسول | connected 17، save_key 26، save_client 57، auth_url 81، oauth_callback 102، refresh 180 | 1.8.7 |
| `includes/class-aaw-merge.php` | ادغام مقالات تکراری | candidates 24، request 133، apply 159، redirect_and_retire 192، undo 240، maybe_redirect 298 | 1.8.6 |
| `includes/class-aaw-settings.php` | تنظیمات + secure_get/secure_set (رمزنگاری) | کلیدهای `local_*`, `image_product_ids`, `image_chat_prompt`, `gsc_*` | 1.9.0 |
| `includes/class-aaw-errors.php` | توضیح فارسی خطاها (عنوان/علت/راه‌حل) | rules() | 1.8.7 |
| سایر includes | admin، cloudflare (deploy/secrets)، github (dispatch/runs)، transfer (تکه‌ای)، bg، activity، topics، post-builder، prompt، products، dedupe، license، knowledge | — | قدیمی |
| `admin/views/engines.php` | تب «موتور هوش مصنوعی روی سرور» (رندر با JS) | data-engines، data-eng-jobs، data-eng-env، data-eng-settings | 1.9.0 |
| `admin/views/strategy.php` | تحلیل هوشمند؛ data-pending/started/mode/error، دکمه لغو | — | 1.9.0 |
| `admin/views/images.php` | تنظیمات تصویر؛ انتخاب عکس محصولات، پیام قابل ویرایش ChatGPT | pick-product-media | 1.9.0 |
| `admin/views/gsc.php` | سرچ کنسول (OAuth + Service Account) و ادغام | — | 1.8.7 |
| `assets/js/admin.js` (2156) | همه UI | تحلیل 1330 (finished 1420)، GSC 1742، موتورها 1965 | 1.9.0 |
| `assets/css/admin.css` (906) | استایل؛ انتهای فایل: بخش «1.9 – AI engines» | `.aaw-eng-*` | 1.9.0 |
| `worker/worker.js` (1791) | ورکر کلادفلر | مسیرها: codex_auth 91، login_status 100، gsc 165، gsc_oauth 179، gsc_get 201، result_get 210، relay 225؛ `CODE_VERSION` 20 | 1.9.1 (فقط شماره) |
| `github-runner/runner.mjs` (996) | اجراکننده GitHub | askClaude 178، askCodex 200، codexImage 237، deviceLogin 756، main 801 (TRIGGERها 804–909) | 1.9.0 (payload.chat) |
| `github-runner/aria-writer.yml` | workflow؛ `run-name: "ARIAGH trigger engine pull_id"` | — | 1.9.0 |

## ۴. معماری و جریان داده
- **API (پیش‌فرض):** وردپرس → `AAW_BG::start` → ورکر کلادفلر (Durable Object) → mailbox KV → `AAW_Pull::poll` (تکه‌ای با AAW_Transfer) → `ingest()` → پیش‌نویس.
- **اکانت اشتراکی از طریق GitHub:** `queue_put` (KV) + `AAW_GitHub::dispatch(trigger, topic, engine, pull_id)` → runner.mjs (`queue_get` → CLI → `result_put`) → poll/ingest.
- **اکانت اشتراکی مستقیم (1.9):** `local_route_claude|codex = local` → `AAW_Local::start()` → job در `~/.aaw-ai-writer/jobs/<id>.json` + ایندکس option `aaw_local_jobs` → `tick()` (کرون `aaw_local_tick`، صفحه فعالیت، status تحلیل) → `ask()` = `AAW_Proc::spawn` (جدا از PHP؛ in/out/err/code/pid/limits.txt) → `collect()` → `task_*` → `finish()` → `AAW_Pull::ingest()`.
- نقاط رهگیری لوکال: `AAW_Pull::dispatch_subscription`، `AAW_REST::job_data`، `AAW_Revise::github_task`، `a_analysis_start`، `AAW_SiteData::start_seo`، `AAW_Priority::text_failover`.
- پوشه خصوصی: `~/.aaw-ai-writer/` (0700، خارج از public_html): `cli/` (npm prefix)، `codex-home/auth.json` (0600)، `claude-home/`، `runs/`، `jobs/`، `login/`، `install-*`.
- ورود: Codex → `codex login --device-auth` روی سرور یا auth.json یا کپی از KV `codex_auth`؛ Claude → توکن `sk-ant-oat01-` (claude setup-token) در `local_claude_token` (رمزنگاری‌شده).
- همگام‌سازی توکن Codex: قبل از اجرا جدیدترین (last_refresh) از تنظیمات/پوشه/KV؛ بعد از اجرا اگر عوض شد ذخیره + push به KV (اگر GitHub هم همین ورود را دارد).
- تحلیل: options `aaw_analysis_pending` (id)، `aaw_analysis_job` {id, mode: github|async|local|legacy, t, url, checked, done_at}، `aaw_analysis_error`.
- سرچ کنسول: ورکر (JWT یا OAuth refresh در KV `gsc_oauth`) → KV `gsc:report` → `aaw_gsc_report`. ادغام: option‌های `aaw_redirects`, `aaw_merges`, `aaw_merge_pending`.

## ۵. تصمیم‌های کلیدی
- اجرای مستقیم با **CLIهای رسمی** (مثل افزونه SEOlity) نه شبیه‌سازی وب چت ← قانونی، تست‌پذیر. کد SEOlity کپی نشد (GPL، فقط الگو).
- **ورود با ایمیل/رمز پیاده نشد** ← خلاف قوانین OpenAI/Anthropic، کپچا/2FA، خطر مسدودی. جایگزین: device code در پنجره خود کاربر.
- Claude روی سرور ورود تعاملی ندارد ← فقط توکن setup-token.
- «مستقیم» یعنی بدون fallback بی‌صدا به GitHub (درخواست صریح کاربر).
- اجرای جدا (setsid -f) + ماشین حالت با tick ← محدودیت ۶۰ ثانیه PHP و LiteSpeed.
- `--ephemeral` (Codex) و `--no-session-persistence` (Claude) ← در تاریخچه چت اپ‌ها دیده نمی‌شود.
- اجرای باینری بومی Codex به‌جای لانچر npm/Node ← حافظه کمتر روی LVE.
- APIها همچنان از کلادفلر (کلیدها فقط در Secrets کلادفلر) — حالت مستقیم فقط برای اکانت‌های اشتراکی.
- پیام تصویر قابل ویرایش (`image_chat_prompt`) هم در لوکال هم در GitHub (`payload.chat`).

## ۶. راه‌های امتحان‌شده و شکست‌خورده
- npm/GitHub releases از محیط ابری Claude مسدود است ← CLI واقعی برای تست در دسترس نیست؛ با CLI جعلی تست شد.
- تحلیل GitHub فقط با انتظار برای نتیجه ← اگر runner بدون گزارش بمیرد تا ابد «در حال انجام» می‌ماند (رفع با check_stale).
- `wp_unslash` دوباره روی JSON ← خط‌های جدید private_key از بین رفت (Invalid PKCS8، 1.8.7 رفع).
- اجرای Codex از لانچر Node روی هاست با محدودیت حافظه ← «memory allocation of 36 bytes failed» + core dump (1.9.1: باینری بومی + بالا بردن ulimit نرم + MALLOC_ARENA_MAX/TOKIO_WORKER_THREADS؛ اگر سقف سخت/LVE کم باشد فقط هاست می‌تواند حل کند).
- benlifood: هر اتصال بین‌المللی ~۱۵ ثانیه قطع می‌شود، آپلود بسیار کند ← درخواست‌های طولانی مستقیم از هاست کار نمی‌کند (راه‌حل: کارهای پس‌زمینه کلادفلر، دانلود تکه‌ای، relay). حالت مستقیم روی این هاست احتمالاً کار نمی‌کند.

## ۷. قوانین و ترجیحات کاربر
- پاسخ‌ها فارسی، کوتاه؛ UI و پیام‌های خطا فارسی با «عنوان / علت / راه‌حل».
- هر تغییر = نسخه جدید (1.x.y)؛ به‌روزرسانی شماره در: `aria-ai-writer.php` (هدر + AAW_VERSION)، `README.md`، `worker/worker.js` (CODE_VERSION)، `worker/wrangler.toml`، `readme.txt` (Stable tag + Changelog فارسی).
- بسته‌بندی: دو ZIP با پوشه ریشه `aria-ai-writer/`: فروش (license-config بدون edition) و `-OWNER-Unlimited` (با `'edition' => 'owner'`). همیشه با grep بررسی شود که ZIP فروش edition ندارد. هر دو در پوشه دسکتاپ «ariagh claud» ذخیره شوند.
- نسخه مالک هرگز توزیع نشود. برای benlifood: Claude سایت را خودش تغییر نمی‌دهد، فقط بررسی و قدم‌به‌قدم راهنمایی؛ المنتور به کد ترجیح دارد؛ کار مستقیم روی دیتابیس نه.
- بعد از هر نسخه سند پروژه `claude/ariagh-aiwriter-status.md` (Project) هم به‌روز شود.

## ۸. باگ‌های حل‌شده مهم
- تحلیل گیرکرده (1.9.0): check_stale + run-name + لغو + JS `finished()`.
- Invalid PKCS8 (1.8.7). کد ۱۵ ثانیه cURL 52 (1.8.1). تصاویر API ساخته نمی‌شد (1.8.2). صفحه اصلی با پیوند ساده ?p= ریدایرکت می‌شد (1.8.6 رفع). خطای حافظه Codex (1.9.1).

## ۹. مشکلات باز و قدم‌های بعدی
0. (انجام شد) پشتیبان کامل در GitHub.
1. کاربر 1.9.1 را نصب و «تست اتصال» Codex را بزند؛ اگر باز خطای حافظه بود، متن خطا (سقف حافظه نمایش‌داده‌شده) را بفرستد ← اگر سقف کمتر از ~۲GB بود، فقط هاست (VMEM/PMEM/Memory Limit لایت‌اسپید) یا روش GitHub.
2. اگر هاست VPS/خارجی شد: تست کامل مقاله/تصویر/تحلیل در حالت مستقیم با CLI واقعی.
3. خودکارسازی انتشار نسخه از مخزن خصوصی GitHub به سرور لایسنس ← منتظر آدرس سایت فروش و نام مخزن.
4. (اختیاری) اجرای مستقیم برای کلیدهای API (فعلاً فقط از کلادفلر).

## ۱۰. راهنمای کار با این نقشه
- اول این نقشه را بخوان؛ فایل‌های کد را فقط وقتی لازم شد و فقط خطوط لازم (با شماره خط یا grep نماد) بخوان.
- کد: سورس در `plugin/aria-ai-writer/` همین مخزن (یا آخرین ZIP فروش در پوشه «ariagh claud»). ساخت هر دو ZIP فقط با `bash tools/build.sh`. تست: `php tests/local-test.php`.
- برای پیدا کردن کد: `docs/CODE_GUIDE.md` (قابلیت → فایل/تابع) و `docs/SYMBOLS.md` (همه توابع با شماره خط). نمودارها: `docs/ARCHITECTURE.md`. اشتباه‌های تکرارنشدنی: `docs/LESSONS.md`.
- چیزی از بخش «شکست‌خورده» را تکرار نکن.
- بعد از هر تغییر مهم (نسخه، فایل، تصمیم، باگ) همین نقشه را با یک Edit کوچک در همان نوبت به‌روز کن.
- هر وقت چت طولانی شد، project-handoff را دوباره اجرا کن و به چت جدید برو.
- هیچ رمز/توکن/کلیدی در این نقشه ننویس.
