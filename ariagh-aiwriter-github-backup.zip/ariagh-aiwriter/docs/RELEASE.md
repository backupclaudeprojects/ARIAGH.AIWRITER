# چک‌لیست نسخه جدید (ساخت، تست، تحویل)

## ۱. شروع کار در چت جدید
- اگر محیط تازه است: این مخزن را clone کن، یا آخرین `ARIAGH-AIWRITER-x.y.z.zip` (فروش) را از پوشه «ariagh claud» بگیر و در `plugin/` باز کن.
- اگر فقط ZIP مالک در دسترس است: آن را باز کن و از `license-config.php` این دو را حذف کن: خط `'edition'        => 'owner',` و دو خط توضیح «OWNER EDITION». فایل باید با نسخه فروش یکی شود.

## ۲. بعد از تغییر کد
1. `php -l` روی فایل‌های تغییرکرده و `node --check` روی `admin.js`، `worker.js` و `runner.mjs`.
2. تست مرتبط را اجرا کن یا اضافه کن (`tests/`). برای منطق موتور سرور: `php tests/local-test.php`.
3. اگر UI تغییر کرد: اسکرین‌شات با `php tests/shot-engines.php > /tmp/eng.html && node tests/shot.cjs` (یا مشابه آن برای تب دیگر) و نگاه کردن به تصویر.

## ۳. بالا بردن نسخه (هر ۵ جا یکسان)
| فایل | جا |
|---|---|
| `aria-ai-writer.php` | هدر `Version:` و `define( 'AAW_VERSION', … )` |
| `README.md` (افزونه) | خط اول |
| `worker/worker.js` | `const CODE_VERSION` |
| `worker/wrangler.toml` | `AAW_VERSION = "…"` |
| `readme.txt` | `Stable tag:` و بخش جدید `= x.y.z =` در Changelog (فارسی) |

اگر فایل‌های runner (`github-runner/*`) تغییر کرد، با بالا رفتن `AAW_VERSION` خودکار به GitHub کاربر فرستاده می‌شود (`gh_files_version`). اگر ورکر تغییر کرد، به کاربر بگو «استقرار مجدد» را در تب کلادفلر بزند.

## ۴. ساخت
```bash
bash tools/build.sh
```
این اسکریپت یکسان بودن نسخه، نبودن `'edition'` در نسخه فروش، `php -l` و `node --check` را بررسی می‌کند و دو ZIP در `dist/` می‌سازد.

## ۵. تحویل
- هر دو ZIP را برای کاربر بفرست و در `C:\Users\PARDAZESH SHOP\Desktop\ariagh claud\` بنویس.
- پیام فارسی کوتاه: چه چیزی رفع یا اضافه شد، کاربر چه کاری باید بکند (مثلاً استقرار مجدد ورکر یا تست اتصال)، و چه چیزی تست واقعی نشده است.
- `docs/PROJECT_MAP.md` و `docs/HISTORY.md` را به‌روز کن، سند Project `claude/ariagh-aiwriter-status.md` را به‌روز کن، commit و push کن.

## ۶. انتشار برای مشتریان
ZIP فروش را در سایت فروش ← «فروش AIWRITER» ← «نسخه‌ها» آپلود کن. مشتریان ظرف ۱۲ ساعت اعلان به‌روزرسانی می‌بینند. خودکارسازی از GitHub هنوز انجام نشده است.
