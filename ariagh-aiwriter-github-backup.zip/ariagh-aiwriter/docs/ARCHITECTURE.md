# معماری ARIAGH.AIWRITER (با نمودار)

نمودارها با Mermaid کشیده شده‌اند و GitHub خودش آن‌ها را نمایش می‌دهد.

## ۱. نمای کلی اجزا

```mermaid
flowchart LR
  subgraph WP["سایت وردپرس مشتری (افزونه aria-ai-writer)"]
    UI["پیشخوان ادمین<br/>admin/views/*.php + assets/js/admin.js"]
    AJAX["AAW_Ajax<br/>اکشن‌های aaw_*"]
    REST["AAW_REST<br/>/wp-json/aaw/v1/*"]
    CORE["هسته: Topics · Prompt · Post_Builder · Images · Revise · Analyzer · Knowledge · GSC · Merge"]
    PULL["AAW_Pull<br/>poll() / ingest()"]
    LOCAL["AAW_Local + AAW_Proc<br/>موتور روی همین سرور"]
    LIC["AAW_License<br/>(license-config.php)"]
  end
  subgraph CF["کلادفلر (ورکر کاربر)"]
    W["worker.js<br/>مسیرهای امضاشده HMAC"]
    DO["Durable Object AawJobs<br/>کارهای پس‌زمینه"]
    KV[("KV<br/>mailbox · blobs · codex_auth · gsc · site:index")]
  end
  subgraph GH["GitHub (مخزن خصوصی کاربر)"]
    ACT["Actions: aria-writer.yml"]
    RUN["runner.mjs + Claude Code / Codex CLI"]
    DATA[("شاخه aaw-data<br/>بک‌آپ سایت + دانش سئو")]
  end
  subgraph AI["سرویس‌های هوش مصنوعی"]
    API["APIها: OpenAI, Anthropic, Gemini, OpenRouter, Workers AI, Higgsfield, fal…"]
    SUB["اشتراک ChatGPT / Claude"]
    GOOG["Google Search Console"]
  end
  LS["سایت فروش: ariagh-license-server<br/>ووکامرس + Ed25519"]

  UI --> AJAX --> CORE
  CORE --> W
  W --> DO --> API
  DO --> KV
  CORE -- "queue_put + dispatch" --> ACT --> RUN --> SUB
  RUN --> KV
  RUN --> DATA
  PULL -- "result_list / result_get (تکه‌تکه)" --> KV
  LOCAL -- "proc_open → CLI رسمی" --> SUB
  W --> GOOG
  LIC <-- "activate / check / update" --> LS
  W -- "REST امضاشده (حالت push)" --> REST
```

## ۲. سه مسیر اجرای یک کار (مقاله، اصلاح، تصویر، تحلیل)

```mermaid
flowchart TD
  START["کاربر یا کرون: «نوشتن مقاله»"] --> JD["AAW_REST::job_data()<br/>انتخاب موضوع، ساخت پرامپت‌ها<br/>(قوانین + دانش سئو + محصولات + لینک داخلی)"]
  JD --> Q{"موتور اول لیست اولویت؟"}
  Q -- "کلید API" --> BG["AAW_BG::start('generate')<br/>→ ورکر/Durable Object"]
  BG --> MB[("KV mailbox pr:&lt;id&gt;")]
  Q -- "اکانت اشتراکی<br/>route = github" --> GHQ["queue_put (KV) + AAW_GitHub::dispatch<br/>(trigger, topic, engine, pull_id)"]
  GHQ --> RN["runner.mjs روی GitHub<br/>queue_get → CLI → result_put"]
  RN --> MB
  Q -- "اکانت اشتراکی<br/>route = local (1.9)" --> LS["AAW_Local::start_generate()<br/>→ job در ~/.aaw-ai-writer/jobs"]
  LS --> TK["AAW_Local::tick()<br/>(کرون aaw_local_tick + صفحات ادمین)"]
  TK --> SP["AAW_Proc::spawn()<br/>اجرای جدا: codex exec / claude -p"]
  SP --> TK
  TK --> FIN["AAW_Local::finish()"]
  MB --> POLL["AAW_Pull::poll()<br/>دانلود تکه‌ای (AAW_Transfer)"]
  POLL --> ING["AAW_Pull::ingest()"]
  FIN --> ING
  ING --> OUT["پیش‌نویس / اصلاح / تصویر / تحلیل / دانش سئو<br/>(apply_draft · apply_revision · apply_image · Analyzer::save · Knowledge::save)"]
```

**نکته:** هر سه مسیر به یک `ingest()` می‌رسند. منطق اعمال نتیجه فقط یک‌جا نوشته شده است.

## ۳. موتور هوش مصنوعی روی همین سرور (1.9): چرخه یک کار

```mermaid
stateDiagram-v2
  [*] --> queued: AAW_Local::start()
  queued --> running: tick() → step(job, null)
  running --> waiting: ask() → AAW_Proc::spawn (pid, in.txt)
  waiting --> waiting: tick(): status = running
  waiting --> collected: code.txt ظاهر شد → collect()
  waiting --> error: lost (بی‌کد) / timeout / لغو
  collected --> running: task_*() قدم بعد (outline → write → fix → تصویر داخل متن…)
  collected --> done: finish(ok) → ingest
  collected --> error: AUTH / QUOTA / NETWORK / MEMORY → finish(fail)
  done --> [*]
  error --> [*]
```

- فایل‌های هر اجرا در `runs/run-<job>-<rand>/`: `in.txt`، `system.txt` (Claude)، `out.txt`، `err.txt`، `last.txt` (خروجی Codex)، `code.txt`، `pid`، `started`، `limits.txt`.
- اسکریپت پوشاننده در `AAW_Proc::spawn`: `ulimit` نرم را تا حد سخت بالا می‌برد، محدودیت‌ها را ثبت می‌کند، برنامه را با `"$@"` اجرا می‌کند (بدون قرار دادن ورودی کاربر در متن shell) و در پایان `code.txt` را می‌نویسد.
- Codex: باینری بومی (`native_codex`)، `--ephemeral`، `--sandbox read-only`، `CODEX_HOME` خصوصی، `MALLOC_ARENA_MAX=2`، `TOKIO_WORKER_THREADS=2`.
- Claude: `-p --output-format json --no-session-persistence --system-prompt-file`، `CLAUDE_CODE_OAUTH_TOKEN`، `HOME` خصوصی.
- تصویر (فقط Codex): `--sandbox workspace-write -C <dir> -i ref1,ref2,…`؛ پیام از `image_chat_prompt` ساخته می‌شود.

## ۴. تحلیل هوشمند: چرا دیگر گیر نمی‌کند

```mermaid
flowchart TD
  A["a_analysis_start"] --> T["AAW_Analyzer::track(id, mode, url)<br/>option aaw_analysis_job"]
  T --> S{"mode"}
  S -- local --> L["وضعیت job در aaw_local_jobs<br/>error/done بدون نتیجه → fail"]
  S -- async --> C["Cloudflare: بیش از ۲۵ دقیقه → fail"]
  S -- "github / legacy" --> G["هر ۲ دقیقه AAW_GitHub::runs()<br/>تطبیق با run-name «ARIAGH trigger engine id»"]
  G --> G1["completed + failure → poll، سپس fail با لینک اجرا"]
  G --> G2["completed + success → poll؛ ۱۰ دقیقه بی‌نتیجه → fail"]
  G --> G3["پیدا نشد و بیش از ۱۵ دقیقه → fail"]
  G --> G4["legacy و هیچ اجرای فعالی نیست → fail"]
  G --> G5["بیش از ۷۰ دقیقه → fail"]
  X["check_stale() صدا زده می‌شود از:<br/>a_analysis_status · strategy.php · AAW_Pull::tick · a_analysis_start"] -.-> S
```

سمت JS: تابع `finished()` در `admin.js` در هر سه حالت کار را تمام می‌کند و دیگر بی‌پایان منتظر نمی‌ماند. اگر ` !pending` باشد و نتیجه جدیدی نرسیده باشد، کار تمام‌شده حساب می‌شود.

## ۵. سرچ کنسول و ادغام مقالات

```mermaid
sequenceDiagram
  participant U as مدیر سایت
  participant WP as وردپرس (AAW_GSC)
  participant W as ورکر کلادفلر
  participant G as Google
  U->>WP: Client ID / Secret (یا JSON سرویس)
  WP->>W: put_secret AAW_GSC_CLIENT_ID/SECRET
  U->>G: ورود با حساب گوگل (auth_url)
  G-->>WP: admin-post.php?action=aaw_gsc_oauth&code
  WP->>W: gsc_oauth {exchange, code}
  W->>G: token → refresh_token در KV gsc_oauth
  WP->>W: gsc {report}
  W->>G: searchAnalytics (query / page / query+page)
  W-->>WP: gsc_get (تکه‌تکه) → option aaw_gsc_report
  WP->>WP: AAW_Merge::candidates (cannibal + شباهت)
  U->>WP: «ادغام»
  WP->>WP: dispatch_rewrite → apply → 301 + پیش‌نویس + اصلاح لینک‌ها (قابل بازگردانی)
```

## ۶. لایسنس و فروش

```mermaid
flowchart LR
  B["خریدار در سایت فروش<br/>(ووکامرس)"] --> O["سفارش تکمیل"] --> K["ALS_Licenses: صدور کلید<br/>پلن/سایت/ماه از محصول"]
  K --> D["دانلود ZIP برندشده<br/>(license-config.php تزریق‌شده)"]
  D --> C["سایت مشتری: AAW_License"]
  C -- "activate/check (امضا Ed25519، ۱۴ روز آفلاین)" --> API["/wp-json/ariagh/v1/*"]
  C -- "update/check" --> R["ALS_Releases: لینک امضاشده موقت"]
```

## ۷. امنیت و داده‌ها
- کلیدهای API فقط در Secrets کلادفلر ذخیره می‌شوند و در وردپرس فقط ماسک آن‌ها هست (`key_meta`).
- ورودهای اشتراکی سرور (`local_codex_auth` و `local_claude_token`) با `AAW_Settings::secure_set` رمزنگاری می‌شوند. فایل `auth.json` با دسترسی 0600 در پوشه 0700 خارج از public_html ذخیره می‌شود.
- مسیرهای ورکر با HMAC امضا می‌شوند: `X-AAW-Timestamp/Nonce/Signature` روی `ts.nonce.route.body`، ۵ دقیقه اعتبار، ضد تکرار.
- اکشن‌های حساس فقط برای مدیر کل (`manage_options`) مجازند: فهرست `$admin_only` در `AAW_Ajax::dispatch`. بقیه با قابلیت `aaw_manage`؛ مدیر فروشگاه در صورت فعال بودن `allow_shop_managers` دسترسی دارد.
