# راهنمای کد: برای هر بخش به کجا مراجعه کنیم

همه مسیرها نسبت به `plugin/aria-ai-writer/` هستند. فهرست کامل تابع‌ها با شماره خط در [`SYMBOLS.md`](SYMBOLS.md) است. اول از جدول زیر فایل و تابع را پیدا کن، بعد با grep فقط همان قسمت را بخوان.

## ۱. قابلیت → فایل → تابع

| قابلیت / مشکل | اول اینجا | بعد |
|---|---|---|
| بارگذاری افزونه، ثابت‌ها، require کلاس‌ها | `aria-ai-writer.php` | `includes/class-aaw-plugin.php` (هوک‌ها و کرون‌ها: `aaw_pull_tick`، `aaw_local_tick`، `template_redirect`) |
| منو، تب‌ها، چاپ فیلدها، ارسال داده به JS | `includes/class-aaw-admin.php` → `tabs()`، `assets()` (wp_localize `AAW`)، `head/card_open/text/textarea/toggle` | `admin/views/<tab>.php` |
| همه دکمه‌های پیشخوان (AJAX) | `includes/class-aaw-ajax.php` → `register()` (فهرست اکشن‌ها)، `dispatch()` (nonce، دسترسی، `$admin_only`) | متد `a_<action>` |
| رابط کاربری و تعامل‌ها | `assets/js/admin.js`: `ajax()`، `Modal`، `toast`، `withBusy`، `fmtErr` | بخش‌ها: تحلیل (~1330)، سرچ کنسول (~1742)، موتورها (~1965) |
| تنظیمات و رمزنگاری | `includes/class-aaw-settings.php` → `schema()`، `get/update/all`، `secure_get/secure_set`، `key_meta` | `class-aaw-crypto.php` |
| موضوعات و صف | `class-aaw-topics.php` (`claim_next`، `mark_done/failed`) | `admin/views/topics.php` |
| ساخت پرامپت مقاله (قوانین، لحن، لینک داخلی) | `class-aaw-prompt.php` → `build()`، `default_prompt()`، `output_schema()` | `class-aaw-rest.php` → `build_job()`، `job_data()` |
| ساخت پیش‌نویس، FAQ، فهرست مطالب، تصویر شاخص | `class-aaw-post-builder.php` → `create()`، `update_from_article()`، `attach_image()` | `class-aaw-rest.php` → `apply_draft()` |
| لینک محصولات ووکامرس | `class-aaw-products.php` → `related()`، `prompt_block()`، `ensure_links()` | |
| جلوگیری از مقاله تکراری | `class-aaw-dedupe.php` → `nearest()`، `duplicate_of()`، `corpus()` | |
| لیست اولویت موتورها و جایگزینی | `class-aaw-priority.php` → `text_chain/image_chain`، `text_ready/image_ready`، `text_failover`، `image_failover` | `admin/views/text_ai.php`، `image_ai.php` |
| پرووایدرها و مدل‌ها | `class-aaw-providers.php` → `get()`، `model_for()` | `admin/views/ai.php` |
| کلادفلر: استقرار، Secrets، صدا زدن ورکر | `class-aaw-cloudflare.php` → `deploy`، `put_secret`، `call_worker` | `worker/worker.js`، `admin/views/cloudflare.php` |
| کارهای پس‌زمینه روی کلادفلر | `class-aaw-bg.php` → `start()`، `get()`، `new_id()` | worker: `AawJobs`، مسیرهای `bg_start/bg_get` |
| دریافت نتایج از KV (هاست کند) | `class-aaw-pull.php` → `poll()`، **`ingest()`** | `class-aaw-transfer.php` (تکه‌های تطبیقی، ادامه دانلود) |
| GitHub: اتصال، فایل‌ها، dispatch، اجراها | `class-aaw-github.php` → `push_files`، `dispatch()`، `runs()` | `github-runner/aria-writer.yml`، `runner.mjs` |
| اکانت اشتراکی از طریق GitHub | `admin/views/subscription.php`، `class-aaw-pull.php::dispatch_subscription` | `runner.mjs::main` (TRIGGERها) |
| ورود ChatGPT با کد روی GitHub (1.8.5) | `class-aaw-ajax.php::a_codex_login_start/status` | `runner.mjs::deviceLogin`، worker `login_status` |
| **موتور روی همین سرور (1.9)** | `class-aaw-local.php` (همه چیز)، `class-aaw-proc.php` (اجرای برنامه) | `admin/views/engines.php`، JS بخش موتورها |
| روش اجرا (مستقیم یا GitHub) | تنظیمات `local_route_claude|codex`؛ `AAW_Local::is_local()` | رهگیری‌ها: `Pull::dispatch_subscription`، `REST::job_data`، `Revise::github_task`، `a_analysis_start`، `SiteData::start_seo`، `Priority::text_failover` |
| خطای حافظه، شبکه یا ورود در حالت مستقیم | `AAW_Local::classify()`، `message()` | `AAW_Proc::spawn` (اسکریپت ulimit)، `limits_text()`، `AAW_Local::native_codex()`، `codex_env()` |
| تصویر: موتورها و مرجع‌ها | `class-aaw-images.php` → `engines()`، `runtime()`، `references_for()` (اول `image_product_ids`) | worker `generateImage`، `class-aaw-revise.php::request_image/apply_image` |
| پیام ساخت تصویر ChatGPT (قابل ویرایش) | `AAW_Local::image_message()`، `image_task()`؛ تنظیم `image_chat_prompt` | `admin/views/images.php`؛ runner: `payload.chat` |
| اصلاح مقاله / فقط تصویر جدید | `class-aaw-revise.php` → `request_revision`، `dispatch_rewrite`، `apply_revision`، `after_draft`، `image_retry` | |
| تحلیل هوشمند سایت | `class-aaw-analyzer.php` → `inventory`، `build_prompt`، `save`؛ **`track/check_stale/fail/cancel`** | `ajax::a_analysis_start/status/cancel`، `admin/views/strategy.php`، JS `finished()` |
| بک‌آپ سایت روی GitHub و دانش سئو | `class-aaw-sitedata.php`، `class-aaw-knowledge.php` | runner: `crawlSite`، `seoPrompt`؛ `AAW_Local::task_seo_learn` |
| سرچ کنسول | `class-aaw-gsc.php` | worker: `gscToken/gscReport/gscText`، مسیرهای `gsc`، `gsc_oauth`، `gsc_get`؛ `admin/views/gsc.php` |
| ادغام مقالات تکراری و ریدایرکت ۳۰۱ | `class-aaw-merge.php` | `Revise::apply_revision` (شاخه merge)، `Plugin` هوک `template_redirect` |
| خط زمانی و «الان چه خبر است» | `class-aaw-timeline.php` | |
| فعالیت زنده | `class-aaw-activity.php` → `start/step/finish/finish_job/feed` (`feed` موتور سرور را هم tick می‌کند) | `admin/views/activity.php` |
| گزارش‌ها | `class-aaw-logs.php` | |
| توضیح فارسی خطاها | `class-aaw-errors.php` → `rules()`، `explain()`، `format()` | JS `explainAjaxFail` |
| لایسنس سمت مشتری | `class-aaw-license.php`، `license-config.php` | `license-server/…/includes/class-als-api.php` |
| امنیت REST و IP | `class-aaw-security.php` | |
| نصب و حذف | `class-aaw-installer.php`، `uninstall.php` | |

## ۲. مسیرهای ورکر (`worker/worker.js`، POST امضاشده)
`run` · `test` · `models` · `status` · `suggest` · `generate` · `revise` · `image` · `analyze` · `competitors` · `complete` · `seo_learn` · `style_learn` · `post_image` · `bg_start/bg_get` · `queue_put/queue_get` · `result_put/result_list/result_get/result_ack` · `blob_get/blob_del` · `part` · `relay` (فقط api.github.com و api.cloudflare.com) · `codex_auth` · `login_status` · `site_put` · `gsc` · `gsc_oauth` · `gsc_get` · `diag` · `unlock`. GET بدون امضا: `/` و `/health` (`CODE_VERSION`). POST بدون امضا: `/ping`.

## ۳. Triggerهای runner (`github-runner/runner.mjs::main`)
`codex_login` · `test` · `crawl` (بک‌آپ سایت، و در صورت وجود analyze، تحلیل) · `seo_learn` · `image` · `revise` · `analyze` · بقیه: `cron`/`manual` = نوشتن مقاله (خواندن job از KV یا REST).

## ۴. Optionهای مهم وردپرس
| option | محتوا |
|---|---|
| `aaw_settings` | همه تنظیمات (فهرست کلیدها در SYMBOLS.md) |
| `aaw_key_meta` | ماسک کلیدها و ورودها (`sub_codex`، `sub_claude`، `gsc`، `gsc_client`، `img_*`…) |
| `aaw_pull_pending` (`AAW_Pull::PENDING`) | کارهای ارسال‌شده به GitHub که منتظر نتیجه‌اند |
| `aaw_analysis` · `aaw_analysis_pending` · `aaw_analysis_job` · `aaw_analysis_error` | تحلیل هوشمند |
| `aaw_local_jobs` · `aaw_local_state` · `aaw_local_login` · `aaw_local_install_<engine>` · `aaw_private_dir` | موتور روی سرور |
| `aaw_gsc_report` · `aaw_redirects` · `aaw_merges` · `aaw_merge_pending` | سرچ کنسول و ادغام |
| `aaw_site_data` · `aaw_site_crawl` · `aaw_seo_learning` | بک‌آپ سایت و دانش سئو |

## ۵. اکشن‌های AJAX (۱۱۶ اکشن؛ هندلر = `a_<نام>`)
در `AAW_Ajax::register()` فهرست شده‌اند. گروه‌ها: تنظیمات (`save_settings`، `settings_*`)، کلادفلر (`cf_*`)، کلیدها (`key_*`، `image_key_save`)، موضوعات (`topic*`، `suggest_*`)، تولید (`run_ticket`، `generate_ticket`، `run_bg`، `bg_status`، `pull_*`)، بازبینی (`review_*`، `revise`، `post_image`، `revision_publish`)، GitHub (`gh_*`، `codex_login_*`، `site_*`، `seo_learn`، `style_learn`)، تحلیل (`analysis_*`)، موتور سرور (`local_*`)، سرچ کنسول (`gsc_*`)، ادغام (`merge_*`)، لایسنس (`license_*`)، فعالیت (`act_*`، `activity*`)، اولویت (`priority*`، `sub_role`).

## ۶. سرور لایسنس (`license-server/ariagh-license-server/`)
| فایل | کار |
|---|---|
| `ariagh-license-server.php` | ورودی |
| `includes/class-als-api.php` | REST `/wp-json/ariagh/v1/` (activate، check، deactivate، update/check، download، store/plans، info) |
| `includes/class-als-licenses.php` | مدل لایسنس و فعال‌سازی دامنه |
| `includes/class-als-keys.php` | کلید Ed25519 (کلید خصوصی رمزنگاری‌شده) |
| `includes/class-als-woo.php` | محصولات لایسنس‌دار، صدور خودکار بعد از پرداخت، تمدید و ابطال |
| `includes/class-als-releases.php` | آپلود نسخه، ZIP برندشده (تزریق license-config)، دانلود امضاشده |
| `includes/class-als-shortcodes.php`، `templates/landing.php` | صفحه فروش `[ariagh_landing]`، `[ariagh_pricing]` |
| `admin/*.php` | پیشخوان، لایسنس‌ها، نسخه‌ها، تنظیمات |

## ۷. تست‌ها (`tests/`)
- `stub.php`: شبیه‌سازی توابع وردپرس به‌همراه نسخه‌های جعلی کلاس‌های اطراف (REST، Revise، Cloudflare، GitHub و…). کلاس‌های واقعی: Settings، Crypto، Errors، Activity، Proc، Local، Analyzer، Pull.
- `local-test.php`: بیش از ۵۰ تست موتور سرور با پردازش واقعی جدا و CLI جعلی، به‌همراه تست‌های تحلیل گیرکرده.
- `bin/codex` و `bin/claude`: CLI جعلی Node. رفتارشان با کلمه‌های داخل پیام کنترل می‌شود: `FAILAUTH`، `FAILNET`، `FAILQUOTA`، `MEMFAIL`، `CRASH`، `SLOW`، `BADJSON`، `OUTLINE`، `IDEAS`، `ANALYZE`، `REVISE`، `NOIMAGE`. تنظیمات ورود در `/tmp/fake-flags.json` است.
- `render-test.php`، `shot-engines.php` + `shot.cjs`: رندر و اسکرین‌شات تب موتورها با Playwright.
