# فهرست خودکار نمادها (تولید از سورس 1.9.1)

برای هر فایل: تابع/متد → شماره خط. شماره‌ها مربوط به همین نسخه است؛ اگر کد عوض شد، با `grep -n "function NAME"` تأیید کن.

### `includes/class-aaw-activity.php` (161 خط)
**class AAW_Activity**:11 · all:16 · save:21 · start:32 · step:53 · finish:61 · finish_job:73 · running_count:81 · feed:92 · clear_finished:150

### `includes/class-aaw-admin.php` (520 خط)
**class AAW_Admin**:9 · instance:14 · __construct:21 · meta_box:32 · render_meta_box:41 · editor_assets:68 · tabs:76 · menu:105 · assets:116 · current_tab:184 · redirect_after_activation:189 · notices:199 · render:240 · prio_list:319 · prio_items:330 · head:371 · card_open:384 · card_close:392 · row_open:396 · row_close:404 · toggle:408 · number:419 · text:434 · textarea:450 · select:466 · segmented:477 · range:494 · save_bar:508 · categories_choices:512

### `includes/class-aaw-ajax.php` (1846 خط)
**class AAW_Ajax**:9 · register:11 · dispatch:27 · data:56 · a_save_settings:64 · next_run_label:109 · a_settings_export:114 · a_settings_import:121 · a_settings_reset:127 · a_prompt_preview:137 · a_dashboard:160 · a_cf_save:171 · a_cf_accounts:190 · a_cf_deploy:205 · a_cf_delete:221 · a_cf_schedule:226 · a_cf_status:231 · a_cf_sync:249 · a_cf_restore:253 · a_cf_rotate:258 · a_reveal_secret:279 · a_manual_worker:283 · a_diagnose:297 · a_pull_run:372 · a_pull_poll:380 · analysis_payload:391 · a_analysis_ticket:413 · a_analysis_start:418 · a_analysis_save:526 · a_analysis_status:533 · a_analysis_cancel:577 · local_engine:583 · a_local_doctor:588 · a_local_install:593 · a_local_install_status:598 · a_local_login_save:603 · a_local_login_start:608 · a_local_login_status:612 · a_local_login_import:616 · a_local_signout:620 · a_local_test:625 · a_local_jobs:634 · a_local_cancel:649 · a_local_route:654 · a_local_settings:670 · a_analysis_add:687 · a_timeline:692 · a_now:700 · a_worker_unlock:704 · a_key_save:712 · a_key_delete:737 · save_claude_token:748 · a_claude_pro_connect:776 · a_claude_pro_disconnect:817 · a_gh_connect:828 · a_gh_sub_save:868 · activate_sub:922 · a_gh_activate:935 · a_gh_test:948 · a_gh_runs:969 · a_gh_sync:985 · a_gh_disconnect:994 · a_provider_test:1003 · a_provider_models:1028 · a_custom_save:1038 · a_custom_delete:1068 · topic_out:1086 · a_topics_list:1094 · a_topic_add:1109 · a_topics_bulk:1114 · a_topic_update:1119 · a_topics_delete:1125 · a_topics_reorder:1130 · a_topic_move:1135 · a_topics_status:1140 · a_topic_duplicate:1145 · a_topics_export:1150 · a_topics_import:1154 · ticket:1160 · a_proxy:1176 · a_suggest_ticket:1200 · a_suggest_add:1213 · a_run_ticket:1226 · a_generate_ticket:1234 · a_save_generated:1257 · a_review_list:1270 · a_review_action:1309 · a_logs_list:1356 · a_logs_clear:1374 · a_logs_export:1379 · a_test_notify:1383 · a_license_activate:1395 · a_license_check:1403 · a_license_deactivate:1408 · a_explain:1417 · a_run_bg:1429 · a_bg_status:1441 · a_image_key_save:1470 · a_image_test:1497 · a_style_learn:1528 · a_seo_learn:1536 · a_knowledge:1542 · a_gsc_key_save:1548 · a_gsc_client_save:1552 · a_gsc_auth_url:1556 · a_gsc_disconnect:1560 · a_gsc_report:1564 · a_gsc_sites:1569 · a_gsc_site_save:1573 · a_gsc_refresh:1583 · gsc_view:1594 · a_gsc_add_topics:1607 · a_merge_list:1619 · a_merge_start:1632 · a_merge_undo:1642 · a_codex_login_start:1653 · a_codex_login_status:1670 · a_priority:1710 · a_priority_save:1719 · a_sub_role:1753 · a_site_crawl:1765 · a_site_status:1773 · a_act_start:1783 · a_act_end:1789 · a_activity:1794 · a_activity_clear:1812 · a_revise:1819 · a_post_image:1828 · a_revision_publish:1837

### `includes/class-aaw-analyzer.php` (483 خط)
**class AAW_Analyzer**:11 · track:19 · pending_id:25 · fail:30 · done:37 · cancel:42 · check_stale:62 · inventory:161 · inventory_light:242 · stats:253 · inventory_text:266 · build_prompt:305 · sanitize_result:332 · save:389 · get:411 · add_topics:417 · web_capable:475

### `includes/class-aaw-bg.php` (153 خط)
**class AAW_BG**:14 · available:17 · new_id:29 · start:42 · get:73 · wait:87 · kind_label:113 · step_label:136

### `includes/class-aaw-cloudflare.php` (747 خط)
**class AAW_Cloudflare**:9 · token:13 · account:17 · script:21 · is_configured:25 · wp_api:30 · endpoint:36 · is_deployed:41 · request:50 · verify_token:107 · list_accounts:116 · ensure_kv:122 · kv_put:149 · kv_get:158 · worker_source:169 · deploy:187 · upload_script:296 · origin:311 · ensure_workers_dev:316 · delete_worker:334 · put_secret:347 · delete_secret:361 · script_exists:368 · list_secrets:382 · cron_expressions:394 · schedule_expressions:403 · needs_gating:431 · valid_cron:439 · apply_schedule:452 · get_schedule:469 · next_run_ts:476 · next_from_expr:503 · field_match:523 · sync_kv:554 · restore_from_kv:565 · caps:598 · relay:632 · use_relay:649 · call_worker:653 · parse_worker_response:724

### `includes/class-aaw-crypto.php` (73 خط)
**class AAW_Crypto**:10 · key:12 · encrypt:20 · decrypt:37 · mask:60 · random_secret:69

### `includes/class-aaw-dedupe.php` (202 خط)
**class AAW_Dedupe**:17 · stopwords:23 · tokens:39 · score:60 · corpus:74 · flush:109 · nearest:122 · threshold:148 · duplicate_of:153 · queued_duplicate:159 · prompt_block:175 · existing_index:188

### `includes/class-aaw-errors.php` (275 خط)
**class AAW_Errors**:11 · rules:24 · curl_code:90 · is_network:94 · explain:108 · format:121 · network:140 · upload_probe:150 · diagnose:170

### `includes/class-aaw-features.php` (603 خط)
**class AAW_Features**:10 · groups:12 · count:595

### `includes/class-aaw-github.php` (325 خط)
**class AAW_GitHub**:11 · token:16 · owner:20 · repo:24 · is_connected:28 · repo_url:32 · request:36 · user:84 · ensure_repo:89 · blob_sha:120 · tree:125 · put_file:142 · push_files:171 · put_secret:199 · delete_secret:221 · list_secrets:227 · sync_base_secrets:235 · default_branch:253 · dispatch_spec:265 · dispatch:283 · runs:302

### `includes/class-aaw-gsc.php` (232 خط)
**class AAW_GSC**:13 · connected:17 · site:21 · save_key:26 · redirect_uri:53 · save_client:57 · auth_url:81 · oauth_callback:102 · notice:136 · disconnect:145 · sites:155 · refresh:180 · collect:193 · report:209 · page_stats:215 · norm_url:226

### `includes/class-aaw-icons.php` (108 خط)
**class AAW_Icons**:9 · paths:11 · get:91 · e:104

### `includes/class-aaw-images.php` (376 خط)
**class AAW_Images**:11 · engines:21 · engine:90 · model:98 · runtime:132 · cache_dir:181 · ref_from_attachment:196 · refs_by_url:227 · refs_for_remote:233 · related_products:242 · style_attachments:260 · references_for:282 · style_learn_payload:329 · save_theme:349 · insert_inline:359

### `includes/class-aaw-installer.php` (73 خط)
**class AAW_Installer**:9 · activate:11 · deactivate:33 · maybe_upgrade:41 · sync_editor_cap:53

### `includes/class-aaw-knowledge.php` (108 خط)
**class AAW_Knowledge**:16 · get:20 · sources:25 · is_stale:30 · payload:35 · start:48 · save:64 · prompt_block:88 · maybe_refresh:100

### `includes/class-aaw-license.php` (560 خط)
**class AAW_License**:10 · config:21 · flush:62 · is_owner:67 · is_configured:71 · normalize_domain:78 · domain:86 · b64url_encode:90 · b64url_decode:94 · mask_key:103 · sanitize_key_input:111 · data:115 · save:120 · key:124 · verify_token:135 · state:166 · is_active:249 · can_generate:255 · trial:265 · record_article:289 · api:302 · store_token:340 · activate:361 · check:385 · deactivate:418 · plans:431 · register_hooks:461 · cron_check:472 · clear_update_cache:476 · remote_info:481 · inject_update:499 · plugins_api:529 · update_message:554

### `includes/class-aaw-local.php` (1548 خط)
**class AAW_Local**:21 · engine_of:37 · route:49 · is_local:54 · default_engine:59 · ready:65 · start_generate:87 · model:112 · prefix:118 · binary:122 · native_codex:147 · needs_node:167 · nodes:178 · node:214 · bins:229 · version:237 · codex_env:262 · codex_home:279 · claude_home:287 · parse_auth:291 · refreshed:296 · has_login:300 · save_login:308 · store_codex_auth:330 · sign_out:338 · import_github_codex:350 · codex_before:366 · codex_after:393 · login_start:408 · parse_device:428 · login_status:435 · install:470 · install_status:495 · ssh_command:524 · state:530 · set_state:536 · doctor:544 · classify:606 · message:630 · proc_error:652 · job_file:658 · load:662 · store:668 · jobs_summary:685 · active_count:692 · start:707 · label:742 · cancel:751 · schedule:764 · tick:771 · current:804 · advance:825 · ago:859 · ask:869 · collect:923 · find_image:978 · step:998 · fail_ask:1009 · task_test:1021 · task_revise:1038 · task_image:1064 · image_task:1108 · image_message:1117 · default_image_prompt:1140 · ref_files:1145 · cleanup_refs:1176 · task_analyze:1180 · task_seo_learn:1222 · seo_prompt:1268 · task_generate:1279 · next_article:1382 · write_article:1409 · site_context:1419 · finish:1460 · parse_json:1481 · **class AAW_Errors_Redact**:1540 · clean:1541

### `includes/class-aaw-logs.php` (169 خط)
**class AAW_Logs**:9 · table:11 · create_table:16 · add:42 · query:69 · stats:110 · last:129 · count_today:137 · clear:143 · prune:148 · export_csv:155

### `includes/class-aaw-merge.php` (315 خط)
**class AAW_Merge**:11 · candidates:24 · describe:88 · prompts:120 · request:133 · is_merge_request:153 · apply:159 · redirect_and_retire:192 · replace_links:207 · undo:240 · history:263 · history_by_drop:268 · redirects:280 · path:285 · maybe_redirect:298

### `includes/class-aaw-notifier.php` (79 خط)
**class AAW_Notifier**:9 · draft_created:11 · failure:24 · telegram:38 · webhook:58

### `includes/class-aaw-plugin.php` (249 خط)
**class AAW_Plugin**:9 · instance:13 · __construct:20 · daily:63 · on_settings_updated:71 · print_schema:78 · frontend_css:97 · posts_column:111 · posts_column_value:118 · row_actions:131 · approve_action:139 · posts_view:151 · filter_ai_posts:161 · pending_review_count:169 · admin_bar:185 · dashboard_widget:199 · on_status_change:218 · action_links:227 · row_meta:235

### `includes/class-aaw-post-builder.php` (726 خط)
**class AAW_Post_Builder**:9 · create:19 · update_from_article:149 · word_count:206 · slug:211 · process_html:228 · anchor_id:327 · toc_html:341 · faq_html:375 · typography:384 · auto_internal_links:408 · link_pool:464 · assign_terms:514 · detect_seo_plugin:550 · seo_meta:570 · schema_meta:616 · attach_image:653 · image_meta:712

### `includes/class-aaw-priority.php` (435 خط)
**class AAW_Priority**:14 · text_chain:20 · text_ready:29 · text_kind:54 · text_items:68 · save_text:91 · image_chain:132 · image_ready:141 · image_items:170 · save_image:194 · promote:245 · roles:257 · set_role:270 · drop_subs:306 · text_failover:336 · image_failover:377 · sort_items:397 · first_label:418

### `includes/class-aaw-proc.php` (327 خط)
**class AAW_Proc**:16 · blocked:21 · can_exec:32 · user_home:36 · base_dir:49 · private_dir:76 · write_secret:89 · rrmdir:95 · which:114 · env:126 · run:160 · spawn:207 · status:256 · alive:270 · kill:277 · read:290 · vmem_kb:300 · limits:306 · limits_text:318

### `includes/class-aaw-products.php` (116 خط)
**class AAW_Products**:12 · enabled:14 · related:19 · details:54 · prompt_block:77 · ensure_links:90

### `includes/class-aaw-prompt.php` (358 خط)
**class AAW_Prompt**:9 · tones:11 · languages:26 · levels:41 · povs:49 · default_prompt:57 · is_legacy_default:84 · presets:88 · variables:117 · jalali_year:137 · replace_vars:145 · rules:176 · output_schema:275 · build:299 · topic_ideas_prompt:342

### `includes/class-aaw-providers.php` (179 خط)
**class AAW_Providers**:9 · builtin:11 · all:63 · get:73 · secret_name:79 · model_for:86 · runtime:98 · sanitize_custom:121

### `includes/class-aaw-pull.php` (548 خط)
**class AAW_Pull**:18 · site_is_local:22 · active:36 · long_request:47 · run_cycle:59 · dispatch_subscription:164 · poll:222 · ingest:320 · download_note:421 · blob_keys:441 · resolve_blobs:464 · bg_poll:489 · schedule_bg_poll:504 · tick:511 · ensure_schedule:539

### `includes/class-aaw-rest.php` (317 خط)
**class AAW_REST**:9 · register:13 · body:37 · ping:42 · runtime:54 · build_job:84 · job:106 · job_data:111 · add_topics:216 · apply_topics:220 · draft:235 · apply_draft:244 · fail:290 · apply_fail:294 · log:311

### `includes/class-aaw-revise.php` (400 خط)
**class AAW_Revise**:15 · article_from_post:23 · prompts:46 · api_runtime:57 · uses_subscription_text:70 · set_state:75 · github_task:80 · request_revision:108 · dispatch_rewrite:136 · apply_revision:150 · mark_history:180 · publish_pending:194 · request_image:213 · full_image_prompt:260 · apply_image:277 · after_draft:319 · image_retry:339 · cron_image_retry:383 · state:395

### `includes/class-aaw-security.php` (86 خط)
**class AAW_Security**:11 · sign:15 · verify:33 · client_ip:65 · browser_token:77

### `includes/class-aaw-settings.php` (423 خط)
**class AAW_Settings**:9 · schema:19 · defaults:222 · all:232 · get:240 · set_runtime:246 · sanitize_value:251 · update:308 · reset:325 · secure_get:333 · secure_set:338 · shared_secret:352 · custom_providers:363 · save_custom_providers:368 · key_meta:373 · set_key_meta:378 · export:392 · import:402

### `includes/class-aaw-sitedata.php` (154 خط)
**class AAW_SiteData**:16 · local_engine:23 · available:28 · get:33 · engine:39 · branch_url:49 · task:54 · start_crawl:84 · start_seo:94 · save:115 · crawling:135 · status:141

### `includes/class-aaw-timeline.php` (185 خط)
**class AAW_Timeline**:9 · future_times:12 · upcoming_topics:51 · future:59 · past:98 · now:146

### `includes/class-aaw-topics.php` (461 خط)
**class AAW_Topics**:9 · table:13 · create_table:18 · sanitize_row:48 · add:82 · min_position:96 · add_bulk:104 · resolve_category:156 · normalize:171 · all_titles_normalized:178 · get:188 · update:193 · delete:216 · duplicate:226 · reorder:236 · move:245 · update_position:259 · bulk_status:264 · query:278 · counts:315 · release_stale:328 · claim_next:337 · mark_done:359 · mark_failed:372 · export_csv:387 · import_csv:402 · similar_post_exists:447

### `includes/class-aaw-transfer.php` (218 خط)
**class AAW_Transfer**:17 · speeds:30 · record:45 · target:72 · down_chunk:77 · up_chunk:86 · reset_clock:99 · time_left:103 · dir:120 · file:131 · state_key:135 · download:144 · progress:196 · release:201 · cleanup:210

### `worker/worker.js` (1792 خط)
route run:55 · route test:59 · route models:68 · route status:72 · route suggest:75 · route generate:79 · route revise:83 · route image:87 · route codex_auth:91 · route login_status:100 · route queue_put:115 · route queue_get:116 · route result_put:117 · route result_list:118 · route result_ack:119 · route gsc:165 · route gsc_oauth:179 · route gsc_get:201 · route result_get:210 · route blob_del:220 · route relay:225 · route site_put:240 · route complete:248 · route competitors:252 · route analyze:255 · route diag:259 · route bg_start:263 · route part:275 · route blob_get:283 · route bg_get:293 · route unlock:300 · runCycle:340 · gscCreds:424 · gscOAuth:430 · gscGoogleToken:434 · gscToken:446 · gscApi:476 · gscSites:487 · gscReport:492 · gscText:519 · gscCached:530 · siteIndex:545 · siteContext:557 · completeAny:583 · generateArticle:599 · generateIdeas:667 · getKey:693 · callAI:700 · buildUrl:722 · authHeaders:728 · route none:734 · callOpenAI:740 · callAnthropic:784 · callClaudePro:805 · callWorkersAI:837 · listModels:855 · imgLimit:902 · pickRefs:908 · imagePrompt:921 · aspectOf:940 · imgKey:947 · b64ToBytes:955 · urlToImage:962 · renderOne:969 · resolveRefs:1084 · generateImage:1101 · generateImageOne:1116 · reviseArticle:1148 · learnSeo:1163 · learnStyle:1196 · wpCall:1229 · hmacHex:1255 · signHeaders:1261 · readBody:1275 · verifySigned:1303 · stripTags:1329 · fetchText:1333 · slugTitle:1339 · fetchCompetitors:1347 · analyzeSite:1388 · diagnose:1421 · status:1447 · remember:1465 · parseJSON:1479 · escapeControlCharsInStrings:1499 · addUsage:1523 · timedFetch:1529 · httpError:1543 · extractError:1550 · corsHeaders:1561 · streamed:1573 · json:1589 · timingSafeEqual:1593 · randomId:1600 · bytesToBase64:1606 · sleep:1613 · errMsg:1614 · AawJobs:1625 · shrinkImage:1647 · storeMailbox:1664 · bgSet:1691 · runBackground:1695 · route analyze:1704 · route generate:1711 · route suggest:1737 · route run:1743 · route image:1747 · route revise:1751 · route post_image:1758 · route seo_learn:1766 · route style_learn:1772

### `github-runner/runner.mjs` (997 خط)
signHeaders:42 · signedPost:49 · reportDraft:77 · reportFail:83 · reportLog:87 · compressImage:92 · compressMailbox:102 · flushMailbox:112 · run:120 · prepare:141 · persistCodexAuth:166 · askClaude:178 · askCodex:200 · codexImage:237 · refsToFiles:278 · askAny:297 · escapeControl:304 · parseJSON:317 · htmlToText:339 · getRaw:352 · getJSON:363 · restBase:371 · paged:387 · priceText:402 · crawlRest:416 · crawlSitemap:443 · crawlSite:490 · buildIndex:511 · backupFiles:523 · inventoryFromIndex:538 · siteContext:555 · dataRemote:580 · git:586 · loadData:592 · saveSection:608 · fetchSources:638 · seoPrompt:650 · seoFiles:659 · writeArticle:670 · fallbackViaWorker:707 · processJob:717 · parseDeviceCode:747 · loginStatus:753 · deviceLogin:756 · main:801 · trigger codex_login:804 · trigger test:808 · trigger crawl:817 · trigger seo_learn:856 · trigger image:876 · trigger revise:892 · trigger analyze:909

### `assets/js/admin.js` (2157 خط)
§ Utilities:11 · fmtErr:17 · explainAjaxFail:29 · explainPending:43 · ajax:50 · workerFetch:64 · toast:88 · busy:97 · withBusy:113 · confirmBox:141 · download:154 · pickFile:164 · § Countdown:182 · tickCountdowns:184 · § Settings forms:202 · collect:204 · applyShowIf:223 · § Run now:280 · aiStateBadge:284 · aiReviseModal:289 · aiImageModal:302 · trackOp:314 · waitBg:328 · runNow:342 · § Dashboard:404 · renderChart:406 · § Review queue:430 · § AI providers:863 · § Cloudflare:957 · § Tools / notify / features:1180 · renderNow:1235 · futureItemHtml:1256 · pastItemHtml:1262 · groupByDay:1267 · § Smart analysis (strategy tab):1330 · renderReport:1359 · § License:1520 · § Images & SEO knowledge (background jobs on Cloudflare):1548 · waitGh:1625 · § Search Console + merging duplicate articles:1742 · § Live activity tab:1920 · § AI engines on this server (direct, no GitHub / Cloudflare):1965 · card:1986 · render:2022 · renderJobs:2033 · load:2043 · loginDialog:2048 · § Keyboard shortcuts:2142

### `admin/views/` (تب‌ها)
activity.php · ai.php · cloudflare.php · content.php · dashboard.php · engines.php · features.php · gsc.php · image_ai.php · images.php · index.php · knowledge.php · license.php · logs.php · notify.php · partials-codex-login.php · prompt.php · review.php · schedule.php · seo.php · strategy.php · subscription.php · text_ai.php · timeline.php · tools.php · topics.php

## کلیدهای تنظیمات (`AAW_Settings`، option `aaw_settings`)
`enabled`(bool) · `site_name`(text) · `niche`(textarea) · `audience`(text) · `brand_name`(text) · `brand_description`(textarea) · `brand_mention`(bool) · `language`(select) · `tone`(select) · `reading_level`(select) · `pov`(select) · `word_count_min`(int) · `word_count_max`(int) · `h2_count`(int) · `use_h3`(bool) · `paragraph_max_sentences`(int) · `include_intro_hook`(bool) · `include_toc`(bool) · `include_key_takeaways`(bool) · `include_table`(bool) · `include_faq`(bool) · `faq_count`(int) · `include_conclusion`(bool) · `include_cta`(bool) · `cta_text`(textarea) · `include_stats`(bool) · `include_examples`(bool) · `include_lists`(bool) · `include_pros_cons`(bool) · `include_glossary`(bool) · `include_quote`(bool) · `include_howto_steps`(bool) · `include_mistakes`(bool) · `include_checklist`(bool) · `bold_keywords`(bool) · `keyword_density`(float) · `lsi_count`(int) · `forbidden_words`(list) · `avoid_cliches`(bool) · `no_emoji`(bool) · `custom_instructions`(textarea) · `fix_persian_typography`(bool) · `persian_digits`(bool) · `convert_arabic_chars`(bool) · `remove_h1`(bool) · `min_quality_words`(int) · `seo_plugin`(select) · `seo_title_max`(int) · `meta_desc_max`(int) · `slug_mode`(select) · `slug_max_words`(int) · `faq_schema`(bool) · `article_schema`(bool) · `internal_links_count`(int) · `internal_links_pool`(int) · `internal_links_mode`(select) · `external_links_nofollow`(bool) · `external_links_blank`(bool) · `tags_max`(int) · `create_tags`(bool) · `category_mode`(select) · `default_category`(int) · `image_alt_keyword`(bool) · `toc_title`(text) · `toc_min_headings`(int) · `toc_collapsible`(bool) · `toc_numbered`(bool) · `duplicate_check`(bool) · `duplicate_threshold`(int) · `post_type`(text) · `post_status`(select) · `future_days`(int) · `author_id`(int) · `comment_status`(select) · `post_format`(select) · `excerpt_enabled`(bool) · `featured_image`(bool) · `image_provider`(select) · `image_model`(text) · `image_openai_model`(text) · `image_size`(select) · `image_style`(text) · `image_engine`(select) · `image_engine_model`(text) · `image_custom_url`(text) · `image_inline_count`(int) · `image_product_refs`(int) · `image_style_refs`(int) · `image_max_refs`(int) · `image_style_ids`(text) · `image_use_theme`(bool) · `image_brand_colors`(text) · `image_ref_transport`(select) · `product_links`(bool) · `product_links_count`(int) · `product_box`(bool) · `product_box_title`(text) · `site_source`(select) · `gsc_site`(text) · `gsc_client_id`(text) · `local_route_claude`(select) · `local_route_codex`(select) · `local_node_path`(text) · `local_bin_claude`(text) · `local_bin_codex`(text) · `local_timeout`(int) · `image_product_ids`(text) · `image_chat_prompt`(textarea) · `seo_learn`(bool) · `seo_learn_days`(int) · `seo_sources`(textarea) · `provider`(text) · `model`(text) · `fallbacks`(list) · `image_fallbacks`(list) · `image_free_fallback`(bool) · `image_models`(map) · `temperature`(float) · `max_tokens`(int) · `top_p`(float) · `two_pass`(bool) · `json_mode`(bool) · `request_timeout`(int) · `retries`(int) · `system_prompt`(textarea_raw) · `prompt_preset`(text) · `provider_models`(map) · `cron_mode`(select) · `interval_hours`(int) · `run_minute`(int) · `custom_cron`(textarea) · `posts_per_run`(int) · `auto_topics`(bool) · `auto_topics_count`(int) · `retry_failed`(bool) · `max_attempts`(int) · `paused`(bool) · `daily_limit`(int) · `cf_account_id`(text) · `worker_name`(slug) · `kv_namespace_id`(text) · `worker_url`(text) · `worker_custom_url`(text) · `wp_api_override`(text) · `connection_mode`(select) · `runner_name`(slug) · `gh_owner`(text) · `gh_repo`(slug) · `gh_branch`(text) · `gh_connected_at`(int) · `gh_files_version`(text) · `claude_pro_enabled`(bool) · `claude_pro_fallback`(select) · `deployed_at`(int) · `deployed_version`(text) · `worker_bg`(bool) · `net_part_kb`(int) · `net_relay`(select) · `bg_migrated`(text) · `bind_workers_ai`(bool) · `kv_sync`(bool) · `notify_email`(bool) · `notify_email_to`(text) · `notify_on_fail`(bool) · `telegram_enabled`(bool) · `telegram_chat`(text) · `webhook_url`(text) · `dashboard_widget`(bool) · `admin_bar`(bool) · `posts_column`(bool) · `debug`(bool) · `log_retention_days`(int) · `delete_on_uninstall`(bool) · `allow_editors`(bool) · `allow_shop_managers`(bool) · `load_font`(bool) · `frontend_css`(bool) · `toc_accent`(text) · `rest_ip_allow`(list)
